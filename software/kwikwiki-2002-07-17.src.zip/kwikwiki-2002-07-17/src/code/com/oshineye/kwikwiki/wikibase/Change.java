package com.oshineye.kwikwiki.wikibase;

import com.oshineye.kwikwiki.page.RawPage;
import java.util.Date;
import java.text.SimpleDateFormat;
import java.text.ParseException;

/**
	Represents a change to a page.
*/
public class Change implements Comparable {
	private static final SimpleDateFormat FORMATTER = new SimpleDateFormat("yyyy_MM_dd");
	private String title;
	private Date date;
	private String day;
	private String editor;

	public Change(RawPage rawPage) {
		this.title = rawPage.getTitle();
		this.date = rawPage.getDate();
		this.day = Change.formatChangeDate(this.date);
		this.editor = rawPage.getLastEditor();
		if (this.editor == null) {
			this.editor = "";
		}
	}
	
	public Change(String title, Date date, String editor) {
		this.title = title;
		this.date = date;
		this.day = Change.formatChangeDate(this.date);
		this.editor = editor;
	}

	public Date getDate() {
		return this.date;
	}
	
	public String getDay() {
		return this.day;
	}

	public String getTitle() {
		return this.title;
	}

	public String getEditor() {
		return this.editor;
	}

	/**
	 * If date is null return the empty string otherwise return a string
	 * representation of date.
	 */
	public static String formatChangeDate(Date date) {
		if (date == null) {
			return "";
		} else {
			return FORMATTER.format(date);
		}
	}

	public static Date parseChangeDay(String day) throws ParseException {
		return FORMATTER.parse(day);
	}

	public boolean equals(Object obj) {
		if ((obj==null) || (!(obj instanceof Change))) {
			return false;
		}

		Change newObj = (Change) obj;
		return ((this.title.equals(newObj.title)) && (this.date.equals(newObj.date)));
	}

	public int hashCode() {
		String hash = title + date.toString() + day + editor;
		return hash.hashCode();
	}

	public int compareTo(Change change) {
		return this.date.compareTo(change.date);
	}

	public int compareTo(Object obj) {
		return this.compareTo((Change)obj);
	}
}