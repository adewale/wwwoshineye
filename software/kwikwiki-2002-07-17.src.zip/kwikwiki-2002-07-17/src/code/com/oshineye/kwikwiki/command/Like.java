package com.oshineye.kwikwiki.command;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.oshineye.kwikwiki.wikibase.WikiBase;
import com.oshineye.kwikwiki.page.RawPage;
import com.oshineye.kwikwiki.markup.MarkUpEngine;

import java.util.regex.Pattern;
import java.util.regex.Matcher;
import java.util.SortedSet;
import java.util.Iterator;

public class Like extends Command {
	private static final String EMPTY_TABLE_CELL = "<td></td>";
	private static final Pattern FIRST_WORD_PATTERN = Pattern.compile("(^[A-Z][a-z0-9]+)");
	private static final Pattern LAST_WORD_PATTERN = Pattern.compile("([A-Z][a-z0-9]+)$");
	public void execute(HttpServletRequest req, HttpServletResponse resp,
						ServletContext sc) throws Exception {
		System.err.println("==Executing like command==");

        String title = req.getParameter("title");
		WikiBase wikiBase = WikiBase.getInstance();

		if (MarkUpEngine.isWikiName(title)) {
			String firstWord = extractFirstWord(title);
			String lastWord = extractLastWord(title);

			SortedSet firstWordMatches = wikiBase.getTitlesStartingWith(firstWord);
			SortedSet lastWordMatches = wikiBase.getTitlesEndingWith(lastWord);
			firstWordMatches.remove(title);
			lastWordMatches.remove(title);

			StringBuffer text = new StringBuffer();
			Iterator firstWords=firstWordMatches.iterator();
			Iterator lastWords=lastWordMatches.iterator();

			int loopLength = Math.max(firstWordMatches.size(), lastWordMatches.size());
			text.append("<tr><td class=\"header\"> Titles beginning with ");
			text.append(firstWords);
			text.append("</td><td class=\"header\">Titles ending with ");
			text.append(lastWord);
			text.append("</td></tr>");
			for (int i=0; i<loopLength; i++) {
				text.append("<tr>");
				populateTableCell(firstWords, text);
				populateTableCell(lastWords, text);
				text.append("</tr>");
			}

			RawPage page = new RawPage(title, text.toString(), true);
			req.setAttribute("pageBean", page);
			this.include(Command.LIKE, req, resp, sc);
			this.include("/readOnlyFooter.jsp", req, resp, sc);
		} else {
			//go to invalid page title error page
			this.include(Command.INVALID_TITLE, req, resp, sc);
		}
	}

	private void populateTableCell(Iterator it, StringBuffer text) {
		if (it.hasNext()) {
			String title = (String)it.next();
			text.append("<td><a href=\"View?title=" + title + "\">" + title + "</a></td>");
		} else {
			text.append(EMPTY_TABLE_CELL);
		}
	}

	private String extractFirstWord(String title) {
		Matcher firstWordMatcher = FIRST_WORD_PATTERN.matcher(title);
		firstWordMatcher.find();
		return firstWordMatcher.group(1);
	}

	private String extractLastWord(String title) {
		Matcher lastWordMatcher = LAST_WORD_PATTERN.matcher(title);
		lastWordMatcher.find();
		return lastWordMatcher.group(1);
	}
}
