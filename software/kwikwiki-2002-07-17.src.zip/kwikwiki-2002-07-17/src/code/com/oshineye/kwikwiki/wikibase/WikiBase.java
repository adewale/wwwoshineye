package com.oshineye.kwikwiki.wikibase;

import com.oshineye.kwikwiki.page.RawPage;
import com.oshineye.kwikwiki.markup.MarkUpEngine;
import java.util.Arrays;
import java.util.SortedSet;
import java.util.Set;
import java.util.List;
import java.util.ArrayList;

/**
A Singleton class which represents the persistence store for this Wiki.
Because it's abstract the actual singleton is an instance of a conrete class.
*/
public abstract class WikiBase {
	private static WikiBase instance;
	private SortedSet allTitles;
	private static final String ELLIPSIS = "&nbsp;.&nbsp;.&nbsp;.&nbsp;";
	private static final int DEFAULT_AMOUNT_OF_CHANGES = 5;

    //the special pages array must be in sorted order
	private static final String[] SPECIAL_PAGES = {"RecentChanges",
												   "TitleIndex",
												   "TodaysChanges",
												   "WantedPages"};

	protected WikiBase() {
		allTitles = loadTitles();
		
		//add special pages to the set of titles
		for (int i=0; i<SPECIAL_PAGES.length; i++) {
			allTitles.add(SPECIAL_PAGES[i]);
		}
		
	}
		
	public static WikiBase getInstance() {
		if (instance == null) {
			instance = new FileBase();
		}
		return instance;
	}
	
	public RawPage getPage(String title) {
		RawPage rawPage;
		if (this.isSpecialPage(title)) {
			rawPage = this.getSpecialPage(title);
		} else {
			rawPage = this.loadPage(title);
		}
		return rawPage;
	}

	
	public void savePage(RawPage rawPage) {
		String title = rawPage.getTitle();
		if (!this.pageExists(title)) {
			allTitles.add(title);
			storeNewPage(rawPage);
		} else {		
			storePage(rawPage);
		}
		storeChange(new Change(rawPage));
	}

	/**
	Return a SortedSet of the titles of all the pages
	in this Wiki.
	*/
	protected SortedSet getAllTitles() {
		return allTitles;
	}
	
	public boolean pageExists(String title) {
		return allTitles.contains(title);
	}
	
	protected boolean isSpecialPage(String title) {
		//binarySearch returns positive ints if it finds the title and a
		//negative int if it doesn't
		return (Arrays.binarySearch(SPECIAL_PAGES, title) >= 0);
	}
	
	public RawPage getSpecialPage(String title) {
		if (title.equals("TitleIndex")) {
			return getTitleIndexPage();
		} else if (title.equals("TodaysChanges")) {
			return getTodaysChangesPage();
		} else if (title.equals("RecentChanges")) {
			return getRecentChangesPage();
		} else {
			return getWantedPagesPage();
		}
	}
	
	private RawPage getTitleIndexPage() {
		String text = MarkUpEngine.convertToWikiList(allTitles);
		return new RawPage("TitleIndex", text, true);
	}

	private RawPage getTodaysChangesPage() {
		ChangeLog[] log = this.getRecentChanges(1);
		ChangeLog todaysLog = log[0];
		Change[] changes = todaysLog.getChanges();

		String text = convertChanges(changes);
		String header = MarkUpEngine.convertToBold(todaysLog.getDay()) + MarkUpEngine.LINE_ENDING;
		return new RawPage("TodaysChanges", header + text, true);
	}

	private String convertChanges(Change[] changes) {
		List lines = new ArrayList();
		for (int i=0; i<changes.length; i++) {
			Change item = changes[i];
			String line = item.getTitle() + ELLIPSIS + item.getEditor();
			lines.add(line);
		}

		return MarkUpEngine.convertToWikiList(lines);
	}

	private RawPage getRecentChangesPage() {
		ChangeLog[] log = this.getRecentChanges(DEFAULT_AMOUNT_OF_CHANGES);

		StringBuffer sb = new StringBuffer();

		//go through logs in reverse chronological order
		for (int i=log.length-1; i>=0; i--) {
			ChangeLog currentLog = log[i];
			Change[] changes = currentLog.getChanges();
			String header = MarkUpEngine.convertToBold(currentLog.getDay()) + MarkUpEngine.LINE_ENDING;
			sb.append(header);
			sb.append(convertChanges(changes));
		}

		return new RawPage("RecentChanges", sb.toString(), true);
	}


	public RawPage findWord(String word) {
		Set titles = this.locateWord(word);
		String text = MarkUpEngine.convertToWikiList(titles);

		return new RawPage(null, text, true);
	}

	private RawPage getWantedPagesPage() {
		SortedSet wantedPages = this.getWantedPages();
		String text = MarkUpEngine.convertToWikiList(wantedPages);
		return new RawPage("WantedPages", text, true);
	}


	protected abstract RawPage loadPage(String title);

	/**
	* Store an updated version of a pre-existing page.
	*/
	protected abstract void storePage(RawPage rawPage);
	
	protected abstract void storeNewPage(RawPage rawPage);
	
	protected abstract void storeChange(Change change);
	
	protected abstract SortedSet loadTitles();

	/**
	 * Get an array of ChangeLogs for the last numberOfDays. The number of days
	 * must be greater than 0.
	 */
	protected abstract ChangeLog[] getRecentChanges(int numberOfDays);
	
	/**
	* Return a SortedSet of Strings representing the titles of the pages that
	* contain the word
	*/
	protected abstract SortedSet locateWord(String word);

	protected abstract SortedSet getWantedPages();

	public abstract SortedSet getTitlesStartingWith(String word);

	public abstract SortedSet getTitlesEndingWith(String word);
	
	public abstract void deletePage(String title);
}
