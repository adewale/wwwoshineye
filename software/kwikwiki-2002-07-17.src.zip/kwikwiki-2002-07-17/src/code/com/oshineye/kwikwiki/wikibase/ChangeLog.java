package com.oshineye.kwikwiki.wikibase;

import java.util.Arrays;
import java.util.Comparator;
import java.text.SimpleDateFormat;

/**
 * A representation of all the changes that happened on a particular day.
 */
public class ChangeLog {
	private String day;
	private Change[] changes;

	//format is Thursday 30 May 2002
	private static final SimpleDateFormat DAY_FORMATTER = new SimpleDateFormat("EEEE dd MMMM yyyy");
	private static final ChangeComparator CHANGE_COMPARATOR = new ChangeComparator();

	/**
	 * @param changes An array of Change objects for a particular day. This
	 * array must have at least one element or a NullPointException will be
	 * thrown. Days without changes can't have ChangeLogs.
	 *
	 */
	public ChangeLog(Change[] changes) {
		//sort the changes in ascending order, earliest first
		Arrays.sort(changes, CHANGE_COMPARATOR);

		this.changes = changes;
		this.day = DAY_FORMATTER.format(this.changes[0].getDate());
	}

	public String getDay() {
		return this.day;
	}

	public Change[] getChanges() {
		return this.changes;
	}

	static class ChangeComparator implements Comparator {
		public int compare(Object obj1, Object obj2) {
			Change c1 = (Change) obj1;
			Change c2 = (Change) obj2;

			int result = c1.compareTo(c2);

			//flip the results
			if (result < 0) {
				return 1;
			} else if (result == 0) {
				return 0;
			} else {
				return -1;
			}
		}
	}
}