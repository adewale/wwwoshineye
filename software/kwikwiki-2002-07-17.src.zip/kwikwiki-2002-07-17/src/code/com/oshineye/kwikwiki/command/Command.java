package com.oshineye.kwikwiki.command;

import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.HashMap;

/**
 * An abstract factory that is used to instantiate it's various sub-classes.
 * It defines the contract that all commands must fulfill.
 */
public abstract class Command {
	protected static final String INVALID_TITLE = "/invalidTitle.jsp";
	protected static final String ERROR = "/error.jsp";
	protected static final String EDIT = "/editTemplate.jsp";
	protected static final String LIKE = "/likeTemplate.jsp";
	private static HashMap preloadedClasses = new HashMap();


	//preload all the command classes we'll be using
	static {
		try {
			preloadedClasses.put("View", Class.forName("com.oshineye.kwikwiki.command.View"));
			preloadedClasses.put("Edit", Class.forName("com.oshineye.kwikwiki.command.Edit"));
			preloadedClasses.put("Save", Class.forName("com.oshineye.kwikwiki.command.Save"));
			preloadedClasses.put("Create", Class.forName("com.oshineye.kwikwiki.command.Create"));
			preloadedClasses.put("Search", Class.forName("com.oshineye.kwikwiki.command.Search"));
			preloadedClasses.put("Like", Class.forName("com.oshineye.kwikwiki.command.Like"));
		} catch (Exception e) {
			e.printStackTrace(System.err);
		}
		
	}
	
	public static Command getCommand(String typeName) throws 
		InstantiationException, IllegalAccessException {
		Class classType = (Class)preloadedClasses.get(typeName);
		return (Command) classType.newInstance();
	}
	
	protected void include(String resource, HttpServletRequest req,
						   HttpServletResponse resp, ServletContext sc) 
		throws IOException, ServletException {
		RequestDispatcher rd = sc.getRequestDispatcher(resource);
		rd.include(req, resp);
	}
	
	public abstract void execute(HttpServletRequest req, HttpServletResponse resp,
								 ServletContext sc) throws Exception;
}
