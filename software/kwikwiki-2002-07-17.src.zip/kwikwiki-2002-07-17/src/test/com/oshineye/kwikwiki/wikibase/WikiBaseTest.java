/*
 * WikiBaseTest.java
 * JUnit based test
 *
 * 
 */

package com.oshineye.kwikwiki.wikibase;

import junit.framework.*;
import com.oshineye.kwikwiki.markup.MarkUpEngine;
import com.oshineye.kwikwiki.page.RawPage;
import java.util.Date;
import java.util.Iterator;
import java.util.SortedSet;
import java.util.Set;

/**
 *
 * @author aoshineye
 */
public class WikiBaseTest extends TestCase {
	/*
	A private instance variable is being used till I work out how to use the setUp method from JUnit.
	*/
	private WikiBase wikiBase;
	
    public WikiBaseTest(java.lang.String testName) {
        super(testName);
    }
    
    public static void main(java.lang.String[] args) {
        junit.textui.TestRunner.run(suite());
    }
    
    public static Test suite() {
        TestSuite suite = new TestSuite(WikiBaseTest.class);
        
        return suite;
    }
    
	public void setUp() {
		wikiBase = WikiBase.getInstance();
	}
	
	public void testLoadTitles() {
		SortedSet set = wikiBase.loadTitles();
		String msg = " is not a wiki name but is in the title set";
		for(Iterator it = set.iterator(); it.hasNext(); ) {
			String title = (String) it.next();
			assertTrue(title + msg, MarkUpEngine.isWikiName(title));
		}
	}
	
	public void testGetInstance() {
		assertNotNull(WikiBase.getInstance());
		Object obj1 = WikiBase.getInstance();
		Object obj2  = WikiBase.getInstance();
		assertTrue(obj1.equals(obj2));
		assertTrue(obj1 == obj2);
	}

	public void testGetPage() {
		assertNotNull(wikiBase.getPage("StartingPoints"));
		assertNotNull(wikiBase.getPage("TitleIndex"));
		assertNotNull(wikiBase.getPage("RecentChanges"));
		assertTrue(wikiBase.getPage("AdewaleOshineye") instanceof RawPage);
	}

	public void testSavePage() {
		RawPage page = createTestPage();
		wikiBase.savePage(page);
		RawPage page2 = wikiBase.getPage("KwikWikiTestingTestPage");
		
		String text1 = page.getText();
		String text2 = page2.getText();

		assertEquals("Page retrieved was not the same as original page", text1, text2);
		assertTrue("Newly saved page is not in titleset", wikiBase.pageExists(page.getTitle()));
	}

	public void testSaveNewPage() {
		//delete test page
		wikiBase.deletePage("KwikWikiTestingTestPage");
		
		//assert that the page no longer exists
		assertTrue(!wikiBase.pageExists("KwikWikiTestingTestPage"));
		
		//create test page anew
		RawPage page = createTestPage();
		wikiBase.savePage(page);

		//assert that the page exists
		assertTrue(wikiBase.pageExists("KwikWikiTestingTestPage"));
	}

	public void testGetAllTitles() {
		SortedSet loadedTitles = wikiBase.loadTitles();
		SortedSet allTitles = wikiBase.getAllTitles();
		
		//some titles are in the title set but not in the persistent store
		//so there should always be more titles in memory than in the store
		assertTrue(allTitles.containsAll(loadedTitles));
		assertTrue(allTitles.size() > loadedTitles.size());
	}
	
	public void testPageExists() {
		assertTrue("StartingPoints doesn't exist", wikiBase.pageExists("StartingPoints"));
		assertTrue("fake-page actually exists",  !wikiBase.pageExists("fake-page"));
	}
	
	public void testIsSpecialPage() {
		String should = "Not treating a page as special when it should be";
		String shouldNot = "Treating a page as special when it shouldn't be";
		assertTrue(should, wikiBase.isSpecialPage("TitleIndex"));
		assertTrue(should, wikiBase.isSpecialPage("RecentChanges"));
		assertTrue(shouldNot, !wikiBase.isSpecialPage("AdewaleOshineye"));
	}
	
	public void testGetSpecialPage() {
		String titleIndex = "TitleIndex";
		RawPage page1 = wikiBase.getSpecialPage(titleIndex);
		RawPage page2 = wikiBase.getSpecialPage("RecentChanges");
		RawPage page3 = wikiBase.getSpecialPage("OrdinaryPage");
		
		assertTrue(titleIndex.equals(page1.getTitle()));
		assertTrue(!titleIndex.equals(page2.getTitle()));
		assertTrue(!titleIndex.equals(page3.getTitle()));
	}

    public void testChangeLogging() {
        RawPage rawPage = createTestPage();
        wikiBase.savePage(rawPage);

		ChangeLog[] logs = wikiBase.getRecentChanges(1);
		ChangeLog todaysLog = logs[0];
		Change[] changes = todaysLog.getChanges();//get the changes for today

		Change expectedChange = new Change(rawPage);
		Change retrievedChange = changes[0];

		assertEquals("Titles did not match", rawPage.getTitle(), retrievedChange.getTitle());

		String msg = "Expected change:" + expectedChange + " did not match retrived change:"
			+ retrievedChange;
		assertEquals(msg, expectedChange, retrievedChange);
	}

	public void testGetRecentChanges() {
		int ridicilouslyLargeNumber = 10000;
		ChangeLog[] logs = wikiBase.getRecentChanges(ridicilouslyLargeNumber);
		ChangeLog todaysLog = wikiBase.getRecentChanges(1)[0];

		assertTrue(todaysLog != null);
        assertTrue(logs.length < ridicilouslyLargeNumber);
		assertTrue(logs.length > 0);
	}

    public void testFindWord() {
		RawPage rawPage = createTestPage();
		wikiBase.savePage(rawPage);

		Set titles = wikiBase.locateWord("testing");
		assertTrue(titles.size() >= 1);//"testing" exists on KwikWikiTestingTestPage
		assertTrue(titles.contains("KwikWikiTestingTestPage"));//testing page referred to above

		Set titles2 = wikiBase.locateWord("KwikWiki");
		String msg = "KwikWiki search word hasn't been found the requisite number of times";
		//"KwikWiki" exists on at least StartingPoints,KwikWiki and KwikWikiFeatures
		assertTrue(msg, titles2.size() >= 3);
    }

	public void testGetWantedPages() {
		Set wantedPages = wikiBase.getWantedPages();
		assertNotNull( "WantedPages Set is null", wantedPages);
		assertTrue("There are no WantedPages", wantedPages.size() > 0);
		assertTrue(wantedPages.contains("PleaseDoNotCreateThisPageAsItIsUsedForTesting"));
		assertTrue(!wantedPages.contains("KwikWikiTestingPage"));
	}

    public void testGetTitlesStartingWith() {
		Set sharedStart = wikiBase.getTitlesStartingWith("Kwik");
		assertNotNull(sharedStart);
    }

	public void testGetTitlesEndingWith() {
		Set sharedEnd = wikiBase.getTitlesEndingWith("Wiki");
		assertNotNull(sharedEnd);
	}
	
	//bug introduced when searching for the word "http"
	public void testIndexShrinking() {
		String targetWord = "deliberately";
		
		//create a page with a particular word in it --"deliberately"
		RawPage rawPage = createTestPage();
		wikiBase.savePage(rawPage);
		
		//confirm that the word is there
		Set beforeResults = wikiBase.locateWord(targetWord);
		String beforeMsg = "Target word " + targetWord + " was not found after initial save";
		assertTrue(beforeMsg, beforeResults.contains("KwikWikiTestingTestPage"));
		
		//save the page again but without the unusual word
		rawPage = new RawPage("KwikWikiTestingTestPage", "", new Date());
		wikiBase.savePage(rawPage);
		
		//the index should no longer say that the page has the unusual word
		Set afterResults = wikiBase.locateWord(targetWord);//don't rely on reference aliasing

		String indexRemovalMsg = "Target word " + targetWord + " was found after removal";
		assertTrue(indexRemovalMsg, !afterResults.contains("KwikWikiTestingTestPage"));
		
		//confirm that the word is back
		rawPage = createTestPage();
		wikiBase.savePage(rawPage);
		afterResults = wikiBase.locateWord(targetWord);
		String indexReadditionMsg = "Target word " + targetWord 
			+ " was not found after adding it back tothe page";
		assertTrue(indexReadditionMsg, afterResults.contains("KwikWikiTestingTestPage"));
	}

	private RawPage createTestPage() {
		//the newline is essential when creating pages by hand in this way.
		RawPage page = new RawPage("KwikWikiTestingTestPage",
	   "This page exists for testing purposes only at:: " + new Date() + "\n"
	   + ". It contains a deliberately missing page. Known as " 
	   + "PleaseDoNotCreateThisPageAsItIsUsedForTesting.\n",new Date());
		return page;
	}
}
