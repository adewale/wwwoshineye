/*
 * CommandTest.java
 * JUnit based test
 *
 * Created on 12 April 2002, 00:12
 */

package com.oshineye.kwikwiki.command;

import junit.framework.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author aoshineye
 */
public class CommandTest extends TestCase {
    
    public CommandTest(java.lang.String testName) {
        super(testName);
    }
    
    public static void main(java.lang.String[] args) {
        junit.textui.TestRunner.run(suite());
    }
    
    public static Test suite() {
        TestSuite suite = new TestSuite(CommandTest.class);
        
        return suite;
    }
    
    public void testGetCommand() throws Exception {
		assertTrue(Command.getCommand("View") instanceof View);
		assertTrue(Command.getCommand("Edit") instanceof Edit);
		assertTrue(Command.getCommand("Save") instanceof Save);
		assertTrue(Command.getCommand("Create") instanceof Create);
    }
	
	//performance testing code
	//~ public void testGetCommandSpeed() throws Exception {
		//~ /*
		//~ The normal version takes a measurable amount of time on Qwan 
		//~ [Athlon 1200 with 896mb under Win2K] when iterations is at 10.
		//~ The cached version takes a measurable amount of time when iterations 
		//~ is at 1000.
		//~ The preloaded version takes a measurable amount of time when iterations
		//~ is at 10000 .
		//~ [Results were obtained by increasing iterations by an order of 
		//~ magnitude and testing repeatedly.]
		//~ */
		//~ int iterations = 10000000;
		
		//~ long timeBeforeNormal = System.currentTimeMillis();
		//~ for (int i=0; i<iterations; i++) {
			//~ Command.getCommand("View");
			//~ Command.getCommand("Edit");
			//~ Command.getCommand("Save");
			//~ Command.getCommand("Create");
		//~ }
		//~ long resultNormal = System.currentTimeMillis()-timeBeforeNormal;
		
		//~ long timeBeforeCached = System.currentTimeMillis();
		//~ for (int i=0; i<iterations; i++) {
			//~ Command.getCachedCommandOriginal("View");
			//~ Command.getCachedCommandOriginal("Edit");
			//~ Command.getCachedCommandOriginal("Save");
			//~ Command.getCachedCommandOriginal("Create");
		//~ }
		//~ long resultCached = System.currentTimeMillis()-timeBeforeCached;

		//~ long timeBeforePreLoaded = System.currentTimeMillis();
		//~ for (int i=0; i<iterations; i++) {
			//~ Command.getPreLoadedCommand("View");
			//~ Command.getPreLoadedCommand("Edit");
			//~ Command.getPreLoadedCommand("Save");
			//~ Command.getPreLoadedCommand("Create");
		//~ }
		//~ long resultPreLoaded = System.currentTimeMillis()-timeBeforePreLoaded;
		
		//~ System.out.println("Pre Loaded version:: " + resultPreLoaded);
		//~ System.out.println("Cached version:: " + resultCached);
		//~ System.out.println("Normal version:: " + resultNormal);
	//~ }
	
}
