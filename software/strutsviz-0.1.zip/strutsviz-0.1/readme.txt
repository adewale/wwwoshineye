Readme for strutsviz
=====================
strutsviz visualises the paths between the actions, forwards and global-forwards in a struts-config.xml file. It's been tested on struts 1.0 and struts 1.1 files with no problems.

This program assumes you're using extension mapping i.e /action.do
It currently doesn't visualise what happens to your page flow if you're using an exception handlers, filters, redirection, application modules or any of the fancier actions that come with struts.


Dependencies
============
Ruby 1.6.8.			[http://www.ruby-lang.org/en/]
RubyTestUnit 		[http://testunit.talbott.ws/doc/index.html]
Ruby Graph Library 	[http://rgl.sourceforge.net/]
GraphViz 			[http://www.graphviz.org/]
Rexml 				[http://www.germane-software.com/software/rexml/]

Usage
=====
Assuming you have all the dependencies correctly installed.
"ruby strutsviz.rb struts-config.xml outputFileName" will process an xml file in the current directory and output a .png image called outputFileName.png


Questions
=========
Q: It doesn't work?
A: Make sure that all the dependencies are installed and that the bin directory of GraphViz is in your path.

Q: It complains that it "Could not find/open font"?
A: Ignore it. This is a problem with Graphviz itself. However the images still get generated. Be happy.