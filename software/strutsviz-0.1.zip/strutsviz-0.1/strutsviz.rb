require "rexml/document"
include REXML

require 'rgl/adjacency'
require 'rgl/dot'

class StrutsViz
	def initialize(fileName)
		@doc = Document.new(File.new(fileName))
	end

	def getActions
		return @doc.elements.to_a("//*/action")
		
	end
	
	def getGlobalForwards
		return @doc.elements.to_a("/*/global-forwards/*")
	end

	def createImage(graphicName)
		dg = RGL::DirectedAdjacencyGraph.new
		self.getGlobalForwards().each { |fwd|
		  	fwdPath = fwd.attributes["path"]
			dg.add_edge(fwd.attributes["name"] + "::globalFwd", fwdPath)
			if fwdPath[-3..-1] == ".do"
				dg.add_edge(fwdPath, fwdPath[0..-4])
			end
		}
		
		self.getActions().each {|action|
			actionName = action.attributes["path"]
			if action.attributes["input"]
				dg.add_edge(action.attributes["input"], actionName)
				dg.add_edge(actionName, action.attributes["input"])
			end
			
			if action.attributes["forward"]#forwarding action
				dg.add_edge(actionName, action.attributes["forward"])
			end
			
			action.elements.each("forward") { |fwd|#action that contains forward tags
				fwdFullName = action.attributes["path"] + "::" + fwd.attributes["name"] + "::fwd"
				dg.add_edge(actionName, fwdFullName)
				dg.add_edge(fwdFullName, fwd.attributes["path"])
			}
		}
		
		dg.write_to_graphic_file("png", graphicName)
	end
end

if $0 == __FILE__
	if ARGV.length == 2
		viz = StrutsViz.new(ARGV[0])
		viz.createImage(ARGV[1])
	else
		puts "Usage: ruby strutsviz.rb struts-config.xml outputFileName. outputFileName.png will be created."
	end
	

end
