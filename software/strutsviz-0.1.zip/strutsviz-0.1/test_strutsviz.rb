require 'test/unit'
require "strutsviz"


class StrutsVizTest < Test::Unit::TestCase
	def setup
		@viz = StrutsViz.new("example/struts-config.xml")
	end

	def testExtractActions()
		assert(@viz.getActions().length == 4, "Failed to extract all 4 <action> tags")
	end
	
	def testExtractGlobalForwards
		assert(@viz.getGlobalForwards().length == 4, "Failed to extract the 4 <forward> tags")
	end
	
	def testExtractActionLocalForwards
		forwardTotal = 0
		@viz.getActions().each {|action|
			forwardTotal += action.elements().to_a("*").length
		}
		
		assert_equal(2, forwardTotal)
	end
	
	def testExtractionActionForwardAttributes
		forwardAttributeTotal = 0
		@viz.getActions.each {|action|
			if action.attributes["forward"]
				forwardAttributeTotal += 1
			end
		}
		assert_equal(3, forwardAttributeTotal)
	end

	def testCreateImageFromXml
		graphicName = "strutsGraphic"
		
		if FileTest.exists?(graphicName + ".png")
			File.delete(graphicName + ".png")
		end
		
		@viz.createImage(graphicName)
		
		assert(FileTest.exists?(graphicName + ".png"))
	end
end
