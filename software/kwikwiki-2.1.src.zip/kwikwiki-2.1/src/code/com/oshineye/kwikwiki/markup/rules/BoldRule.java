package com.oshineye.kwikwiki.markup.rules;

public class BoldRule extends MarkUpRule {
    private static final String PATTERN = "'{3}(.*?)'{3}";
    private static final String REPLACEMENT_TEXT = "<b>$1</b>";

    public BoldRule() {
        super(BoldRule.PATTERN, BoldRule.REPLACEMENT_TEXT);
    }
}
