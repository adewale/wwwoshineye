package com.oshineye.kwikwiki.wikibase;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Represents information about a change to a page. Instances of this class are immutable.
 */
public class Change implements Comparable {
	private static final SimpleDateFormat FORMATTER = new SimpleDateFormat("yyyy_MM_dd");
	private static final int MILLISECONDS = 1000;
	
	private final String title;
	private final Date date;
	private final String day;
	private final String editor;
	private final int hashCode;
	
	public Change(WikiPage rawPage) {
		this.title = rawPage.getTitle();
		this.date = rawPage.getDate();

		this.day = Change.formatChangeDate(this.date);

		String temp = rawPage.getLastEditor();
		this.editor = validate(temp);
		this.hashCode = generateHashCode();
	}

	public Change(String title, Date date, String editor) {
		this.title = title;
		this.date = date;

		this.day = Change.formatChangeDate(this.date);
		this.editor = validate(editor);
		this.hashCode = generateHashCode();
	}

	private String validate(String target) {
		if (target == null) {
			return "";
		} else {
			return target;
		}
	}

	private int generateHashCode() {
		String hash = title + date.toString() + day + editor;

		return hash.hashCode();
	}

	public Date getDate() {
		return this.date;
	}
	
	protected long getTime() {
		return this.date.getTime();
	}

	public String getDay() {
		return this.day;
	}

	public String getTitle() {
		return this.title;
	}

	public String getEditor() {
		return this.editor;
	}

	/**
	* If date is null return the empty string otherwise return a string
	* representation of date.
	*/
	public static String formatChangeDate(Date date) {
		if (date == null) {
			return "";
		} else {
			return FORMATTER.format(date);
		}
	}

	public static Date parseChangeDay(String day) throws ParseException {
		return FORMATTER.parse(day);
	}

	public boolean equals(Object otherObject) {
		if ((otherObject == null) || (!(otherObject instanceof Change))) {
			return false;
		}

		Change otherChange = (Change) otherObject;

		return (
			(this.title.equals(otherChange.title))
				&& (compareWithMillisecondPrecision(this.date, otherChange.date)));
	}

	private boolean compareWithMillisecondPrecision(Date thisDate, Date otherDate) {
		return (thisDate.getTime() / MILLISECONDS) == (otherDate.getTime() / MILLISECONDS);
	}

	/**
	* Since instances of Change are immutable then the hash code can be
	* calclulated in advance.
	*/
	public int hashCode() {
		return this.hashCode;
	}

	public int compareTo(Change change) {
		return this.date.compareTo(change.date);
	}

	public int compareTo(Object obj) {
		return this.compareTo((Change) obj);
	}

	public static List parseChanges(List changeLines) {
		List changes = new ArrayList();
		for (Iterator it = changeLines.iterator(); it.hasNext();) {
			String line = (String) it.next();
			if (!line.trim().equals("")) {
				changes.add(Change.createChangeFromString(line));
			}
		}
		return changes;
	}

	
	public static Change createChangeFromString(String line) {
		Pattern pattern = Pattern.compile("(title:(.*),date:(.*),editor:(.*),)", Pattern.MULTILINE);
		Matcher matcher = pattern.matcher(line);
		
		Change change = null;
		if (matcher.find()) {
			String tempTitle = matcher.group(2);
			String tempDate = matcher.group(3);
			String tempEditor = matcher.group(4);
			long tempTime = Long.parseLong(tempDate);
			change = new Change(tempTitle, new Date(tempTime), tempEditor);
		}
		return change;
	}

	public String convertToString() {
		//This isn't called toString because it's designed to output a string that can be passed
		//to the createChangeFromString factory method. As such if it's altered without
		//altering createChangeFromString (for instance whilst debugging) then there will be
		//side-effects. 
		return "title:" + this.getTitle() + ",date:" + this.getTime() + ",editor:" 
			+ this.getEditor() + ",";
	}
}
