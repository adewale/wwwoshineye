package com.oshineye.kwikwiki.specialpages;

import com.oshineye.kwikwiki.markup.MarkUpEngine;
import com.oshineye.kwikwiki.wikibase.WikiBase;

import java.util.Random;
import java.util.SortedSet;
import java.util.TreeSet;


public class RandomPagesPage implements SpecialPage {
    private final int numberOfRandomPages;

    public RandomPagesPage(int numberOfRandomPages) {
        super();
        this.numberOfRandomPages = numberOfRandomPages;
    }

    public String getText() {
        SortedSet randomTitles = new TreeSet();
        Random random = new Random();
        Object[] titles = WikiBase.getInstance().getAllTitles().toArray();

        for (int i = 0; i < numberOfRandomPages; i++) {
            int randomIndex = random.nextInt(titles.length);
            randomTitles.add(titles[randomIndex]);
        }

        return MarkUpEngine.convertToWikiList(randomTitles);
    }
}
