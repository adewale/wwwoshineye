package com.oshineye.kwikwiki.servlet;

import java.io.IOException;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.jsp.PageContext;

import com.opensymphony.module.oscache.base.Cache;
import com.opensymphony.module.oscache.web.ServletCacheAdministrator;

/**
 * @author aoshineye
 * A Filter which flushes all cache entries related to a particular page after it's been edited.
 */
public class EditPageFilter extends AbstractFilter {
	public void doFilter(ServletRequest req, ServletResponse resp, FilterChain filterChain)
		throws IOException, ServletException {
		System.err.println("EditPageFilter");
		ServletCacheAdministrator admin = getServletCacheAdministrator();
		
		//flush a particular entry
		String key = req.getParameter("title");
		Cache cache = admin.getCache((HttpServletRequest) req, PageContext.APPLICATION_SCOPE);
		cache.flushEntry(key);

		//flush all the shared and search related cache entries
		cache.flushPattern(AbstractFilter.SHARED_PATTERN);
		cache.flushPattern(AbstractFilter.SEARCH_PATTERN);
		
		filterChain.doFilter(req, resp);
	}
}
