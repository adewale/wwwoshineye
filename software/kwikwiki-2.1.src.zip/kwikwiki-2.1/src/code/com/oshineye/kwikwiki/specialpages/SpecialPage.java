package com.oshineye.kwikwiki.specialpages;

public interface SpecialPage {
    public String getText();
}
