package com.oshineye.kwikwiki.markup.rules;

public class BlankLineRule extends MarkUpRule {
    private static final String PATTERN = "^\\s*$";
    private static final String REPLACEMENT_TEXT = "<br><br>\n";

    public BlankLineRule() {
        super(BlankLineRule.PATTERN, BlankLineRule.REPLACEMENT_TEXT);
    }
}
