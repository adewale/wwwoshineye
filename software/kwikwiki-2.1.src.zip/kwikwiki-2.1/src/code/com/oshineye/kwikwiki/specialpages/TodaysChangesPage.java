package com.oshineye.kwikwiki.specialpages;

import java.util.List;

import com.oshineye.kwikwiki.config.Config;
import com.oshineye.kwikwiki.markup.MarkUpEngine;
import com.oshineye.kwikwiki.wikibase.ChangeLog;
import com.oshineye.kwikwiki.wikibase.WikiBase;

public class TodaysChangesPage extends RecentChangesPage {
	private static final int NUMBER_OF_CHANGES = 1;

	public TodaysChangesPage() {
		super(TodaysChangesPage.NUMBER_OF_CHANGES);
	}
	
	public String getText() {
		List logs = WikiBase.getInstance().getChangeLogs(TodaysChangesPage.NUMBER_OF_CHANGES);
		
		ChangeLog lastLog = (ChangeLog) logs.get(0);
		
		if (lastLog.isToday()) {
			return convertToText(logs);
		} else {
			return MarkUpEngine.convertToBold(lastLog.getDay()) + Config.LINE_ENDING;
		}
	}

}
