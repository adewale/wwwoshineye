package com.oshineye.kwikwiki.markup.rules;

public class InlineLinkRule extends MarkUpRule {
    private static final String PATTERN = "([a-zA-Z]{3,}://([\\S]+))";
    private static final String REPLACEMENT_TEXT = "<a href=\"$1\">$1</a>";

    public InlineLinkRule() {
        super(InlineLinkRule.PATTERN, InlineLinkRule.REPLACEMENT_TEXT);
    }
}
