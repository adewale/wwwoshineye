package com.oshineye.kwikwiki.wikibase;

import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;

/**
 * A class that provides indexing and searching services to implementations
 * of WikiBase.
 */
public class Index {
	private SortedSet allTitles;
	private static final SortedSet EMPTY_SET = Collections.unmodifiableSortedSet(new TreeSet());

	/*
		A mapping from a word to the titles of the set of page it appears on.
		For every word in the WikiBase this enables us to see which pages use it.
	*/
	private final Map caseSensitiveReverseFileIndex;
	private final Map caseInsensitiveReverseFileIndex;

	public Index(SortedSet allTitles) {
		this.caseSensitiveReverseFileIndex = new HashMap();
		this.caseInsensitiveReverseFileIndex = new HashMap();
		this.allTitles = allTitles;
	}

	public void add(String pageTitle, String text) {
		Set words = tokenize(text);
		this.addPageToIndexes(pageTitle, words);
		this.allTitles.add(pageTitle);
	}

	public SortedSet getLocations(String word) {
		return search(word, this.caseSensitiveReverseFileIndex);
	}

	private SortedSet search(String word, Map fileIndex) {
		if (fileIndex.containsKey(word)) {
			return (SortedSet) fileIndex.get(word);
		} else {
			return EMPTY_SET;
		}
	}

	public SortedSet getLocationsCaseInsensitive(String word) {
		return search(word.toLowerCase(), this.caseInsensitiveReverseFileIndex);
	}

	private Set tokenize(String text) {
		String[] words = text.split("\\W");

		Set set = new HashSet();

		for (int i = 0; i < words.length; i++) {
			set.add(words[i]);
		}

		return set;
	}

	public void update(String title, String oldText, String newText) {
		Set oldWords = this.tokenize(oldText);
		Set newWords = this.tokenize(newText);

		//identify set of words that are in old text but not in new text
		Set oldWordsToRemove = new HashSet(oldWords);
		oldWordsToRemove.removeAll(newWords);

		//remove this page from the indexes for those words
		this.removeTitle(oldWordsToRemove, title);

		//identify words that are in new text but not in old text
		newWords.removeAll(oldWords);

		//add this page to their indexes
		this.addPageToIndexes(title, newWords);
	}

	private void removeTitle(Set words, String pageTitle) {
		removeTitle(words, pageTitle, this.caseSensitiveReverseFileIndex);
		removeTitle(this.lowerCase(words), pageTitle, this.caseInsensitiveReverseFileIndex);
	}

	private void removeTitle(Set words, String pageTitle, Map fileIndex) {
		for (Iterator it = words.iterator(); it.hasNext();) {
			String word = (String) it.next();
			Set pageTitles = (Set) fileIndex.get(word);
			pageTitles.remove(pageTitle);

			if (pageTitles.size() == 0) {
				fileIndex.remove(word);
			}
		}
	}

	private void addPageToIndexes(String pageTitle, Set words) {
		addPageToIndex(pageTitle, words, this.caseSensitiveReverseFileIndex);
		addPageToIndex(pageTitle, this.lowerCase(words), this.caseInsensitiveReverseFileIndex);
	}

	private Set lowerCase(Set words) {
		Set lowerCaseWords = new HashSet();

		for (Iterator it = words.iterator(); it.hasNext();) {
			String word = (String) it.next();
			lowerCaseWords.add(word.toLowerCase());
		}

		return lowerCaseWords;
	}

	private void addPageToIndex(String pageTitle, Set words, Map fileIndex) {
		for (Iterator it = words.iterator(); it.hasNext();) {
			Object word = it.next();

			if (fileIndex.containsKey(word)) {
				Set pageTitles = (Set) fileIndex.get(word);
				pageTitles.add(pageTitle);
			} else {
				Set titles = new TreeSet();
				titles.add(pageTitle);
				fileIndex.put(word, titles);
			}
		}
	}

	public Set getAllWordsInWiki() {
		return caseSensitiveReverseFileIndex.keySet();
	}

	/**
	* Delete the contents of page named <code>title</code> from the index
	* @param title the name of the page which will be removed from the index
	*/
	public void delete(String pageTitle, String text) {
		Set oldWords = tokenize(text);
		this.removeTitle(oldWords, pageTitle);
		this.allTitles.remove(pageTitle);
	}

	public SortedSet getAllTitles() {
		return this.allTitles;
	}

	public void registerSpecialPages(Set specialPages) {
		this.allTitles.addAll(specialPages);
	}
}
