package com.oshineye.kwikwiki.specialpages;

import com.oshineye.kwikwiki.markup.MarkUpEngine;
import com.oshineye.kwikwiki.wikibase.WikiBase;


public class TitleIndexPage implements SpecialPage {
    public String getText() {
        String text = MarkUpEngine.convertToWikiList(WikiBase.getInstance().getAllTitles());
        return text;
    }
}
