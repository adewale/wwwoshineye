package com.oshineye.kwikwiki.markup.rules;

import junit.framework.TestCase;

public class CodeRuleTest extends TestCase {
    public void testCodeRule() {
        String text = "\n{{{\n" + "    public static void main(java.lang.String[] args) {\n" +
            "        junit.textui.TestRunner.run(suite());\n" + "    }\n" + "}}}\n";
        String result = new CodeRule().apply(text).toString();
        assertTrue(result.indexOf("pre class=\"code\">") != -1);
        assertTrue(result.indexOf("</pre>") != -1);
    }

    public void testCodeRuleWithoutPrecedingLine() {
        String text = "{{{\n" + "    public static void main(java.lang.String[] args) {\n" +
            "        junit.textui.TestRunner.run(suite());\n" + "    }\n" + "}}}\n";
        String result = new CodeRule().apply(text).toString();
        assertTrue(result.indexOf("pre class=\"code\">") != -1);
        assertTrue(result.indexOf("</pre>") != -1);
    }

    public void testCodeRuleWithoutSucceedingLine() {
        String text = "\n{{{\n" + "    public static void main(java.lang.String[] args) {\n" +
            "        junit.textui.TestRunner.run(suite());\n" + "    }\n" + "}}}";
        String result = new CodeRule().apply(text).toString();
        assertTrue(result.indexOf("pre class=\"code\">") != -1);
        assertTrue(result.indexOf("</pre>") != -1);
    }
    
    public void testMultipleCodeBlocksInPage() {
    	String text = "{{{\nTEXT\n}}}\n{{{\nMORE_TEXT\n}}}";
		String expectedText = "<pre class=\"code\">\nTEXT\n</pre>\n" 
			+ "<pre class=\"code\">\nMORE_TEXT\n</pre>";
		String resultText = new CodeRule().apply(text).toString();
    	assertEquals(expectedText, resultText);
    }
}
