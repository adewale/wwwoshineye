package com.oshineye.kwikwiki.wikibase;

import junit.framework.TestCase;

/**
 * @author aoshineye
 */
public class RevisionTest extends TestCase {

	public void testConvertRevisionToString() {
		String line = "title:KwikWikiTestingTestPage,date:1049552251814,editor:testUser,id:1,";
		Revision revision = Revision.createRevisionFromString(line);
		Revision revision2 = Revision.createRevisionFromString(revision.convertToString());
		
		assertNotNull(revision2);
	}

	public void testCreateRevisionFromString() {
		String line = "title:KwikWikiTestingTestPage,date:1049552251814,editor:testUser,id:1,";
		Revision revision = Revision.createRevisionFromString(line);
		
		assertNotNull(revision);
	}

}
