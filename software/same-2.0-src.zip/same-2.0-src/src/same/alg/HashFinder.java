package same.alg;

public class HashFinder {
	private final int fragmentSize;
	private final FragmentHashRegistry registry;

	private String currentFileName;
	private int currentLineNumber;
	private LongQueue lineNumbersQueue;

	private long currentFragmentHash;
	private LongQueue lineHashesQueue;

	public HashFinder(int fragmentSize, FragmentHashRegistry registry) {
		this.fragmentSize = fragmentSize;
		this.registry = registry;
	}

	public void startFile(String fileName) {
		currentFileName = fileName;
		currentLineNumber = 0;
		lineNumbersQueue = new LongQueue(fragmentSize);
		currentFragmentHash = 0;
		lineHashesQueue = new LongQueue(fragmentSize); //initially all nulls
	}

	public void addLine(CharSequence line) {
		currentLineNumber++;
		if (line.length() == 0) {
			return;
		}
		lineNumbersQueue.append(currentLineNumber);

		long oldestLineHash = lineHashesQueue.getFirst();
		currentFragmentHash = currentFragmentHash ^ oldestLineHash;

		long newLineHash = this.computeStringHash(line);
		currentFragmentHash = currentFragmentHash ^ newLineHash;
		lineHashesQueue.append(newLineHash);

		if (!lineNumbersQueue.isFull()) {
			//current fragment is not of maximum size; ignoring
			return;
		}

		long fragmentFirstLineNumber = lineNumbersQueue.getFirst();
		registry.registerFragment(currentFragmentHash, currentFileName,
			(int)fragmentFirstLineNumber);
	}
	
	//package access so test can see it
	long computeStringHash(CharSequence line) {
		//this improves on String.hashCode only in the sense that using longs reduces the chances
		//of hash collisions as there are 32 extra bits
		long result = 0;
		int s = line.length();
		for (int i = 0; i < s; i++) {
			int c = line.charAt(i);
			result = ((result << 23) | (result >>> 41));
			result = result ^ c;
		}
		return result;
	}
}
