package same.alg;

import java.util.List;

import same.fs.FilePosition;

public class Match {
	private final FilePosition position1;
	private final FilePosition position2;
	private final List lines;
	
	public Match(FileFragment fragment1, FileFragment fragment2) {
		this.position1 = fragment1.getStartingPoint();
		this.position2 = fragment2.getStartingPoint();
		this.lines = fragment1.getLines();
	}
	
	public List getLines() {
		return this.lines;
	}
	
	public FilePosition getPosition1() {
		return this.position1;
	}

	public FilePosition getPosition2() {
		return this.position2;
	}
}
