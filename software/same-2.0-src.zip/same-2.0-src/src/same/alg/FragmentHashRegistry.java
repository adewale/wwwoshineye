package same.alg;

import gnu.trove.TLongObjectHashMap;

import java.util.ArrayList;
import java.util.List;

import same.fs.FilePosition;

public class FragmentHashRegistry {
	private TLongObjectHashMap linesByHash;//<long, List<FilePosition>>
	private List potentialMatches; //<List<FilePosition>> 

	public FragmentHashRegistry() {
		linesByHash = new TLongObjectHashMap();
		potentialMatches = new ArrayList();
	}

	public void registerFragment(long hash, String fileName, int lineNumber) {
		/*
		 * This is strange. potentialMatches really only makes sense as a
		* hashmap. Instead we have a list of lists and a list of filePositions
		* in both the hashmap (linesByHashes) for fast lookup and
		* potentialMatches.
		* 
		* The idea seems to be that only hash collisions (when we see the same
		* hash value twice) cause a FilePosition to be added to
		* potentialMatches. This results in potentialMatches being signifcantly
		* smaller than linesByHash.
		* 
		 */
		
		FilePosition filePosition = new FilePosition(fileName, lineNumber);
		List filePositions = (List) linesByHash.get(hash);
		
		if (filePositions == null) {
			filePositions = new ArrayList(2);//why 2?
			linesByHash.put(hash, filePositions);
		} else {
			//2nd time we've seen this hash so we may have a match
			//although it could just be a hash collision which is why this is just a
			//_potential_ match
			if (filePositions.size() == 1) {
				potentialMatches.add(filePositions);
			}
		}
		filePositions.add(filePosition);
	}

	public List getPotentialMatches() {
		return potentialMatches;
	}
}