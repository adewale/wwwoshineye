package same.filter;

/** TODO: Make sure that this filter ignores comment delimiters within String literals.
 */
class JavaFilter extends SourceFilter {
	private boolean inMultiLineComment;

	public JavaFilter() {
		inMultiLineComment = false;
	}

	public String filter(String line) {
		line = super.removeWhiteSpace(line);

		if (line.startsWith("package") || line.startsWith("import")) {
			return ""; //ignore.
		}

		//This loop removes all comments from the line.
		int mlcStart = 0;
		int pos = 0;
		while (true) {
			if (inMultiLineComment) {
				int multiLineCommentEnd = line.indexOf("*/", pos);
				if (multiLineCommentEnd >= 0) {
					line = line.substring(0, mlcStart) + line.substring(multiLineCommentEnd + 2);
					inMultiLineComment = false;
					pos = mlcStart;
				} else {
					line = line.substring(0, mlcStart);
					break;
				}
			} else {
				int singleLineCommentStart = line.indexOf("//", pos);
				int multiLineCommentStart = line.indexOf("/*", pos);
				if (singleLineCommentStart >= 0 
					&& (multiLineCommentStart > singleLineCommentStart	
						|| multiLineCommentStart < 0)) {
					//single line comment
					line = line.substring(0, singleLineCommentStart);
					break;
				}
				if (multiLineCommentStart < 0) {
					break;
				}
				//multiline comment start
				inMultiLineComment = true;
				mlcStart = multiLineCommentStart;
				pos = mlcStart + 2;
			}
		}

		return line;
	}
}
