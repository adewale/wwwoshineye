package same.filter;

/**
 * 
 * @author ade
 *
 * A SourceFilter which trims white space off the lines it's asked to filter
 */
class TrimFilter extends SourceFilter {
	public String filter(String line) {
		return line.trim();
	}
}
