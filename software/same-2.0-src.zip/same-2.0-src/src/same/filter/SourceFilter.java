package same.filter;

public abstract class SourceFilter {
	public abstract String filter(String line);
	
	protected String removeWhiteSpace(String line) {
		int lineLength = line.length();
		StringBuffer result = new StringBuffer(lineLength);
		for (int i = 0; i < lineLength; i++) {
			char c = line.charAt(i);
			if (!Character.isWhitespace(c)) {
				result.append(c);
			}
		}
		return result.toString();
	}
}
