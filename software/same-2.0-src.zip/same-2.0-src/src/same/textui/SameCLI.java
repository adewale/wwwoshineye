package same.textui;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import same.SameVersion;
import same.alg.Listener;
import same.alg.MatchMap;
import same.alg.Same;
import same.fs.FilePosition;
import same.fs.SourceReader;

public class SameCLI implements Listener {
	private Same same;
	private boolean noFilesSpecified;

	public static void main(String[] args) throws Exception {
		new SameCLI().run(args);
	}

	public void onStart() {
		System.out.println("Same starts.");
	}

	public void onErrorPreprocessFile(File file, Exception ex) {
		System.err.println("Error while processing file " + file + ": " + ex);
		ex.printStackTrace(System.err);
		System.err.println("...skipping file and continuing");
	}

	public void onStartMatches() {
		System.out.println("Number of potential matches: " + same.getNumberOfPotentialMatches());
	}

	public void onEndMatches() {
		System.out.println("Match identification ends");
	}

	public void onEnd() {
		printMatchReport();
		printStatistics();
		System.out.println("Same ends.");
	}

	//package access so test can see it
	void run(String[] args) throws IOException {
		buildSame(args);
		same.run();
	}

	private void buildSame(String[] args) throws IOException {
		//set up default values
		int fragmentSize = 10;
		String filterType = "none";
		int cacheSize = 100;
		
		noFilesSpecified = true;
		List fileNames = new ArrayList();
		for (int i = 0; i < args.length; i++) {
			String arg = args[i];
			if (arg.equals("-m")) {
				fragmentSize = Integer.valueOf(args[++i]).intValue();
				continue;
			} else if (arg.equals("-f")) {
				filterType = args[++i];
				continue;
			} else if(arg.startsWith("-p")) {
				cacheSize = Integer.parseInt(args[++i]);
				continue;
			} else if (arg.startsWith("@")) {
				fileNames.addAll(SourceReader.readLines(arg.substring(1)));
				noFilesSpecified = false;
				continue;
			}
			fileNames.add(arg);
			noFilesSpecified = false;
			System.err.println("File(s) added");
		}
		
		if (noFilesSpecified) {
			usage();
			System.err.println("No files were specified in " + convertToString(args));
			System.exit(1);
		}
		
		this.same = new Same(this, fragmentSize, filterType, cacheSize);
		same.addAllFiles(fileNames);
	}
	
	private String convertToString(String[] args) {
		StringBuffer sb = new StringBuffer("[ ");
		String separator = " : ";
		for (int i = 0; i < args.length; i++) {
			sb.append(args[i]);
			sb.append(separator);
		}
		sb.append(" ]");
		return sb.toString();
	}

	private void usage() {
		System.err.println("Finds duplicate lines of source code across files.");
		System.err.println();
		System.err.println("Usage: same [-f filter] [-m minimalSize] [-p poolSize] filenames...");
		System.err.println("-f filter\t\tfilter all files with this filter");
		System.err.println("\t\t\t\tone of--(none, trim, baan, java) [default: none]");
		System.err.println("-m minimalSize  minimal fragment length in lines [default: 10]");
		System.err.println("-p poolSize  minimal reader pool size [default: 100]");
		System.err.println("filenames...    the files to be checked for duplicates");
		System.err.println("\t\t\t\t@filename indicates a file that contains filenames,");
		System.err.println("\t\t\t\tone filename per line");
		System.err.println();
		System.err.println("Version " + SameVersion.getBuildName() + ", built on "
				+ SameVersion.getBuildDate() + " at " + SameVersion.getBuildTime()	+ ".");
	}

	private void printMatchReport() {
		System.out.println("Match report");
		System.out.println();
		
		MatchMap matchMap = same.getMatchMap();
		
		//print them out in any old order
		Object[] entries = matchMap.getEntries();
		for (int i = 0; i < entries.length; i++) {
			Map.Entry entry = (Map.Entry) entries[i];
			List linesOfText = (List) entry.getKey();
			List filePositions = (List) entry.getValue();
			
			System.out.print(	"Frequency: " + filePositions.size() + ", length: " 
				+ linesOfText.size() + " (");
			System.out.println("The following text is duplicated");
			
			//print text
			for(int index=0, size=linesOfText.size(); index<size; index++) {
				Object text = linesOfText.get(index);//no need to cast
				System.out.println(text);
			}
			
			System.out.println("=====================");
			//print positions
			for(int index=0, size=filePositions.size(); index<size; index++) {
				FilePosition position = (FilePosition) filePositions.get(index);
				System.out.println(position.getFileName() + " from line " 
					+ position.getLineNumber());
			}
			System.out.println("^^^^^^^^^^^^^^^^^^^^^");
		}
	}

	private void printStatistics() {
		System.out.println("Statistics:");
		System.out.println();
		System.out.println("Number of files: " + same.getNumberOfFiles());
		System.out.println("Total number of lines: " + same.getTotalNumberOfLines());
		System.out.println("Number of filtered lines: "	+ same.getRelevantNumberOfLines()
				+ " (" + percent(same.getRelevantNumberOfLines(), same.getTotalNumberOfLines())
				+ " of total)");
				
		System.out.println("Number of potential pairwise matches: " 
			+ same.getNumberOfPotentialMatches());
		System.out.println("Number of pairwise comparisons made: " 
			+ same.getNumberOfComparisons());
		System.out.println("Number of duplicates found: "+ same.getNumberOfActualMatches());
		System.out.println();
	}

	private static String percent(double numerator, double denominator) {
		if (denominator < 0.01) {
			return "<meaningless>%";
		}

		return String.valueOf(Math.round(numerator * 1000 / denominator) / (double) 10) + "%";
	}
	
	//package access so test can see it
	Same getSame() {
		return this.same;
	}
}
