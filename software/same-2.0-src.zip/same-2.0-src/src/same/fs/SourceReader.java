package same.fs;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.LineNumberReader;
import java.util.ArrayList;
import java.util.List;

import same.filter.SourceFilter;

public class SourceReader extends LineNumberReader {
	//debug use only//private static int count = 0;
	private static final int BUFFER_SIZE = 16384; //TODO: Experiment with this value.
	
	private final SourceFilter filter;
	private String lastLine = null;
	private String lastLineFiltered = null;
	private boolean pooled;


	public SourceReader(String fileName, SourceFilter filter, boolean pooled) 
		throws IOException {
		this(fileName, filter);
		this.pooled = pooled;	
	}

	public SourceReader(String fileName, SourceFilter filter) throws IOException {
		super(new FileReader(fileName), BUFFER_SIZE);
		this.filter = filter;
		//debug use only//count++;
	}

	public static SourceReader makePooledReader(String fileName, SourceFilter filter) 
		throws IOException {
		return new SourceReader(fileName, filter, true);
	}

	private void doReadLine() throws IOException {
		lastLine = super.readLine();
		lastLineFiltered = (lastLine == null ? null : filter.filter(lastLine));
	}

	public String readLine() throws IOException {
		doReadLine();
		return lastLine;
	}

	public String readLineFiltered() throws IOException {
		doReadLine();
		return lastLineFiltered;
	}

	public String getLastLine() {
		return lastLine;
	}

	public CharSequence getLastLineFiltered() {
		return lastLineFiltered;
	}

	public void mark() throws IOException {
		super.mark(BUFFER_SIZE);
	}

	public void close() throws IOException {
		//debug use only//System.err.println("reader count is " + SourceReader.count);
		//debug use only//count--;
		super.close();
	}

	public boolean isPooled() {
		return this.pooled;
	}

	public static void closeSafely(BufferedReader reader) {
		if (reader != null) {
			try {
				reader.close();
			} catch (IOException ioe) {
				System.err.println("Safe closing failed");
				ioe.printStackTrace(System.err);
			}
		}
	}

	public static List readLines(String fileName) throws IOException {
		return SourceReader.readLines(new File(fileName));
	}

	public static List readLines(File file) throws IOException {
		List lines = new ArrayList();
		BufferedReader reader = null;
		
		try {
			reader = new BufferedReader(new FileReader(file));
			String line = null;
			while((line=reader.readLine()) != null) {
				lines.add(line);
			}
		}finally {
			SourceReader.closeSafely(reader);
		}
		
		return lines;
	}
}
