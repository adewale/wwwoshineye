package same.fs;

import java.io.File;
import java.io.IOException;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;

import same.filter.SourceFilter;
import same.filter.SourceFilterFactory;

public class SourceFileSystem {
	//strings were chosen to ensure widely distributed hashes
	public static final String ACROSS = "AAAAAAAAAAAAAA";
	public static final String DOWN = "ZZZZZZZZZZ";
	private int maxReaders;
	private int cacheHits = 0;
	private int cacheMisses = 0;
	private int invalidMarks =0;
	
	private final Map readerPool;/*String->SourceReader*/
	private SourceFilter filter;
	private int fragmentSize;

	public SourceFileSystem(int cacheSize, int fragmentSize, String filterType) {
		this.filter = SourceFilterFactory.instance().createFilter(filterType);
		this.readerPool = new HashMap(cacheSize*2);//across and down
		this.maxReaders = cacheSize;
		this.fragmentSize = fragmentSize;
	}

	public SourceReader getNewReader(String fileName) throws IOException {
		return new SourceReader(fileName, filter);
	}

	public SourceReader getReader(FilePosition filePosition, String series) throws IOException {
		String fileName = filePosition.getFileName();
		int lineNumber = filePosition.getLineNumber();
		SourceReader result = this.getPooledReader(fileName, series);

		if ((result.getLineNumber() + 1) > lineNumber) {//ahead of position
			if (!reset(lineNumber, result)) {//try to reset
				//failed to reset so that reader is now invalid and must be replaced
				SourceReader.closeSafely(result);

				String key = fileName+series;
				if (readerPool.containsKey(key)) {//update pool
					readerPool.remove(key);
					result = SourceReader.makePooledReader(fileName, filter);
					readerPool.put(key, result);
				} else {
					result = getNewReader(fileName);
				}

				invalidMarks++;
			}
		}
		
		if ((result.getLineNumber() + 1) > lineNumber) {
			throw new RuntimeException("Trying to go to line number "+ lineNumber
			+ " while we are at "	+ (result.getLineNumber() + 1));
		}
		
		readAhead(lineNumber, result);
		return result;
	}

	private SourceReader getPooledReader(String fileName, String series) throws IOException {
		String key = fileName + series;
		SourceReader reader = (SourceReader) readerPool.get(key);
		if (reader == null) {
			cacheMisses++;//cache miss
			reader = getNewReader(fileName);
		} else {
			cacheHits++;//cache hit
		}
		return reader;
	}


	private boolean reset(int lineNumber, SourceReader result) {
		boolean resetSucceeded = true;
		try {
			result.reset(); //go back to the previous mark().
			resetSucceeded = ((result.getLineNumber() + 1) <= lineNumber);
		} catch (IOException ioe) {
			//this happens often enough without being a problem so we bury it
			//ioe.printStackTrace(System.err);
			resetSucceeded = false;
		}
		return resetSucceeded;
	}

	private void readAhead(int lineNumber, SourceReader result) throws IOException {
		while ((result.getLineNumber() + 1) < lineNumber) {
			result.readLine();
		}
		result.mark();
	}

	public void clear() {
		Object[] readers = readerPool.values().toArray();
		for (int i = 0; i < readers.length; i++) {
			SourceReader reader = (SourceReader) readers[i];
			SourceReader.closeSafely(reader);
		}
		readerPool.clear();
		
		//print cache results
		System.err.println("Number of cache hits = " + cacheHits);
		System.err.println("Number of cache misses = " + cacheMisses);
		System.err.println("Number of invalid marks = " + invalidMarks);
	}

	public void prepare(List files) throws IOException {
		//sort by file size descending
		Collections.sort(files, new Comparator() {
			public int compare(Object obj1, Object obj2) {
				File file1 = (File) obj1;
				File file2 = (File) obj2;
				
				long file1Length = file1.length();
				long file2Length = file2.length();
				if (file1Length < file2Length) {
					return 1;
				} else if (file1Length == file2Length) {
					return 0;
				} else {
					return -1;
				}
			}
		});		

		removeOverlySmallFiles(files);
		
		cacheBiggestFiles(files);
	}

	private void removeOverlySmallFiles(List files) throws IOException {
		//remove all files that are too small to be worth processing
		for (ListIterator it = files.listIterator(files.size()); it.hasPrevious();) {
			File file = (File) it.previous();
			List lines = SourceReader.readLines(file);
			
			if (lines.size() < this.fragmentSize) {
				it.remove(); //current file too small so don't process
			} else {
				break;//files have become big enough
			}
		}
	}
	
	private void cacheBiggestFiles(List files) throws IOException {
		//cache biggest files
		int filesSize = files.size();
		Object[] fileElements = files.toArray();
		for (int i = 0; i < fileElements.length; i++) {
			File file = (File) fileElements[i];
			int poolSize = readerPool.size() ;
			if ((poolSize == filesSize) || (poolSize == maxReaders)) {
				break;
			}
			
			String fileName = file.getAbsolutePath();
			String keyAcross = fileName + SourceFileSystem.ACROSS;
			String keyDown = fileName + SourceFileSystem.DOWN;
			readerPool.put(keyAcross, SourceReader.makePooledReader(fileName, filter));
			readerPool.put(keyDown, SourceReader.makePooledReader(fileName, filter));
		}
	}

	/**
	 * Release the reader. This involves closing it if it's not in the pool
	 * @param reader1
	 */
	public void release(SourceReader reader) {
		//don't bother closing pooled readers
		if ((reader != null) && (reader.isPooled())) {
			return;
		}

		SourceReader.closeSafely(reader);
	}
}
