package same.util;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

/**
 * @author ade
 *
 * A group of useful methods for operating on and with java.io.File objects.
 * Basically these are methods I wish were available on the File class.
 */
public class FileUtils {

	//return all the files in this directory and it's sub-directories
	public static List getDirectoryContents(File dir) {
		File[] allFiles = dir.listFiles();
		List resultFiles = new ArrayList();
		for (int i = 0; i < allFiles.length; i++) {
			File temp = allFiles[i];
			if (temp.isDirectory()) {
				//recurse
				resultFiles.addAll(getDirectoryContents(temp));
			} else {
				resultFiles.add(temp);
			}
		}
		return resultFiles;
	}

}
