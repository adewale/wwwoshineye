#!/bin/sh

JAVA_HOME_DIR=/usr/java/j2sdk1.4.1_01/

$JAVA_HOME_DIR/bin/java -Xmx512M -cp same-classes.zip:trove.jar same.textui.SameCLI $*
