package same.fs;

import same.filter.NullFilter;
import same.filter.SourceFilter;
import junit.framework.TestCase;
import junit.textui.TestRunner;

/**
 * @author ade
 *
 * A testcase for the SourceReader class
 */
public class SourceReaderTest extends TestCase {
	private static final String FILE_NAME = "TestData.txt";
	private static final SourceFilter FILTER = new NullFilter();
	public SourceReaderTest(String args) {
		super(args);
	}

	public static void main(String[] args) {
		TestRunner.run(SourceReaderTest.class);
	}

	public void testReadLine() throws Exception {
		SourceReader sr = new SourceReader(FILE_NAME, FILTER);
		String line = sr.readLine();
		sr.close();
		
		assertEquals(line, "//duplicate friendly code for testing same");
	}

	public void testGetLastLine() throws Exception {
		SourceReader sr = new SourceReader(FILE_NAME, FILTER);
		assertEquals(sr.readLine(), sr.getLastLine());
	}

	public void testGetLineNumber() throws Exception {
		SourceReader sr = new SourceReader(FILE_NAME, FILTER);
		sr.readLine();
		sr.readLine();
		sr.readLine();
		sr.readLine();
		sr.readLine();
		
		assertTrue(sr.getLineNumber() == 5);
	}


}
