package same.filter;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;
import junit.textui.TestRunner;

/**
 * @author ade
 *
 * Unit test confirming that the SourceFilterFactory works
 */
public class SourceFilterFactoryTest extends TestCase {

	/**
	 * Constructor for SourceFilterFactoryTest.
	 * 
	 */
	public SourceFilterFactoryTest(String args) {
		super(args);
	}

	public static void main(java.lang.String[] args) {
		TestRunner.run(suite());
	}

	public static Test suite() {
		TestSuite suite = new TestSuite(SourceFilterFactoryTest.class);

		return suite;
	}
	
	public void testSingleton() {
		assertNotNull(SourceFilterFactory.instance());
		assertSame(SourceFilterFactory.instance(), SourceFilterFactory.instance());
		assertTrue(SourceFilterFactory.instance() == SourceFilterFactory.instance());
	}

	public void testCreateFilter() {
		assertTrue(new SourceFilterFactory().createFilter(null) instanceof NullFilter);
		assertTrue(new SourceFilterFactory().createFilter("none") instanceof NullFilter);
		assertTrue(new SourceFilterFactory().createFilter("None") instanceof NullFilter);
		
		assertTrue(new SourceFilterFactory().createFilter("baan") instanceof BaanFilter);
		assertTrue(new SourceFilterFactory().createFilter("Baan") instanceof BaanFilter);
		assertTrue(new SourceFilterFactory().createFilter("java") instanceof JavaFilter);
		assertTrue(new SourceFilterFactory().createFilter("Java") instanceof JavaFilter);
		assertTrue(new SourceFilterFactory().createFilter("trim") instanceof TrimFilter);
		assertTrue(new SourceFilterFactory().createFilter("Trim") instanceof TrimFilter);
		
		assertNull(new SourceFilterFactory().createFilter("nonsenical type code"));
	}

}
