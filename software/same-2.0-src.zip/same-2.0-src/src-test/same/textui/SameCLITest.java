package same.textui;

import junit.framework.TestCase;
import junit.textui.TestRunner;
import same.alg.Same;

/**
 * @author ade
 *
 * Test that uses SameCLI as an entry point for testing the behaviour of the
 * whole system. It's not really a unit-test but it's useful. 
 */
public class SameCLITest extends TestCase {

	public SameCLITest(String args) {
		super(args);
	}

	public static void main(String[] args) {
		TestRunner.run(SameCLITest.class);
	}
	
	public void testFunctionality() throws Exception {
		String[] args = {"-m", "1", "-p", "1", "TestData.txt"};
		SameCLI cli = new SameCLI();
		cli.run(args);
		
		Same same = cli.getSame();
		
		assertTrue(same.getNumberOfActualMatches() == 4);
		assertTrue(same.getNumberOfFiles() == 1);
		assertTrue(same.getTotalNumberOfLines() == 37);
	}

}
