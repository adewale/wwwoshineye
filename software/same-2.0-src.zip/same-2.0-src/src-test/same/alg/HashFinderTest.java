package same.alg;

import junit.framework.TestCase;
import junit.textui.TestRunner;

/**
 * @author ade
 *
 * Testcase for the hash finder
 */
public class HashFinderTest extends TestCase {

	public HashFinderTest(String arg) {
		super(arg);
	}

	public static void main(String[] args) {
		TestRunner.run(HashFinderTest.class);
	}

	public void testComputeStringHash() {
		String hello = "hello";
		String jello = "jello";
		String ohell = "ohell";
		HashFinder hf = new HashFinder(-1, null);//nonsense values
		
		assertTrue(hf.computeStringHash(hello) == hf.computeStringHash(hello));
		assertTrue(hf.computeStringHash(hello) != hf.computeStringHash(ohell));
		assertTrue(hf.computeStringHash(hello) != hf.computeStringHash(jello));
	}

}
