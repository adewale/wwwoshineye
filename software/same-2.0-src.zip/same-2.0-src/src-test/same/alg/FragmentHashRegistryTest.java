package same.alg;

import java.util.ArrayList;
import java.util.List;

import junit.framework.TestCase;
import same.fs.FilePosition;


public class FragmentHashRegistryTest extends TestCase {
	public FragmentHashRegistryTest(String a_name) {
		super(a_name);
	}

	public void test() {
		FragmentHashRegistry registry = new FragmentHashRegistry();
		registry.registerFragment(627, "file1", 33);
		registry.registerFragment(442, "file1", 45);
		registry.registerFragment(627, "file2", 21);

		List potentialMatches = new ArrayList();
		List potentialMatch = new ArrayList();
		
		potentialMatch.add(new FilePosition("file1", 33));
		potentialMatch.add(new FilePosition("file2", 21));
		
		potentialMatches.add(potentialMatch);

		assertEqualMatches(potentialMatches, registry.getPotentialMatches());
	}

	private void assertEqualMatches(List expectedMatches, List actualMatches) {
		assertEquals("expected equal List sizes", expectedMatches.size(), actualMatches.size());
		for (int i = 0; i < expectedMatches.size(); i++) {
			List expected = (List) expectedMatches.get(i);
			List actual = (List) actualMatches.get(i);

			assertEquals("expected equal nested List sizes at position " + i,
				expected.size(), actual.size());
				
			for (int j = 0; j < expected.size(); j++) {
				assertEquals("expected equal nested List element at position " + i + "->" + j,
					expected.get(j), actual.get(j));
			}
		}
	}

	public void onPotentialMatchFound(FilePosition a_fileLine1, FilePosition a_fileLine2) {
		//TODO: test this.
	}
}
