package com.oshineye.kwikwiki.markup.rules;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.oshineye.kwikwiki.markup.rules.ListRule;
import junit.framework.TestCase;
import junit.framework.Test;
import junit.framework.TestSuite;

public class ListRuleTest extends TestCase {

    public static void main(java.lang.String[] args) {
        junit.textui.TestRunner.run(suite());
    }

    public static Test suite() {
        TestSuite suite = new TestSuite(ListRuleTest.class);

        return suite;
    }

    public void testListRule() {
        CharSequence listText = " * Level1\n" +
                "  * Level2\n" +
                "   * Level3";

		ListRule rule = new ListRule();
		listText = rule.execute(listText);
        String result = listText.toString();
        Pattern pattern = Pattern.compile("listItem\\d", Pattern.MULTILINE);
        Matcher matcher = pattern.matcher(result);
        assertTrue(matcher.find());
    }

	public void testMultiList() {
		String wikiList = "Testing 1,2,3 \n" 
			+ " * test1\n  * test2\n   * test3\n"
			+ "Mellow world\n"
			+ " * test1\n  * test2\n   * test3\n"
			+ "Mellow world";
		String expectedHtmlChunk = "Testing 1,2,3 \n"
			+ "<ul>\n"
			+ "<li class=\"listItem1\">test1</li>\n"
			+ "<li class=\"listItem2\">test2</li>\n"
			+ "<li class=\"listItem3\">test3</li>\n"
			+ "</ul>\n"
			+ "Mellow world\n"
			+ "<ul>\n"
			+ "<li class=\"listItem1\">test1</li>\n"
			+ "<li class=\"listItem2\">test2</li>\n"
			+ "<li class=\"listItem3\">test3</li>\n"
			+ "</ul>\n"
			+ "Mellow world\n";

		String result = new ListRule().execute(wikiList).toString();
 		assertTrue(result.matches(expectedHtmlChunk));
	}

}
