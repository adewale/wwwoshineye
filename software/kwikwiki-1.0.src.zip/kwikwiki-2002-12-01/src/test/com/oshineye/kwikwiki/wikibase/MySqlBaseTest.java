package com.oshineye.kwikwiki.wikibase;

import junit.framework.Test;
import junit.framework.TestSuite;

public class MySqlBaseTest extends AbstractWikiBaseTest {
    public static void main(java.lang.String[] args) {
        junit.textui.TestRunner.run(suite());
    }

    public static Test suite() {
        TestSuite suite = new TestSuite(MySqlBaseTest.class);

        return suite;
    }

    public WikiBase createWikiBase() {
        return new MySqlBase();
    }

}
