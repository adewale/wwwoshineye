package com.oshineye.kwikwiki.wikibase;

import junit.framework.Test;
import junit.framework.TestSuite;

public class FileBaseTest extends AbstractWikiBaseTest {

    public static void main(java.lang.String[] args) {
        junit.textui.TestRunner.run(suite());
    }

    public static Test suite() {
        TestSuite suite = new TestSuite(FileBaseTest.class);

        return suite;
    }

    public WikiBase createWikiBase() {
        return new FileBase();
    }
}
