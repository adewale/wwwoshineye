package com.oshineye.kwikwiki.markup.rules;

import junit.framework.TestCase;
import junit.framework.Test;
import junit.framework.TestSuite;

public class CodeRuleTest extends TestCase {
    public static void main(java.lang.String[] args) {
        junit.textui.TestRunner.run(suite());
    }

    public static Test suite() {
        TestSuite suite = new TestSuite(CodeRuleTest.class);

        return suite;
    }

    public void testCodeRule() {
        String text = "\n{{{\n"
                + "    public static void main(java.lang.String[] args) {\n"
                + "        junit.textui.TestRunner.run(suite());\n"
                + "    }\n"
                + "}}}\n";
        String result = new CodeRule().execute(text).toString();
        assertTrue(result.indexOf("pre class=\"code\">") != -1);
        assertTrue(result.indexOf("</pre>") != -1);
    }

    public void testCodeRuleWithoutPrecedingLine() {
        String text = "{{{\n"
                + "    public static void main(java.lang.String[] args) {\n"
                + "        junit.textui.TestRunner.run(suite());\n"
                + "    }\n"
                + "}}}\n";
        String result = new CodeRule().execute(text).toString();
        assertTrue(result.indexOf("pre class=\"code\">") != -1);
        assertTrue(result.indexOf("</pre>") != -1);
    }

    public void testCodeRuleWithoutSucceedingLine() {
        String text = "\n{{{\n"
                + "    public static void main(java.lang.String[] args) {\n"
                + "        junit.textui.TestRunner.run(suite());\n"
                + "    }\n"
                + "}}}";
        String result = new CodeRule().execute(text).toString();
        assertTrue(result.indexOf("pre class=\"code\">") != -1);
        assertTrue(result.indexOf("</pre>") != -1);
    }
}
