package com.oshineye.kwikwiki.markup.rules;

import junit.framework.*;
import com.oshineye.kwikwiki.markup.rules.LinkRule;

public class LinkRuleTest extends TestCase {

    public static void main(java.lang.String[] args) {
        junit.textui.TestRunner.run(suite());
    }

    public static Test suite() {
        TestSuite suite = new TestSuite(LinkRuleTest.class);

        return suite;
    }

    public void testRule() {
        CharSequence linkText = " StartingPoints ";
        CharSequence processedLink = " <a href=\"View?title=StartingPoints\">StartingPoints</a> ";
        LinkRule rule = new LinkRule();
        assertEquals(processedLink.toString(), rule.execute(linkText).toString());
        assertEquals("".toString(), rule.execute("").toString());
    }
}