package com.oshineye.kwikwiki.page;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;
import com.oshineye.kwikwiki.wikibase.WikiBase;
import com.oshineye.kwikwiki.KwikWikiTestUtils;
import java.util.SortedSet;
import java.util.Iterator;

public class OrphanedPagesTest extends TestCase {

    public static void main(java.lang.String[] args) {
        junit.textui.TestRunner.run(suite());
    }

    public static Test suite() {
        TestSuite suite = new TestSuite(WantedPagesTest.class);
        return suite;
    }
	
    public void testGetOrphanedPages() {
		WikiBase wikiBase = WikiBase.getInstance();
        wikiBase.savePage(KwikWikiTestUtils.createTestOrphanedPage());

		OrphanedPages op = new OrphanedPages();
        SortedSet pages = op.getOrphanedPages();
        assertNotNull(pages);
        assertTrue(pages.size() > 0);

        for (Iterator it = pages.iterator(); it.hasNext();) {
            String wikiName = (String) it.next();
            SortedSet wordLocations = wikiBase.locateWord(wikiName);

            assertTrue(wordLocations.size() == 0);
            assertTrue(wikiBase.pageExists(wikiName));
            assertFalse(Page.isSpecialPage(wikiName));
        }
		assertNotNull(op.getText());
    }
}
