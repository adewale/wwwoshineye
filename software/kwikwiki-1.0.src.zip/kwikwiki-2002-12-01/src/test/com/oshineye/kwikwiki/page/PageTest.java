package com.oshineye.kwikwiki.page;

import junit.framework.Test;
import junit.framework.TestSuite;
import junit.framework.TestCase;

public class PageTest extends TestCase {

    public static void main(java.lang.String[] args) {
        junit.textui.TestRunner.run(suite());
    }

    public static Test suite() {
        TestSuite suite = new TestSuite(PageTest.class);

        return suite;
    }

    public void testIsSpecialPage() {
        String should = "Not treating a page as special when it should be";
        String shouldNot = "Treating a page as special when it shouldn't be";
        assertTrue(should, Page.isSpecialPage("TitleIndex"));
        assertTrue(should, Page.isSpecialPage("RecentChanges"));
        assertTrue(shouldNot, !Page.isSpecialPage("AdewaleOshineye"));
    }

    public void testGetSpecialPage() {
        String titleIndex = "TitleIndex";
        WikiPage titleIndexPage = Page.getSpecialPage(titleIndex);
        WikiPage recentChangesPage = Page.getSpecialPage("RecentChanges");

        assertTrue(titleIndex.equals(titleIndexPage.getTitle()));
        assertFalse(titleIndex.equals(recentChangesPage.getTitle()));
        assertTrue(titleIndexPage.isSpecial());
        assertTrue(recentChangesPage.isSpecial());
    }

}
