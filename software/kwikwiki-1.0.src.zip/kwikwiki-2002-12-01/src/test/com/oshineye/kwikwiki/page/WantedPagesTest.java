package com.oshineye.kwikwiki.page;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;
import com.oshineye.kwikwiki.wikibase.WikiBase;
import com.oshineye.kwikwiki.KwikWikiTestUtils;
import java.util.SortedSet;

public class WantedPagesTest extends TestCase {

    public static void main(java.lang.String[] args) {
        junit.textui.TestRunner.run(suite());
    }

    public static Test suite() {
        TestSuite suite = new TestSuite(WantedPagesTest.class);
        return suite;
    }
	
    public void testGetWantedPages() {
		WikiPage page = KwikWikiTestUtils.createTestPage();
		WikiBase.getInstance().savePage(page);
		WantedPages wp = new WantedPages();
        SortedSet wantedPages = wp.getWantedPages();
        assertNotNull("WantedPages Set is null", wantedPages);
        assertTrue("There are no WantedPages", wantedPages.size() > 0);
        assertTrue(wantedPages.contains("PleaseDoNotCreateThisPageAsItIsUsedForTesting"));
        assertFalse(wantedPages.contains("KwikWikiTestingPage"));
		
		assertNotNull(wp.getText());
    }
}