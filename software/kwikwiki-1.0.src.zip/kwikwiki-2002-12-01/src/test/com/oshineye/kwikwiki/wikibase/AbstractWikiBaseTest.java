package com.oshineye.kwikwiki.wikibase;

import com.oshineye.kwikwiki.KwikWikiTestUtils;
import com.oshineye.kwikwiki.markup.MarkUpEngine;
import com.oshineye.kwikwiki.page.WikiPage;
import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

import java.util.Date;
import java.util.Iterator;
import java.util.SortedSet;

/*
This test uses the AbstractTest to ensure that sub-classes of WikiBase
conform to the contract defined by WikiBase and obey the LSP
*/
public abstract class AbstractWikiBaseTest extends TestCase {
    /*
    An instance variable used by all the tests.
    */
    private WikiBase wikiBase;

    public static void main(java.lang.String[] args) {
        junit.textui.TestRunner.run(suite());
    }

	//this method will be used by subclasses
    public static Test suite() {
        TestSuite suite = new TestSuite(AbstractWikiBaseTest.class);
        return suite;
    }

    public final void setUp() {
        this.wikiBase = this.createWikiBase();
    }

	//factory method that sub-classes of this test will need to provide
	public abstract WikiBase createWikiBase();

    public void testLoadTitles() {
        SortedSet titles = wikiBase.loadTitles();
        String msg = " is not a wiki name but is in the title set";
        assertTrue(titles.size() > 0);
        for (Iterator it = titles.iterator(); it.hasNext();) {
            String title = (String) it.next();
            assertTrue(title + msg, MarkUpEngine.isWikiName(title));
        }
    }

    public void testGetInstance() {
        assertNotNull(WikiBase.getInstance());
        Object obj1 = WikiBase.getInstance();
        Object obj2 = WikiBase.getInstance();
        assertTrue(obj1.equals(obj2));
        assertTrue(obj1 == obj2);
    }

    public void testGetPage() {
        assertNotNull(wikiBase.getPage("StartingPoints"));
        assertNotNull(wikiBase.getPage("TitleIndex"));
        assertNotNull(wikiBase.getPage("RecentChanges"));
        assertTrue(wikiBase.getPage("StartingPoints") instanceof WikiPage);
    }

    public void testSavePage() {
        WikiPage page = KwikWikiTestUtils.createTestPage();
        wikiBase.savePage(page);
        WikiPage page2 = wikiBase.getPage("KwikWikiTestingTestPage");

        String text1 = page.getText();
        String text2 = page2.getText();

        assertEquals("Page retrieved was not the same as original page", text1, text2);
        assertTrue("Newly saved page is not in titleset", wikiBase.pageExists(page.getTitle()));
        assertTrue(this.getLastChange().getTitle().equals(page.getTitle()));
    }

    public void testSaveNewPage() {
        //confirm test page doesn't exist
        if (wikiBase.pageExists("KwikWikiTestingTestPage")) {
            wikiBase.deletePage("KwikWikiTestingTestPage");

            //assert that the page no longer exists
            assertTrue("Page continues to exist after being deleted", !wikiBase.pageExists("KwikWikiTestingTestPage"));
        }

        //create test page anew
        WikiPage page = KwikWikiTestUtils.createTestPage();
        wikiBase.savePage(page);

        //assert that the page exists
        assertTrue(wikiBase.pageExists("KwikWikiTestingTestPage"));
    }

    public void testGetAllTitles() {
        SortedSet persistentTitles = wikiBase.loadTitles();
        SortedSet allTitles = wikiBase.getAllTitles();

        //some titles are in the title set but not in the persistent store,
        //these are the titles of special pages,
        //so there should always be more titles in memory than in the store
        assertTrue(allTitles.containsAll(persistentTitles));
        assertTrue(allTitles.size() > persistentTitles.size());
    }

    public void testPageExists() {
        assertTrue("StartingPoints doesn't exist", wikiBase.pageExists("StartingPoints"));
        assertTrue("fake-page actually exists", !wikiBase.pageExists("fake-page"));
    }

    /*test for bug when mysql code was returning too many changelogs (2 instead of 1) when it was
    passed 1 and there were changes yesterday*/
    public void testChangeLogSize() {
        WikiPage rawPage = KwikWikiTestUtils.createTestPage();
        wikiBase.savePage(rawPage);
        int numberOfDaysToRetrieve = 1;
        int lengthOfChangeLog = wikiBase.getRecentChanges(numberOfDaysToRetrieve).length;
        assertEquals("Failed to get only today's changelog",
                numberOfDaysToRetrieve, lengthOfChangeLog);
    }

    public void testChangeLogging() {
        WikiPage rawPage = KwikWikiTestUtils.createTestPage();
        wikiBase.savePage(rawPage);

        Change createdChange = new Change(rawPage);
        Change retrievedChange = this.getLastChange();

        assertEquals("Titles did not match", rawPage.getTitle(), retrievedChange.getTitle());
        assertEquals("Changes were not equal", createdChange, retrievedChange);
    }

    public void testGetRecentChanges() {
        int ridicilouslyLargeNumber = 10000;
        ChangeLog[] logs = wikiBase.getRecentChanges(ridicilouslyLargeNumber);
        ChangeLog[] lastLogs = wikiBase.getRecentChanges(1);
        ChangeLog todaysLog = lastLogs[0];

        assertNotNull(logs);
        assertNotNull(todaysLog);
        assertTrue(logs.length < ridicilouslyLargeNumber);
        assertTrue(logs.length > 0);
    }

    public void testLocateWord() {
        WikiPage rawPage = KwikWikiTestUtils.createTestPage();
        wikiBase.savePage(rawPage);

        SortedSet titles = wikiBase.locateWord("testing");
        assertTrue(titles.size() >= 1);//"testing" exists on KwikWikiTestingTestPage
        assertTrue(titles.contains("KwikWikiTestingTestPage"));//testing page referred to above
        assertNotNull(wikiBase.locateWord("wordthatdefinitelydoesnotexist-�$%�$%$��%$%%^^"));
    }

    public void testGetTitlesStartingWith() {
        SortedSet sharedStart = wikiBase.getTitlesStartingWith("Kwik");
        assertNotNull(sharedStart);

        //should get an empty set
        sharedStart = wikiBase.getTitlesStartingWith("");
        assertNotNull(sharedStart);
    }

    public void testGetTitlesEndingWith() {
        SortedSet sharedEnd = wikiBase.getTitlesEndingWith("Wiki");
        assertNotNull(sharedEnd);

        //should get an empty set
        sharedEnd = wikiBase.getTitlesStartingWith("");
        assertNotNull(sharedEnd);
    }

    //bug introduced when searching for the word "http"
    public void testIndexShrinking() {
        String targetWord = "deliberately";

        //create a page with a particular word in it --"deliberately"
        WikiPage rawPage = KwikWikiTestUtils.createTestPage();
        wikiBase.savePage(rawPage);

        //confirm that the word is there
        SortedSet beforeResults = wikiBase.locateWord(targetWord);
        String beforeMsg = "Target word " + targetWord + " was not found after initial save";
        assertTrue(beforeMsg, beforeResults.contains("KwikWikiTestingTestPage"));

        //save the page again but without the unusual word
        rawPage = new WikiPage("KwikWikiTestingTestPage", "", new Date());
        wikiBase.savePage(rawPage);

        //the index should no longer say that the page has the unusual word
        SortedSet afterResults = wikiBase.locateWord(targetWord);//don't rely on reference aliasing

        String indexRemovalMsg = "Target word " + targetWord + " was found after removal";
        assertTrue(indexRemovalMsg, !afterResults.contains("KwikWikiTestingTestPage"));

        //confirm that the word is back
        rawPage = KwikWikiTestUtils.createTestPage();
        wikiBase.savePage(rawPage);
        afterResults = wikiBase.locateWord(targetWord);
        String indexReadditionMsg = "Target word " + targetWord
                + " was not found after adding it back to the page";
        assertTrue(indexReadditionMsg, afterResults.contains("KwikWikiTestingTestPage"));
    }

    public void testDelete() {
        WikiPage page = KwikWikiTestUtils.createTestPage();
        wikiBase.savePage(page);
        wikiBase.deletePage(page.getTitle());

        assertFalse(wikiBase.pageExists(page.getTitle()));
    }

    private Change getLastChange() {
        ChangeLog[] logs = wikiBase.getRecentChanges(1);
        return logs[0].getChanges()[0];
    }

}
