package com.oshineye.kwikwiki.markup.rules;

import java.util.regex.Pattern;

public class CodeRule extends MarkUpRule {
	private static final String PATTERN = "\\{\\{\\{\n(.*)\n\\}\\}\\}";
	private static final String REPLACEMENT_TEXT = "<pre class=\"code\">\n$1\n</pre>";

    public CodeRule() {
        super(Pattern.compile(CodeRule.PATTERN, Pattern.DOTALL), CodeRule.REPLACEMENT_TEXT);
    }
}
