package com.oshineye.kwikwiki.markup.rules;

public class HorizontalLineRule extends MarkUpRule {
	private static final String PATTERN = "^----";
	private static final String REPLACEMENT_TEXT = "<hr>";

    public HorizontalLineRule() {
        super(HorizontalLineRule.PATTERN, HorizontalLineRule.REPLACEMENT_TEXT);
    }
}