package com.oshineye.kwikwiki.markup.rules;


public class ListRule extends MarkUpRule {
	private static final int LEVELS = 5;
	private static final ListItemRule [] LIST_LEVELS = new ListItemRule[LEVELS];

	public ListRule() {
		for(int i=0; i<LEVELS; i++) {
			LIST_LEVELS[i] = new ListItemRule(i);
		}
	}
	
	public CharSequence execute(CharSequence text) {
		//add appropriate <li> tags
		for(int i=0; i<LEVELS; i++) {
			text = LIST_LEVELS[i].execute(text);
		}
		
		String[] lines = text.toString().split("\\n");
		
		for (int i=0; i<lines.length; i++) {
			if (isListStart(lines, i)) {
				lines[i] = "<ul>\n" + lines[i];
			} else if (i != 0){
				if (isListEnd(lines, i)) {
					lines[i] = lines[i] + "\n</ul>";
				}
			}
		}
		
		//join the lines back together
		StringBuffer sb = new StringBuffer();
		for (int i=0; i<lines.length; i++) {
			sb.append(lines[i] + "\n");
		}
		return sb.toString();
	}
	
	private static boolean isListStart(String[] lines, int index) {
		boolean previousLineIsList;
		if (index == 0) {
			previousLineIsList = false;
		} else {
			previousLineIsList = isListItem(lines[index-1]);
		}
		
		return (!previousLineIsList && isListItem(lines[index]));
	}
	
	private static boolean isListItem(String line) {
		if (line.equals("")) {
			return false;
		}
		return line.startsWith("<li") || line.startsWith("<ul>");
	}
	
	private static boolean isListEnd(String[] lines, int index) {
		boolean listItem = isListItem(lines[index]);
		if (listItem) {
			if (index <= lines.length-2) {//list item that looks ahead
				return !isListItem(lines[index + 1]);
			} else if (listItem && (index==(lines.length-1))) {//list item on last line
				return true;
			} 
		}
		return false;
	}

	class ListItemRule extends MarkUpRule {
		private static final String PATTERN_START = "^(\\s){";
		private static final String PATTERN_END = "}(\\*)(\\s)(.*)";
		private static final String REPLACEMENT_TEXT_START = "<li class=\"listItem";
		private static final String REPLACEMENT_TEXT_END = "\">$4</li>";		
		public ListItemRule(int level) {
			super(ListItemRule.PATTERN_START + level + ListItemRule.PATTERN_END,
				  ListItemRule.REPLACEMENT_TEXT_START + level + ListItemRule.REPLACEMENT_TEXT_END);	
		}
	}
}
