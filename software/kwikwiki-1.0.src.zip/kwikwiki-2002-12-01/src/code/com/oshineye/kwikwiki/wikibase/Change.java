package com.oshineye.kwikwiki.wikibase;

import com.oshineye.kwikwiki.page.WikiPage;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 Represents a change to a page.
 */
public class Change implements Comparable {
    private static final SimpleDateFormat FORMATTER = new SimpleDateFormat("yyyy_MM_dd");
    private final String title;
    private final Date date;
    private final String day;
    private String editor;
    private static final int MILLISECONDS = 1000;

    public Change(WikiPage rawPage) {
        this.title = rawPage.getTitle();
        this.date = rawPage.getDate();
        this.day = Change.formatChangeDate(this.date);
        this.editor = rawPage.getLastEditor();
        if (this.editor == null) {
            this.editor = "";
        }
    }

    public Change(String title, Date date, String editor) {
        this.title = title;
        this.date = date;
        this.day = Change.formatChangeDate(this.date);
        this.editor = editor;
    }

    public Date getDate() {
        return this.date;
    }

    public String getDay() {
        return this.day;
    }

    public String getTitle() {
        return this.title;
    }

    public String getEditor() {
        return this.editor;
    }

    /**
     * If date is null return the empty string otherwise return a string
     * representation of date.
     */
    public static String formatChangeDate(Date date) {
        if (date == null) {
            return "";
        } else {
            return FORMATTER.format(date);
        }
    }

    public static Date parseChangeDay(String day) throws ParseException {
        return FORMATTER.parse(day);
    }

    public boolean equals(Object otherObject) {
        if ((otherObject == null) || (!(otherObject instanceof Change))) {
            return false;
        }

        Change otherChange = (Change) otherObject;
        return ((this.title.equals(otherChange.title))
                && (compareWithMillisecondPrecision(this.date, otherChange.date)));
    }

    private boolean compareWithMillisecondPrecision(Date thisDate, Date otherDate) {
        return thisDate.getTime() / MILLISECONDS == otherDate.getTime() / MILLISECONDS;
    }

    public int hashCode() {
        String hash = title + date.toString() + day + editor;
        return hash.hashCode();
    }

    public int compareTo(Change change) {
        return this.date.compareTo(change.date);
    }

    public int compareTo(Object obj) {
        return this.compareTo((Change) obj);
    }

    public String toString() {
        return title + "::" + date.getTime() + "::" + "::" + editor;
    }
}