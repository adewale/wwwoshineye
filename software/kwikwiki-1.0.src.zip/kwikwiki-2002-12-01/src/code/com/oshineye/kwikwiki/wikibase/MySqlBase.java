package com.oshineye.kwikwiki.wikibase;

import com.oshineye.kwikwiki.TunnellingException;
import com.oshineye.kwikwiki.config.Config;
import com.oshineye.kwikwiki.page.WikiPage;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.SortedSet;
import java.util.TreeSet;

/**
 * A WikiBase back-end implementation which stores WikiPages and Changes in a MySql Database.
 */
public class MySqlBase extends WikiBase {
    static {
        /*
		Load the database driver.
		Needed for Tomcat. WLS6.1 works fine without it.
		*/
        try {
            Class.forName("org.gjt.mm.mysql.Driver");
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    private static final String DELETE_PAGE = "delete from pages where title=?";
    private static final String INSERT_CHANGE
            = "insert into changes(title, time, last_editor) values(?, ?, ?)";
    private static final String INSERT_PAGE = "insert into pages values(?, ?, ?)";
    private static final String SELECT_CHANGES
            = "select * from changes where TO_DAYS(NOW()) - TO_DAYS(time) <= ?";
    private static final String SELECT_PAGE = "select * from pages where title=?";
    private static final String SELECT_PAGE_TITLE = "select title from pages where text like '%";
    private static final String SELECT_TITLES = "select title from pages";
    private static final String UPDATE_PAGE
            = "update pages set title=?, last_edit=?, text=? where title=?";

    private final String dbUrl;
    private final String userName;
    private final String password;

    protected MySqlBase() {
        Config config = Config.getInstance();
        this.dbUrl = config.getProperty("kwikwiki.persistence.mysql.url");
        this.userName = config.getProperty("kwikwiki.persistence.mysql.username");
        this.password = config.getProperty("kwikwiki.persistence.mysql.password");
    }

    protected WikiPage loadPage(String title) {
        WikiPage page = null;
        Connection conn = this.getConnection();
        PreparedStatement prep = null;
        ResultSet rset = null;

        try {
            prep = conn.prepareStatement(SELECT_PAGE);
            prep.setString(1, title);
            rset = prep.executeQuery();

            if (rset.next()) {
                page = new WikiPage(rset.getString("title"),
                        rset.getString("text"),
                        rset.getDate("last_edit"));
            }
        } catch (SQLException sqle) {
            throw new TunnellingException(sqle);
        } finally {
            this.release(conn, prep, rset);
		}

        return page;
    }

    protected void storePage(WikiPage page) {
        Connection conn = this.getConnection();
        PreparedStatement prep = null;

        try {
            prep = conn.prepareStatement(UPDATE_PAGE);
            prep.setString(1, page.getTitle());
            prep.setDate(2, new Date(page.getDate().getTime()));
            prep.setString(3, page.getText());
            prep.setString(4, page.getTitle());
            prep.executeUpdate();
        } catch (SQLException sqle) {
            throw new TunnellingException(sqle);
        } finally {
            this.release(conn, prep, null);
        }
    }

    protected void storeNewPage(WikiPage page) {
        Connection conn = this.getConnection();
        PreparedStatement prep = null;

        try {
            prep = conn.prepareStatement(INSERT_PAGE);
            prep.setString(1, page.getTitle());
            prep.setDate(2, new Date(page.getDate().getTime()));
            prep.setString(3, page.getText());
            prep.executeUpdate();
        } catch (SQLException sqle) {
            throw new TunnellingException(sqle);
        } finally {
            this.release(conn, prep, null);
        }
    }

    protected void storeChange(Change change) {
        Connection conn = this.getConnection();
        PreparedStatement prep = null;

        try {
            prep = conn.prepareStatement(INSERT_CHANGE);
            prep.setString(1, change.getTitle());
            prep.setTimestamp(2, new Timestamp(change.getDate().getTime()));
            prep.setString(3, change.getEditor());
            prep.executeUpdate();
        } catch (SQLException sqle) {
            throw new TunnellingException(sqle);
        } finally {
            this.release(conn, prep, null);
        }
    }

    protected SortedSet loadTitles() {
        SortedSet titles = new TreeSet();
        titles.addAll(loadAllTitles());
        return titles;
    }

    public ChangeLog[] getRecentChanges(int numberOfDays) {
        Map logMap = new HashMap();
        List allChanges = getChangesFromDb(numberOfDays);

        //create a map of the logs with the days as keys
        for (Iterator it = allChanges.iterator(); it.hasNext();) {
            Change currentChange = (Change) it.next();
            String currentDay = currentChange.getDay();

            List changes = (List) logMap.get(currentDay);
            if (changes == null) {
                changes = new LinkedList();
                logMap.put(currentDay, changes);
            }

            changes.add(currentChange);
        }

        //convert the lists of changes to an array of changelogs
        Collection changeLists = logMap.values();
        ChangeLog[] changeLogs = new ChangeLog[changeLists.size()];
        int i = 0;
        for (Iterator it = changeLists.iterator(); it.hasNext();) {
            List changes = (List) it.next();
            Change[] tempChanges = (Change[]) changes.toArray(new Change[0]);
            changeLogs[i] = new ChangeLog(tempChanges);
            i++;
        }

        return changeLogs;
    }

    private List getChangesFromDb(int numberOfDays) {
        List allChanges = new LinkedList();
        Connection conn = this.getConnection();
        PreparedStatement prep = null;
        ResultSet rset = null;

        //query the db
        try {
            prep = conn.prepareStatement(SELECT_CHANGES);
            prep.setInt(1, numberOfDays-1);//0 days is today
            rset = prep.executeQuery();

            while (rset.next()) {
                String title = rset.getString("title");
                java.util.Date date = new java.util.Date(rset.getTimestamp("time").getTime());
                String lastEditor = rset.getString("last_editor");
                Change change = new Change(title, date, lastEditor);
                allChanges.add(change);
            }
        } catch (SQLException sqle) {
            throw new TunnellingException(sqle);
        } finally {
            this.release(conn, prep, rset);
        }
        return allChanges;
    }

    public SortedSet locateWord(String word) {
        Connection conn = this.getConnection();
        PreparedStatement prep = null;
        ResultSet rset = null;
        SortedSet titles = new TreeSet();

        try {
            prep = conn.prepareStatement(SELECT_PAGE_TITLE + word + "%'");
            rset = prep.executeQuery();
            while (rset.next()) {
                titles.add(rset.getString("title"));
            }
        } catch (SQLException sqle) {
            throw new TunnellingException(sqle);
        } finally {
            this.release(conn, prep, rset);
        }
        return titles;
    }

    public void deletePage(String title) {
        getIndex().delete(title);

        deleteRow(title);

        //remove it from the list of pages
        super.removeTitle(title);
    }

    private void deleteRow(String title) {
        Connection conn = this.getConnection();
        PreparedStatement prep = null;

        try {
            prep = conn.prepareStatement(DELETE_PAGE);
            prep.setString(1, title);
            prep.executeUpdate();
        } catch (SQLException sqle) {
            throw new TunnellingException(sqle);
        } finally {
            this.release(conn, prep, null);
        }
    }

    private Connection getConnection() {
        Connection conn;
        try {
            //conn = DriverManager.getConnection("jdbc:mysql://localhost/kwikwiki", "", "");
            conn = DriverManager.getConnection(this.dbUrl, this.userName, this.password);
        } catch (SQLException sqle) {
            throw new TunnellingException(sqle);
        }
        return conn;
    }

    private void release(Connection conn, Statement stmt, ResultSet rset) {
        if (rset != null) {
            try {
                rset.close();
            } catch (SQLException sqle) {
                throw new TunnellingException(sqle);
            }
        }

        if (stmt != null) {
            try {
                stmt.close();
            } catch (SQLException sqle) {
                throw new TunnellingException(sqle);
            }
        }

        if (conn != null) {
            try {
                conn.close();
            } catch (SQLException sqle) {
                throw new TunnellingException(sqle);
            }
        }
    }

    private List loadAllTitles() {
        List titles = new LinkedList();
        Connection conn = this.getConnection();
        PreparedStatement prep = null;
        ResultSet rset = null;

        //query the db
        try {
            prep = conn.prepareStatement(SELECT_TITLES);
            rset = prep.executeQuery();

            while (rset.next()) {
                String title = rset.getString("title");
                titles.add(title);
            }
        } catch (SQLException sqle) {
            throw new TunnellingException(sqle);
        } finally {
            this.release(conn, prep, rset);
        }
        return titles;
    }
}
