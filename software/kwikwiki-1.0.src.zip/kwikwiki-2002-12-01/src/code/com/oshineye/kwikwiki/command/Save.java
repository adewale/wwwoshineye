package com.oshineye.kwikwiki.command;

import com.oshineye.kwikwiki.page.WikiPage;
import com.oshineye.kwikwiki.wikibase.WikiBase;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.Date;

public class Save extends Command {
    private static final String SAVE = "/saveTemplate.jsp";

    public void execute(HttpServletRequest req, HttpServletResponse resp,
                        ServletContext sc) throws Exception {
        System.err.println("==Executing save command==");

        String title = req.getParameter("title");
        String text = req.getParameter("text");
        WikiBase wikiBase = WikiBase.getInstance();

        if (isValid(title) && isValid(text)) {

            //save page with user identification
            //FIXME we should check for a user name cookie not just use the hostname
            WikiPage rawPage = new WikiPage(title, text, new Date(), req.getRemoteHost());
            wikiBase.savePage(rawPage);

            //go to save successful page
            this.include(SAVE, req, resp, sc);
        } else {
            //go to generic error page because this indicates programming error
            //not user error and should never happen
            this.include(Command.ERROR, req, resp, sc);
        }
    }

    private boolean isValid(String toTest) {
        return ((toTest != null) && (!toTest.equals("")));
    }
}
