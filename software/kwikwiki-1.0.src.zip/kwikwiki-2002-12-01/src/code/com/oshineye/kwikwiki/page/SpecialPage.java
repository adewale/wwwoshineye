package com.oshineye.kwikwiki.page;

public interface SpecialPage {
    public String getText();
}
