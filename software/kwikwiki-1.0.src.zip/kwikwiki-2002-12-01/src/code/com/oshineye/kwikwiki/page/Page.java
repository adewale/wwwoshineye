package com.oshineye.kwikwiki.page;

import com.oshineye.kwikwiki.markup.MarkUpEngine;
import com.oshineye.kwikwiki.wikibase.Change;
import com.oshineye.kwikwiki.wikibase.ChangeLog;
import com.oshineye.kwikwiki.wikibase.WikiBase;
import java.io.Serializable;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeMap;
import java.util.TreeSet;

/**
 An abstraction representing a page of data.
 This class fulfills all the criteria to be a JavaBean.
 */
public abstract class Page implements Serializable {
    //Use of self-encapsulation enables subclasses to override the behvaiour
    //of the constructors
    private String title;
    private String text;
    private boolean special;
    private static final int NUMBER_OF_CHANGES = 5;
    private static final int NUMBER_OF_RANDOM_PAGES = 7;
    private static final Map SPECIAL_PAGES = new TreeMap();

    static {
        SPECIAL_PAGES.put("WantedPages", new WantedPages());
        SPECIAL_PAGES.put("OrphanedPages", new OrphanedPages());

        SPECIAL_PAGES.put("TitleIndex", new SpecialPage() {
            public String getText() {
                String text = MarkUpEngine.convertToWikiList(WikiBase.getInstance().getAllTitles());
                return text;
            }
        });

        SPECIAL_PAGES.put("RecentChanges", new SpecialPage() {
            public String getText() {
                ChangeLog[] log = WikiBase.getInstance().getRecentChanges(NUMBER_OF_CHANGES);

                StringBuffer sb = new StringBuffer();
                //go through logs in reverse chronological order
                for (int i = log.length - 1; i >= 0; i--) {
                    ChangeLog currentLog = log[i];
                    Change[] changes = currentLog.getChanges();
                    sb.append(MarkUpEngine.convertToBold(currentLog.getDay())
                            + MarkUpEngine.LINE_ENDING);
                    sb.append(MarkUpEngine.convertChanges(changes));
                }

                return sb.toString();
            }
        });

        SPECIAL_PAGES.put("TodaysChanges", new SpecialPage() {
            public String getText() {
                ChangeLog[] log = WikiBase.getInstance().getRecentChanges(1);
                ChangeLog todaysLog = log[0];
                Change[] changes = todaysLog.getChanges();

                String text = MarkUpEngine.convertChanges(changes);
                String boldDay = MarkUpEngine.convertToBold(todaysLog.getDay());
                String header = boldDay + MarkUpEngine.LINE_ENDING;
                return header + text;
            }
        });

        SPECIAL_PAGES.put("SpecialPages", new SpecialPage() {
            public String getText() {
                return MarkUpEngine.convertToWikiList(SPECIAL_PAGES.keySet());
            }
        });

        SPECIAL_PAGES.put("RandomPages", new SpecialPage() {
            public String getText() {
                SortedSet randomTitles = new TreeSet();
                Random random = new Random();
                Object[] titles = WikiBase.getInstance().getAllTitles().toArray();

                for (int i = 0; i < NUMBER_OF_RANDOM_PAGES; i++) {
                    int randomIndex = random.nextInt(titles.length);
                    randomTitles.add(titles[randomIndex]);
                }

                return MarkUpEngine.convertToWikiList(randomTitles);
            }
        });


    }

    protected Page() {
    }

    protected Page(String title, String text) {
        this.setTitle(title);
        this.setText(text);
    }

    public String getTitle() {
        return title;
    }

    protected void setTitle(String title) {
        this.title = title;
    }

    public String getText() {
        return text;
    }

    protected void setText(String text) {
        this.text = text;
    }

    public boolean isSpecial() {
        return this.special;
    }

    protected void setSpecial(boolean special) {
        this.special = special;
    }

    public static boolean isSpecialPage(String title) {
        return SPECIAL_PAGES.containsKey(title);
    }

    public static WikiPage getSpecialPage(String title) {
        SpecialPage special = (SpecialPage) SPECIAL_PAGES.get(title);
        return WikiPage.createSpecialPage(title, special.getText());
    }

    public static Set getAllSpecialPages() {
        return SPECIAL_PAGES.keySet();
    }
}
