package com.oshineye.kwikwiki.command;

import com.oshineye.kwikwiki.page.HtmlPage;
import com.oshineye.kwikwiki.page.WikiPage;
import com.oshineye.kwikwiki.wikibase.WikiBase;
import com.oshineye.kwikwiki.markup.MarkUpEngine;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.Collection;

public class Search extends Command {
    public void execute(HttpServletRequest req, HttpServletResponse resp,
                        ServletContext sc) throws Exception {
        System.err.println("==Executing search command==");

        String word = req.getParameter("word");
        WikiBase wikiBase = WikiBase.getInstance();

        HtmlPage page;
        if ((word == null) || (word.equals(""))) {
            this.include("/defaultSearchHeader.jsp", req, resp, sc);
            this.include("/searchForm.jsp", req, resp, sc);
        } else {
            Collection items = wikiBase.locateWord(word);
            String text = MarkUpEngine.convertToWikiList(items);

            page = new HtmlPage(WikiPage.createSpecialPage(word, text));
            req.setAttribute("pageBean", page);

            this.include("/displayingResultsSearchHeader.jsp", req, resp, sc);
            this.include("/searchForm.jsp", req, resp, sc);
            this.include("/searchResults.jsp", req, resp, sc);
        }
        this.include("/readOnlyFooter.jsp", req, resp, sc);
    }
}
