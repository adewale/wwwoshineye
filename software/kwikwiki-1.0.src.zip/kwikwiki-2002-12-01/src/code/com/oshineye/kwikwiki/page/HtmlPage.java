package com.oshineye.kwikwiki.page;

import com.oshineye.kwikwiki.markup.MarkUpEngine;
import java.util.Date;

public class HtmlPage extends Page {
    private String lastEdited;

    public HtmlPage() {
    }

    /**
     * This constructor exists for situations where the calling method already
     *  has the text in html or does not wish the text to be further formatted.
     * @param title the title of the page
     * @param text the formatted text of the page
     */
    public HtmlPage(String title, String text) {
        super(title, text);
    }

    /**
     * This constructor takes in a page in wiki format and converts it's
     * contents into html.
     * @param rawPage the WikiPage that have it's text converted to html
     */
    public HtmlPage(WikiPage rawPage) {
        this.setTitle(rawPage.getTitle());

        String tempText = rawPage.getText();
        this.setText(MarkUpEngine.convertToHtml(tempText));

        Date date = rawPage.getDate();
        if (date == null) {
            this.lastEdited = "Unknown time";
        } else {
            this.lastEdited = date.toString();
        }

        this.setSpecial(rawPage.isSpecial());
    }

    public String getLastEdited() {
        return lastEdited;
    }

}
