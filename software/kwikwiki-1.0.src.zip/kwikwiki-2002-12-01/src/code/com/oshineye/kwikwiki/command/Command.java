package com.oshineye.kwikwiki.command;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

/**
 * An abstract factory that is used to instantiate it's various sub-classes.
 * It defines the contract that all commands must fulfill.
 */
public abstract class Command {
    protected static final String INVALID_TITLE = "/invalidTitle.jsp";
    protected static final String ERROR = "/error.jsp";
    protected static final String EDIT = "/editTemplate.jsp";
    protected static final String LIKE = "/likeTemplate.jsp";
    private static final Map PRELOADED_INSTANCES = new HashMap();

    //preload all the command class instances we'll be re-using
    static {
        PRELOADED_INSTANCES.put("View", new View());
        PRELOADED_INSTANCES.put("Edit", new Edit());
        PRELOADED_INSTANCES.put("Save", new Save());
        PRELOADED_INSTANCES.put("Create", new Create());
        PRELOADED_INSTANCES.put("Search", new Search());
        PRELOADED_INSTANCES.put("Like", new Like());
    }

    public static Command getCommand(String commandName) {
        return (Command) PRELOADED_INSTANCES.get(commandName);
    }

    protected void include(String resource, HttpServletRequest req,
                           HttpServletResponse resp, ServletContext sc)
            throws IOException, ServletException {
        RequestDispatcher rd = sc.getRequestDispatcher(resource);
        rd.include(req, resp);
    }

    public abstract void execute(HttpServletRequest req, HttpServletResponse resp,
                                 ServletContext sc) throws Exception;
}
