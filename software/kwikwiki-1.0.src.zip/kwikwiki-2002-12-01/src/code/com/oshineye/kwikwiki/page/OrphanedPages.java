package com.oshineye.kwikwiki.page;

import com.oshineye.kwikwiki.markup.MarkUpEngine;
import com.oshineye.kwikwiki.wikibase.WikiBase;
import java.util.SortedSet;
import java.util.TreeSet;
import java.util.Iterator;



public class OrphanedPages implements SpecialPage {
	public String getText() {
		return MarkUpEngine.convertToWikiList(this.getOrphanedPages());
	}

    SortedSet getOrphanedPages() {
        SortedSet wikiNames = WikiBase.getInstance().getAllTitles();

        SortedSet orphanedPages = new TreeSet();
        for (Iterator it = wikiNames.iterator(); it.hasNext();) {
            String wikiName = (String) it.next();
            if (this.isOrphanedPage(wikiName)) {
                orphanedPages.add(wikiName);
            }
        }
        return orphanedPages;
    }

    private boolean isOrphanedPage(String wikiName) {
		WikiBase wikiBase = WikiBase.getInstance();
        SortedSet occurrences = wikiBase.locateWord(wikiName);
        boolean hasOccurrences = occurrences.size() == 0;
        boolean isNotSpecial = !Page.isSpecialPage(wikiName);
        return (hasOccurrences && (wikiBase.pageExists(wikiName)) && isNotSpecial);
    }
}
