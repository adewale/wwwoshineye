package com.oshineye.kwikwiki.wikibase;

import com.oshineye.kwikwiki.markup.MarkUpEngine;
import com.oshineye.kwikwiki.page.Page;
import com.oshineye.kwikwiki.page.WikiPage;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;

/**
 * A class that provides indexing and searching services to implementations
 * of WikiBase.
 */
public class Index {
	/* 
	   A mapping from a word to the titles of the set of page it appears on.
	   For every word in the WikiBase this enables us to see which pages use it.
	*/
	private final HashMap reverseFileIndex;
	private final WikiBase wikiBase;
	private static final SortedSet EMPTY_SET = Collections.unmodifiableSortedSet(new TreeSet());

	public Index(WikiBase wikiBase) {
		this.reverseFileIndex = new HashMap();
		this.wikiBase = wikiBase;

		//add all non-special pages to the index
		for (Iterator it = wikiBase.getAllTitles().iterator(); it.hasNext();) {
			String title = (String) it.next();
			if (!Page.isSpecialPage(title)) {
				this.add(title);
			}
		}
	}

	public void add(String title) {
		WikiPage rawPage = wikiBase.loadPage(title);
		String text = rawPage.getText();
		Set words = tokenize(text);

		this.addPageToIndexes(title, words);
	}

	public SortedSet getLocations(String word) {
		if (this.reverseFileIndex.containsKey(word)) {
			return (SortedSet) this.reverseFileIndex.get(word);
		} else {
			return EMPTY_SET;
		}
	}

	private HashSet tokenize(String text) {
		String[] words = text.split("\\W");

		HashSet set = new HashSet();
		for (int i = 0; i < words.length; i++) {
			set.add(words[i]);
		}
		return set;
	}

	public void update(String title, String oldText, String newText) {
		HashSet oldWords = this.tokenize(oldText);
		HashSet newWords = this.tokenize(newText);

		//identify set of words that are in old text but not in new text
		Set oldWordsToRemove = (Set) oldWords.clone();
		oldWordsToRemove.removeAll(newWords);

		//remove this page from the indexes for those words
		this.removeTitle(oldWordsToRemove, title);

		//identify words that are in new text but not in old text
		newWords.removeAll(oldWords);

		//add this page to their indexes
		this.addPageToIndexes(title, newWords);
	}

	private void removeTitle(Set words, String title) {
		for (Iterator it = words.iterator(); it.hasNext();) {
			String word = (String) it.next();
			if (this.reverseFileIndex.containsKey(word)) {
				Set titles = (Set) this.reverseFileIndex.get(word);
				titles.remove(title);
			}
		}
	}

	private void addPageToIndexes(String title, Set words) {
		for (Iterator it = words.iterator(); it.hasNext();) {
			Object word = it.next();
			if (this.reverseFileIndex.containsKey(word)) {
				Set titles = (Set) this.reverseFileIndex.get(word);
				titles.add(title);
			} else {
				Set titles = new TreeSet();
				titles.add(title);
				this.reverseFileIndex.put(word, titles);
			}
		}
	}

	/**
	 * Get the all the words in the WikiBase which happen to be wiki names.
	 *
	 * @return a <code>Set</code> of Strings which are all the wiki names in the WikiBase
	 */
	public Set getWikiNames() {
		Set wikiNames = new HashSet();
		for (Iterator it = reverseFileIndex.keySet().iterator(); it.hasNext();) {
			String word = (String) it.next();

			if (MarkUpEngine.isWikiName(word)) {
				wikiNames.add(word);
			}
		}
		return wikiNames;
	}

	/**
	 * Delete the contents of page named <code>title</code> from the index
	 * @param title the name of the page which will be removed from the index
	 */
	public void delete(String title) {
		String oldText = wikiBase.loadPage(title).getText();
		HashSet oldWords = tokenize(oldText);

		this.removeTitle(oldWords, title);
	}
}
