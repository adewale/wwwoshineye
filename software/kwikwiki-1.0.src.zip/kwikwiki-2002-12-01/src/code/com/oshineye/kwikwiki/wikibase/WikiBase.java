package com.oshineye.kwikwiki.wikibase;

import com.oshineye.kwikwiki.TunnellingException;
import com.oshineye.kwikwiki.config.Config;
import com.oshineye.kwikwiki.page.Page;
import com.oshineye.kwikwiki.page.WikiPage;
import java.util.Iterator;
import java.util.SortedSet;
import java.util.TreeSet;

/**
 * A Singleton class which represents the persistence store for this Wiki.
 * Because it's abstract the actual singleton is an instance of a concrete class.
 */
public abstract class WikiBase {
    private static WikiBase instance;
    private SortedSet allTitles;
    private Index index;

    public static WikiBase getInstance() {
        if (instance == null) {
            instance = makeInstance();
        }

        return instance;
    }

    private static WikiBase makeInstance() {
        String impl = Config.getInstance().getProperty("kwikwiki.persistence");
        try {
            return (WikiBase) Class.forName(impl).newInstance();
        } catch (ClassNotFoundException cnfe) {
            throw new TunnellingException(cnfe);
        } catch (InstantiationException ie) {
            throw new TunnellingException(ie);
        } catch (IllegalAccessException iae) {
            throw new TunnellingException(iae);
        }
    }

    private void createIndex() {
        this.index = new Index(this);
    }

    public Index getIndex() {
        if (this.index==null) {
            this.createIndex();
        }
        return this.index;
    }

    public WikiPage getPage(String title) {
        WikiPage rawPage;
        if (Page.isSpecialPage(title)) {
            rawPage = Page.getSpecialPage(title);
        } else {
            rawPage = this.loadPage(title);
        }
        return rawPage;
    }


    public void savePage(WikiPage rawPage) {
        String title = rawPage.getTitle();
        if (!this.pageExists(title)) {
            storeNewPage(rawPage);

            allTitles.add(title);
            this.getIndex().add(title);
        } else {
            String newText = rawPage.getText();
            String oldText = this.loadPage(title).getText();
            this.getIndex().update(title, oldText, newText);

            storePage(rawPage);
        }
        storeChange(new Change(rawPage));
    }

    /**
     Return a SortedSet of the titles of all the pages
     in this Wiki.
     */
    public SortedSet getAllTitles() {
        if (this.allTitles == null) {
            //prepare title set
            this.allTitles = this.loadTitles();
            this.allTitles.addAll(Page.getAllSpecialPages());
        }
        return allTitles;
    }

    protected void removeTitle(String title) {
        this.getAllTitles().remove(title);
    }

    public boolean pageExists(String title) {
        return this.getAllTitles().contains(title);
    }

    public SortedSet getTitlesStartingWith(String word) {
        //obtain set of titles that begin with the word
        SortedSet shareWord = new TreeSet();
        for (Iterator it = this.getAllTitles().iterator(); it.hasNext();) {
            String candidateTitle = (String) it.next();
            if (candidateTitle.startsWith(word)) {
                shareWord.add(candidateTitle);
            }
        }
        return shareWord;
    }

    public SortedSet getTitlesEndingWith(String word) {
        //obtain set of titles that end with the word
        SortedSet shareWord = new TreeSet();
        for (Iterator it = this.getAllTitles().iterator(); it.hasNext();) {
            String candidateTitle = (String) it.next();
            if (candidateTitle.endsWith(word)) {
                shareWord.add(candidateTitle);
            }
        }
        return shareWord;
    }

    protected abstract WikiPage loadPage(String title);

    /**
     * Store an updated version of a pre-existing page.
     */
    protected abstract void storePage(WikiPage rawPage);

    protected abstract void storeNewPage(WikiPage rawPage);

    protected abstract void storeChange(Change change);

    protected abstract SortedSet loadTitles();

    /**
     * Get an array of ChangeLogs for the last numberOfDays. The number of days
     * must be greater than 0.
     */
    public abstract ChangeLog[] getRecentChanges(int numberOfDays);

    /**
     * Return a SortedSet of Strings representing the titles of the pages that
     * contain the word
     */
    public abstract SortedSet locateWord(String word);

    public abstract void deletePage(String title);

}
