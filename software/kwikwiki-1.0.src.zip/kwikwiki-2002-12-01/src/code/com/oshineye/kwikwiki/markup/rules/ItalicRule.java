package com.oshineye.kwikwiki.markup.rules;

public class ItalicRule extends MarkUpRule {
	private static final String PATTERN = "'{2}(.*?)'{2}";
	private static final String REPLACEMENT_TEXT = "<i>$1</i>";

    public ItalicRule() {
        super(ItalicRule.PATTERN, ItalicRule.REPLACEMENT_TEXT);
    }
}