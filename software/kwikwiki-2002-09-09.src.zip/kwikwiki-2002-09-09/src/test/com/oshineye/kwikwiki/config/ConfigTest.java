package com.oshineye.kwikwiki.config;

import junit.framework.Test;
import junit.framework.TestSuite;
import junit.framework.TestCase;

public class ConfigTest extends TestCase {
	private Config config = Config.getInstance();

	public static void main(java.lang.String[] args) {
	    junit.textui.TestRunner.run(suite());
	}

	public static Test suite() {
	    TestSuite suite = new TestSuite(ConfigTest.class);

	    return suite;
	}

	public void testGetInstance() {
		assertNotNull(Config.getInstance());
		Object obj1 = Config.getInstance();
		Object obj2  = Config.getInstance();
		assertTrue(obj1.equals(obj2));
		assertTrue(obj1 == obj2);
	}

	public void testGetProperty() {
		assertNull(config.getProperty(null));
		assertNull(config.getProperty("non-existent-property"));
		assertNotNull(config.getProperty("user.home"));
	}

	public void testGetPropertyWithDefaults() {
		assertNotNull(config.getProperty(null, "DefaultString"));
		assertEquals(config.getProperty("non-existent-property", "DefaultString"),
		        "DefaultString");

	}
}
