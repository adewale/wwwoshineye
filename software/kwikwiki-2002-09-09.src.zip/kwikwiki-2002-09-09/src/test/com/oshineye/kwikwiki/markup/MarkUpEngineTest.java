package com.oshineye.kwikwiki.markup;

import junit.framework.*;

public class MarkUpEngineTest extends TestCase {
    
    public static void main(java.lang.String[] args) {
        junit.textui.TestRunner.run(suite());
    }
    
    public static Test suite() {
        TestSuite suite = new TestSuite(MarkUpEngineTest.class);
        
        return suite;
    }
	
	public void testIsWikiName() {
		assertFalse(MarkUpEngine.isWikiName("helloworld"));
		assertFalse(MarkUpEngine.isWikiName(""));
		assertFalse(MarkUpEngine.isWikiName(null));
		assertTrue(MarkUpEngine.isWikiName("HelloWorld"));
    }
	
	public void testConvertToHtml() {
		String testString = "StartingPoints is a link but thisIsNotALink and ThisPageDoesNotExist.";
		String expectedResult = "<a href=\"View?title=StartingPoints\">StartingPoints</a> is a link but thisIsNotALink and ThisPageDoesNotExist<a href=\"Create?title=ThisPageDoesNotExist\">?</a>.";
		String realResult = MarkUpEngine.convertToHtml(testString);

		assertTrue("Text wasn't properly converted", realResult.equals(expectedResult));
	}
}