package com.oshineye.kwikwiki.wikibase;

import com.oshineye.kwikwiki.page.RawPage;
import com.oshineye.kwikwiki.page.Page;
import java.util.SortedSet;
import java.util.Collections;

/**
A Singleton class which represents the persistence store for this Wiki.
Because it's abstract the actual singleton is an instance of a conrete class.
*/
public abstract class WikiBase {
	private static WikiBase instance;
	private final SortedSet allTitles;

	protected WikiBase() {
		allTitles = loadTitles();
		
		//add special pages to the set of titles
		allTitles.addAll(Page.getAllSpecialPages());
	}
		
	public static WikiBase getInstance() {
		if (instance == null) {
			instance = new FileBase();
		}
		return instance;
	}
	
	public RawPage getPage(String title) {
		RawPage rawPage;
		if (Page.isSpecialPage(title)) {
			rawPage = Page.getSpecialPage(title);
		} else {
			rawPage = this.loadPage(title);
		}
		return rawPage;
	}

	
	public void savePage(RawPage rawPage) {
		String title = rawPage.getTitle();
		if (!this.pageExists(title)) {
			allTitles.add(title);
			storeNewPage(rawPage);
		} else {		
			storePage(rawPage);
		}
		storeChange(new Change(rawPage));
	}

	/**
	Return a SortedSet of the titles of all the pages
	in this Wiki.
	*/
	public SortedSet getAllTitles() {
		return Collections.unmodifiableSortedSet(allTitles);
	}

	public void removeTitle(String title) {
		this.allTitles.remove(title);
	}

	public boolean pageExists(String title) {
		return allTitles.contains(title);
	}

	protected abstract RawPage loadPage(String title);

	/**
	* Store an updated version of a pre-existing page.
	*/
	protected abstract void storePage(RawPage rawPage);
	
	protected abstract void storeNewPage(RawPage rawPage);
	
	protected abstract void storeChange(Change change);
	
	protected abstract SortedSet loadTitles();

	/**
	 * Get an array of ChangeLogs for the last numberOfDays. The number of days
	 * must be greater than 0.
	 */
	public abstract ChangeLog[] getRecentChanges(int numberOfDays);
	
	/**
	* Return a SortedSet of Strings representing the titles of the pages that
	* contain the word
	*/
	public abstract SortedSet locateWord(String word);

	public abstract SortedSet getWantedPages();

	public abstract SortedSet getTitlesStartingWith(String word);

	public abstract SortedSet getTitlesEndingWith(String word);
	
	public abstract void deletePage(String title);

	public abstract SortedSet getOrphanedPages();
}
