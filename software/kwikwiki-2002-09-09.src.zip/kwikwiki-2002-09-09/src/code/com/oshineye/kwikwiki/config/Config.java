package com.oshineye.kwikwiki.config;

public class Config {
	private static Config instance;

	private Config() {
	}

	public static Config getInstance() {
		if (instance == null) {
			instance = new Config();
		}
		return instance;
	}

	public String getProperty(String name) {
		if (name == null) {
			return null;
		} else {
			return System.getProperty(name);
		}
	}

	public String getProperty(String name, String defaultValue) {
		String result = this.getProperty(name);
		if (result == null) {
			return defaultValue;
		} else {
			return result;
		}
	}
}
