package com.oshineye.kwikwiki.command;

import com.oshineye.kwikwiki.markup.MarkUpEngine;
import com.oshineye.kwikwiki.page.RawPage;
import com.oshineye.kwikwiki.wikibase.WikiBase;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Edit extends Command {
	public void execute(HttpServletRequest req, HttpServletResponse resp, 
						ServletContext sc) throws Exception {
		System.err.println("==Executing edit command==");

        String title = req.getParameter("title");
		WikiBase wikiBase = WikiBase.getInstance();
		
		if (MarkUpEngine.isWikiName(title)) {
			
			if (wikiBase.pageExists(title)) {
				RawPage page = wikiBase.getPage(title);
				req.setAttribute("pageBean", page);
				this.include(Command.EDIT, req, resp, sc);
			} else {
				//title is valid wikiName but page doesn't exist
				Command action = Command.getCommand("Create");
				action.execute(req, resp, sc);
			}
			
		} else {
			//go to invalid page title error page
			this.include(Command.INVALID_TITLE, req, resp, sc);
		}
	}
}
