package com.oshineye.kwikwiki.page;

import com.oshineye.kwikwiki.wikibase.WikiBase;
import com.oshineye.kwikwiki.wikibase.ChangeLog;
import com.oshineye.kwikwiki.wikibase.Change;
import com.oshineye.kwikwiki.markup.MarkUpEngine;

import java.io.Serializable;
import java.util.Map;
import java.util.HashMap;
import java.util.SortedSet;
import java.util.Set;
import java.util.Random;
import java.util.Arrays;
import java.util.TreeSet;

/**
An abstraction representing a page of data. 
This class fulfills all the criteria to be a JavaBean.
*/
public abstract class Page implements Serializable {
	//Use of self-encapsulation enables subclasses to override the behvaiour
	//of the constructors
	private String title;
	private String text;
	private boolean special;
	private static final int DEFAULT_AMOUNT_OF_CHANGES = 5;
	public static final int DEFAULT_NUMBER_OF_RANDOM_PAGES = 7;
	private static Map specialPages = new HashMap();

	static {
		specialPages.put("WantedPages", new SpecialPage(){
		        public String getText() {
			        SortedSet wantedPages = WikiBase.getInstance().getWantedPages();
					return MarkUpEngine.convertToWikiList(wantedPages);
		        }
		});

		specialPages.put("TitleIndex", new SpecialPage() {
				public String getText() {
					String text = MarkUpEngine.convertToWikiList(WikiBase.getInstance().getAllTitles());
					return text;
				}
		});

		specialPages.put("RecentChanges", new SpecialPage() {
			public String getText() {
					ChangeLog[] log = WikiBase.getInstance().getRecentChanges(DEFAULT_AMOUNT_OF_CHANGES);

					StringBuffer sb = new StringBuffer();

					//go through logs in reverse chronological order
					for (int i=log.length-1; i>=0; i--) {
						ChangeLog currentLog = log[i];
						Change[] changes = currentLog.getChanges();
						String header = MarkUpEngine.convertToBold(currentLog.getDay()) + MarkUpEngine.LINE_ENDING;
						sb.append(header);
						sb.append(MarkUpEngine.convertChanges(changes));
					}

					return sb.toString();
			}
		});

		specialPages.put("TodaysChanges", new SpecialPage() {
			public String getText() {
				ChangeLog[] log = WikiBase.getInstance().getRecentChanges(1);
				ChangeLog todaysLog = log[0];
				Change[] changes = todaysLog.getChanges();

				String text = MarkUpEngine.convertChanges(changes);
				String header = MarkUpEngine.convertToBold(todaysLog.getDay()) + MarkUpEngine.LINE_ENDING;
				return header + text;
			}
		});

		specialPages.put("SpecialPages", new SpecialPage() {
			public String getText() {
				Object[] keys = specialPages.keySet().toArray();
				Arrays.sort(keys);
				return MarkUpEngine.convertToWikiList(Arrays.asList(keys));
			}
		});

		specialPages.put("RandomPages", new SpecialPage() {
			public String getText() {
				SortedSet randomTitles = new TreeSet();
				Random random = new Random();
				Object[] titles = WikiBase.getInstance().getAllTitles().toArray();

				for (int i=0; i<DEFAULT_NUMBER_OF_RANDOM_PAGES; i++) {
					int randomIndex = random.nextInt(titles.length);
					randomTitles.add(titles[randomIndex]);
				}

				return MarkUpEngine.convertToWikiList(randomTitles);
			}
		});

		specialPages.put("OrphanedPages", new SpecialPage() {
			public String getText() {
				return MarkUpEngine.convertToWikiList(WikiBase.getInstance().getOrphanedPages());
			}
		});
	}

	protected Page() {
	}

	protected Page(String title, String text) {
		this.setTitle(title);
		this.setText(text);
	}
	
	public String getTitle() {
		return title;
	}
	
	protected void setTitle(String title) {
		this.title = title;
	}
	
	public String getText() {
		return text;
	}
	
	protected void setText(String text){
		this.text = text;
	}

	public boolean isSpecial() {
		return this.special;
	}

	protected void setSpecial(boolean special) {
		this.special = special;
	}

	public static boolean isSpecialPage(String title) {
        return specialPages.containsKey(title);
	}

	public static RawPage getSpecialPage(String title) {
		SpecialPage special = (SpecialPage)specialPages.get(title);
		return new RawPage(title, special.getText(), true);
	}

	public static Set getAllSpecialPages() {
		return specialPages.keySet();
	}
}
