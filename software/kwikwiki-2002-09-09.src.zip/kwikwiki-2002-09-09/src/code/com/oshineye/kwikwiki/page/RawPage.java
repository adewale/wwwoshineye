package com.oshineye.kwikwiki.page;

import com.oshineye.kwikwiki.markup.MarkUpEngine;

import java.util.Date;
import java.util.Collection;

/**
A class that represent a page's raw unformatted data.
It also keeps track of when it was created and who last edited it.
This class fulfills all the criteria to be a JavaBean.
*/
public class RawPage extends Page {
	private Date date;
	private String lastEditor;

	public RawPage() {
	}

	public RawPage(String title, String text, Date date) {
		this(title, text, date, null, false);
	}

	public RawPage(String title, String text, boolean special) {
		this(title, text, null, null, special);
	}

	public RawPage(Collection items) {
		this(null, MarkUpEngine.convertToWikiList(items), null, null, true);
	}

	public RawPage(String title, String text, Date date, String lastEditor) {
		this(title, text, date, lastEditor, false);
	}

	public RawPage(String title, String text, Date date, String lastEditor, boolean special) {
		super(title, text);
		this.date = date;
		this.lastEditor = lastEditor;
		this.setSpecial(special);
	}

	public Date getDate() {
		return this.date;
	}

	public String getLastEditor() {
		return this.lastEditor;
	}
}
