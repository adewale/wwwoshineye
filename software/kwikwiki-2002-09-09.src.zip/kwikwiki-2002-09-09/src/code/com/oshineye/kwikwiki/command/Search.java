package com.oshineye.kwikwiki.command;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.oshineye.kwikwiki.wikibase.WikiBase;
import com.oshineye.kwikwiki.page.HtmlPage;
import com.oshineye.kwikwiki.page.RawPage;

public class Search extends Command {
	public void execute(HttpServletRequest req, HttpServletResponse resp,
						ServletContext sc) throws Exception {
		System.err.println("==Executing search command==");

        String word = req.getParameter("word");
		WikiBase wikiBase = WikiBase.getInstance();

		HtmlPage page;
		if ((word == null) || (word.equals(""))){
			this.include("/defaultSearchHeader.jsp", req, resp, sc);
			page = new HtmlPage();
		} else {
			req.setAttribute("word", word);
			this.include("/displayingResultsSearchHeader.jsp", req, resp, sc);
			page = new HtmlPage(new RawPage(wikiBase.locateWord(word)));
		}

		req.setAttribute("pageBean", page);
		this.include("/searchTemplate.jsp", req, resp, sc);
		this.include("/readOnlyFooter.jsp", req, resp, sc);
	}
}
