package com.oshineye.kwikwiki.markup;


import com.oshineye.kwikwiki.wikibase.WikiBase;
import com.oshineye.kwikwiki.wikibase.Change;

import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MarkUpEngine {
	//original link pattern from WardsWiki
	//((upper case letterthen 1 or more lower case letters) at least 2 times)
	//private static final Pattern LINK_PATTERN = Pattern.compile("\\b([A-Z][a-z]+){2,}\\b");
	
	//mutant link pattern used by kwikwiki to enable use of J2eeConsultant as a wiki name
	//((upper case letter then (1 or more lower case letters or numbers)) at least 2 times)
	private static final Pattern LINK_PATTERN = Pattern.compile("\\b([A-Z][a-z0-9]+){2,}\\b");

	/* 
	The order of the mark-up rules is important : patterns that operate on
	whole lines have to come first, there's also a tiny wrinkle caused
	by the side-effects of replacing the _whole_ of a blank-line with
	<br><br>. The /n is removed and subsequent matches behave
	strangely.  Since the only things affected by this are lists I've
	made them the first rules so that they're safe.
	Basically patterns that have side-effects on successive patterns are last.
	*/
	private static final MarkUpRule[] WIKI_MARKUP_RULES = {
		//inline link
		new MarkUpRule("([a-zA-Z]{3,}://([\\S]+))", "<a href=\"$1\">$1</a>"),
		/*1 blank, 1 star and some text*/
		new MarkUpRule("^(\\s){1}(\\*)(.*)", "<span class=\"listItem\">$3</span>"),
		/*2 blanks, 1 star and some text*/
		new MarkUpRule("^(\\s){2}(\\*)(.*)", "<span class=\"listItem2\">$3</span>"),
		/*3 blanks, 1 star and some text*/
		new MarkUpRule("^(\\s){3}(\\*)(.*)", "<span class=\"listItem3\">$3</span>"),
		/*Replace 4 dashes at start of line with an hr tag*/
		new MarkUpRule("^----", "<hr>"),
		new MarkUpRule("^\\s*$", "<br><br>"),
		new MarkUpRule("'{5}(.*?)'{5}", "<b><i>$1</i></b>"),//bold and italic
		new MarkUpRule("'{3}(.*?)'{3}", "<b>$1</b>"),//bold
		new MarkUpRule("'{2}(.*?)'{2}", "<i>$1</i>")//italic
	};
	private static final String BOLD = "'''";
	private static final String ELLIPSIS = "&nbsp;.&nbsp;.&nbsp;.&nbsp;";

	//We always use unix line-endings
	public static final String LINE_ENDING = "\n";
	private static final String LIST_START = " * ";

	public static String convertToHtml(CharSequence text) {
		CharSequence tempResult = processWikiNames(text);
		CharSequence result = processMarkUp(tempResult);
		return result.toString();
	}
	
	private static CharSequence processWikiNames(CharSequence text) {
		Matcher m = LINK_PATTERN.matcher(text);
		StringBuffer htmlText = new StringBuffer();

		WikiBase wikiBase = WikiBase.getInstance();
		while (m.find()) {
			if (wikiBase.pageExists(m.group())) {
				m.appendReplacement(htmlText, "<a href=\"View?title=$0\">$0</a>");
			} else {
				m.appendReplacement(htmlText, "$0<a href=\"Create?title=$0\">?</a>");
			}
		}
		m.appendTail(htmlText);
		return htmlText;
	}
	
	private static CharSequence processMarkUp(CharSequence text) {
		for (int i = 0, length = WIKI_MARKUP_RULES.length; i < length; i++) {
			text = processGenericMarkup(text, WIKI_MARKUP_RULES[i]);
		}
		return text;
	}
	
	private static CharSequence processGenericMarkup(CharSequence text, MarkUpRule rule) {
		Pattern pattern = rule.getPattern();
		Matcher m = pattern.matcher(text);
		
		if (m.find()) {//only process if there are matches
			return m.replaceAll(rule.getReplacementText());
		} else {
			return text;//no matches so return original
		}
	}

	public static boolean isWikiName(String title) {
		if ((title == null) || title.equals("")) {
			return false;
		}
		
		Matcher m = LINK_PATTERN.matcher(title);
		return m.matches();
	}

	public static String convertToBold(CharSequence sequence) {
		return BOLD + sequence + BOLD;
	}

	public static String convertToWikiList(Collection items) {
		StringBuffer wikiList = new StringBuffer();
		for (Iterator it=items.iterator(); it.hasNext();) {
			String line = (String) it.next();
			wikiList.append(LIST_START + line + LINE_ENDING);
		}
		return wikiList.toString();
	}

	public static String convertChanges(Change[] changes) {
		List lines = new ArrayList(changes.length);
		for (int i=0; i<changes.length; i++) {
			Change item = changes[i];
			String line = item.getTitle() + ELLIPSIS + item.getEditor();
			lines.add(line);
		}

		return MarkUpEngine.convertToWikiList(lines);
	}
}
