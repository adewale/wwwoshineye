package com.oshineye.kwikwiki.markup;

import java.util.regex.Pattern;

/**
A class that encapsulates a pairing of a regular expression pattern and the text that 
should replace it. Taken together these form a markup rule that defines the 
meaning of the language used on a wiki page.
*/
public class MarkUpRule {
	private Pattern pattern;
	private String replacementText;

	/**
	Construct a MarkUpRule and specify that it uses multi-line mode
	*/
	public MarkUpRule(String regularExpression, String replacementText) {
		this.pattern = Pattern.compile(regularExpression, Pattern.MULTILINE);
		this.replacementText = replacementText;
	}

	public Pattern getPattern() {
		return this.pattern;
	}
	
	public String getReplacementText() {
		return this.replacementText;
	}
}