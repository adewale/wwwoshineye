KwikWiki
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
KwikWiki is an implementation of Ward Cunningham's WikiWikiWeb idea. In other
words it is a web-based collaborative hypertext environment. 
It's written in Java and makes use of features from Java 1.4 such as regular
expressions. The author is Adewale Oshineye.

I can be reached via my website at www.oshineye.com.

The website for KwikWiki itself is at:
http://www.oshineye.com/software/kwikwiki.html

New builds tend to go up when there's been some change worth sharing.

KwikWiki is deliberately designed to use new technologies, such as Java 
1.4, Servlets 2.3 and lots of CSS2. Good free implementations are available
if you need them. Sun's JDK1.4, Jakarta Tomcat and Mozilla are all you need.

If that's unacceptable then I suggest taking a look at either MoinMoin or
Gareth Cronin's VeryQuickWiki.


Installation instructions
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Before installing make sure you have installed and properly
configured:
*	Java 1.4
*	An app server/servlet engine such as Tomcat or BEA
Weblogic. I've tested KwikWiki on Tomcat 4.0.2 (under Windows and
Linux), Weblogic 6.1 (SP1 and SP2 under Windows 2000) and Weblogic 7.0
(under Windows 2000).  
* A MySql database. This is only necessary if you wish to use the database
back-end to store your files

1--Unzip the file you downloaded. If you downloaded the binary version
then you will have a war file. Deploy that to your app-server using
whatever technique you feel is appropriate. That may involve copying
the war across to a deployment directory or using some kind of GUI
tool.

2--Decide if you wish to store your files in a directory or in a database.

2-1-Storing files in a directory
After deploying the war file, copy across the kwikwiki-data
folder to your home directory. This is the same as the standard java
property user.home.  Unix users can just copy it to ~/yourUserName.
Windows users will have more problems. 
On Windows 2000 your home directory is C:\Documents and Settings\yourUserName\.
On Windows NT your home directory is C:\WINNT\profiles\yourUserName\

Your home directory should now contain a folder called kwikwiki-data.

2-2-Storing files in a mySql database
Go to mySql and create a database. Use the create statements in mysql.ddl to create the  
tables. Ignore any lines that begin with --
Create a file called kwikwiki.properties in your home directory.
Add the following lines to it:
	kwikwiki.persistence=com.oshineye.kwikwiki.wikibase.MySqlBase
	kwikwiki.persistence.db.url=jdbc:mysql://yourdbserver/yourdbname
	kwikwiki.persistence.db.username=yourusername
	kwikwiki.persistence.db.password=yourpassword

Replace "yourdbserver" with the name of your database server, yourdbname with 
the name of your database, yourusername with your username on that database 
and yourpassword with your password.


Start a web browser and visit:
http://yourServerName:yourPort/kwikwiki/View?title=StartingPoints

Enjoy.


Upgrading to KwikWiki 2.0 for MySql users
~~~~~~~~~~~~~~~~~~~~~~~~~
1-All the tables now use the BIGINT type to store unixtime (milliseconds since 1970)
thus ensuring consistency with other back-ends.
2-You have to alter your property file. The names are no longer in the form 
[kwikwiki.persistence.mysql.url=jdbc:mysql://yourdbserver/yourdbname] but 
[kwikwiki.persistence.dbl.url=jdbc:mysql://yourdbserver/yourdbname]. The 
reference to mysql has been replaced with "db" to make it easier to support other
databases.
3-You have to add another table for revision information to support the page history
functionality. The new create statement has been added to the mysql.ddl file.


Design and implementation questions
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Q:	What package was used to produce the (sadly out of date) UML diagrams?
A:	Dia (http://www.lysator.liu.se/~alla/dia) was used to create the .dia file 
and the png version. It's a free, open source, cross-platform tool.



FAQ
~~~
Q: I've upgraded to 2.0, I'm using the file-based back-end and I'm getting errors when 
	I try to access anything to do with revision control.
A: Make sure that there's a folder called "history" under the kwikwiki/metadata directory.

Q: What external libraries does KwikWiki require to build from source?
A: OsCache 1.7.5, MockObjects 0.0.9 and Java 1.4 (the MySql drivers are optional)

Q: How do I customise KwikWiki's web pages?
A: The kwikwiki.properties file enables you to customise the name of your wiki. This will 
change what shows up as the header on your pages. You can also open the war file that
comes with binary release. Just alter the CSS file in there and save it back. Or you could
just alter the JSP pages directly.