package com.oshineye.kwikwiki.wikibase;

public class MySqlBaseTest extends AbstractWikiBaseTest {
    public AbstractWikiBase createWikiBase() {
        return new MySqlBase();
    }
}
