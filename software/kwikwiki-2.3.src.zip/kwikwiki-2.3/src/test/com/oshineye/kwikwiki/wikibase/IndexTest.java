package com.oshineye.kwikwiki.wikibase;

import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;

import junit.framework.TestCase;

import com.oshineye.kwikwiki.KwikWikiTestUtils;


public class IndexTest extends TestCase {
    public void testCaseInsensitiveSearching() {
        Index index = getIndexWithNewPage();

        //do a search for various mixed-case spellings
        Set locations1 = index.getLocationsCaseInsensitive("kwikwiki");
        Set locations2 = index.getLocationsCaseInsensitive("KwIkwIki");

        //assert that we find at least one mention of "kwikwiki"
        assertTrue(locations1.size() > 0);

        //assert that they all give the same results
        assertEquals("Case-insensitive search results differed", locations1, locations2);

        //assert that when we search for something case-insensitively we get at least as many
        //results back as if we search case-sensitively
        assertTrue(index.getLocations("KwikWiki").size() <= locations1.size());
    }

    private Index getIndexWithNewPage() {
        //create an index
        Index index = new Index(new TreeSet());

        //add kwikwiki and KwikWiki to it
        WikiPage page = KwikWikiTestUtils.createTestPage();
        index.add(page.getTitle(), "kwikwiki");

        return index;
    }

    public void testDelete() {
        Index index = getIndexWithNewPage();

        Set locationsAtBeginning = index.getLocations("kwikwiki");
        int numberOfLocationsAtStart = locationsAtBeginning.size();

        index.delete(KwikWikiTestUtils.TEST_PAGE_TITLE, "kwikwiki");

        Set locationsAtEnd = index.getLocations("kwikwiki");

        assertTrue(numberOfLocationsAtStart > 0);

        String msg = "The number of occurrences did not shrink after deletion";
        assertTrue(msg, numberOfLocationsAtStart > locationsAtEnd.size());
        
        assertFalse(index.getAllTitles().contains(KwikWikiTestUtils.TEST_PAGE_TITLE));
    }
    
    public void testUpdate() {
		Index index = new Index(new TreeSet());
		index.add("TestPage", "WordThatDoesNotExist test text");
    	index.update("TestPage", "WordThatDoesNotExist test text", "text");
    	assertFalse("Index didn't update properly", index.getAllWordsInWiki().contains("WordThatDoesNotExist"));
    }
    
    public void testGetAllTitles() {
		Index index = getIndexWithNewPage();
		SortedSet allTitles = index.getAllTitles();
		assertNotNull(allTitles);
		assertTrue("Not enough titles in allTitles", allTitles.size() >= 1);
    }
    
    public void testAdd() {
		Index index = new Index(new TreeSet());

		index.add("TestPage", "test text");
		assertTrue(index.getAllTitles().contains("TestPage"));
		assertTrue(index.getLocations("test").contains("TestPage"));
    }
}
