package com.oshineye.kwikwiki.command;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import junit.framework.TestCase;

import com.mockobjects.dynamic.C;
import com.mockobjects.dynamic.Mock;
import com.oshineye.kwikwiki.KwikWikiTestUtils;
import com.oshineye.kwikwiki.markup.ViewBean;
import com.oshineye.kwikwiki.wikibase.AbstractWikiBase;
import com.oshineye.kwikwiki.wikibase.WikiPage;

/**
 * @author aoshineye
 */
public class ViewTest extends TestCase {

	private Mock mockRequestDispatcher;
	private Mock mockContext;
	private Mock mockResponse;
	private Mock mockRequest;

	protected void setUp() throws Exception {
		this.mockRequest = new Mock(HttpServletRequest.class);
		this.mockResponse = new Mock(HttpServletResponse.class);
		this.mockContext = new Mock(ServletContext.class);
		this.mockRequestDispatcher = new Mock(RequestDispatcher.class);
	}

	protected void tearDown() throws Exception {
		this.mockRequest.verify();
		this.mockContext.verify();
		this.mockRequestDispatcher.verify();
	}

	public void testViewingValidPage() throws Exception {
		mockRequest.expectAndReturn("getParameter", "title", KwikWikiTestUtils.TEST_PAGE_TITLE);
		mockRequest.expectAndReturn("getParameter", "revision", null);
		mockRequest.expect("setAttribute", C.args(C.eq("pageBean"), C.isA(ViewBean.class)));

		mockRequestDispatcher.expect("include", C.ANY_ARGS);

		mockContext.expectAndReturn("getRequestDispatcher", C.IS_NOT_NULL,
			mockRequestDispatcher.proxy());

		new View().execute((HttpServletRequest) mockRequest.proxy(),
			(HttpServletResponse) mockResponse.proxy(),
			(ServletContext) mockContext.proxy());
	}
	
	public void testViewingNonExistentPageWithValidName() throws Exception {
		mockRequest.matchAndReturn("getParameter", "title", KwikWikiTestUtils.TEST_PAGE_TITLE + "123");
		mockRequest.matchAndReturn("getParameter", "revision", null);
		mockRequest.expect("setAttribute", C.args(C.eq("pageBean"), C.isA(WikiPage.class)));

		mockRequestDispatcher.expect("include",  C.ANY_ARGS);

		mockContext.expectAndReturn("getRequestDispatcher", Command.EDIT_TEMPLATE,
			mockRequestDispatcher.proxy());

		new View().execute(
			(HttpServletRequest) mockRequest.proxy(),
			(HttpServletResponse) mockResponse.proxy(),
			(ServletContext) mockContext.proxy());
	}
	
	public void testViewingPageVersion() throws Exception {
		AbstractWikiBase.getInstance().savePage(KwikWikiTestUtils.createTestPage());
		mockRequest.expectAndReturn("getParameter", "title", KwikWikiTestUtils.TEST_PAGE_TITLE);
		mockRequest.expectAndReturn("getParameter", "revision", "1");
		mockRequest.expect("setAttribute", C.args(C.eq("pageBean"), C.isA(ViewBean.class)));

		mockRequestDispatcher.expect("include", C.ANY_ARGS);

		mockContext.expectAndReturn("getRequestDispatcher", C.IS_NOT_NULL,
			mockRequestDispatcher.proxy());

		new View().execute((HttpServletRequest) mockRequest.proxy(),
			(HttpServletResponse) mockResponse.proxy(),
			(ServletContext) mockContext.proxy());
	}
}
