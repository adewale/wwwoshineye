package com.oshineye.kwikwiki.specialpages;

import java.util.SortedSet;

import junit.framework.TestCase;

import com.oshineye.kwikwiki.KwikWikiTestUtils;
import com.oshineye.kwikwiki.wikibase.AbstractWikiBase;
import com.oshineye.kwikwiki.wikibase.WikiPage;

public class WantedPagesPageTest extends TestCase {
    public void testGetWantedPages() {
        WikiPage page = KwikWikiTestUtils.createTestPage();
        AbstractWikiBase.getInstance().savePage(page);

        WantedPagesPage wp = new WantedPagesPage();
        SortedSet wantedPages = wp.getWantedPages();
        assertNotNull("WantedPages Set is null", wantedPages);
        assertTrue("There are no WantedPages", wantedPages.size() > 0);
        assertTrue(wantedPages.contains("PleaseDoNotCreateThisPageAsItIsUsedForTesting"));
        assertFalse(wantedPages.contains("KwikWikiTestingPage"));

        assertNotNull(wp.getText());
    }
}
