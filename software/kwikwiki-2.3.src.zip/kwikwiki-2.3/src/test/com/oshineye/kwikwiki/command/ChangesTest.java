package com.oshineye.kwikwiki.command;

import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import junit.framework.TestCase;

import com.mockobjects.constraint.Constraint;
import com.mockobjects.dynamic.C;
import com.mockobjects.dynamic.Mock;
import com.oshineye.kwikwiki.markup.Syntax;
import com.oshineye.kwikwiki.markup.ViewBean;
import com.oshineye.kwikwiki.wikibase.WikiBase;

/**
 * @author aoshineye
 *
 */
public class ChangesTest extends TestCase {
	private Mock mockRequestDispatcher;
	private Mock mockContext;
	private Mock mockResponse;
	private Mock mockRequest;
	private Mock mockWikiBase;
	private Mock mockSyntax;

	protected void setUp() throws Exception {
		this.mockRequest = new Mock(HttpServletRequest.class);
		this.mockResponse = new Mock(HttpServletResponse.class);
		this.mockContext = new Mock(ServletContext.class);
		this.mockRequestDispatcher = new Mock(RequestDispatcher.class);
		this.mockWikiBase = new Mock(WikiBase.class);
		this.mockSyntax = new Mock(Syntax.class);
	}
	
	public void testUsesDefaultNumberOfDaysGivenInvalidNumber() throws Exception {
		mockWikiBase.expectAndReturn("getChangeLogs", C.eq(Changes.DEFAULT_NUMBER_OF_DAYS), new ArrayList());

		String convertedString = "convertedString";
		mockSyntax.expectAndReturn("convertToText", C.IS_ANYTHING, convertedString);
		mockSyntax.expectAndReturn("convertToHtml", C.eq(convertedString), "htmlString");
		
		mockRequest.expectAndReturn("getParameter", C.eq("days"), "invalid number");
		mockRequest.expect("setAttribute", C.args(C.eq("pageBean"), C.isA(ViewBean.class)));
		
		mockRequestDispatcher.expect("include", C.ANY_ARGS);

		mockContext.expectAndReturn("getRequestDispatcher", C.IS_NOT_NULL,
			mockRequestDispatcher.proxy());
		
		Changes command = new Changes((WikiBase)mockWikiBase.proxy(), (Syntax)mockSyntax.proxy());
		command.execute(
				(HttpServletRequest) mockRequest.proxy(),
				(HttpServletResponse) mockResponse.proxy(),
				(ServletContext) mockContext.proxy());
		
		this.mockWikiBase.verify();
		this.mockSyntax.verify();
		this.mockRequest.verify();
		this.mockContext.verify();
		this.mockRequestDispatcher.verify();
	}
	
	public void testUsesDefaultNumberOfDaysGivenNegativeNumber() throws Exception {
		mockWikiBase.expectAndReturn("getChangeLogs", C.eq(Changes.DEFAULT_NUMBER_OF_DAYS), new ArrayList());
		
		String convertedString = "convertedString";
		mockSyntax.expectAndReturn("convertToText", C.IS_ANYTHING, convertedString);
		mockSyntax.expectAndReturn("convertToHtml", C.eq(convertedString), "htmlString");
		
		mockRequest.expectAndReturn("getParameter", C.eq("days"), "-5");
		mockRequest.expect("setAttribute", C.args(C.eq("pageBean"), C.isA(ViewBean.class)));
		
		mockRequestDispatcher.expect("include", C.ANY_ARGS);

		mockContext.expectAndReturn("getRequestDispatcher", C.IS_NOT_NULL,
			mockRequestDispatcher.proxy());
		
		Changes command = new Changes((WikiBase)mockWikiBase.proxy(), (Syntax)mockSyntax.proxy());
		command.execute(
				(HttpServletRequest) mockRequest.proxy(),
				(HttpServletResponse) mockResponse.proxy(),
				(ServletContext) mockContext.proxy());
		
		this.mockWikiBase.verify();
		this.mockSyntax.verify();
		this.mockRequest.verify();
		this.mockContext.verify();
		this.mockRequestDispatcher.verify();
	}
	
	public void testUsesDefaultNumberOfDaysGivenNumberThatIsNotAnInteger() throws Exception {
		mockWikiBase.expectAndReturn("getChangeLogs", C.eq(Changes.DEFAULT_NUMBER_OF_DAYS), new ArrayList());
		
		String convertedString = "convertedString";
		mockSyntax.expectAndReturn("convertToText", C.IS_ANYTHING, convertedString);
		mockSyntax.expectAndReturn("convertToHtml", C.eq(convertedString), "htmlString");
		
		mockRequest.expectAndReturn("getParameter", C.eq("days"), "3.14");
		mockRequest.expect("setAttribute", C.args(C.eq("pageBean"), C.isA(ViewBean.class)));
		
		mockRequestDispatcher.expect("include", C.ANY_ARGS);

		mockContext.expectAndReturn("getRequestDispatcher", C.IS_NOT_NULL,
			mockRequestDispatcher.proxy());
		
		Changes command = new Changes((WikiBase)mockWikiBase.proxy(), (Syntax)mockSyntax.proxy());
		command.execute(
				(HttpServletRequest) mockRequest.proxy(),
				(HttpServletResponse) mockResponse.proxy(),
				(ServletContext) mockContext.proxy());
		
		this.mockWikiBase.verify();
		this.mockSyntax.verify();
		this.mockRequest.verify();
		this.mockContext.verify();
		this.mockRequestDispatcher.verify();
	}
	
	public void testUsesDefaultNumberOfDaysGivenNull() throws Exception {
		mockWikiBase.expectAndReturn("getChangeLogs", C.eq(Changes.DEFAULT_NUMBER_OF_DAYS), new ArrayList());
		
		String convertedString = "convertedString";
		mockSyntax.expectAndReturn("convertToText", C.IS_ANYTHING, convertedString);
		mockSyntax.expectAndReturn("convertToHtml", C.eq(convertedString), "htmlString");
		
		mockRequest.expectAndReturn("getParameter", C.eq("days"), null);
		mockRequest.expect("setAttribute", C.args(C.eq("pageBean"), C.isA(ViewBean.class)));
		
		mockRequestDispatcher.expect("include", C.ANY_ARGS);

		mockContext.expectAndReturn("getRequestDispatcher", C.IS_NOT_NULL,
			mockRequestDispatcher.proxy());
		
		Changes command = new Changes((WikiBase)mockWikiBase.proxy(), (Syntax)mockSyntax.proxy());
		command.execute(
				(HttpServletRequest) mockRequest.proxy(),
				(HttpServletResponse) mockResponse.proxy(),
				(ServletContext) mockContext.proxy());
		
		this.mockWikiBase.verify();
		this.mockSyntax.verify();
		this.mockRequest.verify();
		this.mockContext.verify();
		this.mockRequestDispatcher.verify();
	}
	
	public void testUsesSpecificMessageForTodaysChanges() throws Exception {
		int todayAsDaysParameter = 0;
		mockWikiBase.expectAndReturn("getChangeLogs", C.eq(todayAsDaysParameter), new ArrayList());

		String convertedString = "convertedString";
		mockSyntax.expectAndReturn("convertToText", C.IS_ANYTHING, convertedString);
		mockSyntax.expectAndReturn("convertToHtml", C.eq(convertedString), "htmlString");
		
		mockRequest.expectAndReturn("getParameter", C.eq("days"), todayAsDaysParameter + "");
		mockRequest.expect("setAttribute", C.args(C.eq("pageBean"), new ViewBeanTitleEqualsConstraint("Changes today")));
		
		mockRequestDispatcher.expect("include", C.ANY_ARGS);

		mockContext.expectAndReturn("getRequestDispatcher", C.IS_NOT_NULL,
			mockRequestDispatcher.proxy());
		
		Changes command = new Changes((WikiBase)mockWikiBase.proxy(), (Syntax)mockSyntax.proxy());
		command.execute(
				(HttpServletRequest) mockRequest.proxy(),
				(HttpServletResponse) mockResponse.proxy(),
				(ServletContext) mockContext.proxy());
		
		this.mockWikiBase.verify();
		this.mockSyntax.verify();
		this.mockRequest.verify();
		this.mockContext.verify();
		this.mockRequestDispatcher.verify();
	}
	
	public void testUsesSpecificMessageForYesterdaysChanges() throws Exception {
		int yesterdayAsDaysParameter = 1;
		mockWikiBase.expectAndReturn("getChangeLogs", C.eq(yesterdayAsDaysParameter), new ArrayList());

		String convertedString = "convertedString";
		mockSyntax.expectAndReturn("convertToText", C.IS_ANYTHING, convertedString);
		mockSyntax.expectAndReturn("convertToHtml", C.eq(convertedString), "htmlString");
		
		mockRequest.expectAndReturn("getParameter", C.eq("days"), yesterdayAsDaysParameter + "");
		mockRequest.expect("setAttribute", C.args(C.eq("pageBean"), new ViewBeanTitleEqualsConstraint("Changes yesterday")));
		
		mockRequestDispatcher.expect("include", C.ANY_ARGS);

		mockContext.expectAndReturn("getRequestDispatcher", C.IS_NOT_NULL,
			mockRequestDispatcher.proxy());
		
		Changes command = new Changes((WikiBase)mockWikiBase.proxy(), (Syntax)mockSyntax.proxy());
		command.execute(
				(HttpServletRequest) mockRequest.proxy(),
				(HttpServletResponse) mockResponse.proxy(),
				(ServletContext) mockContext.proxy());
		
		this.mockWikiBase.verify();
		this.mockSyntax.verify();
		this.mockRequest.verify();
		this.mockContext.verify();
		this.mockRequestDispatcher.verify();
	}

	class ViewBeanTitleEqualsConstraint implements Constraint {
		private String title;

		public ViewBeanTitleEqualsConstraint(String title) {
			this.title = title;
		}
		
		public boolean eval(Object object) {
			ViewBean viewBean = (ViewBean) object;
			return title.equals(viewBean.getTitle());
		}
		
		public String toString() {
			return "ViewBean's title = " + title;
		}
	}
}
