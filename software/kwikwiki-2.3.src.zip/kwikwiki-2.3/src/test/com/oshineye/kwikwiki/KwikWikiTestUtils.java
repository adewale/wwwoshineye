package com.oshineye.kwikwiki;

import java.util.Date;

import com.oshineye.kwikwiki.wikibase.WikiPage;


public class KwikWikiTestUtils {
	public static final String TEST_PAGE_TITLE = "KwikWikiTestingTestPage";

    public static WikiPage createTestPage() {
        //the newline is essential when creating pages by hand in this way.
        WikiPage page = new WikiPage(TEST_PAGE_TITLE,
                "This page exists for testing purposes only at:: " + new Date() + "\n" +
                ". It contains a deliberately missing page. Known as " +
                "PleaseDoNotCreateThisPageAsItIsUsedForTesting.\n", new Date(), "testUser");

        return page;
    }

    public static WikiPage createTestOrphanedPage() {
        WikiPage page = new WikiPage("KwikWikiTestingTestPageThatIsNotMeantToBeLinkedTo", "",
                new Date(), "testUser");

        return page;
    }

	public static WikiPage createStartingPoints() {
		WikiPage page = new WikiPage("StartingPoints", "Default StartingPoints page\n",
			new Date(), "testUser");
		return page;
	}
}
