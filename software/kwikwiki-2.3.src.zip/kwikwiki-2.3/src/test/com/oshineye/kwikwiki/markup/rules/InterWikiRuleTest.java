package com.oshineye.kwikwiki.markup.rules;

import junit.framework.TestCase;

import com.mockobjects.dynamic.Mock;
import com.oshineye.kwikwiki.wikibase.WikiBase;

/**
 * @author aoshineye
 */
public class InterWikiRuleTest extends TestCase {
	private InterWikiRule rule;

	public void setUp() {
		Mock wikiBase = new Mock(WikiBase.class);
		this.rule = new InterWikiRule((WikiBase) wikiBase.proxy());	
	}

	public void testConvertInterWikiLink() {
		String text = "Testing a link to a page on Wiki:AdewaleOshineye that exists.";
		String expected = "Testing a link to a page on <a href=\"http://c2.com/cgi/wiki?AdewaleOshineye\">Wiki:AdewaleOshineye</a> that exists.";
		
		assertEquals(expected, rule.apply(text));
	}
	
	public void testConvertMultipleInterWikiLinksInOneLine() {
		String text = "Links to Wiki:AdewaleOshineye and Xtc:AdewaleOshineye";
		String expected = "Links to <a href=\"http://c2.com/cgi/wiki?AdewaleOshineye\">Wiki:AdewaleOshineye</a> and <a href=\"http://www.xpdeveloper.org/xpdwiki/Wiki.jsp?page=AdewaleOshineye\">Xtc:AdewaleOshineye</a>";

		assertEquals(expected, rule.apply(text));
	}
	
	public void testConvertingInterWikiLinks() {
		assertEquals("<a href=\"http://c2.com/cgi/wiki?FrontPage\">Wiki:FrontPage</a>", rule.apply("Wiki:FrontPage"));
		assertEquals("<a href=\"http://www.xpdeveloper.org/xpdwiki/Wiki.jsp?page=FrontPage\">Xtc:FrontPage</a>", rule.apply("Xtc:FrontPage"));
		assertEquals("<a href=\"http://bookshelved.org/cgi-bin/wiki.pl?FrontPage\">BookShelved:FrontPage</a>", rule.apply("BookShelved:FrontPage"));
		assertEquals("<a href=\"http://www.usemod.com/cgi-bin/mb.pl?FrontPage\">MeatBall:FrontPage</a>", rule.apply("MeatBall:FrontPage"));
	}
}
