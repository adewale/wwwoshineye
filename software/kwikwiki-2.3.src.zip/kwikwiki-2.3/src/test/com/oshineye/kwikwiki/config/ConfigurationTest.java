package com.oshineye.kwikwiki.config;

import junit.framework.TestCase;

public class ConfigurationTest extends TestCase {
    private final Configuration config = Configuration.getInstance();

    public void testGetInstance() {
        assertNotNull(Configuration.getInstance());

        Object obj1 = Configuration.getInstance();
        Object obj2 = Configuration.getInstance();
        assertTrue(obj1.equals(obj2));
        assertTrue(obj1 == obj2);
    }

    public void testGetProperty() {
        assertNull(config.getProperty(null));
        assertNull(config.getProperty("non-existent-property"));
        assertNotNull(config.getProperty("user.home"));
    }

    public void testGetPropertyWithDefaults() {
        assertNotNull(config.getProperty(null, "DefaultString"));
        assertEquals(config.getProperty("non-existent-property", "DefaultString"), "DefaultString");
    }

    public void testGetPersistenceEngine() {
        assertNotNull(config.getProperty("kwikwiki.persistence"));
    }
    
    public void testGetValue() {
    	assertFalse(config.getValue("non-existentProperty"));
    	assertFalse(config.getValue(null));
    	
    }
}
