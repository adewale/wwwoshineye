package com.oshineye.kwikwiki.markup.rules;

import junit.framework.TestCase;

import com.mockobjects.dynamic.C;
import com.mockobjects.dynamic.Mock;
import com.oshineye.kwikwiki.wikibase.WikiBase;

public class WikiNameRuleTest extends TestCase {
	private WikiNameRule rule;
	private Mock wikiBase;
	public void setUp() {
		this.wikiBase = new Mock(WikiBase.class);
		this.rule = new WikiNameRule((WikiBase) wikiBase.proxy());
	}
	
    public void testConversionOfLinkToExtantPage() {
    	wikiBase.expectAndReturn("pageExists", C.eq("StartingPoints"), true);
        String text = " StartingPoints ";
        String expected = " <a href=\"View?title=StartingPoints\">StartingPoints</a> ";

        assertEquals(expected, rule.apply(text));
    }
    
    public void testConversionOfLinkWithColonAfterwards() {
    	String text = "StartingPoints:";
    	String expected = "StartingPoints:";
    	
    	assertEquals(expected, rule.apply(text));
    }
}
