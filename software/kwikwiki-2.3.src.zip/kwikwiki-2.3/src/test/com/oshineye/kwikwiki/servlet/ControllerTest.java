package com.oshineye.kwikwiki.servlet;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;

import junit.framework.TestCase;

import com.mockobjects.dynamic.C;
import com.mockobjects.dynamic.Mock;
import com.mockobjects.servlet.MockHttpServletRequest;
import com.mockobjects.servlet.MockHttpServletResponse;
import com.mockobjects.servlet.MockRequestDispatcher;
import com.mockobjects.servlet.MockServletConfig;
import com.mockobjects.servlet.MockServletContext;
import com.oshineye.kwikwiki.KwikWikiTestUtils;
import com.oshineye.kwikwiki.command.Command;
import com.oshineye.kwikwiki.config.ConfigurationBean;

/**
 * @author aoshineye
 */
public class ControllerTest extends TestCase {
	private MockServletContext context;
	
	public void setUp() {
		this.context = new MockServletContext();
		context.setupGetRequestDispatcher(new MockRequestDispatcher());
	}

	public void testRequestingCommandWithInvalidTitle() throws Exception {
		MockHttpServletRequest req = new MockHttpServletRequest();
		req.setupAddParameter("title", "bad_page_name");
		req.setupGetServletPath("/View");

		context.setExpectedRequestDispatcherURI(Command.INVALID_TITLE);

		MockServletConfig config = new MockServletConfig();
		config.setServletContext(context);
		
		Controller controller = new Controller();
		controller.init(config);
		controller.service(req, null);
		
		context.verify();
	}
	
	public void testRequestingCommandWithValidTitle() throws Exception {
		Mock req = new Mock(HttpServletRequest.class);
		req.matchAndReturn("getParameter", "title", KwikWikiTestUtils.TEST_PAGE_TITLE);
		req.expectAndReturn("getParameter", "revision", null);
		req.expectAndReturn("getServletPath", "/View");
		req.expect("setAttribute", C.ANY_ARGS);

		MockHttpServletResponse resp = new MockHttpServletResponse();
		resp.setExpectedContentType("text/html");

		Controller controller = setupController();
		controller.service((HttpServletRequest)req.proxy(), resp);

		req.verify();
		resp.verify();
	}

	public void testRequestingNonExistentCommand() throws Exception {
		MockHttpServletRequest req = new MockHttpServletRequest();
		req.setupAddParameter("title", KwikWikiTestUtils.TEST_PAGE_TITLE);
		req.setupGetServletPath("/NonExistentCommand");
		
		MockHttpServletResponse resp = new MockHttpServletResponse();
		resp.setExpectedContentType("text/html");

		Controller controller = setupController();
		controller.service(req, resp);
		
		resp.verify();
	}
	
	public void testInitialisingControllerBindsConfigurationBeanIntoContext() 
		throws ServletException {
		context.addExpectedAttribute(Controller.CONFIG_BEAN_ATTRIBUTE, new ConfigurationBean());

		setupController();
		
		context.verify();
	}
	
	private Controller setupController() throws ServletException {
		MockServletConfig config = new MockServletConfig();
		config.setServletContext(context);
		
		Controller controller = new Controller();
		controller.init(config);
		
		return controller;
	}
}
