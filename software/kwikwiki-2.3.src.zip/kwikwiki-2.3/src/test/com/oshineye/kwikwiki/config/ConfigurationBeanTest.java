package com.oshineye.kwikwiki.config;

import junit.framework.TestCase;

/**
 * @author aoshineye
 */
public class ConfigurationBeanTest extends TestCase {
	public void testGetWikiNameDefaultsProperly() {
		ConfigurationBean bean = new ConfigurationBean();
		Configuration config = Configuration.getInstance();
		assertEquals(config.getProperty(Configuration.WIKI_NAME), bean.getWikiName());
	}

	public void testSettingConfigurationAltersConfigurationBean() {
		String newName = "newWikiName";
		Configuration.getInstance().setProperty(Configuration.WIKI_NAME, newName);
		ConfigurationBean bean = new ConfigurationBean();
		
		assertEquals(newName, bean.getWikiName());
	}
}
