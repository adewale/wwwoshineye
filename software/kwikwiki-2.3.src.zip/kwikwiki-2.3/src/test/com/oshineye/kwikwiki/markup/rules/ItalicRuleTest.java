package com.oshineye.kwikwiki.markup.rules;

import junit.framework.TestCase;

/**
 * @author aoshineye
 */
public class ItalicRuleTest extends TestCase {
	private ItalicRule rule;
	public void setUp() {
		this.rule = new ItalicRule();
	}
	
	public void testWithEmptyString() {
		String text = "";
		assertEquals(text, rule.apply(text));
	}
	
	public void testTextWithNoItalics(){
		String text = "test text with no italics";
		assertEquals(text, rule.apply(text));
	}
	
	public void testItalicize() {
		String text = "test text ''with italics''";
		String expected = "test text <i>with italics</i>";
		assertEquals(expected, rule.apply(text));
	}
}
