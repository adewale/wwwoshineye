package com.oshineye.kwikwiki.markup;

import java.util.ArrayList;
import java.util.List;

import junit.framework.TestCase;

import com.oshineye.kwikwiki.KwikWikiTestUtils;
import com.oshineye.kwikwiki.wikibase.Revision;


public class MarkUpEngineTest extends TestCase {
    public void testIsWikiName() {
        assertFalse(MarkUpEngine.isWikiName("helloworld"));
        assertFalse(MarkUpEngine.isWikiName(""));
        assertFalse(MarkUpEngine.isWikiName(null));
        assertTrue(MarkUpEngine.isWikiName("HelloWorld"));
    }

    public void testConversionToHtml() {
        String testString = "StartingPoints is a link but thisIsNotALink and ThisPageDoesNotExist.";
        String expectedResult = "<a href=\"View?title=StartingPoints\">StartingPoints</a> is a link" +
            " but thisIsNotALink and ThisPageDoesNotExist<a href=\"Create?title=ThisPageDoesNotExist\">?</a>.\n";
        String realResult = MarkUpEngine.convertToHtml(testString);
        assertEquals("Text wasn't properly converted", expectedResult, realResult);
    }
    
    public void testConversionToHtmlEscapesLeftAngleBracket() {
    	String testString = "<blink>Twinkle twinkle little star</blink>";
    	String expectedResult = "&lt;blink>Twinkle twinkle little star&lt;/blink>\n";
    	String realResult = MarkUpEngine.convertToHtml(testString);
    	assertEquals(expectedResult, realResult);
    }

    public void testConversionToHtmlList() {
        String wikiList = " * test1\n  * test2\n  * test2b\n   * test3\n";
        String expectedHtmlChunk = "<ul>\n" + "<li class=\"listItem1\">test1</li>\n" +
            "<li class=\"listItem2\">test2</li>\n" + "<li class=\"listItem2\">test2b</li>\n" +
            "<li class=\"listItem3\">test3</li>\n" + "</ul>\n";
        String result = MarkUpEngine.convertToHtml(wikiList);
        assertEquals(expectedHtmlChunk, result);
    }

    public void testConversionToHtmlListWithTextBefore() {
        String wikiList = "Testing 1,2,3 \n" + " * test1\n  * test2\n   * test3\n";
        String expectedHtmlChunk = "Testing 1,2,3 \n" + "<ul>\n" 
        + "<li class=\"listItem1\">test1</li>\n" + "<li class=\"listItem2\">test2</li>\n" 
        + "<li class=\"listItem3\">test3</li>\n" + "</ul>\n";
        String result = MarkUpEngine.convertToHtml(wikiList);
		assertEquals(expectedHtmlChunk, result);
    }
    
    public void testLinkInListItem() {
	    String text = "  * http://c2.com/w4/cc/wiki.cgi?CruiseControlDocs";
	    String expected = "<ul>\n<li class=\"listItem2\">" 
	    + "<a href=\"http://c2.com/w4/cc/wiki.cgi?CruiseControlDocs\">" 
	    + "http://c2.com/w4/cc/wiki.cgi?CruiseControlDocs</a></li>\n</ul>\n";
	    String result = MarkUpEngine.convertToHtml(text);
	    assertEquals(expected, result);
    }
    
    public void testWikiNameInList() {
    	String text = " * WikiNameThatDoesNotExist";
    	String expected = "<ul>\n<li class=\"listItem1\">" 
    	+ "WikiNameThatDoesNotExist<a href=\"Create?title=WikiNameThatDoesNotExist\">?</a>"
    	+ "</li>\n</ul>\n";
    	String result = MarkUpEngine.convertToHtml(text);
    	assertEquals(expected, result);
    }
    
    public void testConversionOfRevisionsToHtmlList() {
    	Revision testRevision = 
    		new Revision(KwikWikiTestUtils.TEST_PAGE_TITLE, 0, "testUser", 0);
    	List revisions = new ArrayList();
    	revisions.add(testRevision);
		revisions.add(testRevision);
		
    	String resultText = MarkUpEngine.convertRevisions(revisions);
    	assertTrue(resultText.matches("((.*)" + KwikWikiTestUtils.TEST_PAGE_TITLE
    		+ "(.*)){2}"));
    }
    
    public void testConversionToHtmlWithLocalAndInterWikiLinks() {
    	String text = "AdewaleOshineye and Xtc:AdewaleOshineye";
    	String expected = "<a href=\"View?title=AdewaleOshineye\">AdewaleOshineye</a> and "
    		+ "<a href=\"http://www.xpdeveloper.org/xpdwiki/Wiki.jsp?page=AdewaleOshineye\">Xtc:AdewaleOshineye</a>\n";
    	assertEquals(expected, MarkUpEngine.convertToHtml(text));
    }
    
    public void testConversionToHtmlWhenInterWikiKeywordIsWikiName() {
		String text = "Do links like BookShelved:FrontPage actually work?";
		String expected = "Do links like <a href=\"http://bookshelved.org/cgi-bin/wiki.pl?FrontPage\">BookShelved:FrontPage</a> actually work?\n";
		assertEquals(expected, MarkUpEngine.convertToHtml(text));
    }
}
