package com.oshineye.kwikwiki.markup.rules;

import junit.framework.TestCase;

public class CodeRuleTest extends TestCase {
	private CodeRule rule;
	public void setUp() {
		this.rule = new CodeRule();
	}
    public void testCodeRule() {
        String text = "\n{{{\n" + "    public static void main(java.lang.String[] args) {\n" +
            "        junit.textui.TestRunner.run(suite());\n" + "    }\n" + "}}}\n";
        String result = rule.apply(text).toString();
        assertTrue(result.indexOf("pre class=\"code\">") != -1);
        assertTrue(result.indexOf("</pre>") != -1);
    }

    public void testCodeRuleWithoutPrecedingLine() {
        String text = "{{{\n" + "    public static void main(java.lang.String[] args) {\n" +
            "        junit.textui.TestRunner.run(suite());\n" + "    }\n" + "}}}\n";
        String result = rule.apply(text).toString();
        assertTrue(result.indexOf("pre class=\"code\">") != -1);
        assertTrue(result.indexOf("</pre>") != -1);
    }

    public void testCodeRuleWithoutSucceedingLine() {
        String text = "\n{{{\n" + "    public static void main(java.lang.String[] args) {\n" +
            "        junit.textui.TestRunner.run(suite());\n" + "    }\n" + "}}}";
        String result = rule.apply(text).toString();
        assertTrue(result.indexOf("pre class=\"code\">") != -1);
        assertTrue(result.indexOf("</pre>") != -1);
    }
    
    public void testMultipleCodeBlocksInPage() {
    	String text = "{{{\nTEXT\n}}}\n{{{\nMORE_TEXT\n}}}";
		String expectedText = "<pre class=\"code\">\nTEXT\n</pre>\n" 
			+ "<pre class=\"code\">\nMORE_TEXT\n</pre>";
    	assertEquals(expectedText, rule.apply(text));
    }
}
