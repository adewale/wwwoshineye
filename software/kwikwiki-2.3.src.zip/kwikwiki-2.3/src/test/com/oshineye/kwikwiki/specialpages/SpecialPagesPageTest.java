package com.oshineye.kwikwiki.specialpages;

import junit.framework.TestCase;

import com.oshineye.kwikwiki.config.Configuration;

/**
 * @author aoshineye
 */
public class SpecialPagesPageTest extends TestCase {
	public void testCreationOfSpecialPagesPage() {
		int numberOfSpecialPages = PageFactory.getAllSpecialPages().size();
		String text = new SpecialPagesPage().getText();
		int linesCreated = text.split(Configuration.LINE_ENDING).length;

		assertEquals(numberOfSpecialPages, linesCreated);
	}
}
