package com.oshineye.kwikwiki.command;

import java.util.logging.Logger;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.oshineye.kwikwiki.markup.ViewBean;
import com.oshineye.kwikwiki.specialpages.PageFactory;
import com.oshineye.kwikwiki.wikibase.AbstractWikiBase;
import com.oshineye.kwikwiki.wikibase.WikiBase;
import com.oshineye.kwikwiki.wikibase.WikiPage;

public class View extends Command {
	private static final Logger LOG = Logger.getLogger("com.oshineye.kwikwiki.command.View");

	public void execute(HttpServletRequest req, HttpServletResponse resp, ServletContext sc)
		throws Exception {
		LOG.info("==Executing view command==");

		String title = req.getParameter("title");
		String revision = req.getParameter("revision");

		WikiBase wikiBase = AbstractWikiBase.getInstance();

		if (wikiBase.pageExists(title)) {
			WikiPage rawPage;

			if ((revision == null) || revision.trim().equals("")) {
				rawPage = PageFactory.getPage(title);
			} else {
				int revisionId = Integer.parseInt(revision);
				rawPage = PageFactory.getPage(title, revisionId);
			}

			ViewBean page = new ViewBean(rawPage);

			req.setAttribute("pageBean", page);

			if (rawPage.isSpecial()) {
				Command.include("/viewSpecialPageTemplate.jsp", req, resp, sc);
			} else {
				Command.include("/viewTemplate.jsp", req, resp, sc);
			}
		} else {
			//title is valid wikiName but page doesn't exist
			Command action = CommandFactory.getCommand("Create");
			action.execute(req, resp, sc);
		}
	}
}
