package com.oshineye.kwikwiki.specialpages;

import java.util.Iterator;
import java.util.SortedSet;
import java.util.TreeSet;

import com.oshineye.kwikwiki.markup.MarkUpEngine;
import com.oshineye.kwikwiki.wikibase.AbstractWikiBase;
import com.oshineye.kwikwiki.wikibase.WikiBase;


public class OrphanedPagesPage implements SpecialPage {
    public String getText() {
        return MarkUpEngine.convertToWikiList(this.getOrphanedPages());
    }

    SortedSet getOrphanedPages() {
        WikiBase wikiBase = AbstractWikiBase.getInstance();

        SortedSet orphanedPages = new TreeSet();

        for (Iterator it = wikiBase.getAllTitles().iterator(); it.hasNext();) {
            String wikiName = (String) it.next();

            if (this.isOrphanedPage(wikiName)) {
                orphanedPages.add(wikiName);
            }
        }

        return orphanedPages;
    }

    private boolean isOrphanedPage(String wikiName) {
        WikiBase wikiBase = AbstractWikiBase.getInstance();
        SortedSet occurrences = wikiBase.locateWikiName(wikiName);
        boolean hasNoOccurrences = occurrences.size() == 0;

        return (hasNoOccurrences && (wikiBase.pageExists(wikiName)) 
        	&& !PageFactory.isSpecialPage(wikiName));
    }
}
