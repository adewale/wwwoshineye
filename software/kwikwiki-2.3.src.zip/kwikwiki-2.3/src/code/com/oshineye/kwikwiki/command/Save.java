package com.oshineye.kwikwiki.command;

import java.util.Date;
import java.util.logging.Logger;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.oshineye.kwikwiki.wikibase.AbstractWikiBase;
import com.oshineye.kwikwiki.wikibase.WikiBase;
import com.oshineye.kwikwiki.wikibase.WikiPage;

public class Save extends Command {
	private static final Logger LOG = Logger.getLogger("com.oshineye.kwikwiki.command.Save");
	private static final String SAVE = "/saveTemplate.jsp";

	public void execute(HttpServletRequest req, HttpServletResponse resp, ServletContext sc)
		throws Exception {
		LOG.info("==Executing save command==");

		String title = req.getParameter("title");
		String text = req.getParameter("text");

		if (isValid(title) && isValid(text)) {
			WikiBase wikiBase = AbstractWikiBase.getInstance();

			//save page with user identification
			//FIXME we should check for a user name cookie not just use the hostname
			WikiPage rawPage = new WikiPage(title, text, new Date(), req.getRemoteHost());
			wikiBase.savePage(rawPage);

			//go to save successful page
			Command.include(Save.SAVE, req, resp, sc);
		} else {
			//go to generic error page because this indicates programming error
			//not user error and should never happen
			Command.include(Command.ERROR, req, resp, sc);
		}
	}

	private boolean isValid(String toTest) {
		return ((toTest != null) && (!toTest.equals("")));
	}
}
