package com.oshineye.kwikwiki.servlet;

import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.oshineye.kwikwiki.command.Command;
import com.oshineye.kwikwiki.command.CommandFactory;
import com.oshineye.kwikwiki.config.ConfigurationBean;
import com.oshineye.kwikwiki.markup.MarkUpEngine;



public class Controller extends HttpServlet {
	private static final Logger LOG = Logger.getLogger("com.oshineye.kwikwiki.servlet.Controller");
	private static final String SEARCH = "Search";
	private static final String CHANGES = "Changes";
	static final String CONFIG_BEAN_ATTRIBUTE = "configurationBean";
    public void service(HttpServletRequest req, HttpServletResponse resp)
        throws ServletException, IOException {
        long timeBefore = System.currentTimeMillis();

		ServletContext sc = this.getServletContext();
		
        //skip the leading slash
        String command = req.getServletPath().substring(1);

		if (!command.equals(SEARCH) 
			&& !command.equals(CHANGES)
			&& !MarkUpEngine.isWikiName(req.getParameter("title"))) {
			//go to invalid page title error page
			Command.include(Command.INVALID_TITLE, req, resp, sc);
			return;
		}

        try {
            Command action = CommandFactory.getCommand(command);
            resp.setContentType("text/html");
            action.execute(req, resp, sc);
        } catch (Exception ex) {
            LOG.log(Level.WARNING, ex.getMessage(), ex);
			Command.include(Command.ERROR, req, resp, sc);
        }

        long timeAfter = System.currentTimeMillis();
		LOG.info("===Request took:: " + (timeAfter - timeBefore) + " milliseconds===");
    }
    
    public void init(ServletConfig config) throws ServletException {
    	super.init(config);
    	ServletContext context = config.getServletContext();
    	context.setAttribute(CONFIG_BEAN_ATTRIBUTE, new ConfigurationBean());
    }
}
