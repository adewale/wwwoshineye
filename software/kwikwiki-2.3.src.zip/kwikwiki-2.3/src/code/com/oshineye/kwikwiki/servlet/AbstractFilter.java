package com.oshineye.kwikwiki.servlet;

import javax.servlet.Filter;
import javax.servlet.FilterConfig;

import com.opensymphony.module.oscache.base.Cache;
import com.opensymphony.module.oscache.web.ServletCacheAdministrator;

/**
 * @author aoshineye
 */
public abstract class AbstractFilter implements Filter {
	protected static String CHANGES_PATTERN = "__CHANGES__";
	protected static final String SEARCH_PATTERN = "__SEARCH__";
	protected static final String SHARED_PATTERN = "__SHARED__";
	protected static final String HISTORICAL_VIEW_PATTERN = "__HISTORICAL";
	private FilterConfig config;
	
	/* (non-Javadoc)
	 * @see javax.servlet.Filter#init(javax.servlet.FilterConfig)
	 */
	public void init(FilterConfig config) {
		this.config = config;
	}

	/* (non-Javadoc)
	 * @see javax.servlet.Filter#destroy()
	 */
	public void destroy() {
		this.config = null;
	}

	protected ServletCacheAdministrator getServletCacheAdministrator() {
		return ServletCacheAdministrator.getInstance(this.config.getServletContext());
	}

	protected void flushCategories(Cache cache) {
		//flush all the shared, search and changes related cache entries
		cache.flushPattern(AbstractFilter.SHARED_PATTERN);
		cache.flushPattern(AbstractFilter.SEARCH_PATTERN);
		cache.flushPattern(AbstractFilter.CHANGES_PATTERN);
	}
}
