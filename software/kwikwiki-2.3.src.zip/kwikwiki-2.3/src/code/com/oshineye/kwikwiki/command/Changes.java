package com.oshineye.kwikwiki.command;

import java.util.List;
import java.util.logging.Logger;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.oshineye.kwikwiki.markup.Syntax;
import com.oshineye.kwikwiki.markup.ViewBean;
import com.oshineye.kwikwiki.wikibase.WikiBase;

/**
 * @author aoshineye
 */
public class Changes extends Command {
	public static final int DEFAULT_NUMBER_OF_DAYS = 1;
	private static final String CHANGES = "/Changes";
	private static final Logger LOG = Logger.getLogger("com.oshineye.kwikwiki.command.Changes");
	private WikiBase wikiBase;
	private Syntax syntax;
	public Changes(WikiBase wikiBase, Syntax syntax) {
		this.wikiBase = wikiBase;
		this.syntax = syntax;
	}

	public void execute(HttpServletRequest req, HttpServletResponse resp, ServletContext sc) 
		throws Exception {
		LOG.info("==Executing changes command==");
		
		int numberOfDays = getNumberOfDays(req);
		List logs = wikiBase.getChangeLogs(numberOfDays);
		String text = syntax.convertToText(logs);
		String title = getTitle(numberOfDays);
		
		ViewBean page = new ViewBean(title, syntax.convertToHtml(text));
		req.setAttribute("pageBean", page);
		Command.include("/changesTemplate.jsp", req, resp, sc);
	}
	
	private String getTitle(int numberOfDays) {
		if (numberOfDays == 0) {
			return "Changes today";
		} else if (numberOfDays == 1) {
			return "Changes yesterday";
		} else {
			return "Changes in the last " + numberOfDays + " days";
		}
	}

	private int getNumberOfDays(HttpServletRequest req) {
		String numberOfDays = req.getParameter("days");
		int days = parseDays(numberOfDays);
		if (days >= 0) {
			return days;
		}
		return DEFAULT_NUMBER_OF_DAYS;
	}
	
	private int parseDays(String numberOfDays) {
		try {
			return Integer.parseInt(numberOfDays);
		} catch (NumberFormatException e) {
			return DEFAULT_NUMBER_OF_DAYS;
		}
	}

	public static boolean isChanges(String commandName) {
		return CHANGES.equals(commandName);
	}
	

}
