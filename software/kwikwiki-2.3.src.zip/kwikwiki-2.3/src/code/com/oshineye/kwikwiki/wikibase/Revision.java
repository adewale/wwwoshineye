package com.oshineye.kwikwiki.wikibase;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * @author aoshineye
 * 
 * This immutable class represents the metadata that uniquely identifies a particular version
 * of a WikiPage. Revision objects are used to retrieve the content of a particular WikiPage
 *  at a particular point in it's history.
 */
public class Revision extends Change {
	private int id;
	public Revision(String title, long time, String editor, int id) {
		super(title, new Date(time), editor);
		this.id = id;
	}
	
	public Revision(WikiPage rawPage, int id) {
		super(rawPage.getTitle(), rawPage.getDate(), rawPage.getLastEditor());
		this.id = id;
	}
	public int getId() {
		return this.id;
	}

	public static List parseRevisions(List revisionLines) {
		List revisions = new ArrayList();
		for (Iterator it = revisionLines.iterator(); it.hasNext();) {
			String line = (String) it.next();
			if (!line.trim().equals("")) {
				revisions.add(Revision.createRevisionFromString(line));
			}
		}
		return revisions;
	}

	public static Revision createRevisionFromString(String line) {
		Pattern pattern = Pattern.compile("(title:(.*),date:(.*),editor:(.*),id:(.*),)");
		Matcher matcher = pattern.matcher(line);
		
		Revision result = null;
		if (matcher.find()) {
			String tempTitle = matcher.group(2);
			String tempDate = matcher.group(3);
			String tempEditor = matcher.group(4);
			String tempId = matcher.group(5);
			
			long tempTime = Long.parseLong(tempDate);
			int id = Integer.parseInt(tempId);
			result = new Revision(tempTitle, tempTime, tempEditor, id);
		}

		return result;	
	}

	public String convertToString() {
		return "title:" + this.getTitle() + ",date:"	+ this.getTime() + ",editor:" 
			+ this.getEditor() + ",id:" + this.getId() + ",";
	}

	public int compareTo(Object other) {
		Revision otherRevision = (Revision) other;
		return this.id - otherRevision.id;
	}

}
