package com.oshineye.kwikwiki.command;

import java.util.HashMap;
import java.util.Map;

import com.oshineye.kwikwiki.markup.WikiSyntax;
import com.oshineye.kwikwiki.wikibase.AbstractWikiBase;
import com.oshineye.kwikwiki.wikibase.WikiBase;


/**
 * @author aoshineye
 * A factory for Commands.
 */
public class CommandFactory {
    private static final Map INSTANCE_CACHE = new HashMap();

    //preload all the command class instances we'll be re-using
    static {
    	WikiBase wikiBase = AbstractWikiBase.getInstance();
        INSTANCE_CACHE.put("View", new View());
        INSTANCE_CACHE.put("Edit", new Edit());
        INSTANCE_CACHE.put("Save", new Save());
        INSTANCE_CACHE.put("Create", new Create());
        INSTANCE_CACHE.put("Search", new Search());
        INSTANCE_CACHE.put("Like", new Like());
        INSTANCE_CACHE.put("History", new History());
		INSTANCE_CACHE.put("Changes", new Changes(wikiBase, new WikiSyntax()));
		INSTANCE_CACHE.put(null, new NullCommand());
    }

    public static Command getCommand(String commandName) {
		if (INSTANCE_CACHE.containsKey(commandName)) {
			return (Command) INSTANCE_CACHE.get(commandName);
		}
		return (Command) INSTANCE_CACHE.get(null);
    }
}
