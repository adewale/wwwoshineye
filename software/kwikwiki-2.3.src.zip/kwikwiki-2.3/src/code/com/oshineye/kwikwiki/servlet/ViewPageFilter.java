package com.oshineye.kwikwiki.servlet;

import java.io.IOException;
import java.util.Enumeration;
import java.util.logging.Logger;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.jsp.PageContext;

import com.opensymphony.module.oscache.base.Cache;
import com.opensymphony.module.oscache.base.NeedsRefreshException;
import com.opensymphony.module.oscache.web.ServletCacheAdministrator;
import com.opensymphony.module.oscache.web.filter.CacheHttpServletResponseWrapper;
import com.opensymphony.module.oscache.web.filter.ResponseContent;
import com.oshineye.kwikwiki.command.Changes;
import com.oshineye.kwikwiki.command.Search;
import com.oshineye.kwikwiki.specialpages.PageFactory;

/**
 * @author aoshineye
 */
public class ViewPageFilter extends AbstractFilter {
	private static final Logger LOG =
		Logger.getLogger("com.oshineye.kwikwiki.servlet.ViewPageFilter");
	private static final String LIKE = "/Like";
	private static final String HISTORY = "/History";
	private static final int REFRESH_TIME = 60 * 60 * 24 ;//once a day in seconds

	public void doFilter(ServletRequest req, ServletResponse resp, FilterChain filterChain)
		throws IOException, ServletException {
		LOG.info("ViewPageFilter");
		ServletCacheAdministrator admin = getServletCacheAdministrator();
		HttpServletRequest httpReq = (HttpServletRequest) req;
		
		String key = this.composeKey(httpReq);
		Cache cache = admin.getCache(httpReq, PageContext.APPLICATION_SCOPE);
		try {
			ResponseContent respContent = (ResponseContent) cache.getFromCache(key, REFRESH_TIME);
			respContent.writeTo(resp);
		} catch (NeedsRefreshException nre) {
			CacheHttpServletResponseWrapper cacheResponse = new KwikWikiResponseWrapper(resp);
			filterChain.doFilter(req, cacheResponse);
			
			//workaround for bug on Tomcat which needs flushing to show the actual page
			cacheResponse.flushBuffer();
			cache.putInCache(key, cacheResponse.getContent());
		}
	}

	private String composeKey(HttpServletRequest req) {
		String title = req.getParameter("title");
		String commandName = req.getServletPath();
		if (Search.isSearch(commandName)) {
			return AbstractFilter.SEARCH_PATTERN + parseParameters(req);
		} else if(Changes.isChanges(commandName)){
			return AbstractFilter.CHANGES_PATTERN + parseParameters(req); 
		}else if (title == null){
			return commandName;//no title
		} else if (isShared(title, commandName)) {
			return AbstractFilter.SHARED_PATTERN + req.getServletPath() + title;
		} else {
			String revision = req.getParameter("revision");
			if (revision == null) {
				return title;//viewing latest version
			}
			return AbstractFilter.HISTORICAL_VIEW_PATTERN + title + revision;
		}
	}

	private String parseParameters(HttpServletRequest req) {
		StringBuffer result = new StringBuffer();
		for(Enumeration paramNames = req.getParameterNames(); paramNames.hasMoreElements();) {
			String param = (String) paramNames.nextElement();
			result.append(req.getParameter(param));
		}
		return result.toString();
	}

	private boolean isShared(String title, String commandName) {
		return PageFactory.isSpecialPage(title) 
			|| LIKE.equals(commandName) || HISTORY.equals(commandName);
	}
}
