package com.oshineye.kwikwiki.markup;

import java.util.Collection;
import java.util.List;

/**
 * @author aoshineye
 *
 */
public interface Syntax {
	public String convertToHtml(CharSequence text);
	public String convertToRawList(Collection items);
	public boolean isValidName(String title);
	public String convertToText(List logs);
}
