package com.oshineye.kwikwiki.servlet;

import java.io.IOException;
import java.util.Iterator;
import java.util.Set;
import java.util.logging.Logger;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.jsp.PageContext;

import com.opensymphony.module.oscache.base.Cache;
import com.opensymphony.module.oscache.web.ServletCacheAdministrator;
import com.oshineye.kwikwiki.wikibase.AbstractWikiBase;

/**
 * @author aoshineye
 *
 * A Filter which ensures that all the "create page" dead links with the question marks
 * all become live links.
 */
public class CreatePageFilter extends AbstractFilter {
	private static final Logger LOG =
		Logger.getLogger("com.oshineye.kwikwiki.servlet.CreatePageFilter");
	public void doFilter(ServletRequest req, ServletResponse resp, FilterChain filterChain)
		throws IOException, ServletException {
		LOG.info("CreatePageFilter");
		ServletCacheAdministrator admin = getServletCacheAdministrator();
		Cache cache = admin.getCache((HttpServletRequest) req, PageContext.APPLICATION_SCOPE);
		
		String title = req.getParameter("title");
		Set locations = AbstractWikiBase.getInstance().locateWikiName(title);

		//flush all backlinks
		for (Iterator it = locations.iterator(); it.hasNext();) {
			String backLinkTitle = (String) it.next();
			cache.flushEntry(backLinkTitle);
		}
		
		//flush revision history pages
		cache.flushPattern(AbstractFilter.HISTORICAL_VIEW_PATTERN);
		
		flushCategories(cache);
		
		filterChain.doFilter(req, resp);
	}
}
