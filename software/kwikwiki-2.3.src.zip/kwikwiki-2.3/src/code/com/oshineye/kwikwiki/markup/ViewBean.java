package com.oshineye.kwikwiki.markup;

import java.io.Serializable;
import java.util.Date;

import com.oshineye.kwikwiki.wikibase.WikiPage;

/**
 * @author aoshineye
 * A javabean containing an html view of a WikiPage.
 */
public class ViewBean implements Serializable {
	private String lastEdited;
	private String title;
	private String text;

	public ViewBean() {
	}

	/**
	* This constructor exists for situations where the calling method already
	*  has the text in html or does not wish the text to be further formatted.
	* @param title the title of the page
	* @param text the formatted text of the page
	*/
	public ViewBean(String title, String text) {
		this.title = title;
		this.text = text;
	}

	/**
	* This constructor takes in a page in wiki format and converts it's
	* contents into html.
	* @param rawPage the WikiPage that will have it's text converted to html
	*/
	public ViewBean(WikiPage rawPage) {
		this.setTitle(rawPage.getTitle());

		String tempText = rawPage.getText();
		this.setText(MarkUpEngine.convertToHtml(tempText));

		Date date = rawPage.getDate();

		if (date == null) {
			this.lastEdited = "Unknown time";
		} else {
			this.lastEdited = date.toString();
		}
	}

	public String getLastEdited() {
		return lastEdited;
	}

	private void setTitle(String title) {
		this.title = title;
	}

	public String getTitle() {
		return this.title;
	}

	private void setText(String text) {
		this.text = text;
	}

	public String getText() {
		return this.text;
	}
}
