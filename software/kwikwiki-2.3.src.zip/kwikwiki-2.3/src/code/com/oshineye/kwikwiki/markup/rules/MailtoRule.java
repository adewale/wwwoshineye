package com.oshineye.kwikwiki.markup.rules;

/**
 * @author amezick
 */
public class MailtoRule extends MarkUpRule {

	private static final String PATTERN = "(mailto:([\\S]+))";
	private static final String REPLACEMENT_TEXT = "<a href=\"$1\">$1</a>";

	public MailtoRule() {
		super(MailtoRule.PATTERN, MailtoRule.REPLACEMENT_TEXT);
	}
}
