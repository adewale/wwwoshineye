package com.oshineye.kwikwiki.wikibase;

import java.io.Serializable;
import java.util.Date;


/**
 * @author aoshineye
 * A javabean (except for the lack of a default no-args constructor) that
 * represent a page's data in wiki format.
 * It also keeps track of when it was created and who last edited it.
 */
public class WikiPage implements Serializable {
	private String title;
	private String text;
	private boolean special;
    private Date date;
    private String lastEditor;

	private static final String UNKNOWN_EDITOR = "unknown";

    public WikiPage(String title, String text) {
        this(title, text, new Date(), UNKNOWN_EDITOR, false);
    }
    
    public WikiPage(String title, String text, long date) {
		this(title, text, new Date(date), UNKNOWN_EDITOR, false);
    }

    public WikiPage(String title, String text, Date date, String lastEditor) {
        this(title, text, date, lastEditor, false);
    }

    private WikiPage(String title, String text, Date date, String lastEditor, boolean special) {
		this.title = title;
		this.text = text;
        this.date = date;
        this.lastEditor = lastEditor;
        this.special = special;
    }

	public static WikiPage createSpecialPage(String title, String text) {
		return new WikiPage(title, text, null, null, true);
	}
    
    public Date getDate() {
        return this.date;
    }

    public String getLastEditor() {
        return this.lastEditor;
    }

	public String getTitle() {
		return title;
	}

	public String getText() {
		return text;
	}

	public boolean isSpecial() {
		return this.special;
	}

    public boolean equals(Object otherObject) {
    	if (this == otherObject) {
    		return true;
    	}
		if ((otherObject == null) || (this.getClass() != otherObject.getClass())) {
			return false;
		}

		WikiPage otherWikipage = (WikiPage) otherObject;
		return this.getTitle().equals(otherWikipage.getTitle()) 
			&& this.date.equals(otherWikipage.date) 
			&& this.getText().equals(otherWikipage.getText());
    }

	public void setSpecial(boolean special) {
		this.special = special;
	}

}
