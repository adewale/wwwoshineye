package com.oshineye.kwikwiki.config;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import com.oshineye.kwikwiki.TunnellingException;

/**
 * @author aoshineye
 * A singleton that makes configuration information available to the rest of the system
 */
public class Configuration {
	private static Configuration instance;

	//We always use unix line-endings
	public static final String LINE_ENDING = "\n";
	private Properties properties;

	public static final String DB_URL = "kwikwiki.persistence.db.url";
	public static final String USER_NAME = "kwikwiki.persistence.db.username";
	public static final String PASSWORD = "kwikwiki.persistence.db.password";
	public static final String WIKI_BASE = "kwikwiki.persistence";
	public static final String WIKI_NAME = "kwikwiki.wikiname";

	private Configuration() {
		//load the kwikwiki.properties in the war
		ClassLoader loader = this.getClass().getClassLoader();
		InputStream is = loader.getResourceAsStream("kwikwiki.properties");
		Properties defaultProperties = new Properties(System.getProperties());

		try {
			defaultProperties.load(is);
		} catch (IOException ioe) {
			throw new TunnellingException(ioe);
		}

		loadUserProperties(defaultProperties);
	}

	private void loadUserProperties(Properties defaultProperties) {
		//if there's a kwikwiki.properties in user.home then load it on top
		String userHome = System.getProperty("user.home");
		File file = new File(userHome, "kwikwiki.properties");
		
		if (file.exists()) {
			Properties userProperties = new Properties(defaultProperties);
		
			try {
				userProperties.load(new FileInputStream(file));
			} catch (IOException ioe) {
				throw new TunnellingException(ioe);
			}
		
			this.properties = userProperties;
		} else {
			this.properties = defaultProperties;
		}
	}

	public static Configuration getInstance() {
		if (instance == null) {
			instance = new Configuration();
		}

		return instance;
	}

	public String getProperty(String name) {
		if (name == null) {
			return null;
		}
		return this.properties.getProperty(name);
	}

	public String getProperty(String name, String defaultValue) {
		String result = this.getProperty(name);

		if (result == null) {
			return defaultValue;
		}
		return result;
	}

	public boolean getValue(String name) {
		String value = this.getProperty(name);
		return "true".equalsIgnoreCase(value);
	}

	public void setProperty(String name, String value) {
		this.properties.setProperty(name, value);
	}
}
