package com.oshineye.kwikwiki.command;

import java.util.logging.Logger;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.oshineye.kwikwiki.specialpages.PageFactory;
import com.oshineye.kwikwiki.wikibase.AbstractWikiBase;
import com.oshineye.kwikwiki.wikibase.WikiBase;
import com.oshineye.kwikwiki.wikibase.WikiPage;

public class Edit extends Command {
	private static final Logger LOG = Logger.getLogger("com.oshineye.kwikwiki.command.Edit");

	public void execute(HttpServletRequest req, HttpServletResponse resp, ServletContext sc)
		throws Exception {
		LOG.info("==Executing edit command==");

		String title = req.getParameter("title");

		WikiBase wikiBase = AbstractWikiBase.getInstance();

		if (wikiBase.pageExists(title)) {
			WikiPage page = PageFactory.getPage(title);
			req.setAttribute("pageBean", page);
			Command.include(Command.EDIT_TEMPLATE, req, resp, sc);
		} else {
			//title is valid wikiName but page doesn't exist
			Command action = CommandFactory.getCommand("Create");
			action.execute(req, resp, sc);
		}
	}
}
