package com.oshineye.kwikwiki.wikibase;

import java.util.List;
import java.util.SortedSet;

public interface WikiBase {
	public abstract Index getIndex();
	public abstract void savePage(WikiPage rawPage);
	/**
	Return a SortedSet of the titles of all the pages
	in this Wiki.
	*/
	public abstract SortedSet getAllTitles();
	public abstract boolean pageExists(String title);
	public abstract SortedSet getTitlesStartingWith(String word);
	public abstract SortedSet getTitlesEndingWith(String word);
	/**
	* Return a SortedSet of Strings representing the titles of the pages that
	* contain the word.
	*/
	public abstract SortedSet locateWord(String word, boolean isCaseSensitive);
	/**
	* Return a SortedSet of Strings representing the titles of the pages that
	* contain the wikiname. WikiNames are case-sensitive so a search for
	* KwikWikiTest and KwikwikiTest give different results.
	*/
	public abstract SortedSet locateWikiName(String wikiName);
	/**
	* Load a WikiPage with the appropriate title. If the page doesn't exist
	* then return null.
	*/
	public abstract WikiPage loadPage(String title);
	/**
	* Get a List of ChangeLogs for the last numberOfDays. The number of days
	* must be greater than 0.
	*/
	public abstract List getChangeLogs(int numberOfDays);
	public abstract void deletePage(String title);
	/**
	 * A list of revisions to the page with this title sorted in descending order.
	 */
	public abstract List getRevisions(String title);
	public abstract WikiPage loadPage(String page, int revisionId);
}