package com.oshineye.kwikwiki.wikibase;

import java.io.File;
import java.io.FileFilter;
import java.io.FilenameFilter;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.SortedSet;
import java.util.TreeSet;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.oshineye.kwikwiki.TunnellingException;
import com.oshineye.kwikwiki.config.Configuration;

/**
 * @author aoshineye
 * A WikiBase back-end implementation which stores WikiPages and Changes in a file system.
 */
public class FileBase extends AbstractWikiBase {
	private static final Pattern REVISION_PATTERN = Pattern.compile("(.*,id:(.*),)");
	private static final String FILE_SEPARATOR = System.getProperty("file.separator");
	private static final String WIKI_DIR_NAME =
		System.getProperty("user.home") + FILE_SEPARATOR + "kwikwiki-data" + FILE_SEPARATOR;
	private File wikiDir = new File(WIKI_DIR_NAME);
	private static final String METADATA_DIR_NAME =	WIKI_DIR_NAME + FILE_SEPARATOR + "metadata" 
		+ FILE_SEPARATOR;
	private static final String CHANGES_DIR_NAME =
		METADATA_DIR_NAME + FILE_SEPARATOR + "changelogs" + FILE_SEPARATOR;
	private File changesDir = new File(CHANGES_DIR_NAME);
	private static final String HISTORY_DIR_NAME =
		METADATA_DIR_NAME + FILE_SEPARATOR + "history" + FILE_SEPARATOR;
	private File historyDir = new File(HISTORY_DIR_NAME);
	private static final String REVISION_HISTORY_FILE_NAME = "revisions.txt";
	private static final TextFilter TEXT_FILTER = new TextFilter();
	private static final String TEXT_EXTENSION = ".txt";
	private static final int TEXT_EXTENSION_LENGTH = 4; //includes the dot
	private FileSystem fileSystem = getFileSystem();
	private IdGenerator idGenerator;

	protected FileBase() {
	}

	private Map getCurrentRevisions() {
		File[] revisionDirs = historyDir.listFiles(new FileFilter() {
			public boolean accept(File file) {
				return file.isDirectory();
			}
		});
		
		Map revisions = new HashMap();
		for (int i = 0; i < revisionDirs.length; i++) {
			File revisionsFile = new File(revisionDirs[i], REVISION_HISTORY_FILE_NAME);
			if (!this.fileSystem.exists(revisionsFile)) {
				continue;
			}
			
			String line = this.fileSystem.getLastLine(revisionsFile);
			Matcher matcher = REVISION_PATTERN.matcher(line);
			if (matcher.find()) {
				int id = Integer.parseInt(matcher.group(2));
				revisions.put(revisionDirs[i].getName(), new Integer(id));
			}
		}
		return revisions;
	}

	protected SortedSet loadTitles() {
		File[] files = wikiDir.listFiles(TEXT_FILTER);

		SortedSet set = new TreeSet();
		int directoryNameLength = WIKI_DIR_NAME.length();

		for (int i = 0; i < files.length; i++) {
			String temp = files[i].toString();
			int titleLength = temp.length() - TEXT_EXTENSION_LENGTH;

			//we only want the title not including the wiki directory or file extension
			String title = temp.substring(directoryNameLength, titleLength);
			set.add(title);
		}

		return set;
	}

	/**
	* TextFilter only accepts files with names that end in ".txt".
	* A FilenameFilter was used rather than a FileFilter to avoid the ovehead
	* of creating a File object for each file in the directory that will be
	* filtered. This has the side-effect that the <code>file</code> argument is
	* completely redundant.
	*/
	static class TextFilter implements FilenameFilter {
		public boolean accept(File file, String name) {
			return name.endsWith(".txt");
		}
	}

	public void deletePage(String title) {
		File file = new File(WIKI_DIR_NAME + title + TEXT_EXTENSION);

		if (this.fileSystem.exists(file)) {
			getIndex().delete(title, this.fileSystem.readText(file).toString());

			this.fileSystem.delete(file);
		}
	}

	public WikiPage loadPage(String title) {
		File file = new File(WIKI_DIR_NAME + title + TEXT_EXTENSION);

		return convertFileToWikiPage(title, file);
	}

	private WikiPage convertFileToWikiPage(String title, File file) {
		if (!this.fileSystem.exists(file)) {
			return null;
		}
		CharSequence rawText = this.fileSystem.readText(file);
		return new WikiPage(title, rawText.toString(), file.lastModified());
	}

	protected void storePage(WikiPage rawPage) {
		String title = rawPage.getTitle();
		String newText = rawPage.getText();

		//1 argument constructor chosen for performance
		File file = new File(WIKI_DIR_NAME + title + TEXT_EXTENSION);

		this.fileSystem.writeText(file, newText, false);
	}

	protected void storeNewPage(WikiPage rawPage) {
		this.storePage(rawPage);
	}

	protected void storeChange(Change change) {
		//1 argument constructor chosen for performance
		File file = new File(CHANGES_DIR_NAME + change.getDay() + TEXT_EXTENSION);

		String newChangeLine = Configuration.LINE_ENDING + change.convertToString();

		this.fileSystem.writeText(file, newChangeLine, true);
	}

	public List getChangeLogs(int numberOfDays) {
		//load all the names of all the changelog files
		String[] changeLogFiles = changesDir.list();
		int numberOfLogs = changeLogFiles.length;

		Date[] times = convertToDates(changeLogFiles);

		//sort the names by time
		Arrays.sort(times);

		List logs = new ArrayList();
		int startingIndex = numberOfLogs - numberOfDays;
		if (startingIndex < 0) {//numberOfDays > numberOfLogs
			startingIndex = 0;
		}
		
		//create ChangeLog objects representing the last numberOfDays days
		for (int i = startingIndex; i < numberOfLogs; i++) {
			String currentDay = Change.formatChangeDate(times[i]);
			File currentChangeFile = new File(CHANGES_DIR_NAME + currentDay + TEXT_EXTENSION);
			List lines = this.fileSystem.readLines(currentChangeFile);
			logs.add(new ChangeLog(Change.parseChanges(lines)));
		}

		Collections.reverse(logs);
		return logs;
	}

	public List getRevisions(String title) {
		File parentDir = new File(historyDir, title);
		File revisionsFile = new File(parentDir, REVISION_HISTORY_FILE_NAME);
		if (!this.fileSystem.exists(revisionsFile)) {
			return Collections.EMPTY_LIST;
		}

		List revisions = Revision.parseRevisions(this.fileSystem.readLines(revisionsFile));
		Collections.sort(revisions, Collections.reverseOrder());
		return revisions;
	}

	protected void storeRevision(WikiPage rawPage) {
		String title = rawPage.getTitle();
		File parentDir = new File(historyDir, title);
		int revisionId = this.getIdGenerator().next(title);
		File historicalFile = new File(parentDir, revisionId + TEXT_EXTENSION);

		//ensure directory structure exists
		parentDir.mkdirs();

		this.fileSystem.writeText(historicalFile, rawPage.getText(), false);
	
		File revisionFile = new File(parentDir, REVISION_HISTORY_FILE_NAME);

		String newRevisionLine = Configuration.LINE_ENDING 
			+ new Revision(rawPage, revisionId).convertToString();

		this.fileSystem.writeText(revisionFile, newRevisionLine, true);
	}

	public WikiPage loadPage(String title, int revisionId) {
		File parentDir = new File(historyDir, title);
		File file = new File(parentDir, revisionId + TEXT_EXTENSION);
		CharSequence text = this.fileSystem.readText(file);
		List lines = this.fileSystem.readLines(new File(parentDir, REVISION_HISTORY_FILE_NAME));

		//revisions start from 1 so skip element 0 which is blank
		String revisionLine = (String) lines.get(revisionId);
		Revision revision = Revision.createRevisionFromString(revisionLine);
		return new WikiPage(title, text.toString(), revision.getDate(), revision.getEditor());
	}

	private Date[] convertToDates(String[] fileNames) {
		int numberOfLogs = fileNames.length;

		//convert the names to dates
		Date[] times = new Date[numberOfLogs];

		try {
			for (int i = 0; i < numberOfLogs; i++) {
				String currentName = fileNames[i];
				int nameLength = currentName.length() - TEXT_EXTENSION_LENGTH;
				String temp = currentName.substring(0, nameLength);
				times[i] = Change.parseChangeDay(temp);
			}
		} catch (ParseException pe) {
			throw new TunnellingException(pe);
		}

		return times;
	}

	FileSystem getFileSystem() {
		return new DefaultFileSystem();
	}

	private IdGenerator getIdGenerator() {
		if (this.idGenerator == null) {
			this.idGenerator = new IdGenerator(getCurrentRevisions());
		}
		
		return this.idGenerator;
	}

	
	/**
	 * @author aoshineye
	 *
	 * A thread-safe id generator based on the StaticCounter example from Doug Lea's
	 * Concurrent programming in Java 2nd edition, page 86
	 */
	private class IdGenerator {
		private Map idMap;
		
		public IdGenerator(Map currentRevisionIds) {
			this.idMap = currentRevisionIds;
		}
		
		public synchronized int next(String title) {
			int idNumber;
			Integer idObject = (Integer) idMap.get(title);
			if (idObject == null) {
				idNumber = 0;
			} else {
				idNumber = idObject.intValue();
			}
			idNumber++;
			idMap.put(title, new Integer(idNumber));
			return idNumber;
		}
	}
}
