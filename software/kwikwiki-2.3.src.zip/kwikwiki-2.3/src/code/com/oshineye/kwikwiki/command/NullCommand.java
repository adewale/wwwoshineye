package com.oshineye.kwikwiki.command;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * @author aoshineye
 * This command handles special cases.
 */
public class NullCommand extends Command {

	public void execute(HttpServletRequest req, HttpServletResponse resp, ServletContext sc)
		throws Exception {
		Command.include(Command.ERROR, req, resp, sc);
	}

}
