package com.oshineye.kwikwiki.config;

import java.io.Serializable;

/**
 * @author aoshineye
 * These beans should not be compared or hashed.
 */
public class ConfigurationBean implements Serializable {
	private String wikiName;
	public ConfigurationBean() {
		Configuration config = Configuration.getInstance();
		this.wikiName = config.getProperty(Configuration.WIKI_NAME, "KwikWiki");
	}

	public String getWikiName() {
		return this.wikiName;
	}

	public int hashCode() {
		return 0;//these beans should not be compared
	}
	
	public boolean equals(Object other) {
		return true;//these beans should not be compared
	}

}
