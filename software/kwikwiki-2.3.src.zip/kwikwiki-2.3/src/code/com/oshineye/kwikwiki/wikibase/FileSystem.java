package com.oshineye.kwikwiki.wikibase;

import java.io.File;
import java.util.List;


/**
 * @author aoshineye
 */
public interface FileSystem {
	public List readLines(File file);
	
	public CharSequence readText(File file);
	
	public void writeText(File file, CharSequence text, boolean shouldAppend);
	
	public String getLastLine(File file);
	
	public boolean exists(File file);
	
	public void delete(File file);
}
