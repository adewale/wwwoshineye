package com.oshineye.kwikwiki.wikibase;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Reader;
import java.util.ArrayList;
import java.util.List;

import com.oshineye.kwikwiki.TunnellingException;
import com.oshineye.kwikwiki.config.Configuration;


/**
 * @author aoshineye
 */
public class DefaultFileSystem implements FileSystem {
	public void writeText(File file, CharSequence text, boolean shouldAppend) {
		BufferedWriter bw;

		try {
			bw = new BufferedWriter(new FileWriter(file, shouldAppend));
			bw.write(text.toString());
			bw.close();
		} catch (IOException ioe) {
			throw new TunnellingException(ioe);
		}
	}

	public CharSequence readText(File file) {
		/*
		potential exists for performance optimisation by specifying buffer
		sizes for the BufferedReader and StringBuffer based on the file's
		length. Although that might lead to problems with very large files.
		*/
		try {
			BufferedReader br = new BufferedReader(new FileReader(file));
			StringBuffer sb = new StringBuffer();

			String line;
			while ((line = br.readLine()) != null) {
				sb.append(line);
				sb.append(Configuration.LINE_ENDING); //avoid concatenation penalty
			}

			br.close();

			return sb;
		} catch (IOException ioe) {
			throw new TunnellingException(ioe);
		}
	}

	public List readLines(File file) {
		try {
			return readLines(new FileReader(file));
		} catch (IOException ioe) {
			throw new TunnellingException(ioe);
		}
	}

	protected List readLines(Reader reader) throws IOException {
		List lines = new ArrayList();
		BufferedReader br = new BufferedReader(reader);

		String line;
		while ((line = br.readLine()) != null) {
			lines.add(line);
		}

		br.close();

		return lines;
	}

	public String getLastLine(File file) {
			String line = null;
			List lines = this.readLines(file);
			int linesSize = lines.size(); 
			if (linesSize > 0) {
				line = (String) lines.get(linesSize-1);
			}
			return line + "";//always return a valid string
	}

	public boolean exists(File file) {
		return file.exists();
	}
	
	public void delete(File file) {
		file.delete();
	}
}
