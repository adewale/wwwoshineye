package com.oshineye.kwikwiki.markup.rules;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.oshineye.kwikwiki.wikibase.WikiBase;

/**
 * @author aoshineye
 * A class that encapsulates a pairing of a regular expression pattern and the
 *  text that should replace it. Taken together these form a markup rule that
 * defines the meaning of the language used on a wiki page.
 */
public class MarkUpRule {
    private Pattern pattern;
    private String replacementText;
	private WikiBase wikiBase;

    /**
     Construct a MarkUpRule which encapsulates a mapping from a regular expression pattern
     to the text that it will use to replace the input to the pattern's matcher.
     */
    protected MarkUpRule(WikiBase wikiBase, String regularExpression, String replacementText) {
    	this.wikiBase = wikiBase;
        this.pattern = Pattern.compile(regularExpression, Pattern.MULTILINE);
        this.replacementText = replacementText;
    }

    protected MarkUpRule(String regularExpression, String replacementText) {
        this.pattern = Pattern.compile(regularExpression, Pattern.MULTILINE);
        this.replacementText = replacementText;
    }
    
    protected MarkUpRule(WikiBase wikiBase, Pattern pattern, String replacementText) {
    	this.wikiBase = wikiBase;
        this.pattern = pattern;
        this.replacementText = replacementText;
    }

    protected MarkUpRule(Pattern pattern, String replacementText) {
        this.pattern = pattern;
        this.replacementText = replacementText;
    }
    
    protected MarkUpRule() {
        //default no-arguments constructor
    }

	/**
	Construct a MarkUpRule which encapsulates a mapping from a regular expression pattern
	to the text that it will use to replace the input to the pattern's matcher.
	This constructor uses the empty string as it's replacement text to signify that it
	doesn't need that half of the mapping.
	*/
    public MarkUpRule(WikiBase wikiBase, String regularExpression) {
    	this(wikiBase, regularExpression, "");
	}

	protected Matcher getMatcher(CharSequence text) {
        //don't attempt to reuse matchers via reset() as it isn't thread-safe under high-load
        return this.pattern.matcher(text);
    }

    public CharSequence apply(CharSequence text) {
        Matcher matcher = this.getMatcher(text);

        if (matcher.find()) { //only process if there are matches
            return matcher.replaceAll(this.replacementText);
        }

        return text; //no matches so return original
    }
    
    public WikiBase getWikiBase() {
    	return this.wikiBase;
    }

	public static CharSequence applyRules(MarkUpRule[] rules, CharSequence text) {
		for (int i = 0; i < rules.length; i++) {
			text = rules[i].apply(text);
		}
		return text;
	}
}
