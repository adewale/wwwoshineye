package com.oshineye.kwikwiki.markup;

import java.util.Collection;
import java.util.List;

/**
 * @author aoshineye
 *
 */
public class WikiSyntax implements Syntax {

	public String convertToHtml(CharSequence text) {
		return MarkUpEngine.convertToHtml(text);
	}

	public String convertToRawList(Collection items) {
		return MarkUpEngine.convertToWikiList(items);
	}

	public boolean isValidName(String title) {
		return MarkUpEngine.isWikiName(title);
	}

	public String convertToText(List logs) {
		return MarkUpEngine.convertToText(logs);
	}

}
