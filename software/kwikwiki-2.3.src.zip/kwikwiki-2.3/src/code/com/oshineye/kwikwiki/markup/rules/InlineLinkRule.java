package com.oshineye.kwikwiki.markup.rules;

import com.oshineye.kwikwiki.wikibase.WikiBase;

public class InlineLinkRule extends MarkUpRule {
    private static final String PATTERN = "([a-zA-Z]{3,}://([\\S]+))";
    private static final String REPLACEMENT_TEXT = "<a href=\"$1\">$1</a>";

	public InlineLinkRule(WikiBase wikiBase) {
		super(wikiBase, InlineLinkRule.PATTERN, InlineLinkRule.REPLACEMENT_TEXT);
	}
}
