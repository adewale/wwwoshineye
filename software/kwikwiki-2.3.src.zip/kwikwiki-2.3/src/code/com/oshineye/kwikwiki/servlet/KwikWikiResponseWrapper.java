package com.oshineye.kwikwiki.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletResponse;

import com.opensymphony.module.oscache.web.filter.CacheHttpServletResponseWrapper;

/**
 * @author aoshineye
 */
public class KwikWikiResponseWrapper extends CacheHttpServletResponseWrapper {
	private PrintWriter writer;

	public KwikWikiResponseWrapper(ServletResponse resp) {
		super((HttpServletResponse)resp);
	}

	/* (non-Javadoc)
	 * @see javax.servlet.ServletResponse#getWriter()
	 */
	public PrintWriter getWriter() throws IOException {
		this.writer = new PrintWriter(this.getOutputStream());
		return this.writer;
	}

	/* (non-Javadoc)
	 * @see javax.servlet.ServletResponse#flushBuffer()
	 */
	public void flushBuffer() {
		//this exists to make sure that the page is actually displayed on Tomcat
		if (writer != null) {
			writer.flush();
		}
	}

}
