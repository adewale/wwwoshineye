package com.oshineye.kwikwiki.command;

import java.util.logging.Logger;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.oshineye.kwikwiki.wikibase.AbstractWikiBase;
import com.oshineye.kwikwiki.wikibase.WikiBase;
import com.oshineye.kwikwiki.wikibase.WikiPage;

public class Create extends Command {
	private static final String INITIAL_TEXT = "Please add your text here.";
	private static final Logger LOG = Logger.getLogger("com.oshineye.kwikwiki.command.Create");

	public void execute(HttpServletRequest req, HttpServletResponse resp, ServletContext sc)
		throws Exception {
		LOG.info("==Executing create command==");

		String title = req.getParameter("title");

		WikiBase wikiBase = AbstractWikiBase.getInstance();

		if (!wikiBase.pageExists(title)) {
			WikiPage page = new WikiPage(title, INITIAL_TEXT);
			req.setAttribute("pageBean", page);
			Command.include(Command.EDIT_TEMPLATE, req, resp, sc);
		} else {
			Command action = CommandFactory.getCommand("Edit");
			action.execute(req, resp, sc);
		}
	}
}
