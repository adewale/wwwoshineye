package com.oshineye.kwikwiki.markup.rules;

import com.oshineye.kwikwiki.wikibase.WikiBase;

/**
 * @author aoshineye
 */
public class InterWikiRule extends MarkUpRule {
	private static MarkUpRule[] RULES;
	
	public InterWikiRule(WikiBase wikiBase) {
		RULES = new MarkUpRule[]{
			new MarkUpRule(wikiBase, "((Wiki):([A-za-z0-9]+))", "<a href=\"http://c2.com/cgi/wiki?$3\">$1</a>"),
			new MarkUpRule(wikiBase, "((Xtc):([A-za-z0-9]+))", "<a href=\"http://www.xpdeveloper.org/xpdwiki/Wiki.jsp?page=$3\">$1</a>"),
			new MarkUpRule(wikiBase, "((BookShelved):([A-za-z0-9]+))", "<a href=\"http://bookshelved.org/cgi-bin/wiki.pl?$3\">$1</a>"),
			new MarkUpRule(wikiBase, "((MeatBall):([A-za-z0-9]+))", "<a href=\"http://www.usemod.com/cgi-bin/mb.pl?$3\">$1</a>")
		};
	}

	public CharSequence apply(CharSequence text) {
		text = MarkUpRule.applyRules(RULES, text);
		return text;
	}

}
