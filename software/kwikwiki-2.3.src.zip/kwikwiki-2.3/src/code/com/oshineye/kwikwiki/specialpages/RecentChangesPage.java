package com.oshineye.kwikwiki.specialpages;

import java.util.List;

import com.oshineye.kwikwiki.markup.MarkUpEngine;
import com.oshineye.kwikwiki.wikibase.AbstractWikiBase;

public class RecentChangesPage implements SpecialPage {
    private static final int NUMBER_OF_CHANGES = 5;

    public RecentChangesPage() {
    	//default constructor provided to enable dynamic instantiation
    }

	public String getText() {
		List logs = AbstractWikiBase.getInstance().getChangeLogs(NUMBER_OF_CHANGES);

		return MarkUpEngine.convertToText(logs);
	}

}
