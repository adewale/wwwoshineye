package com.oshineye.kwikwiki.specialpages;

import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import com.oshineye.kwikwiki.wikibase.AbstractWikiBase;
import com.oshineye.kwikwiki.wikibase.WikiPage;


/**
 * @author aoshineye
 * A class responsible for creating and retrieving SpecialPages.
 */
public class PageFactory {
    private static final Map SPECIAL_PAGES = new TreeMap();

    static {
        SPECIAL_PAGES.put("WantedPages", new WantedPagesPage());
        SPECIAL_PAGES.put("OrphanedPages", new OrphanedPagesPage());
        SPECIAL_PAGES.put("RecentChanges", new RecentChangesPage());
        SPECIAL_PAGES.put("TodaysChanges", new TodaysChangesPage());
        SPECIAL_PAGES.put("RandomPages", new RandomPagesPage());
        SPECIAL_PAGES.put("TitleIndex", new TitleIndexPage());
        SPECIAL_PAGES.put("SpecialPages", new SpecialPagesPage());
    }

    public static boolean isSpecialPage(String title) {
        return SPECIAL_PAGES.containsKey(title);
    }

    public static Set getAllSpecialPages() {
        return SPECIAL_PAGES.keySet();
    }

    private static WikiPage getSpecialPage(String title) {
        SpecialPage special = (SpecialPage) PageFactory.SPECIAL_PAGES.get(title);

        return WikiPage.createSpecialPage(title, special.getText());
    }

    public static WikiPage getPage(String title) {
        WikiPage rawPage;

        if (PageFactory.isSpecialPage(title)) {
            rawPage = PageFactory.getSpecialPage(title);
        } else {
            rawPage = AbstractWikiBase.getInstance().loadPage(title);
        }

        return rawPage;
    }

	public static WikiPage getPage(String title, int revisionId) {
		WikiPage rawPage;

		if (PageFactory.isSpecialPage(title)) {
			rawPage = PageFactory.getSpecialPage(title);
		} else {
			rawPage = AbstractWikiBase.getInstance().loadPage(title, revisionId);
			
			//all versioned/historical pages are read-only
			rawPage.setSpecial(true);
		}

		return rawPage;
	}
}
