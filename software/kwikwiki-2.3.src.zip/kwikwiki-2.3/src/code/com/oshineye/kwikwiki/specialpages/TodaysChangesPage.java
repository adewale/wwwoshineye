package com.oshineye.kwikwiki.specialpages;

import java.util.List;

import com.oshineye.kwikwiki.config.Configuration;
import com.oshineye.kwikwiki.markup.MarkUpEngine;
import com.oshineye.kwikwiki.wikibase.AbstractWikiBase;
import com.oshineye.kwikwiki.wikibase.ChangeLog;

public class TodaysChangesPage extends RecentChangesPage {
	public String getText() {
		List logs = AbstractWikiBase.getInstance().getChangeLogs(1);
		ChangeLog lastLog = (ChangeLog) logs.get(0);
		
		if (lastLog.isToday()) {
			return MarkUpEngine.convertToText(logs);
		}
		return MarkUpEngine.convertToBold(lastLog.getDay()) + Configuration.LINE_ENDING;
	}

}
