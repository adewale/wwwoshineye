package com.oshineye.aggrevator.components.commands;

import com.oshineye.aggrevator.store.EntryStore;
import com.oshineye.aggrevator.store.FeedStore;


public interface Command {

	void execute(FeedStore feedStore, EntryStore entryStore);

}
