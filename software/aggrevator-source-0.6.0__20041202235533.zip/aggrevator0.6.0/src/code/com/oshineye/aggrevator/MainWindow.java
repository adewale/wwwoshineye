package com.oshineye.aggrevator;

import java.util.List;

import org.apache.log4j.Logger;
import org.eclipse.jface.action.Action;
import org.eclipse.jface.action.MenuManager;
import org.eclipse.jface.action.Separator;
import org.eclipse.jface.action.StatusLineManager;
import org.eclipse.jface.action.ToolBarManager;
import org.eclipse.jface.window.ApplicationWindow;
import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.SashForm;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.layout.RowData;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.TabFolder;
import org.eclipse.swt.widgets.TabItem;
import org.eclipse.swt.widgets.Text;
import org.logicalcobwebs.proxool.ProxoolFacade;

import EDU.oswego.cs.dl.util.concurrent.BoundedBuffer;
import EDU.oswego.cs.dl.util.concurrent.Executor;
import EDU.oswego.cs.dl.util.concurrent.PooledExecutor;
import EDU.oswego.cs.dl.util.concurrent.ThreadedExecutor;

import com.oshineye.aggrevator.components.ApplicationWindowStatusRecorder;
import com.oshineye.aggrevator.components.BrowserController;
import com.oshineye.aggrevator.components.BrowserControllerImpl;
import com.oshineye.aggrevator.components.BrowserModel;
import com.oshineye.aggrevator.components.BrowserModelImpl;
import com.oshineye.aggrevator.components.BrowserStatusTextListener;
import com.oshineye.aggrevator.components.BrowserView;
import com.oshineye.aggrevator.components.BrowserViewImpl;
import com.oshineye.aggrevator.components.ComponentLocator;
import com.oshineye.aggrevator.components.EntryModel;
import com.oshineye.aggrevator.components.EntryModelImpl;
import com.oshineye.aggrevator.components.EntryView;
import com.oshineye.aggrevator.components.EntryViewController;
import com.oshineye.aggrevator.components.EntryViewControllerImpl;
import com.oshineye.aggrevator.components.EntryViewImpl;
import com.oshineye.aggrevator.components.FeedModel;
import com.oshineye.aggrevator.components.FeedModelImpl;
import com.oshineye.aggrevator.components.FeedView;
import com.oshineye.aggrevator.components.FeedViewController;
import com.oshineye.aggrevator.components.FeedViewControllerImpl;
import com.oshineye.aggrevator.components.FeedViewImpl;
import com.oshineye.aggrevator.components.Filter;
import com.oshineye.aggrevator.components.FilterableModel;
import com.oshineye.aggrevator.components.ListView;
import com.oshineye.aggrevator.components.SearchPanelController;
import com.oshineye.aggrevator.components.StatusRecorder;
import com.oshineye.aggrevator.components.ThreadPool;
import com.oshineye.aggrevator.components.ThreadPoolImpl;
import com.oshineye.aggrevator.components.actions.AbstractEntrySelectedAction;
import com.oshineye.aggrevator.components.actions.AbstractWidgetSelectedAction;
import com.oshineye.aggrevator.components.actions.BrowserViewFocusAction;
import com.oshineye.aggrevator.components.actions.EntryViewFocusAction;
import com.oshineye.aggrevator.components.actions.ExitAction;
import com.oshineye.aggrevator.components.actions.ExportOPMLAction;
import com.oshineye.aggrevator.components.actions.FeedViewFocusAction;
import com.oshineye.aggrevator.components.actions.ImportOPMLAction;
import com.oshineye.aggrevator.components.actions.LessLikeThisAction;
import com.oshineye.aggrevator.components.actions.MarkFeedReadAction;
import com.oshineye.aggrevator.components.actions.MoreLikeThisAction;
import com.oshineye.aggrevator.components.actions.NewFeedAction;
import com.oshineye.aggrevator.components.actions.RefreshAllFeedsAction;
import com.oshineye.aggrevator.components.actions.RefreshFeedAction;
import com.oshineye.aggrevator.components.actions.ShowSelectedEntryAction;
import com.oshineye.aggrevator.components.actions.ShowSelectedFeedAction;
import com.oshineye.aggrevator.store.EntryStore;
import com.oshineye.aggrevator.store.FeedIdentityMap;
import com.oshineye.aggrevator.store.FeedStore;
import com.oshineye.aggrevator.store.MySqlEntryStore;
import com.oshineye.aggrevator.store.MySqlFeedStore;
import com.oshineye.aggrevator.util.QueryLoader;

public class MainWindow extends ApplicationWindow {
	private static final Logger LOG = Logger.getLogger(MainWindow.class);
	private static final int[] RATIO_OF_FILTER_TO_PANEL = new int[]{1, 8};
	private static final int[] RATIO_OF_LEFT_TO_RIGHT_PANEL = new int[]{40,60};
	
	private ThreadPool threadPool;
	private Executor refreshFeedExecutor;
	private PooledExecutor searchExecutor;
	
	private StatusLineManager statusLineManager;
	
	private FeedStore feedStore;
	private EntryStore entryStore;
	
	private BrowserModel browserModel;
	private EntryModel entryModel;
	private FeedModel feedModel;
	private FeedView feedView;
	private EntryView entryView;
	private BrowserView browserView;
	
	private Action exitAction;
	private Action importAction;
	private Action newFeedAction;
	private Action refreshAllFeedsAction;
	private RefreshFeedAction refreshFeedAction;
	private Action exportAction;
	private AbstractEntrySelectedAction moreLikeThisAction;
	private AbstractEntrySelectedAction lessLikeThisAction;
	private Action focusOnFeedViewAction;
	private Action focusOnEntryViewAction;
	private Action focusOnBrowserViewAction;
	private AbstractWidgetSelectedAction markFeedReadAction;
	private AbstractWidgetSelectedAction showSelectedFeedAction;
	private AbstractEntrySelectedAction showSelectedEntryAction;
	private FeedIdentityMap feedIdentityMap;
	
	private ComponentLocator componentLocator;
	
	public MainWindow() {
		super(null);
		
		this.feedIdentityMap = new FeedIdentityMap();
		QueryLoader queryLoader = new QueryLoader();
		this.feedStore = new MySqlFeedStore(Configuration.getDatabaseName(), feedIdentityMap, queryLoader);
		this.entryStore = new MySqlEntryStore(Configuration.getDatabaseName(), feedIdentityMap, queryLoader);

		this.browserModel = new BrowserModelImpl();
		this.entryModel = new EntryModelImpl();
		List allFeeds = feedStore.findAllFeeds();
		this.feedModel = new FeedModelImpl(allFeeds);
		
		//this does not have to be shutdown as it doesn't maintain a pool
		this.refreshFeedExecutor = new ThreadedExecutor();
		
		this.threadPool = new ThreadPoolImpl(feedStore, entryStore, feedModel, entryModel);
		this.searchExecutor = new PooledExecutor(new BoundedBuffer(1), 1);
		
		StatusRecorder recorder = new ApplicationWindowStatusRecorder(this);
		this.importAction = new ImportOPMLAction(this, feedStore, feedModel, recorder);
		this.exportAction = new ExportOPMLAction(this, feedModel, recorder);
		this.newFeedAction = new NewFeedAction(this, feedModel, feedStore, entryStore, recorder);
		this.exitAction = new ExitAction(this, threadPool);
		
		this.refreshAllFeedsAction = new RefreshAllFeedsAction(threadPool, feedModel);
		this.refreshFeedAction = new RefreshFeedAction(refreshFeedExecutor, feedStore, entryStore, feedModel, entryModel);
		this.markFeedReadAction = new MarkFeedReadAction(feedStore, entryStore, feedModel, entryModel);

		this.moreLikeThisAction = new MoreLikeThisAction(entryStore, feedModel, entryModel);
		this.lessLikeThisAction = new LessLikeThisAction(entryStore, feedModel, entryModel);
		
		this.componentLocator = new ComponentLocator();
		this.focusOnFeedViewAction = new FeedViewFocusAction(componentLocator);
		this.focusOnEntryViewAction = new EntryViewFocusAction(componentLocator);
		this.focusOnBrowserViewAction = new BrowserViewFocusAction(componentLocator);
		this.showSelectedFeedAction = new ShowSelectedFeedAction(componentLocator);
		this.showSelectedEntryAction = new ShowSelectedEntryAction(feedModel, entryModel, componentLocator);
		
		this.addMenuBar();
		this.addStatusLine();
		this.addToolBar(SWT.SHADOW_OUT);
	}

	protected Control createContents(Composite root) {
		Shell shell = getShell();
		shell.setText(Constants.APPLICATION_NAME_AND_VERSION_NUMBER);
		shell.setMaximized(true);
		
		SashForm feedsPanelAndBrowserPanel = new SashForm(root, SWT.HORIZONTAL);
		Composite feedsAndEntriesPanel = new SashForm(feedsPanelAndBrowserPanel, SWT.VERTICAL);
		
		TabFolder tabFolder = new TabFolder(feedsAndEntriesPanel, SWT.TOP);
		
		SashForm filterAndFeedViewPanel = new SashForm(tabFolder, SWT.VERTICAL);
		createFilterBar(filterAndFeedViewPanel, feedModel, "Filter By Feed Url/Title: ");
		
		TabItem feedTab = new TabItem(tabFolder, SWT.NULL);
		feedTab.setControl(filterAndFeedViewPanel);
		feedTab.setText("Feeds");
		
		createSearchTab(tabFolder);
		
		FeedViewController feedController = new FeedViewControllerImpl(feedModel, entryModel, feedStore, entryStore);
		this.feedView = new FeedViewImpl(feedModel, filterAndFeedViewPanel, feedController);
		componentLocator.registerListView(feedView, FeedView.class);
		addSelectionListeners(feedView, new SelectionListener[]{refreshFeedAction, markFeedReadAction, moreLikeThisAction, lessLikeThisAction, showSelectedEntryAction, showSelectedFeedAction});
		filterAndFeedViewPanel.setWeights(RATIO_OF_FILTER_TO_PANEL);
		
		Composite browserPanel = new SashForm(feedsPanelAndBrowserPanel, SWT.VERTICAL);
		BrowserController browserController = new BrowserControllerImpl(feedModel, entryModel, feedStore, entryStore);
		BrowserStatusTextListener browserStatusTextListener = new BrowserStatusTextListener(statusLineManager);	

		SashForm filterAndEntryViewPanel = new SashForm(feedsAndEntriesPanel, SWT.VERTICAL);
		createFilterBar(filterAndEntryViewPanel, entryModel, "Filter By Entry Title: ");
		EntryViewController entryController = new EntryViewControllerImpl(feedModel, entryModel, browserModel, feedStore, entryStore);
		this.entryView = new EntryViewImpl(entryModel, filterAndEntryViewPanel, entryController);
		componentLocator.registerListView(entryView, EntryView.class);
		addSelectionListeners(entryView, new SelectionListener[]{moreLikeThisAction, lessLikeThisAction, showSelectedEntryAction});
		filterAndEntryViewPanel.setWeights(RATIO_OF_FILTER_TO_PANEL);
		
		this.browserView = new BrowserViewImpl(browserModel, browserPanel, browserStatusTextListener, browserController);
		componentLocator.registerBrowserView(browserView);

		feedModel.loadFeeds();
		feedsPanelAndBrowserPanel.setWeights(RATIO_OF_LEFT_TO_RIGHT_PANEL);
		
		String startMessage = "Started " + Constants.APPLICATION_NAME_AND_VERSION_NUMBER + " with " + feedStore.findAllFeeds().size() + " feeds";
		statusLineManager.setMessage(startMessage);
		LOG.info(startMessage);
		
		return null;
	}

	private void addSelectionListeners(ListView view, SelectionListener[] listeners) {
		for (int i = 0; i < listeners.length; i++) {
			view.addSelectionListener(listeners[i]);
		}
	}

	private void createSearchTab(TabFolder tabFolder) {
		Group searchTermsGroup = new Group(tabFolder, SWT.NONE);
		searchTermsGroup.setText("Describe what you are looking for");
		GridLayout layout = new GridLayout();
		layout.numColumns = 2;
		searchTermsGroup.setLayout(layout);
		Label contentContains = new Label(searchTermsGroup, SWT.NONE);
		contentContains.setText("Content contains: ");
		Text contentContainsInput = new Text(searchTermsGroup, SWT.BORDER);
		contentContainsInput.setLayoutData(new GridData(GridData.GRAB_HORIZONTAL | GridData.HORIZONTAL_ALIGN_FILL));
		new SearchPanelController(entryModel, entryStore, contentContainsInput);
		
		TabItem searchTab = new TabItem(tabFolder, SWT.NULL);
		searchTab.setControl(searchTermsGroup);
		searchTab.setText("Search");
	}

	private void createFilterBar(Composite panel, FilterableModel model, String description) {
		Composite toolBarGroup = new Composite(panel, SWT.NONE);
		toolBarGroup.setLayoutData(new RowData(SWT.MAX, SWT.DEFAULT));
		GridLayout toolBarLayout = new GridLayout();
		toolBarLayout.numColumns = 3;
		toolBarGroup.setLayout(toolBarLayout);
		Label filterLabel = new Label(toolBarGroup, SWT.NONE);
		filterLabel.setText(description);
		final Text filterInput = new Text(toolBarGroup, SWT.BORDER);
		filterInput.setLayoutData(new GridData(GridData.GRAB_HORIZONTAL | GridData.HORIZONTAL_ALIGN_FILL));
		filterInput.addModifyListener(new Filter(model, filterInput));
	}

	public void dispose() {
		searchExecutor.shutdownNow();
		ProxoolFacade.shutdown(0);
	}

	protected MenuManager createMenuManager() {
		MenuManager menuBar = new MenuManager();
		
		MenuManager fileMenu = new MenuManager("&File");
		fileMenu.add(newFeedAction);
		fileMenu.add(importAction);
		fileMenu.add(exportAction);
		fileMenu.add(new Separator());
		fileMenu.add(exitAction);
		
		MenuManager feedMenu = new MenuManager("Fee&d");
		feedMenu.add(refreshAllFeedsAction);
		feedMenu.add(refreshFeedAction);
		feedMenu.add(new Separator());
		feedMenu.add(markFeedReadAction);
		feedMenu.add(showSelectedFeedAction);
		
		MenuManager entryMenu = new MenuManager("&Entry");
		entryMenu.add(moreLikeThisAction);
		entryMenu.add(lessLikeThisAction);
		entryMenu.add(new Separator());
		entryMenu.add(showSelectedEntryAction);
		
		MenuManager viewMenu = new MenuManager("&View");
		viewMenu.add(focusOnFeedViewAction);
		viewMenu.add(focusOnEntryViewAction);
		viewMenu.add(focusOnBrowserViewAction);
		
		menuBar.add(fileMenu);
		menuBar.add(feedMenu);
		menuBar.add(entryMenu);
		menuBar.add(viewMenu);
		return menuBar;
	}

	protected StatusLineManager createStatusLineManager() {
		this.statusLineManager = new StatusLineManager();
		return statusLineManager;
	}
	
	protected ToolBarManager createToolBarManager(int style) {
		ToolBarManager toolBar = new ToolBarManager(style);
		
		toolBar.add(newFeedAction);
		toolBar.add(refreshFeedAction);
		toolBar.add(refreshAllFeedsAction);
		
		toolBar.add(moreLikeThisAction);
		toolBar.add(lessLikeThisAction);
		return toolBar;
	}
}