package com.oshineye.aggrevator.components;

/**
 * @author aoshineye
 *
 */
public interface StatusRecorder {
	public void setStatus(String message);
}
