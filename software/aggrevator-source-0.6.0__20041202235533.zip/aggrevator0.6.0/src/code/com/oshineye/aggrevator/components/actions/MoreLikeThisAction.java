package com.oshineye.aggrevator.components.actions;

import java.util.Iterator;
import java.util.List;

import org.eclipse.jface.resource.ImageDescriptor;

import com.oshineye.aggrevator.Entry;
import com.oshineye.aggrevator.Feed;
import com.oshineye.aggrevator.components.EntryModel;
import com.oshineye.aggrevator.components.FeedModel;
import com.oshineye.aggrevator.store.EntryStore;

/**
 * @author aoshineye
 */
public class MoreLikeThisAction extends AbstractEntrySelectedAction {
	private EntryStore entryStore;

	public MoreLikeThisAction(EntryStore entryStore, FeedModel feedModel, EntryModel entryModel) {
		super(feedModel, entryModel);
		this.entryStore = entryStore;
		this.setText("More Like This@Ctrl+M");
		this.setToolTipText("More like this");
		this.setImageDescriptor(ImageDescriptor.createFromFile(NewFeedAction.class, "/moreLikeThis.png"));
	}

	public void run() {
		EntryModel entryModel = getEntryModel();
		Entry entry = entryModel.getSelectedEntry();
		entryStore.incrementScore(entry);
		List relatedFeeds = entryStore.getRelatedFeeds(entry);
		for (Iterator iter = relatedFeeds.iterator(); iter.hasNext();) {
			Feed feed = (Feed) iter.next();
			feed.incrementScore();
		}
		
		refresh(relatedFeeds);
		entryModel.refreshEntry(entry);
	}
	

}
