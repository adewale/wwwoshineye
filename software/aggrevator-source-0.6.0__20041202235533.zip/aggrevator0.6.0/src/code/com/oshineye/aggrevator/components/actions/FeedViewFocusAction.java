package com.oshineye.aggrevator.components.actions;

import org.eclipse.jface.action.Action;

import com.oshineye.aggrevator.components.ComponentLocator;
import com.oshineye.aggrevator.components.FeedView;
import com.oshineye.aggrevator.components.View;

public class FeedViewFocusAction extends Action {
	private ComponentLocator componentLocator;

	public FeedViewFocusAction(ComponentLocator componentLocator) {
		this.componentLocator = componentLocator;
		this.setText("&Focus On Feeds@Shift+F");
	}
	
	public void run() {
		View view = componentLocator.getListView(FeedView.class);
		view.focus();
	}
}