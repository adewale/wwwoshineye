package com.oshineye.aggrevator.components.actions;

import org.eclipse.jface.action.Action;

import com.oshineye.aggrevator.components.ComponentLocator;
import com.oshineye.aggrevator.components.View;

public class BrowserViewFocusAction extends Action {
	private ComponentLocator componentLocator;

	public BrowserViewFocusAction(ComponentLocator componentLocator) {
		this.componentLocator = componentLocator;
		this.setText("&Focus On Browser@Shift+B");
	}

	public void run() {
		View view = componentLocator.getBrowserView();
		view.focus();
	}
}