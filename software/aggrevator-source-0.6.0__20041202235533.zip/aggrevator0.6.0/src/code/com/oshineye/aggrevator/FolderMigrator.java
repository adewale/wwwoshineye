package com.oshineye.aggrevator;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.Reader;
import java.io.Writer;
import java.lang.reflect.Field;
import java.util.Iterator;
import java.util.List;

import org.apache.log4j.Logger;

import com.oshineye.aggrevator.components.FeedModel;
import com.oshineye.aggrevator.store.EntryStore;
import com.oshineye.aggrevator.store.FeedStore;
import com.oshineye.aggrevator.util.IOUtils;
import com.oshineye.aggrevator.util.WriterFactory;
import com.thoughtworks.xstream.XStream;

/**
 * @author aoshineye
 */
public class FolderMigrator implements Migrator {
	private static final Logger LOG = Logger.getLogger(FolderMigrator.class);
	public static final String TEST_DATA_FOLDER = "testData";
	private FeedStore feedStore;
	private EntryStore entryStore;
	private WriterFactory factory;
	private FeedModel feedModel;

	public FolderMigrator(FeedStore feedStore, EntryStore entryStore, WriterFactory factory, FeedModel feedModel) {
		this.feedStore = feedStore;
		this.entryStore = entryStore;
		this.factory = factory;
		this.feedModel = feedModel;
	}

	public void load(String folderName) throws FileNotFoundException {
		File folder = new File(folderName);
		File[] files = folder.listFiles();
		for (int index = 0; index < files.length; index++) {
			File file = files[index];

			BufferedReader reader = null;
			try {
				reader = new BufferedReader(new FileReader(file));
				this.loadFeed(reader);
			} finally {
				IOUtils.close(reader);
			}
		}
	}

	public void dump(String folderName) {
		List allFeeds = feedStore.findAllFeeds();
		File folder = createFolder(folderName);
		for (Iterator iter = allFeeds.iterator(); iter.hasNext();) {
			Feed feed = (Feed) iter.next();

			Writer writer = null;
			try {
				List entries = entryStore.findEntriesInFeed(feed.getId());
				File file = new File(folder, feed.getId() + ".xml");
				writer = factory.getWriter(file);
				this.dumpFeed(writer, feed, entries);
			} catch (Exception e) {
				LOG.warn("Problem dumping: " + feed + ". Continuing\n" + e.getMessage(), e);
			} finally {
				IOUtils.close(writer);
			}
		}
	}

	private File createFolder(String folderName) {
		File folder = new File(folderName);
		if (!folder.exists()) {
			folder.mkdir();
		}
		return folder;
	}
	
	void dumpFeed(Writer writer, Feed feed, List entries) {
		XStream xstream = new XStream();
		XStreamFeed xsf = new XStreamFeed(feed, entries);
		xstream.toXML(xsf, writer);
	}

	public void loadFeed(Reader reader) {
		XStream xstream = new XStream();
		xstream.setMode(XStream.NO_REFERENCES);
		XStreamFeed xstreamFeed = (XStreamFeed) xstream.fromXML(reader);
		Feed feed = xstreamFeed.feed;
		List entries = xstreamFeed.entries;
		
		if (feedStore.urlExists(feed)) {
			Feed preExistingFeed = feedStore.findFeed(feed);
			
			LOG.debug("Skipping the loading of pre-existing feed: " + feed);
			LOG.debug("Pre-existing version has " + entryStore.findEntriesInFeed(preExistingFeed.getId()).size() + " entries");
			LOG.debug("Newly loaded version has " + entries.size() + " entries");
			return;
		}

		setPrivateField(FeedImpl.class, feed, Feed.PLACE_HOLDER_ID, "id");
		feedStore.add(feed);
		feedModel.addFeed(feed);
		
		for (Iterator iterator = entries.iterator(); iterator.hasNext();) {
			Entry entry = (Entry) iterator.next();
			setPrivateField(Entry.class, entry, feed.getId(), "feedId");
		}
		entryStore.addEntries(entries);
	}
	
	private void setPrivateField(Class clazz, Object instance, Object newValue, String fieldName) {
		try {
			Field field = clazz.getDeclaredField(fieldName);
			field.setAccessible(true);
			field.set(instance, newValue);
		} catch (SecurityException e) {
			handleReflectionProblem(e);
		} catch (IllegalArgumentException e) {
			handleReflectionProblem(e);
		} catch (NoSuchFieldException e) {
			handleReflectionProblem(e);
		} catch (IllegalAccessException e) {
			handleReflectionProblem(e);
		}
	}
	
	private void handleReflectionProblem(Exception e) {
		throw new TunnellingException(e);
	}
	
	private static class XStreamFeed {
		private Feed feed;
		private List entries;
		public XStreamFeed(Feed feed, List entries) {
			this.feed = feed;
			this.entries = entries;
		}
	}
}
