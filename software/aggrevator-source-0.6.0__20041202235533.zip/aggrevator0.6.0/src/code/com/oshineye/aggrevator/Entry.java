package com.oshineye.aggrevator;

import java.net.URL;
import java.util.Date;

import org.apache.commons.lang.time.DateFormatUtils;

import com.oshineye.aggrevator.util.StringUtils;

/**
 * @author aoshineye
 *
 */
public class Entry implements Filterable {
	//we need this because IE tries to save empty content
	public static final String MINIMAL_CONTENT = "...";
	private String title;
	private String content;
	private String feedTitle;
	private Date date;
	private boolean read;
	private Long feedId;
	private String url;
	private int score;
	public static final String NO_LINK = "http://www.example.com/NO_LINK";
	private String formattedDate;

	private Entry(String title, String description, Date date, String url, String feedTitle, Long feedId) {
		this.title = StringUtils.unescapeHtml(title);
		this.content = description;
		this.feedTitle = StringUtils.unescapeHtml(feedTitle);
		this.feedId = feedId;
		
		if (date == null) {
			this.date = new Date();
		} else {
			this.date = date;
		}
		this.formattedDate = format(this.date);
		if (url == null) {
			this.url = Entry.NO_LINK;
		} else {
			this.url = url;
		}
	}
	
	public Entry(String title, String description, Date date, URL url, String feedTitle, Long feedId) {
		this(title, description, date, String.valueOf(url), feedTitle, feedId);
	}
	
	public Entry(String title, String content, Date date, String url, String feedTitle, Long feedId, boolean read, int score) {
		//construct an Entry using data from the EntryStore
		this(title, content, date, url, feedTitle, feedId);
		this.read = read;
		this.score = score;
	}

	public String getContent() {
		return content;
	}

	public String getTitle() {
		return title;
	}

	public String getFormattedDate() {
		return formattedDate;
	}

	private String format(Date dateArg) {
		return DateFormatUtils.format(dateArg, Configuration.DATE_FORMAT);
	}

	public String getFeedTitle() {
		return feedTitle;
	}

	public Date getDate() {
		return date;
	}

	public boolean isRead() {
		return read;
	}

	public void markRead() {
		if (read) {
			return;
		}
		
		read = true;
		setScore(Feed.ENTRY_READ_SCORE);
	}

	public Long getFeedId() {
		return feedId;
	}

	public String getUrl() {
		return url;
	}
	
	public boolean equals(Object other) {
		Entry otherEntry = (Entry) other;
		if (this.url.equals(otherEntry.url)) {
			return true;
		}
		return this.content.equals(otherEntry.content);
	}

	public int getScore() {
		return score;
	}

	private void setScore(int newScore) {
		this.score = newScore;
	}

	public String toString() {
		return "Entry::" + getTitle() + "::" + url;
	}

	public void incrementScore() {
		setScore(getScore() + Feed.SCORE_UNITS);
	}

	public void decrementScore() {
		setScore(getScore() - Feed.SCORE_UNITS);
	}
}
