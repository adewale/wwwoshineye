package com.oshineye.aggrevator.components;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

import com.oshineye.aggrevator.Feed;


public class FeedModelImpl extends AbstractModel implements FeedModel {
	private Feed selectedFeed;
	private List observers;
	private List currentFeeds;
	private List allFeeds;

	public FeedModelImpl(List allFeeds) {
		currentFeeds = new ArrayList(allFeeds);
		this.allFeeds = allFeeds;
		observers = new ArrayList();
	}

	public void addFeed(Feed feed) {
		currentFeeds.add(feed);
		allFeeds.add(feed);
		notifyObserversFeedAdded(feed);
	}

	public void appendFeeds(List newFeeds) {
		currentFeeds.addAll(newFeeds);
		allFeeds.addAll(newFeeds);
		notifyObserversFeedAppended(newFeeds);
	}

	private void notifyObserversFeedAppended(List newFeeds) {
		for (Iterator iter = newFeeds.iterator(); iter.hasNext();) {
			Feed feed = (Feed) iter.next();
			notifyObserversFeedAdded(feed);
		}
	}

	public void addObserver(FeedModelObserver observer) {
		observers.add(observer);
	}

	public void loadFeeds() {
		notifyObserversFeedsLoaded(currentFeeds);
	}
	
	private void notifyObserversFeedsLoaded(List feedsLoaded) {
		for (Iterator iter = observers.iterator(); iter.hasNext();) {
			FeedModelObserver observer = (FeedModelObserver) iter.next();
			observer.notifyFeedsLoaded(feedsLoaded);
		}
	}

	public void deleteFeed(Feed feed) {
		if (!currentFeeds.contains(feed)) {
			return;
		}
		
		int feedIndex = currentFeeds.indexOf(feed);
		
		if (isFirst(feedIndex) && !feedsLeft()) {//only one item left
			//do nothing
		} else if (isFirst(feedIndex) || isMiddle(feedIndex)) {
			select((Feed) currentFeeds.get(feedIndex + 1));//move the selection down
		} else if (isLast(feedIndex) && feedsLeft()) {
			select((Feed) currentFeeds.get(feedIndex - 1));//move the selection up
		}
			
		currentFeeds.remove(feed);
		allFeeds.remove(feed);
		for (Iterator iter = observers.iterator(); iter.hasNext();) {
			FeedModelObserver observer = (FeedModelObserver) iter.next();
			observer.notifyFeedDeleted(feed, feedIndex);
		}
	}

	public void entryRead(List relatedFeeds) {
		for (Iterator iter = relatedFeeds.iterator(); iter.hasNext();) {
			Feed feed = (Feed) iter.next();
			feed.entryRead();
		}
		refreshFeeds(relatedFeeds);
	}

	public void refreshFeeds(List feedsToRefresh) {
		for (Iterator iter = feedsToRefresh.iterator(); iter.hasNext();) {
			Feed feed = (Feed) iter.next();
			refreshFeed(feed);
		}
	}
	
	public void refreshFeed(Feed feed) {
		if (!currentFeeds.contains(feed)) {
			return;
		}
		
		//the feed object we're given and the feed object the view will use are the same object
		//so there's no need to update the list of feeds in the model
		for (Iterator iter = observers.iterator(); iter.hasNext();) {
			FeedModelObserver observer = (FeedModelObserver) iter.next();
			observer.notifyFeedRefreshed(feed);
		}
	}
	
	public void select(Feed feed) {
		this.selectedFeed = feed;
	}

	public int getSelectedFeedIndex() {
		return currentFeeds.indexOf(selectedFeed);
	}
	
	public Feed getSelectedFeed() {
		return selectedFeed;
	}

	public boolean isSelected(Feed feed) {
		return selectedFeed == feed;
	}
	
	private void notifyObserversFeedAdded(Feed feed) {
		for (Iterator iter = observers.iterator(); iter.hasNext();) {
			FeedModelObserver observer = (FeedModelObserver) iter.next();
			observer.notifyFeedAdded(feed);
		}
	}
	
	private boolean isLast(int feedIndex) {
		return (feedIndex == (currentFeeds.size() - 1));
	}
	
	private boolean isFirst(int feedIndex) {
		return feedIndex == 0;
	}
	
	private boolean isMiddle(int feedIndex) {
		return feedIndex > 0 && feedIndex < (currentFeeds.size() - 1);
	}
	
	private boolean feedsLeft() {
		return (currentFeeds.size() - 1) != 0;
	}

	public void loadMatchingItems(String searchText) {
		List matchingItems = findMatchingItems(searchText, allFeeds);

		if (isAlreadyShowing(matchingItems)) {
			return;
		}
		sortWithPreviousComparator(matchingItems);
		
		currentFeeds = matchingItems;
		notifyObserversFeedsLoaded(matchingItems);
		
	}
	
	public List getCurrentFeeds() {
		return Collections.unmodifiableList(currentFeeds);
	}

	public List getItems() {
		return currentFeeds;
	}
}
