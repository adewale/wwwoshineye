package com.oshineye.aggrevator.components;

import com.oshineye.aggrevator.components.commands.Command;
import com.oshineye.aggrevator.components.commands.VisitLocationCommand;
import com.oshineye.aggrevator.store.EntryStore;
import com.oshineye.aggrevator.store.FeedStore;

/**
 * @author aoshineye
 */
public class BrowserControllerImpl implements BrowserController {

	private FeedModel feedModel;
	private EntryModel entryModel;
	private FeedStore feedStore;
	private EntryStore entryStore;

	public BrowserControllerImpl(FeedModel feedModel, EntryModel entryModel, FeedStore feedStore, EntryStore entryStore) {
		this.feedModel = feedModel;
		this.entryModel = entryModel;
		this.feedStore = feedStore;
		this.entryStore = entryStore;
	}

	public void handleLocationVisited(String location) {
		Command cmd = new VisitLocationCommand(feedModel, entryModel, location);
		cmd.execute(feedStore, entryStore);
	}

}
