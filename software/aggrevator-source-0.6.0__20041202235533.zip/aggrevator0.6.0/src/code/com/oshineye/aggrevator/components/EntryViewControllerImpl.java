package com.oshineye.aggrevator.components;

import com.oshineye.aggrevator.Entry;
import com.oshineye.aggrevator.components.commands.Command;
import com.oshineye.aggrevator.components.commands.SelectEntryCommand;
import com.oshineye.aggrevator.store.EntryStore;
import com.oshineye.aggrevator.store.FeedStore;

/**
 * @author aoshineye
 *
 */
public class EntryViewControllerImpl implements EntryViewController {
	private BrowserModel browserModel;
	private FeedStore feedStore;
	private EntryStore entryStore;
	private FeedModel feedModel;
	private EntryModel entryModel;

	public EntryViewControllerImpl(FeedModel feedModel, EntryModel entryModel, BrowserModel browserModel, FeedStore feedStore, EntryStore entryStore) {
		this.feedModel = feedModel;
		this.entryModel = entryModel;
		this.browserModel = browserModel;
		this.feedStore = feedStore;
		this.entryStore = entryStore;
	}

	public void handleEntrySelected(Entry entry) {
		Command cmd = new SelectEntryCommand(entry, feedModel, entryModel, browserModel);
		cmd.execute(feedStore, entryStore);
	}
}
