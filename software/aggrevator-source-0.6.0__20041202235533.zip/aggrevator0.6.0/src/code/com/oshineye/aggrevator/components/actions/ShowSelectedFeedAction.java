package com.oshineye.aggrevator.components.actions;

import com.oshineye.aggrevator.components.ComponentLocator;
import com.oshineye.aggrevator.components.FeedView;
import com.oshineye.aggrevator.components.ListView;

/**
 * @author aoshineye
 *
 */
public class ShowSelectedFeedAction extends AbstractWidgetSelectedAction {
	private ComponentLocator componentLocator;

	public ShowSelectedFeedAction(ComponentLocator componentLocator) {
		this.componentLocator = componentLocator;
		this.setText("Show Selected &Feed");
	}
	
	public void run() {
		ListView listView = componentLocator.getListView(FeedView.class);
		listView.showSelectedItem();
	}
}
