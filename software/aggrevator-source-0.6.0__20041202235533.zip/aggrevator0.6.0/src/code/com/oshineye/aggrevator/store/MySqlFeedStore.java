package com.oshineye.aggrevator.store;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.oshineye.aggrevator.Feed;
import com.oshineye.aggrevator.FeedFactory;
import com.oshineye.aggrevator.TunnellingException;
import com.oshineye.aggrevator.db.AbstractQueryBlock;
import com.oshineye.aggrevator.db.JdbcBlock;
import com.oshineye.aggrevator.db.JdbcProcess;
import com.oshineye.aggrevator.db.JdbcProcessFactory;
import com.oshineye.aggrevator.util.QueryLoader;

/**
 * @author aoshineye
 *
 */
public class MySqlFeedStore extends MySqlStore implements FeedStore {
	private static final String SCORE = "score";
	private static final String UNREAD = "unread";
	private static final String LAST_MODIFIED = "last_modified";
	private static final String ETAG = "etag";
	private static final String FEED_TITLE = "title";
	private static final String URL = "url";
	private static final String ID = "feed_id";
	private JdbcProcessFactory factory;
	protected FeedIdentityMap feedIdentityMap;
	private QueryLoader queryLoader;

	public MySqlFeedStore(String databaseName, FeedIdentityMap feedIdentityMap, QueryLoader queryLoader) {
		super(databaseName);
		this.queryLoader = queryLoader;
		factory = getJdbcProcessFactory();
		this.feedIdentityMap = feedIdentityMap;
		loadAllFeeds();
	}

	public void add(final Feed feed) {
	    if (feed.isStored() || (urlExists(feed))) {
			throw new DuplicateFeedException(feed);
		}

		JdbcProcess process = factory.createProcess();
		Long id = (Long) process.executeInsert(queryLoader.getQuery("ADD_FEED"), new JdbcBlock() {
			public void configure(PreparedStatement stmt) throws SQLException {
				stmt.setString(1, feed.getUrl());
				stmt.setString(2, feed.getTitle());
			}
		});
		
		feed.setId(id);
		
		feedIdentityMap.add(feed);
	}

	private List loadAllFeeds() {
		JdbcProcess process = factory.createProcess();
		List allFeeds = (List) process.executeQuery(queryLoader.getQuery("GET_ALL_FEEDS"), new AbstractQueryBlock(){
			public Object process(ResultSet rset) throws SQLException {
				List feeds = new ArrayList();
				while (rset.next()) {
					Feed feed = makeFeed(rset);
					feeds.add(feed);
				}
				return feeds;
			}
		});
		
		feedIdentityMap.addAll(allFeeds);
		return allFeeds;
	}

	private Feed makeFeed(ResultSet rset) throws SQLException {
		int id = rset.getInt(ID);
		String url = rset.getString(URL);
		String title = rset.getString(FEED_TITLE);
		String etag = rset.getString(ETAG);
		String lastModified = rset.getString(LAST_MODIFIED);
		int unreadEntryCount = rset.getInt(UNREAD);
		int score = rset.getInt(SCORE);
		
		return FeedFactory.createFeedFromStore(id, url, title, unreadEntryCount, score, etag, lastModified);
	}

	public Feed findFeed(Feed feed) {
		return feedIdentityMap.findByUrl(feed);
	}

	public List findAllFeeds() {
		return feedIdentityMap.findAllFeeds();
	}

	public void delete(final Feed feed) {
		JdbcProcess process = factory.createProcess();
		process.executeUpdate(queryLoader.getQuery("DELETE_FEED"), new JdbcBlock() {
			public void configure(PreparedStatement stmt) throws SQLException {
				stmt.setLong(1, feed.getId().longValue());
			}
		});
		feedIdentityMap.remove(feed);
	}

	public void deleteAll() {
		JdbcProcess process = factory.createProcess();
		process.executeUpdate(queryLoader.getQuery("DELETE_ALL_FEEDS"), new JdbcBlock() {
			public void configure(PreparedStatement stmt) {
				//do nothing
			}
		});
		feedIdentityMap.removeAll();
	}

	public void synchronise(final Feed feed) {
		update(feed);
		
		JdbcProcess process = factory.createProcess();
		int[] feedState = (int[]) process.executeQuery(queryLoader.getQuery("GET_FEED_STATE"), new AbstractQueryBlock() {
			public void configure(PreparedStatement stmt) throws SQLException {
				stmt.setLong(1, feed.getId().longValue());
			}
			
			public Object process(ResultSet rset) throws SQLException {
				int[] feedState = new int[2];
				if (rset.next()) {
					feedState[0] = rset.getInt(1);
					feedState[1] = rset.getInt(2);
					return feedState;
				}
				throw new TunnellingException(feed + " not found");
			}
		});
		int unreadEntriesCount = feedState[0];
		int score = feedState[1]; 
		feed.update(unreadEntriesCount, score);
	}

	public void update(final Feed feed) {
		JdbcProcess process = factory.createProcess();
		process.executeUpdate(queryLoader.getQuery("UPDATE_FEED"), new JdbcBlock() {
			public void configure(PreparedStatement stmt) throws SQLException {
				stmt.setString(1, feed.getUrl());
				stmt.setString(2, feed.getTitle());
				stmt.setString(3, feed.getEtag());
				stmt.setString(4, feed.getLastModified());
				stmt.setLong(5, feed.getId().longValue());
			}
		});
	}

	public void markRead(final Feed feed) {
		JdbcProcess process = factory.createProcess();
		process.executeUpdate(queryLoader.getQuery("UPDATE_FEED_MARKING_ALL_ENTRES_AS_READ"), new JdbcBlock() {
			public void configure(PreparedStatement stmt) throws SQLException {
				stmt.setLong(1, feed.getId().longValue());
			}
		});
		feed.markRead();
	}

	public boolean urlExists(Feed feed) {
		return feedIdentityMap.urlExists(feed.getUrl());
	}

	public Feed findFeed(final Long id) {
		JdbcProcess process = factory.createProcess();
		Feed storedFeed = (Feed) process.executeQuery(queryLoader.getQuery("GET_FEED"), new AbstractQueryBlock(){
			public void configure(PreparedStatement stmt) throws SQLException {
				stmt.setLong(1, id.longValue());
				stmt.setLong(2, id.longValue());
			}
			
			public Object process(ResultSet rset) throws SQLException {
				if (rset.next()) {
					return makeFeed(rset);
				}
				throw new TunnellingException("Feed with id: " + id + " not found");
			}
		});
		return storedFeed;
	}

}