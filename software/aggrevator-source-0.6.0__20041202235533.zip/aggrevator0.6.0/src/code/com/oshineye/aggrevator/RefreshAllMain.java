package com.oshineye.aggrevator;

import java.util.List;

import org.logicalcobwebs.proxool.ProxoolFacade;

import com.oshineye.aggrevator.components.FeedModel;
import com.oshineye.aggrevator.components.FeedModelImpl;
import com.oshineye.aggrevator.components.ThreadPool;
import com.oshineye.aggrevator.components.ThreadPoolImpl;
import com.oshineye.aggrevator.store.EntryStore;
import com.oshineye.aggrevator.store.FeedIdentityMap;
import com.oshineye.aggrevator.store.FeedStore;
import com.oshineye.aggrevator.store.MySqlEntryStore;
import com.oshineye.aggrevator.store.MySqlFeedStore;
import com.oshineye.aggrevator.util.QueryLoader;

/**
 * @author aoshineye
 */
public class RefreshAllMain {
	public static void main(String[] args) throws Exception {
		String startMessage = "Refreshing all feeds using: " + Constants.APPLICATION_NAME_AND_VERSION_NUMBER;
		System.out.println(startMessage);

		Configuration.load();
		FeedIdentityMap feedIdentityMap = new FeedIdentityMap();
		QueryLoader queryLoader = new QueryLoader();
		FeedStore feedStore = new MySqlFeedStore(Configuration.getDatabaseName(), feedIdentityMap, queryLoader);
		EntryStore entryStore = new MySqlEntryStore(Configuration.getDatabaseName(), feedIdentityMap, queryLoader);
		
		List allFeeds = feedStore.findAllFeeds();
		FeedModel feedModel = new FeedModelImpl(allFeeds);
		ThreadPool threadPool = new ThreadPoolImpl(feedStore, entryStore, feedModel);
		threadPool.enqueue(allFeeds);
		threadPool.shutDownAfterProcessingCurrentlyQueuedTasks();
		ProxoolFacade.shutdown(0);
		
		System.out.println("Finished refreshing " + allFeeds.size() + " feeds");
	}
}
