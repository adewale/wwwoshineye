package com.oshineye.aggrevator.components;

import com.oshineye.aggrevator.Feed;
import com.oshineye.aggrevator.components.commands.Command;
import com.oshineye.aggrevator.components.commands.DeleteFeedCommand;
import com.oshineye.aggrevator.components.commands.SelectFeedCommand;
import com.oshineye.aggrevator.components.commands.UpdateFeedCommand;
import com.oshineye.aggrevator.store.EntryStore;
import com.oshineye.aggrevator.store.FeedStore;

public class FeedViewControllerImpl implements FeedViewController {
	private EntryModel entryModel;
	private FeedModel feedModel;
	private FeedStore feedStore;
	private EntryStore entryStore;

	public FeedViewControllerImpl(FeedModel feedModel, EntryModel entryModel) {
		this.feedModel = feedModel;
		this.entryModel = entryModel;
	}

	public FeedViewControllerImpl(FeedModel feedModel, EntryModel entryModel, 
			FeedStore feedStore, EntryStore entryStore) {
		this(feedModel, entryModel);
		
		this.feedStore = feedStore;
		this.entryStore = entryStore;
	}

	public void handleFeedSelected(Feed feed) {
		Command cmd = new SelectFeedCommand(feed, feedModel, entryModel);
		cmd.execute(feedStore, entryStore);
	}

	public void handleFeedDeleted(Feed feed) {
		Command deleteFeed = new DeleteFeedCommand(feed, feedModel, entryModel);
		deleteFeed.execute(feedStore, entryStore);
		Command selectNextFeed = new SelectFeedCommand(feedModel.getSelectedFeed(), feedModel, entryModel);
		selectNextFeed.execute(feedStore, entryStore);
	}

	public void handleFeedUpdated(Feed selectedFeed, String newFeedTitle, String newFeedUrl) {
		Command cmd = new UpdateFeedCommand(feedModel, selectedFeed, newFeedTitle, newFeedUrl);
		cmd.execute(feedStore, entryStore);
	}

}
