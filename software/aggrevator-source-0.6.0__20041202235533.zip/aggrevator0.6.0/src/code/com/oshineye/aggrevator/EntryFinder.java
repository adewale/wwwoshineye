package com.oshineye.aggrevator;

import java.util.List;

/**
 * @author aoshineye
 *
 */
public interface EntryFinder {
    public List findMatchingEntriesInFeed(Long feedId, List entries);
}
