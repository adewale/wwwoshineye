package com.oshineye.aggrevator.store;


/**
 * @author aoshineye
 */
public class ContentContainsPredicate implements Predicate {

	private String text;

	public ContentContainsPredicate(String text) {
		this.text = text;
	}

	public String getArgument() {
		return text;
	}

}
