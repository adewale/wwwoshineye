package com.oshineye.aggrevator.components.actions;

import org.apache.log4j.Logger;
import org.eclipse.jface.action.Action;
import org.eclipse.jface.dialogs.IInputValidator;
import org.eclipse.jface.dialogs.InputDialog;
import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.jface.window.ApplicationWindow;
import org.eclipse.swt.dnd.Clipboard;
import org.eclipse.swt.dnd.TextTransfer;
import org.eclipse.swt.widgets.Shell;

import com.oshineye.aggrevator.components.FeedModel;
import com.oshineye.aggrevator.components.StatusRecorder;
import com.oshineye.aggrevator.components.commands.Command;
import com.oshineye.aggrevator.components.commands.SubscribeToFeedCommand;
import com.oshineye.aggrevator.store.DuplicateFeedException;
import com.oshineye.aggrevator.store.EntryStore;
import com.oshineye.aggrevator.store.FeedStore;
import com.oshineye.aggrevator.util.StringInputValidator;

/**
 * @author aoshineye
 */
public class NewFeedAction extends Action {
	private static final Logger LOG = Logger.getLogger(NewFeedAction.class);
	private ApplicationWindow window;
	private FeedModel feedModel;
	private FeedStore feedStore;
	private EntryStore entryStore;
	private StatusRecorder recorder;

	public NewFeedAction(ApplicationWindow window, FeedModel feedModel, FeedStore feedStore, EntryStore entryStore, StatusRecorder recorder) {
		this.window = window;
		this.feedModel = feedModel;
		this.feedStore = feedStore;
		this.entryStore = entryStore;
		this.recorder = recorder;
		
		this.setText("&New Feed@Ctrl+N");
		this.setToolTipText("Add a new feed");
		this.setImageDescriptor(ImageDescriptor.createFromFile(NewFeedAction.class, "/newFeed.png"));
	}
	
	public void run() {
		Shell shell = window.getShell();
		String initialValue = getClipboardTextIfSuitable(shell);
		IInputValidator inputValidator = new StringInputValidator("You need to enter a valid url for the feed");
		InputDialog input = new InputDialog(shell, "Add New Feed", "Please enter the url of the new feed", initialValue, inputValidator);
		int result = input.open();
		if (result == InputDialog.CANCEL) {
			return;
		}
		
		try {
			String feedUrl = input.getValue();
			Command cmd = new SubscribeToFeedCommand(feedUrl, feedModel);
			cmd.execute(feedStore, entryStore);
			recorder.setStatus("Added " + feedUrl);
		} catch (DuplicateFeedException e) {
			LOG.warn(e.toString());
			recorder.setStatus(e.getMessage());
		}
		
	}
	
	private String getClipboardTextIfSuitable(Shell shell) {
		String text = "";
		Clipboard clipBoard  = new Clipboard(shell.getDisplay());
		TextTransfer textTransfer = TextTransfer.getInstance();
	    String textData = (String)clipBoard.getContents(textTransfer);
	    if (textData != null) {
	    	text = textData;
	    }
	    clipBoard.dispose();
	    return text;
	}
}
