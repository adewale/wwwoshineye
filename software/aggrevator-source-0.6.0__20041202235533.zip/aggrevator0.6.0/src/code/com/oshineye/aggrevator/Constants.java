package com.oshineye.aggrevator;

/**
 * @author aoshineye
 *
 */
public interface Constants {
	public static final String APPLICATION_NAME = "Aggrevator";
	public static final String VERSION_NUMBER = "0.6.0";
	public static final String APPLICATION_NAME_AND_VERSION_NUMBER = APPLICATION_NAME + " " + VERSION_NUMBER;
}
