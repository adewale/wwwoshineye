package com.oshineye.aggrevator.components.commands;

import java.util.List;

import com.oshineye.aggrevator.Feed;
import com.oshineye.aggrevator.components.EntryModel;
import com.oshineye.aggrevator.components.FeedModel;
import com.oshineye.aggrevator.store.EntryStore;
import com.oshineye.aggrevator.store.FeedStore;


public class SelectFeedCommand implements Command {

	private EntryModel entryModel;
	private Feed selectedFeed;
	private FeedModel feedModel;

	public SelectFeedCommand(Feed selectedFeed, FeedModel feedModel, EntryModel entryModel) {
		this.entryModel = entryModel;
		this.selectedFeed = selectedFeed;
		this.feedModel = feedModel;
	}

	public void execute(FeedStore feedStore, EntryStore entryStore) {
		List entriesInFeed = entryStore.findEntriesInFeed(selectedFeed.getId());
		entryModel.loadEntries(entriesInFeed);
		feedModel.select(selectedFeed);
		entryModel.selectNone();
	}

}
