package com.oshineye.aggrevator.components.actions;

import org.eclipse.jface.action.Action;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;

/**
 * @author aoshineye
 * 
 * An Action that is enabled if anything is selected.
 */
public abstract class AbstractWidgetSelectedAction extends Action implements SelectionListener {
	public AbstractWidgetSelectedAction() {
		this.setEnabled(false);
	}
	
	public void widgetDefaultSelected(SelectionEvent e) {
		this.widgetSelected(e);
	}
	
	public void widgetSelected(SelectionEvent e) {
		this.setEnabled(true);
	}
}
