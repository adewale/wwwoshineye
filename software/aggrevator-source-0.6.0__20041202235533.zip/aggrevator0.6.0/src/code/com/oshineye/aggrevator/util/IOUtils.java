package com.oshineye.aggrevator.util;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.Writer;

import org.apache.log4j.Logger;

/**
 * @author aoshineye
 *
 */
public class IOUtils {
	private static final Logger LOG = Logger.getLogger(IOUtils.class);
	public static void close(BufferedReader br) {
		try {
			br.close();
		} catch (IOException e) {
			LOG.warn(e.getMessage(), e);
		}
	}
	public static void close(Writer writer) {
		try {
			writer.close();
		} catch (IOException e) {
			LOG.warn(e.getMessage(), e);
		}
	}

}
