package com.oshineye.aggrevator.components.actions;

import com.oshineye.aggrevator.components.ComponentLocator;
import com.oshineye.aggrevator.components.EntryModel;
import com.oshineye.aggrevator.components.EntryView;
import com.oshineye.aggrevator.components.FeedModel;
import com.oshineye.aggrevator.components.ListView;

/**
 * @author aoshineye
 *
 */
public class ShowSelectedEntryAction extends AbstractEntrySelectedAction {
	private ComponentLocator componentLocator;

	public ShowSelectedEntryAction(FeedModel feedModel, EntryModel entryModel, ComponentLocator componentLocator) {
		super(feedModel, entryModel);
		this.componentLocator = componentLocator;
		this.setText("Show Selected &Entry");
	}
	
	public void run() {
		ListView listView = componentLocator.getListView(EntryView.class);
		listView.showSelectedItem();
	}
}
