package com.oshineye.aggrevator;

import java.util.Comparator;


/**
 * @author aoshineye
 */
public class ComparatorFactory {
	private static final Comparator FEED__TITLE_COMPARATOR = new FeedTitleComparator();
	private static final Comparator FEED__UNREAD_ENTRIES_COUNT_COMPARATOR = new FeedUnreadEntriesCountComparator();
	private static final Comparator FEED__URL_COMPARATOR = new FeedUrlComparator();
	private static final Comparator FEED__SCORE_COMPARATOR = new FeedScoreComparator();
	private static final Comparator FEED_DATE_COMPARATOR = new FeedDateComparator();
	private static final Comparator ENTRY_TITLE_COMPARATOR = new EntryTitleComparator();
	private static final Comparator ENTRY_DATE_COMPARATOR = new EntryDateComparator();
	private static final Comparator ENTRY_SCORE_COMPARATOR = new EntryScoreComparator();
	private static final Comparator ENTRY_FEED_TITLE_COMPARATOR = new EntryFeedTitleComparator();
	
	public static Comparator getFeedTitleComparator() {
		return FEED__TITLE_COMPARATOR;
	}

	public static Comparator createReverseComparator(Comparator comparator) {
		return new ReverseComparator(comparator);
	}

	public static Comparator getFeedUnreadEntriesCountComparator() {
		return FEED__UNREAD_ENTRIES_COUNT_COMPARATOR;
	}
	
	public static Comparator getFeedUrlComparator() {
		return FEED__URL_COMPARATOR;
	}

	public static Comparator getFeedScoreComparator() {
		return FEED__SCORE_COMPARATOR;
	}

	public static Comparator getFeedDateComparator() {
		return FEED_DATE_COMPARATOR;
	}
	
	public static Comparator getEntryTitleComparator() {
		return ENTRY_TITLE_COMPARATOR;
	}

	public static Comparator getEntryDateComparator() {
		return ENTRY_DATE_COMPARATOR;
	}
	
	public static Comparator getEntryScoreComparator() {
		return ENTRY_SCORE_COMPARATOR;
	}
	
	public static Comparator getEntryFeedTitleComparator() {
		return ENTRY_FEED_TITLE_COMPARATOR;
	}
	
	private static final class FeedUnreadEntriesCountComparator implements Comparator {
		public int compare(Object o1, Object o2) {
			Feed f1 = (Feed)o1;
			Feed f2 = (Feed)o2;
			return f1.getUnreadEntriesCount() - f2.getUnreadEntriesCount();
		}
	}

	private static final class FeedTitleComparator implements Comparator {
		public int compare(Object o1, Object o2) {
			Feed f1 = (Feed)o1;
			Feed f2 = (Feed)o2;
			return ComparatorFactory.caseSensitiveCompare(f1.getTitle(), f2.getTitle());
		}
	}
	
	private static final class FeedUrlComparator implements Comparator {
		public int compare(Object o1, Object o2) {
			Feed f1 = (Feed)o1;
			Feed f2 = (Feed)o2;
			return f1.getUrl().compareToIgnoreCase(f2.getUrl());
		}
	}
	
	private static final class FeedScoreComparator implements Comparator {
		public int compare(Object o1, Object o2) {
			Feed f1 = (Feed)o1;
			Feed f2 = (Feed)o2;
			return f2.getScore() - f1.getScore();
		}
	}
	
	private static final class FeedDateComparator implements Comparator {
		public int compare(Object o1, Object o2) {
			Feed f1 = (Feed)o1;
			Feed f2 = (Feed)o2;
			return ComparatorFactory.compare(f1.getLastModifiedDate(),f2.getLastModifiedDate());
		}
	}
	
	private static final class EntryTitleComparator implements Comparator {
		public int compare(Object o1, Object o2) {
			Entry e1 = (Entry)o1;
			Entry e2 = (Entry)o2;
			return ComparatorFactory.caseSensitiveCompare(e1.getTitle(), e2.getTitle());
		}
	}

	private static final class EntryDateComparator implements Comparator {
		public int compare(Object o1, Object o2) {
			Entry e1 = (Entry)o1;
			Entry e2 = (Entry)o2;
			return ComparatorFactory.compare(e1.getDate(), e2.getDate());
		}
	}

	private static final class EntryScoreComparator implements Comparator {
		public int compare(Object o1, Object o2) {
			Entry e1 = (Entry)o1;
			Entry e2 = (Entry)o2;
			return e2.getScore() - e1.getScore();
		}
	}
	
	private static final class EntryFeedTitleComparator implements Comparator {
		public int compare(Object o1, Object o2) {
			Entry e1 = (Entry)o1;
			Entry e2 = (Entry)o2;
			return ComparatorFactory.caseSensitiveCompare(e1.getFeedTitle(), e2.getFeedTitle());
		}
	}
	
	private static class ReverseComparator implements Comparator {
		private Comparator originalComparator;

		public ReverseComparator(Comparator originalComparator) {
			this.originalComparator = originalComparator;
		}

		public int compare(Object o1, Object o2) {
			int result = originalComparator.compare(o1, o2);
			if (result < 0) {
				return Math.abs(result);
			} else if (result > 0) {
				return -result;
			}
			return result;
		}	
	}
	
	private static int caseSensitiveCompare(String s1, String s2) {
		if (s1 == null) {
			return -1;
		}
		
		if (s2 == null) {
			return 1;
		}
		return s1.compareToIgnoreCase(s2);
	}
	
	private static int compare(Comparable c1, Comparable c2) {
		if (c1 == null) {
			return -1;
		}
		
		if (c2 == null) {
			return 1;
		}
		return c1.compareTo(c2);
	}
}
