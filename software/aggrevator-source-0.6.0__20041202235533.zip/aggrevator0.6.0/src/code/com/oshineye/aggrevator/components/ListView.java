package com.oshineye.aggrevator.components;

import org.eclipse.swt.events.SelectionListener;

/**
 * @author aoshineye
 *
 */
public interface ListView extends View, SelectionListener{
	public void addSelectionListener(SelectionListener listener);

	public void showSelectedItem();
}
