package com.oshineye.aggrevator.util;

import java.util.Properties;

import com.oshineye.aggrevator.Configuration;

/**
 * @author aoshineye
 *
 */
public class QueryLoader {
	private Properties properties;

	public QueryLoader() {
		this.properties = Configuration.load("query.properties");
	}

	public String getQuery(String key) {
		return properties.getProperty(key);
	}
}
