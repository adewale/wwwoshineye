package com.oshineye.aggrevator.components.commands;

import com.oshineye.aggrevator.Feed;
import com.oshineye.aggrevator.components.EntryModel;
import com.oshineye.aggrevator.components.FeedModel;
import com.oshineye.aggrevator.store.EntryStore;
import com.oshineye.aggrevator.store.FeedStore;

/**
 * @author aoshineye
 *
 */
public class DeleteFeedCommand implements Command {
	private Feed feed;
	private FeedModel feedModel;
	private EntryModel entryModel;

	public DeleteFeedCommand(Feed feed, FeedModel feedModel, EntryModel entryModel) {
		this.feed = feed;
		this.feedModel = feedModel;
		this.entryModel = entryModel;
	}

	public void execute(FeedStore feedStore, EntryStore entryStore) {
		feedStore.delete(feed);
		entryStore.delete(feed);
		feedModel.deleteFeed(feed);
		entryModel.deleteEntriesFromFeed(feed);
	}
}
