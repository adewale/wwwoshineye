package com.oshineye.aggrevator.components.actions;

import org.eclipse.jface.action.Action;

import com.oshineye.aggrevator.components.ComponentLocator;
import com.oshineye.aggrevator.components.EntryView;
import com.oshineye.aggrevator.components.View;

public class EntryViewFocusAction extends Action {
	private ComponentLocator componentLocator;

	public EntryViewFocusAction(ComponentLocator componentLocator) {
		this.componentLocator = componentLocator;
		this.setText("&Focus On Entries@Shift+E");
	}
	
	public void run() {
		View view = componentLocator.getListView(EntryView.class);
		view.focus();
	}
}