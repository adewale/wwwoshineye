package com.oshineye.aggrevator.components.tasks;

import java.io.IOException;
import java.util.List;
import org.apache.log4j.Logger;

import com.oshineye.aggrevator.Feed;
import com.oshineye.aggrevator.RefreshInProgressException;
import com.oshineye.aggrevator.components.EntryModel;
import com.oshineye.aggrevator.components.FeedModel;
import com.oshineye.aggrevator.store.EntryStore;
import com.oshineye.aggrevator.store.FeedStore;

public class RefreshFeedTask extends Task {
	private static final Logger LOG = Logger.getLogger(RefreshFeedTask.class);
	private Feed feed;
	private FeedStore feedStore;
	private EntryStore entryStore;
	private FeedModel feedModel;
	private EntryModel entryModel;
	
	public RefreshFeedTask(Feed feed, FeedStore feedStore, EntryStore entryStore, FeedModel feedModel, EntryModel entryModel) {
		this.feed = feed;
		this.feedStore = feedStore;
		this.entryStore = entryStore;
		this.feedModel = feedModel;
		this.entryModel = entryModel;
	}

	public void doWork() {
		try {
			//try to acquire a write lock on the feed's refresh state
			startRefresh();
			LOG.debug("Started refreshing feed:: " + feed + " with " + feed.getUnreadEntriesCount() + " unread");
		} catch (RefreshInProgressException e) {
			LOG.warn("Detected refresh already in progress. Aborting refresh.");
			return;
		}
		
		try {
			if (!feed.hasChanged()) {
				LOG.debug(feed + " has not changed");
				return;
			}
			
			List newEntries = feed.fetchNewEntries(entryStore);
			if (newEntries.isEmpty()) {
				LOG.debug("No new entries for feed:: " + feed);
				return;
			}
			
			entryStore.addEntries(newEntries);
			feedStore.synchronise(feed);
		} catch (IOException e) {
			LOG.warn("Error whilst checking if " + feed + " had changed.");
			LOG.warn(e.toString());
		} finally {
			//release the lock one has on the feed's refresh state
			finishRefresh();
			LOG.debug("Finished refreshing feed:: " + feed + " with " + feed.getUnreadEntriesCount() + " unread");
		}
		
		/*
		 * The possibility exists of a threading problem here
		 * if the user switches their selected feed in between the test and
		 * the action based on the test. That's because another thread can sneak in
		 * between the if and the body of code that's run inside it.
		 * If this becomes a problem we need to decide what we should synchronize on:
		 * the entire section of code or a particular object/class?
		*/
		//FIXME this has happened at least once when the machine is busy/slow
		if (feedModel.isSelected(feed)) {
			List entriesInFeed = entryStore.findEntriesInFeed(feed.getId());
			entryModel.loadEntries(entriesInFeed);
		}
	}

	private void startRefresh() throws RefreshInProgressException {
		feed.setRefreshStarted();
		feedModel.refreshFeed(feed);
	}

	private void finishRefresh() {
		feed.setRefreshFinished();
		feedModel.refreshFeed(feed);
	}

}