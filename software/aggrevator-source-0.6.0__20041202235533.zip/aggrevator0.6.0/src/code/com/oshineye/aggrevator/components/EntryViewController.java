package com.oshineye.aggrevator.components;

import com.oshineye.aggrevator.Entry;

/**
 * @author aoshineye
 *
 */
public interface EntryViewController {

	void handleEntrySelected(Entry entry);
}
