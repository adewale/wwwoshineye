package com.oshineye.aggrevator.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import org.apache.log4j.Logger;
import org.logicalcobwebs.proxool.ProxoolFacade;

import com.oshineye.aggrevator.TunnellingException;

/**
 * @author aoshineye
 */
public class JdbcProcessFactory {
	private static final Logger LOG = Logger.getLogger(JdbcProcessFactory.class);
	private static PoolRegistrar poolRegistrar; 
	
	public JdbcProcessFactory(String driverName, String url, String userName, String password) {
		if (poolRegistrar == null) {
			poolRegistrar = new PoolRegistrar(driverName, url, userName, password);
		}
	}
	
	public JdbcProcessFactory() {
		//needed by sub-class
	}

	public JdbcProcess createProcess() {
		return new JdbcProcess(getConnection());
	}
	
	public Connection getConnection() {
		Connection conn;
		try {
			conn = DriverManager.getConnection("proxool." + PoolRegistrar.HARVESTER_ALIAS);
		} catch (SQLException sqle) {
			throw new TunnellingException(sqle);
		}

		return conn;
	}

	public void create(String createString) {
		JdbcProcess process = new JdbcProcess(getConnection());
		process.executeCreate(createString);
	}
	
	private static final class PoolRegistrar {
		private static final String HARVESTER_ALIAS = "harvesterAlias";
		public PoolRegistrar(String driverName, String url, String userName, String password) {
			try {
				Class.forName("org.logicalcobwebs.proxool.ProxoolDriver");
				Properties info = new Properties();
				info.setProperty("proxool.maximum-connection-count", "10");
				info.setProperty("proxool.test-before-use", "true");
				info.setProperty("proxool.house-keeping-test-sql", "select CURRENT_DATE");
				info.setProperty("user", userName);
				info.setProperty("password", password);
				String proxoolUrl = "proxool." + PoolRegistrar.HARVESTER_ALIAS + ":" + driverName + ":"
						+ url;
				ProxoolFacade.registerConnectionPool(proxoolUrl, info);
				
			} catch (Exception e) {
				LOG.warn(e.toString());
			}
		}
	}
}
