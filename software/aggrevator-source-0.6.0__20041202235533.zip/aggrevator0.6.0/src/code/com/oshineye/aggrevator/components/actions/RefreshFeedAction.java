package com.oshineye.aggrevator.components.actions;

import org.apache.log4j.Logger;

import org.eclipse.jface.resource.ImageDescriptor;

import EDU.oswego.cs.dl.util.concurrent.Executor;

import com.oshineye.aggrevator.Feed;
import com.oshineye.aggrevator.components.EntryModel;
import com.oshineye.aggrevator.components.FeedModel;
import com.oshineye.aggrevator.components.tasks.RefreshFeedTask;
import com.oshineye.aggrevator.store.EntryStore;
import com.oshineye.aggrevator.store.FeedStore;

/**
 * @author aoshineye
 */
public class RefreshFeedAction extends AbstractWidgetSelectedAction {
	private static final Logger LOG = Logger.getLogger(RefreshFeedAction.class);
	private FeedStore feedStore;
	private EntryStore entryStore;
	private Executor executor;
	private FeedModel feedModel;
	private EntryModel entryModel;

	public RefreshFeedAction(Executor executor, FeedStore feedStore, EntryStore entryStore, FeedModel feedModel, EntryModel entryModel) {
		this.executor = executor;
		this.feedStore = feedStore;
		this.entryStore = entryStore;
		this.feedModel = feedModel;
		this.entryModel = entryModel;
		
		this.setText("&Refresh Feed@F5");
		this.setToolTipText("Refresh the selected feed");
		this.setImageDescriptor(ImageDescriptor.createFromFile(NewFeedAction.class, "/refreshFeed.png"));
	}

	public void run() {
		try {
			Feed selectedFeed = feedModel.getSelectedFeed();
			executor.execute(new RefreshFeedTask(selectedFeed, feedStore, entryStore, feedModel, entryModel));
		} catch (InterruptedException e) {
			LOG.warn(e.toString());
		}
	}
}
