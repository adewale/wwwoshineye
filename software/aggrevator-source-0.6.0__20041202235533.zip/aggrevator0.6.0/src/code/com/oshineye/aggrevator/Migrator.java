package com.oshineye.aggrevator;

import java.io.FileNotFoundException;


/**
 * @author aoshineye
 *
 */
public interface Migrator {
	public abstract void dump(String folderName);

	public void load(String folderName) throws FileNotFoundException;
}