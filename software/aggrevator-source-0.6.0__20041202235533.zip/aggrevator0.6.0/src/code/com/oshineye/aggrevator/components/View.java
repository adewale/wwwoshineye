package com.oshineye.aggrevator.components;

/**
 * @author aoshineye
 */
public interface View {
	public void focus();
}
