package com.oshineye.aggrevator.components;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.oshineye.aggrevator.Entry;

/**
 * @author aoshineye
 *
 */
public class BrowserModelImpl implements BrowserModel {

	private List observers;

	public BrowserModelImpl() {
		this.observers = new ArrayList();
	}
	
	public void loadEntry(Entry entry) {
		for (Iterator iter = observers.iterator(); iter.hasNext();) {
			BrowserObserver observer = (BrowserObserver) iter.next();
			observer.notifyEntryLoaded(entry);
		}
	}

	public void addObserver(BrowserObserver observer) {
		observers.add(observer);
	}
}
