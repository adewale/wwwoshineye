package com.oshineye.aggrevator.components;

import org.eclipse.jface.resource.FontRegistry;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.graphics.Font;
import org.eclipse.swt.graphics.FontData;
import org.eclipse.swt.graphics.GC;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.swt.widgets.TableItem;


public abstract class AbstractTableView implements ListView {
	private FontRegistry fontRegistry;
	private static final String FONT_NAME = "tableFont";
	private static final String PLAIN_FONT_NAME = "tableFontAfterItemIsMarkedRead";
	protected static final int DEFAULT_COLUMN_WIDTH = 218;
	private static final int PREFERRED_WIDTH_OF_NUMERIC_COLUMN = 21;

	public void widgetDefaultSelected(SelectionEvent event) {
		widgetSelected(event);
	}
	
	protected Table createTable(Composite parent, String[] titles, SelectionListener listener) {
		if (fontRegistry == null) {
			fontRegistry = new FontRegistry(parent.getDisplay());
		}

		Table table = new Table(parent, SWT.FULL_SELECTION|SWT.VIRTUAL);
		setFontToBold(table);
		populateColumnHeaders(table, titles);
		table.setLinesVisible(true);
		table.setHeaderVisible(true);
		table.addSelectionListener(listener);
		return table;
	}
    
	protected void setFontToBold(Table table) {
		if (!fontRegistry.hasValueFor(FONT_NAME)) {
			addFontToRegistry(table);
		}
	
		Font newFont = fontRegistry.getBold(FONT_NAME);
		table.setFont(newFont);
	}
	
	protected void setFontToItalic(TableItem item) {
		Control control = getTable();
		if (!fontRegistry.hasValueFor(FONT_NAME)) {
			addFontToRegistry(control);
		}
	
		Font newFont = fontRegistry.getItalic(FONT_NAME);
		item.setFont(newFont);
		//this doesn't change the control's font because it's only ever a temporary alteration
	}

	protected void setFontToBold(TableItem item) {
		Control control = getTable();
		if (!fontRegistry.hasValueFor(FONT_NAME)) {
			addFontToRegistry(control);
		}
	
		Font newFont = fontRegistry.getBold(FONT_NAME);
		item.setFont(newFont);
		control.setFont(newFont);
	}
	
	protected void setFontToPlain(TableItem item) {
		Control control = getTable();
		if (!fontRegistry.hasValueFor(PLAIN_FONT_NAME)) {
			addPlainVersionOfFontToRegistry(control);
		}
	
		Font newFont = fontRegistry.get(PLAIN_FONT_NAME);
		item.setFont(newFont);
		control.setFont(newFont);
	}
	
	protected void setFontToBold(TableItem item, boolean isSameFeed) {
		Control control = getTable();
		if (!fontRegistry.hasValueFor(FONT_NAME)) {
			addFontToRegistry(control);
		}
	
		Font newFont = fontRegistry.getBold(FONT_NAME);
		setFontIfNotAlreadyUsingThatFont(control, item, newFont, isSameFeed);
	}
	
	protected void setFontToPlain(TableItem item, boolean isSameFeed) {
		Control control = getTable();
		if (!fontRegistry.hasValueFor(PLAIN_FONT_NAME)) {
			addPlainVersionOfFontToRegistry(control);
		}
	
		Font newFont = fontRegistry.get(PLAIN_FONT_NAME);
		setFontIfNotAlreadyUsingThatFont(control, item, newFont, isSameFeed);
	}
	
	private void setFontIfNotAlreadyUsingThatFont(Control control, TableItem item, Font newFont, boolean isSameFeed) {
	    if (isSameFeed && newFont.equals(item.getFont())) {
	        return;
	    }
	    item.setFont(newFont);
	    control.setFont(newFont);
	}
	
	private void addPlainVersionOfFontToRegistry(Control control) {
		Font font = control.getFont();
		FontData[] data = font.getFontData();
		for (int i = 0; i < data.length; i++) {
			FontData dataItem = data[i];
			dataItem.setStyle(SWT.ROMAN);
		}
		fontRegistry.put(PLAIN_FONT_NAME, data);
	}

	private void addFontToRegistry(Control control) {
		Font font = control.getFont();
		FontData[] data = font.getFontData();
		fontRegistry.put(FONT_NAME, data);
	}
	
	private void populateColumnHeaders(Table table, String[] titles) {
		for (int index = 0; index < titles.length; index++) {
			TableColumn column = new TableColumn(table, SWT.LEFT);
			String title = titles[index];
			column.setText(title);
			column.setWidth(DEFAULT_COLUMN_WIDTH);
			column.addSelectionListener(this);
			configure(index, column, table);
		}
	}
	
	protected int calculateStringWidthInPixels(Table table, String text) {
		GC gc = new GC(table);
		
		//the x and y values in this Point object are actually the width and 
		//the height of the text string in pixels
		Point point = gc.stringExtent(text);
		gc.dispose();
		return point.x;
	}

	protected abstract void configure(int index, TableColumn column, Table table);
	
	protected abstract Table getTable();
	
	public void focus() {
		getTable().setFocus();
	}

	protected void setWidthForNumericColumn(TableColumn column, Table tableControl) {
		int width = calculateStringWidthInPixels(tableControl, createPadding(PREFERRED_WIDTH_OF_NUMERIC_COLUMN));
		column.setWidth(width);
	}

	private String createPadding(int length) {
		StringBuffer sb = new StringBuffer();
		for (int i=0; i<length; i++) {
			sb.append(" ");
		}
		return sb.toString();
	}

	public void showSelectedItem() {
		getTable().showSelection();
	}
}
