package com.oshineye.aggrevator;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

/**
 * @author aoshineye
 */
public class Configuration {
	private static final Logger LOG = Logger.getLogger(Configuration.class);
	public static final String DATE_FORMAT = "EEEE yyyy-MM-dd";
	
	private static String hostName = "localhost";
	private static String databaseName = "aggrevator";
	private static String databaseServer = "jdbc:mysql://localhost/";
	
	private static String userName = "aggrevator_user";
	private static String password = "aggrevator_user_password";
	
	private static int numberOfThreadsInPool = 10;
	
	//http timeout in milliseconds
	private static int httpTimeOut = 1000 * 60;


	public static String getHostName() {
		return hostName;
	}

	public static String getDatabaseName() {
		return databaseName;
	}
	
	public static String getDatabaseServer() {
		return databaseServer;
	}

	public static String getUserName() {
		return userName;
	}
	
	public static String getPassword() {
		return password;
	}
	
	public static int getNumberOfThreadsInPool() {
		return numberOfThreadsInPool;
	}
	
	public static int getHttpTimeoutInMilliseconds() {
		return httpTimeOut;
	}

	public static void load() {
		startLog4J();
		
		Properties props = load("configuration.properties");
		
		//get all the values defaulting to their original values if the user hasn't entered anything in the file for them
		hostName = props.getProperty("hostName", databaseName);
		databaseName = props.getProperty("databaseName", databaseName);
		databaseServer = props.getProperty("databaseServer", databaseServer);
		userName = props.getProperty("userName", userName);
		password = props.getProperty("password", password);
		numberOfThreadsInPool = Integer.parseInt(props.getProperty("numberOfThreadsInPool", String.valueOf(numberOfThreadsInPool)));
		httpTimeOut = Integer.parseInt(props.getProperty("httpTimeOut", String.valueOf(httpTimeOut)));
	}
	
	public static Properties load(String fileName) {
		File propertyFile = new File(fileName);
		Properties props = new Properties();
		if (!propertyFile.exists()) {
			return props;
		}

		try {
			props.load(new FileInputStream(propertyFile));
		} catch (FileNotFoundException e) {
			LOG.warn(e.getMessage(), e);
		} catch (IOException e) {
			LOG.warn(e.getMessage(), e);
		}
		return props;
	}

	private static void startLog4J() {
		PropertyConfigurator.configureAndWatch("log4j.properties", 1000);
	}
}
