package com.oshineye.aggrevator.components.commands;

import java.util.List;

import com.oshineye.aggrevator.components.EntryModel;
import com.oshineye.aggrevator.components.FeedModel;
import com.oshineye.aggrevator.store.EntryStore;
import com.oshineye.aggrevator.store.FeedStore;

/**
 * @author aoshineye
 */
public class VisitLocationCommand implements Command {

	private FeedModel feedModel;
	private EntryModel entryModel;
	private String location;

	public VisitLocationCommand(FeedModel feedModel, EntryModel entryModel, String location) {
		this.feedModel = feedModel;
		this.entryModel = entryModel;
		this.location = location;
	}

	public void execute(FeedStore feedStore, EntryStore entryStore) {
		if (entryStore.markRead(location)) {
			List relatedFeeds = entryStore.getRelatedFeeds(location);
			feedModel.entryRead(relatedFeeds);
			entryModel.markRead(location);
		}
	}

}
