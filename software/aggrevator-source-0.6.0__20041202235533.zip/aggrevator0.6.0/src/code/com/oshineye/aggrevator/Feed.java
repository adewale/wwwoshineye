package com.oshineye.aggrevator;
import java.io.IOException;
import java.util.Date;
import java.util.List;

/**
 * @author aoshineye
 *
 */
public interface Feed extends Filterable {
	public static final Long PLACE_HOLDER_ID = new Long(-1);
	public static final String NO_TITLE = "No Title";
	public static final int SCORE_UNITS = 10;
	public static final int ENTRY_READ_SCORE = SCORE_UNITS / 10;
	public abstract String getUrl();
	public abstract void setUrl(String newUrl);
	public abstract String getTitle();
	public void setTitle(String newTitle);
	public abstract boolean isRead();
	public abstract void incrementReadEntryCount();
	public abstract int getUnreadEntriesCount();
	public abstract void incrementScore();
	public abstract int getScore();
	public abstract void decrementScore();
	public abstract void setRefreshStarted() throws RefreshInProgressException;
	public abstract boolean isRefreshing();
	public abstract void setRefreshFinished();
	public abstract String getEtag();
	public abstract String getLastModified();
	public abstract Date getLastModifiedDate();
	public abstract String getFormattedDate();
	public abstract boolean hasChanged() throws IOException;
	public abstract Long getId();
	public abstract void setId(Long id);
	public abstract boolean isStored();
	public abstract void markRead();
	public abstract void entryRead();
    public abstract boolean hasSameUrl(Object feed);
    public abstract List fetchNewEntries(EntryFinder finder);
    public abstract List fetchNewEntries();
	public abstract void update(int unreadEntriesCount, int score);
}