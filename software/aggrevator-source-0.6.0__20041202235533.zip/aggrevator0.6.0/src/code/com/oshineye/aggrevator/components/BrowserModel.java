package com.oshineye.aggrevator.components;

import com.oshineye.aggrevator.Entry;

/**
 * @author aoshineye
 *
 */
public interface BrowserModel {

	void loadEntry(Entry entry);

	void addObserver(BrowserObserver observer);
}
