package com.oshineye.aggrevator;

/**
 * @author aoshineye
 * 
 * This class exists because creating a fully valid feed requires a primary key and all
 * FeedImpl constructors should take a primary key.
 * Since access to the primary key requires access to the FeedStore and I don't want
 * to couple the FeedImpl to the Feedstore. Nor do I want to couple clients of the FeedImpl
 * to the FeedStore's primary key generation strategy. Clients of the FeedImpl will use this class instead
 * and receive a Feed (so they need never know about FeedImpl) and this class will act as a facade
 * hiding the FeedStore's primary generation key.
 */
public class FeedFactory {
	public static Feed createFeedFromUrl(String url) {
		return new FeedImpl(url);
	}

	public static Feed createFeedFromStore(long id, String url, String title, int unreadEntryCount, int score, String etag, String lastModified) {
		return new FeedImpl(id, url, title, unreadEntryCount, score, etag, lastModified);
	}

	public static Feed createFeedFromIdUrlAndTitle(Long id, String url, String title) {
		return new FeedImpl(id, url, title);
	}
}
