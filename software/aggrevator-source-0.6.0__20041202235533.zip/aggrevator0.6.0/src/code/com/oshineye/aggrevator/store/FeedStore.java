package com.oshineye.aggrevator.store;

import java.util.List;

import com.oshineye.aggrevator.Feed;

/**
 * @author aoshineye
 *
 */
public interface FeedStore {
	public static final String NO_TITLE = "No Title";
	/**
	 * Add the settings for a feed to the entryStore.
	 * Throws an unchecked DuplicateFeedException if this feed's url is already
	 * present in the entryStore.
	 */
	public abstract void add(Feed feed) throws DuplicateFeedException;
	public abstract Feed findFeed(Feed feed);
	public abstract Feed findFeed(Long id);
	public abstract List findAllFeeds();
	public abstract void delete(Feed feed);
	public abstract void deleteAll();
	public abstract void synchronise(Feed feed);
	public abstract void markRead(Feed feed);
	public abstract boolean urlExists(Feed feed);
	public void update(Feed feed);
}