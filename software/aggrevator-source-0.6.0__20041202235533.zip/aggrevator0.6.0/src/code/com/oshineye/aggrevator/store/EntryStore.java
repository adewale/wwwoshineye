package com.oshineye.aggrevator.store;

import java.util.List;

import com.oshineye.aggrevator.Entry;
import com.oshineye.aggrevator.EntryFinder;
import com.oshineye.aggrevator.Feed;

/**
 * @author aoshineye
 *
 */
public interface EntryStore extends EntryFinder {
	public void addEntries(List entries);

	public void markRead(Entry entry);
	
	public boolean markRead(String entryUrl);

	//FIXME this is an incredibly dangerous method
	//once the amount of data in the system is very large this method will
	//cause out of memory errors when invoked
	public List findAllEntries();

	public List findEntriesInFeed(Long feedId);

	public void delete(Feed feed);

	public void deleteAll();

	public List findEntriesMatching(ContentContainsPredicate predicate);

	public void incrementScore(Entry entry);

	public void decrementScore(Entry entry);
	
	public abstract List getRelatedFeeds(Entry entry);

	public List getRelatedFeeds(String url);

}
