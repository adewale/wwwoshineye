package com.oshineye.aggrevator.components;

import java.util.List;

import com.oshineye.aggrevator.Entry;
import com.oshineye.aggrevator.Feed;


public interface EntryModelObserver {
	void notifyEntriesLoaded(List entries);

	void notifyEntryRefreshed(Entry entry);
	
	void notifyEntriesDeleted(Feed feed);

	void notifyEntryRead(Entry entry);
}
