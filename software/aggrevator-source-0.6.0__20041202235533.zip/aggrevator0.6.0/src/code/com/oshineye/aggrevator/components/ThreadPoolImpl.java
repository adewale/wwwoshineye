package com.oshineye.aggrevator.components;

import java.util.Iterator;
import java.util.List;

import org.apache.log4j.Logger;

import EDU.oswego.cs.dl.util.concurrent.LinkedQueue;
import EDU.oswego.cs.dl.util.concurrent.PooledExecutor;

import com.oshineye.aggrevator.Configuration;
import com.oshineye.aggrevator.Feed;
import com.oshineye.aggrevator.components.tasks.RefreshFeedTask;
import com.oshineye.aggrevator.store.EntryStore;
import com.oshineye.aggrevator.store.FeedStore;

/**
 * @author aoshineye
 *
 */
public class ThreadPoolImpl implements ThreadPool {
	private static final Logger LOG = Logger.getLogger(ThreadPoolImpl.class);
	
	private PooledExecutor pool;
	private EntryStore entryStore;
	private FeedModel feedModel;
	private EntryModel entryModel;
	private FeedStore feedStore;
	public ThreadPoolImpl(FeedStore feedStore, EntryStore entryStore, FeedModel feedModel) {
		this.feedStore = feedStore;
		this.entryStore = entryStore;
		this.feedModel = feedModel;
		
		//work queue is infinite
		this.pool = new PooledExecutor(new LinkedQueue());
        pool.setKeepAliveTime(-1); //threads in pool live forever
        pool.createThreads(Configuration.getNumberOfThreadsInPool());
    }
	
	public ThreadPoolImpl(FeedStore feedStore, EntryStore entryStore, FeedModel feedModel, EntryModel entryModel) {
		this(feedStore, entryStore, feedModel);
		this.entryModel = entryModel;
	}

	public void enqueue(List feeds) {
		for (Iterator iter = feeds.iterator(); iter.hasNext();) {
			Runnable task = getFeedRefreshTask((Feed) iter.next());
			execute(task);
		}
	}

	protected Runnable getFeedRefreshTask(Feed feed) {
		return new RefreshFeedTask(feed, feedStore, entryStore, feedModel, entryModel);
	}

	public void execute(Runnable task) {
		try {
			pool.execute(task);
		} catch (InterruptedException e) {
			LOG.warn(e.toString());
		}
	}

	public void shutDownNow() {
		pool.interruptAll();
		pool.shutdownNow();
	}
	
	public void shutDownAfterProcessingCurrentlyQueuedTasks() {
		pool.shutdownAfterProcessingCurrentlyQueuedTasks();
		try {
			pool.awaitTerminationAfterShutdown();
		} catch (InterruptedException e) {
			LOG.warn(e.toString());
		}
	}
}
