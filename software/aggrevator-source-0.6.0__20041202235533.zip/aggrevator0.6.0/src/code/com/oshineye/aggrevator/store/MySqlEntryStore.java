package com.oshineye.aggrevator.store;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.lang.StringUtils;

import com.oshineye.aggrevator.Entry;
import com.oshineye.aggrevator.Feed;
import com.oshineye.aggrevator.TunnellingException;
import com.oshineye.aggrevator.db.AbstractQueryBlock;
import com.oshineye.aggrevator.db.JdbcBlock;
import com.oshineye.aggrevator.db.JdbcProcess;
import com.oshineye.aggrevator.db.JdbcProcessFactory;
import com.oshineye.aggrevator.db.QueryBlock;
import com.oshineye.aggrevator.util.QueryLoader;

/**
 * @author aoshineye
 *
 */
public class MySqlEntryStore extends MySqlStore implements EntryStore {
	private JdbcProcessFactory factory;
	private FeedIdentityMap feedIdentityMap;
	private QueryLoader queryLoader;

	public MySqlEntryStore(String databaseName, FeedIdentityMap feedIdentityMap, QueryLoader queryLoader) {
		super(databaseName);
		this.queryLoader = queryLoader;
		factory = getJdbcProcessFactory();
		this.feedIdentityMap = feedIdentityMap;
	}

	public void addEntries(List entries){
		if (entries.isEmpty()) {
			return;
		}
		updateFeedTitle(entries);
		
		storeEntriesUsingBatch(entries);
	}

	public void markRead(final Entry entry) {
		markRead(entry.getUrl());
		entry.markRead();
	}

	public boolean markRead(final String url) {
		JdbcProcess process = factory.createProcess();
		int rowsUpdated = process.executeUpdate(queryLoader.getQuery("UPDATE_ENTRY_READ"), new JdbcBlock() {
			public void configure(PreparedStatement stmt) throws SQLException {
				stmt.setBoolean(1, true);
				stmt.setInt(2, Feed.ENTRY_READ_SCORE);
				stmt.setString(3, url);
			}
		});
		
		return rowsUpdated == 1;
	}
	
	private void storeEntriesUsingBatch(List entries) {
		//we must store the metadata first so that if we are interrupted
		//we don't end up with entries that have no metadata
		storeMetadata(entries);
		storeEntries(entries);
	}
	
	private void storeEntries(List entries) {
		Connection conn = factory.getConnection();
		PreparedStatement stmt = null;
		try {
			stmt = conn.prepareStatement(queryLoader.getQuery("INSERT_ENTRY"));
			for (final Iterator iter = entries.iterator(); iter.hasNext();) {
				Entry entry = (Entry) iter.next();
				populateInsertEntryStatement(stmt, entry);
				stmt.addBatch();
			}
			stmt.executeBatch();
		} catch (SQLException e) {
			throw new TunnellingException(e);
		} finally {
			JdbcProcess.release(conn, stmt, null);
		}
	}

	private void storeMetadata(List entries) {
		Connection conn = factory.getConnection();
		PreparedStatement stmt = null;
		try {
			stmt = conn.prepareStatement(queryLoader.getQuery("INSERT_META_DATA"));
			for (final Iterator iter = entries.iterator(); iter.hasNext();) {
				Entry entry = (Entry) iter.next();
				populateInsertMetaDataStatement(stmt, entry);
				stmt.addBatch();
			}
			stmt.executeBatch();
		} catch (SQLException e) {
			throw new TunnellingException(e);
		} finally {
			JdbcProcess.release(conn, stmt, null);
		}
	}

	private void populateInsertEntryStatement(PreparedStatement stmt, Entry entry) throws SQLException {
		stmt.setLong(1, entry.getFeedId().longValue());
		stmt.setString(2, entry.getTitle());
		stmt.setString(3, entry.getContent());
		Date date = entry.getDate();
		stmt.setTimestamp(4, new java.sql.Timestamp(date.getTime()));
		stmt.setString(5, entry.getUrl());
	}
	
	private void populateInsertMetaDataStatement(PreparedStatement stmt, Entry entry) throws SQLException {
		stmt.setInt(1, entry.isRead() ? 1 : 0);
		stmt.setString(2, entry.getUrl());
		stmt.setInt(3, entry.getScore());
	}

	private void updateFeedTitle(List entries) {
		final Entry entry = (Entry) entries.get(0);
		JdbcProcess process = factory.createProcess();
		process.executeUpdate(queryLoader.getQuery("UPDATE_FEED_TITLE"), new JdbcBlock() {
			public void configure(PreparedStatement stmt) throws SQLException {
				stmt.setString(1, entry.getFeedTitle());
				stmt.setLong(2, entry.getFeedId().longValue());
			}
		});
	}

	public void delete(final Feed feed) {
		JdbcProcess process = factory.createProcess();
		process.executeUpdate(queryLoader.getQuery("DELETE_ENTRY"), new JdbcBlock() {
			public void configure(PreparedStatement stmt) throws SQLException {
				stmt.setLong(1, feed.getId().longValue());
			}
		});
	}

	public void deleteAll() {
		JdbcProcess process = factory.createProcess();
		process.executeUpdate(queryLoader.getQuery("DELETE_ALL_ENTRIES"), new JdbcBlock() {
			public void configure(PreparedStatement stmt) {
				//do nothing
			}
		});
		factory.createProcess().executeUpdate(queryLoader.getQuery("DELETE_ALL_METADATA"), new JdbcBlock() {
			public void configure(PreparedStatement stmt) {
				//do nothing
			}
		});
	}

	public List findAllEntries() {
		return findEntries(queryLoader.getQuery("GET_ALL_ENTRIES"));
	}
	
	public List findEntriesInFeed(final Long feedId) {
		JdbcProcess process = factory.createProcess();
		return (List) process.executeQuery(queryLoader.getQuery("GET_ENTRIES_IN_FEED"), new EntryStoreQueryBlock() {
			public void configure(PreparedStatement stmt) throws SQLException {
				stmt.setLong(1, feedId.longValue());
			}
		});
	}
	
    public List findMatchingEntriesInFeed(final Long feedId, final List entries) {
        JdbcProcess process = factory.createProcess();
        return (List) process.executeQuery(queryLoader.getQuery("GET_MULTIPLE_ENTRIES_IN_FEED") + createInClause(entries) + " order by entry.date_published desc", new EntryStoreQueryBlock() {
			public void configure(PreparedStatement stmt) throws SQLException {
				stmt.setLong(1, feedId.longValue());
				int offsetForFirstParameterAndOneBasedIndexing = 2;
				for (int index = 0; index < entries.size(); index++) {
                    Entry entry = (Entry) entries.get(index);
                    stmt.setString(index + offsetForFirstParameterAndOneBasedIndexing, entry.getUrl());
                }
			}
		});
    }
	
	private String createInClause(List entries) {
	    String[] questionMarks = new String[entries.size()];
	    for (int i = 0; i < questionMarks.length; i++) {
            questionMarks[i] = "?";
        }
	    return " and entry.perma_link in(" + StringUtils.join(questionMarks, ", ") + ")";
    }

    private List findEntries(String query) {
		JdbcProcess process = factory.createProcess();
		return (List) process.executeQuery(query, new EntryStoreQueryBlock());
	}
	
	public List findEntriesMatching(ContentContainsPredicate predicate) {
		String query = queryLoader.getQuery("GET_MULTIPLE_ENTRIES") + " and content like '%" + predicate.getArgument() +"%'";
		return findEntries(query);
	}
	
	public void incrementScore(Entry entry) {
		updateScore(entry, Feed.SCORE_UNITS);
		entry.incrementScore();
	}

	public void decrementScore(Entry entry) {
		updateScore(entry, -Feed.SCORE_UNITS);
		entry.decrementScore();
	}
	
	private void updateScore(final Entry entry, final int newScore) {
		JdbcProcess process = factory.createProcess();
		process.executeUpdate(queryLoader.getQuery("UPDATE_SCORE"), new AbstractQueryBlock() {
			public void configure(PreparedStatement stmt) throws SQLException {
				stmt.setInt(1, newScore);
				stmt.setString(2, entry.getUrl());
			}
		});
	}
	
	public List getRelatedFeeds(final Entry entry) {
		return findRelatedFeeds(entry.getUrl(), queryLoader.getQuery("GET_RELATED_FEEDS"));
	}

	private List findRelatedFeeds(final String entryUrl, String query) {
		JdbcProcess process = factory.createProcess();
		List ids = (List) process.executeQuery(query, new QueryBlock() {
			public void configure(PreparedStatement stmt) throws SQLException {
				stmt.setString(1, entryUrl);
			}
			
			public Object process(ResultSet rset) throws SQLException {
				List feedIds = new ArrayList();
				while (rset.next()) {
					feedIds.add(new Long(rset.getLong(1)));
				}
				return feedIds;
			}
		});
		return feedIdentityMap.findByIds(ids);
	}

	public List getRelatedFeeds(String entryUrl) {
		List relatedFeeds = findRelatedFeeds(entryUrl, queryLoader.getQuery("GET_RELATED_FEEDS"));
		return relatedFeeds;
	}
}
