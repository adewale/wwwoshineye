package com.oshineye.aggrevator.components;


public interface Block {

	void execute();

}
