package com.oshineye.aggrevator;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.StringReader;
import java.net.MalformedURLException;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.zip.GZIPInputStream;

import org.apache.commons.httpclient.Header;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpMethod;
import org.apache.commons.httpclient.HttpStatus;
import org.apache.commons.httpclient.methods.GetMethod;
import org.apache.commons.httpclient.methods.HeadMethod;
import org.apache.commons.httpclient.params.HttpClientParams;
import org.apache.commons.lang.time.DateFormatUtils;
import org.apache.log4j.Logger;

import com.oshineye.aggrevator.util.IOUtils;
import com.oshineye.aggrevator.util.StringUtils;

import de.nava.informa.core.ChannelIF;
import de.nava.informa.core.ItemGuidIF;
import de.nava.informa.core.ItemIF;
import de.nava.informa.core.ParseException;
import de.nava.informa.impl.basic.ChannelBuilder;
import de.nava.informa.parsers.FeedParser;

/**
 * An RSS/RDF/ATOM feed
 *
 * @author aoshineye
 */
public class FeedImpl implements Feed {
	private static final Logger LOG = Logger.getLogger(FeedImpl.class);

	private String url;
	private String title;
	private String etag;
	private String lastModified;
	private boolean read;
	private int unreadEntriesCount;
	private int score;
	private boolean refreshing;
	private Long id;
	private String formattedLastModified;
	private Date lastModifiedDate;
	
	/**
	 * Construct a feed pointing to the file at the url.
	 * Throws InvalidUrlException if url is null or an empty string.
	 * @param newUrl
	 */
	public FeedImpl(String newUrl) {
		if ((null == newUrl) || ((newUrl = newUrl.trim()).equals(""))) {
			throw new InvalidUrlException("Attempted to create feed with an invalid url: " + newUrl);
		}
		
		this.setUrl(normalise(newUrl));
		this.setTitle(Feed.NO_TITLE);
		this.updateFeedReadStatus(0);
		this.id = PLACE_HOLDER_ID;
	}
	
	public FeedImpl(long id, String url, String title, int unreadEntriesCount, int score, String etag, String lastModified) {
		this(new Long(id), url, title, unreadEntriesCount, score, etag, lastModified);
	}
	
	public FeedImpl(Long id, String url, String title) {
		//FIXME this is only used for testing
		this(url);
		this.setId(id);
		this.setTitle(title);
	}
	
	protected FeedImpl(String url, String title, int unreadEntriesCount, int score, String etag, String lastModified) {
		//FIXME this is only used for testing
		this(PLACE_HOLDER_ID, url, title, unreadEntriesCount, score, etag, lastModified);
	}
	
	protected FeedImpl(Long id, String url, String title, int unreadEntriesCount, int score, String etag, String lastModified) {
		this.id = id;
		this.setUrl(url);
		this.setTitle(title);
		this.updateFeedReadStatus(unreadEntriesCount);
		this.score = score;
		this.etag = etag;
		this.setLastModified(lastModified);
	}
	
	private String normalise(String unnormalisedUrl) {
		if (unnormalisedUrl.startsWith("feed://")) {
			return "http://" + unnormalisedUrl.substring("feed://".length());
		}
		if (unnormalisedUrl.startsWith("feed:")) {
			return unnormalisedUrl.substring("feed:".length());
		}
		return unnormalisedUrl;
	}

	public void setTitle(String newTitle) {
		String unescapedHtmlTitle = StringUtils.unescapeHtml(newTitle);
		this.title = StringUtils.valueOfWithDefault(unescapedHtmlTitle, "");
	}

	public void setUrl(String newUrl) {
		this.url = newUrl;
	}
	
	protected void setLastModified(String value) {
        this.lastModified = value;
		this.formattedLastModified = formatLastModified();
		this.lastModifiedDate = parseDate();
    }
	
	private Date parseDate() {
		if (lastModified == null) {
			return null;
		}
		Date date = null;
		try {
			SimpleDateFormat simpleDateFormat = new SimpleDateFormat("EE, d MMM yyyy HH:mm:ss");
			date = simpleDateFormat.parse(lastModified);
		} catch (java.text.ParseException e) {
			//this will happen a lot and is to be expected
			LOG.debug(e.toString() + " " + "Last Modified: " + lastModified + " was malformed");
		}
		return date;
	}

	private String formatLastModified() {
		Date date = parseDate();
		if (date == null) {
			return null;
		}
		return DateFormatUtils.format(date, Configuration.DATE_FORMAT);
	}
	
	public List fetchNewEntries() {
		ChannelIF fetchedChannel = null;
		try {
			fetchedChannel = fetchChannel();
		} catch (NothingReadException e) {
		    LOG.warn("Nothing read for: " + this + " Etag: " + etag + " Last modified: " + lastModified);
			//for some reason (404 or socket timeout) nothing could be read
			return Collections.EMPTY_LIST;
		}
		List fetchedEntries = extractEntries(fetchedChannel);
		LOG.debug("Fetched " + fetchedEntries.size() + " entries from " + this);
		
		return fetchedEntries;
	}
	
	public List fetchNewEntries(EntryFinder finder) {
	    List newEntries = this.fetchNewEntries();
		if (newEntries.isEmpty()) {
			return newEntries;
		}
		List oldEntries = finder.findMatchingEntriesInFeed(getId(), newEntries);
		filterOutOldEntries(oldEntries, newEntries);
		LOG.info(this + " had " + newEntries.size() + " new entries");
		
		updateFeedReadStatus(unreadEntriesCount + newEntries.size());
		return newEntries;
	}

	private void filterOutOldEntries(List oldEntries, List fetchedEntries) {
        for (Iterator iter = fetchedEntries.iterator(); iter.hasNext();) {
			Entry element = (Entry) iter.next();
			if (oldEntries.contains(element)) {
				iter.remove();
			}
		}
    }
	
	private ChannelIF fetchChannel() {
		ChannelIF fetchedChannel = null;
		try {
			Reader reader = getReader();
			fetchedChannel = FeedParser.parse(new ChannelBuilder(), reader);
		} catch (SocketTimeoutException e) {
		    LOG.warn(this + " : " + e.getMessage());
			throw new NothingReadException();//timing out is normal and expected
		} catch (SocketException e) {
		    LOG.warn(this + " : " + e.getMessage());
			throw new NothingReadException();
		} catch (IOException e) {
			LOG.warn(this + " : " + e.getMessage());
			throw new TunnellingException(e);
		} catch (ParseException e) {
			LOG.warn(this + " : " + e.getMessage());
			throw new TunnellingException(e);
		}
		
		if (Feed.NO_TITLE.equals(this.getTitle())) {
			setTitle(fetchedChannel.getTitle());
		}
		
		return fetchedChannel;
	}

	protected Reader getReader() throws IOException {
		HttpClient client = createHttpClient();
		HttpMethod method = createGetMethod();
		try {
			method.setFollowRedirects(true);
			method.setRequestHeader("Accept-encoding", "gzip");
			
			int statusCode = client.executeMethod(method);
			if (statusCode == HttpStatus.SC_NOT_FOUND) {//handle 404
				LOG.warn("Requested url: " + url + " can not be found");
				throw new NothingReadException();
			}
			
			if (statusCode == HttpStatus.SC_MOVED_PERMANENTLY) {
				Header responseHeader = method.getResponseHeader("location");
				String newUrl = responseHeader.getValue();
				LOG.info("Changing url from: " + url + " to: " + newUrl);
				this.url = newUrl;
				return getReaderWithoutFollowingRedirects();
			}
			
			LOG.debug("Requested url: " + url + " and status code was: " + statusCode);
			return getReader(method);
		} finally {
			LOG.debug("Retrieved content for: " + url);
			method.releaseConnection();
			LOG.debug("Released connection for: " + url);
		}
	}

	private Reader getReaderWithoutFollowingRedirects() throws IOException {
		HttpClient client = createHttpClient();//time in milliseconds
		HttpMethod method = createGetMethod();
		try {
			setUserAgent(method);
			method.setRequestHeader("Accept-encoding", "gzip");
			
			int statusCode = client.executeMethod(method);
			
			LOG.debug("Requested url: " + url + " and status code was: " + statusCode);
			return getReader(method);
		} finally {
			LOG.debug("Retrieved content for: " + url);
			method.releaseConnection();
			LOG.debug("Released connection for: " + url);
		}
	}

	private Reader getReader(HttpMethod method) throws IOException {
		updateLastModified(method);
		
		Header responseHeader = method.getResponseHeader("content-encoding");
		
		if (responseHeader == null) {
			return getStringReader(method, method.getResponseBodyAsString());
		}
		return getStringReader(method, getGzippedContent(method));
	}

	private HttpClient createHttpClient() {
		HttpClientParams params = new HttpClientParams();
		params.setSoTimeout(Configuration.getHttpTimeoutInMilliseconds());
		HttpClient client = new HttpClient(params);
		return client;
	}

	public boolean hasChanged() throws IOException {
	    //servers that don't support either of these standards should be treated as always having new content
	    if (etag == null && lastModified == null) {
	        return true;
	    }
		HttpClient client = createHttpClient();//time in milliseconds
		HttpMethod method = createHeadMethod();
		
		method.setRequestHeader("Accept-encoding", "gzip");
		method.setRequestHeader("If-None-Match", etag);
		method.setRequestHeader("If-Modified-Since", lastModified);
		int statusCode = client.executeMethod(method);
		return (statusCode != HttpStatus.SC_NOT_MODIFIED);
	}

	private void updateLastModified(HttpMethod method) {
		//we assume that httpclient will do the right thing should there be more
		//than 1 etag or last modified header returned by a client
		LOG.debug(this + " values were-> etag: " + etag + " lastModified: " + lastModified);
		
		Header etagHeader = method.getResponseHeader("ETag");
		if (etagHeader != null) {
			etag = etagHeader.getValue();
		}
		Header lastModifiedHeader = method.getResponseHeader("Last-Modified");
		if (lastModifiedHeader != null) {
			setLastModified(lastModifiedHeader.getValue());
		}
		
		LOG.debug(this + " values are now-> etag: " + etag + " lastModified: " + lastModified);
	}

    private Reader getStringReader(HttpMethod method, String result) {
		if (result == null) {//when the connection times out then the result is null
			throw new NothingReadException();
		}
		return new StringReader(result);
	}

	private String getGzippedContent(HttpMethod method) throws IOException {
		LOG.debug(this.toString() + " is being retrieved as gzipped content");
		GZIPInputStream stream = new GZIPInputStream(method.getResponseBodyAsStream());
		BufferedReader reader = null;
		StringBuffer result = new StringBuffer();
		try {
			reader = new BufferedReader(new InputStreamReader(stream));
			String line = null;
			while (null != (line = reader.readLine())) {
				result.append(line);
			}
		} finally {
			IOUtils.close(reader);
		}
		return result.toString();
	}

	public boolean equals(Object other) {
		if (other == null) {
			return false;
		}

		//actual equality testing takes place here
		Feed otherFeed = (Feed) other;
		return this.id.equals(otherFeed.getId());
	}
	
	public int hashCode() {
		/*
		The valueOf was added because when using reflection to create a FeedImpl
		inside XStream it is possible to call hashCode even though the object hasn't been properly
		constructed yet. This only happens on Linux using java 1.4.2_05.
		*/
		return String.valueOf(this.toString()).hashCode();
	}

	public String getUrl() {
		return url;
	}

	private List extractEntries(ChannelIF channel) {
		List entries = new ArrayList();
		for (Iterator iter = channel.getItems().iterator(); iter.hasNext();) {
			ItemIF item = (ItemIF) iter.next();
			String feedTitle = channel.getTitle();
			URL link = item.getLink();
			if (link == null) {
				link = createLink(item, link);
			}

			String description = item.getElementValue("content:encoded");
			if (description == null) {
				description = item.getDescription();
			}
			
			Entry entry = new Entry(item.getTitle(), description, item.getDate(), link, feedTitle, id);
			entries.add(entry);
		}
		return entries;
	}

	private URL createLink(ItemIF item, URL link) {
		ItemGuidIF guid = item.getGuid();
		if (guid == null) {
			return createUrl(link, Entry.NO_LINK);
		} else if (guid.isPermaLink()) {
			return createUrl(link, guid.getLocation());
		}
		return link;
	}

	private URL createUrl(URL link, String location) {
		try {
			return new URL(location);
		} catch (MalformedURLException e) {
			LOG.warn(e.toString() + " " + "Permalink: " + link + " was malformed for " + this);
		}
		return link;
	}

	public String getTitle() {
		return title;
	}

	public boolean isRead() {
		return read;
	}
	
	public String toString() {
		return "Feed: " + url;
	}

	public void incrementReadEntryCount() {
		updateFeedReadStatus(unreadEntriesCount - 1);
	}

	private void updateFeedReadStatus(int newValueForUnreadEntriesCount) {
		setUnreadEntriesCount(newValueForUnreadEntriesCount);
		read = (unreadEntriesCount == 0);
	}

	public int getUnreadEntriesCount() {
		return unreadEntriesCount;
	}

	public void incrementScore() {
		score += Feed.SCORE_UNITS;
	}

	public int getScore() {
		return score;
	}

	public void decrementScore() {
		score -= Feed.SCORE_UNITS;
	}

	public synchronized void setRefreshStarted() throws RefreshInProgressException {
		if (refreshing) {
			throw new RefreshInProgressException();
		}
		refreshing = true;
	}

	public boolean isRefreshing() {
		return refreshing;
	}

	public synchronized void setRefreshFinished() {
		refreshing = false;
	}

	public String getEtag() {
		return etag;
	}

	public String getLastModified() {
		return lastModified;
	}

	public Date getLastModifiedDate() {
		return lastModifiedDate;
	}
	
	public String getFormattedDate() {
		return formattedLastModified;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		if (isStored()) {
			throw new IllegalStateException("Attempting to set primary key more than once");
		}
		this.id = id;
	}

	public boolean isStored() {
		return !PLACE_HOLDER_ID.equals(id);
	}

	public void markRead() {
		read = true;
		setUnreadEntriesCount(0);
	}

	public void entryRead() {
		incrementReadEntryCount();
		score += Feed.ENTRY_READ_SCORE;
	}

    public boolean hasSameUrl(Object object) {
        if (object == null) {
            return false;
        }
        Feed otherFeed = (Feed) object;
        return this.url.equalsIgnoreCase(otherFeed.getUrl());
    }

	public void update(int unreadEntriesCount, int score) {
		this.updateFeedReadStatus(unreadEntriesCount);
		this.score = score;
	}
	
	private void setUnreadEntriesCount(int newValueForUnreadEntriesCount) {
		if (newValueForUnreadEntriesCount < 0) {
			this.unreadEntriesCount = 0;
			return;
		}
		this.unreadEntriesCount = newValueForUnreadEntriesCount;
	}

	private HeadMethod createHeadMethod() {
		HeadMethod method = new HeadMethod(url);
		setUserAgent(method);
		return method;
	}

	private GetMethod createGetMethod() {
		GetMethod method = new GetMethod(url);
		setUserAgent(method);
		return method;
	}
	
	private void setUserAgent(HttpMethod method) {
		method.setRequestHeader("User-Agent", Constants.APPLICATION_NAME + "/" + Constants.VERSION_NUMBER);
	}
}
