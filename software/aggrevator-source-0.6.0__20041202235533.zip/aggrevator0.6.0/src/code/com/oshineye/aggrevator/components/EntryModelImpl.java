package com.oshineye.aggrevator.components;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

import com.oshineye.aggrevator.Entry;
import com.oshineye.aggrevator.Feed;


public class EntryModelImpl extends AbstractModel implements EntryModel {
	private Entry selectedEntry;
	private List observers;
	private List currentEntries;
	private List allEntries;
	private String currentSearchText;
	
	public EntryModelImpl() {
		observers = new ArrayList();
		currentEntries = Collections.EMPTY_LIST;
		allEntries = Collections.EMPTY_LIST;
		currentSearchText = "";
	}

	public void addObserver(EntryModelObserver observer) {
		observers.add(observer);
	}

	public void loadEntries(List loadedEntries) {
		allEntries = new ArrayList(loadedEntries);
		loadMatchingItems(currentSearchText);
	}

	private void notifyObserversEntriesLoaded(List entriesLoaded) {
		for (Iterator iter = observers.iterator(); iter.hasNext();) {
			EntryModelObserver observer = (EntryModelObserver) iter.next();
			observer.notifyEntriesLoaded(entriesLoaded);
		}
	}

	public void deleteEntriesFromFeed(Feed feed) {
		currentEntries.clear();
		allEntries.clear();
		selectedEntry = null;
		
		for (Iterator iter = observers.iterator(); iter.hasNext();) {
			EntryModelObserver observer = (EntryModelObserver) iter.next();
			observer.notifyEntriesDeleted(feed);
		}
	}

	public void select(Entry entry) {
		this.selectedEntry = entry;
	}

	public Entry getSelectedEntry() {
		return selectedEntry;
	}

	public void selectNone() {
		this.selectedEntry = null;
	}

	public int getSelectedEntryIndex() {
		return currentEntries.indexOf(selectedEntry);
	}

	public void loadMatchingItems(String searchText) {
		currentSearchText = searchText;
		
		if (searchText.equals("")) {
			updateWithMatchingItems(allEntries);
			return;
		}

		List matchingItems = findMatchingItems(searchText, allEntries);
		if (isAlreadyShowing(matchingItems)) {
			return;
		}
		sortWithPreviousComparator(matchingItems);
		updateWithMatchingItems(matchingItems);
	}

	private void updateWithMatchingItems(List matchingItems) {
		currentEntries = matchingItems;
		notifyObserversEntriesLoaded(matchingItems);
	}

	public List getCurrentEntries() {
		return Collections.unmodifiableList(currentEntries);
	}
	
	public List getItems() {
		return currentEntries;
	}

	public void markRead(String location) {
		for (Iterator iter = currentEntries.iterator(); iter.hasNext();) {
			Entry entry = (Entry) iter.next();
			if (entry.getUrl().equalsIgnoreCase(location)) {
				entry.markRead();
				notifyObserversEntryRead(entry);
			}
		}
	}

	private void notifyObserversEntryRead(Entry entry) {
		for (Iterator iter = observers.iterator(); iter.hasNext();) {
			EntryModelObserver observer = (EntryModelObserver) iter.next();
			observer.notifyEntryRead(entry);
		}
	}
	
	public boolean entrySelected() {
		if (this.getSelectedEntry() == null) {
			return false;
		}
		return true;
	}

	public void refreshEntry(Entry entry) {
		for (Iterator iter = observers.iterator(); iter.hasNext();) {
			EntryModelObserver observer = (EntryModelObserver) iter.next();
			observer.notifyEntryRefreshed(entry);
		}
	}
}
