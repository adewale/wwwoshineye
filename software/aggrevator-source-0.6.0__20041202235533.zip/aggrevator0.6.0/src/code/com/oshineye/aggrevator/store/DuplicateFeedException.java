package com.oshineye.aggrevator.store;

import com.oshineye.aggrevator.Feed;

/**
 * @author aoshineye
 *
 */
public class DuplicateFeedException extends RuntimeException {
	public DuplicateFeedException(Feed duplicate) {
		super(duplicate.toString() + " is a duplicate feed");
	}

	public DuplicateFeedException(String url, String title) {
		super("Creating a feed with url: " + url + " and title: " + title + " would duplicate an existing feed");
	}
}
