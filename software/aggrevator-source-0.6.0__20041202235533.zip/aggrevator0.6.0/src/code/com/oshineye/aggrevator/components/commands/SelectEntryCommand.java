package com.oshineye.aggrevator.components.commands;

import java.util.List;

import com.oshineye.aggrevator.Entry;
import com.oshineye.aggrevator.components.BrowserModel;
import com.oshineye.aggrevator.components.EntryModel;
import com.oshineye.aggrevator.components.FeedModel;
import com.oshineye.aggrevator.store.EntryStore;
import com.oshineye.aggrevator.store.FeedStore;

/**
 * @author aoshineye
 *
 */
public class SelectEntryCommand implements Command {
	private BrowserModel browserModel;
	private Entry selectedEntry;
	private FeedModel feedModel;
	private EntryModel entryModel;

	public SelectEntryCommand(Entry selectedEntry, FeedModel feedModel, EntryModel entryModel, BrowserModel browserModel) {
		this.feedModel = feedModel;
		this.entryModel = entryModel;
		this.browserModel = browserModel;
		this.selectedEntry = selectedEntry;
	}

	public void execute(FeedStore feedStore, EntryStore entryStore) {
		entryModel.select(selectedEntry);
		browserModel.loadEntry(selectedEntry);

		if (selectedEntry.isRead()) {
			return;
		}

		List relatedFeeds = entryStore.getRelatedFeeds(selectedEntry.getUrl());
		entryStore.markRead(selectedEntry);
		feedModel.entryRead(relatedFeeds);
		entryModel.markRead(selectedEntry.getUrl());
	}
}
