package com.oshineye.aggrevator.components;

/**
 * @author aoshineye
 *
 */
public interface OPMLImporter {
	public abstract void importFeeds();
}