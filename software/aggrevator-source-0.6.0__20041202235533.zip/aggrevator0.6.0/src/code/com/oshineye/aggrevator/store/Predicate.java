package com.oshineye.aggrevator.store;

/**
 * @author aoshineye
 */
public interface Predicate {

	public String getArgument();
}
