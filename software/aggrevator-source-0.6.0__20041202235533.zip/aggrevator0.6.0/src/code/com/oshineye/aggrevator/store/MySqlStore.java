package com.oshineye.aggrevator.store;

import com.oshineye.aggrevator.Configuration;
import com.oshineye.aggrevator.db.JdbcProcessFactory;

/**
 * @author aoshineye
 *
 */
public abstract class MySqlStore {
	private String databaseName;

	public MySqlStore(String databaseName) {
		this.databaseName = databaseName;
	}

	protected JdbcProcessFactory getJdbcProcessFactory() {
		String driver = "org.gjt.mm.mysql.Driver";
		String url = Configuration.getDatabaseServer() + databaseName;
		String user = Configuration.getUserName();
		String passWord = Configuration.getPassword();
		return new JdbcProcessFactory(driver, url, user, passWord);
	}
}
