package com.oshineye.aggrevator.components;

import java.util.List;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.swt.widgets.TableItem;

import com.oshineye.aggrevator.ComparatorFactory;
import com.oshineye.aggrevator.Entry;
import com.oshineye.aggrevator.Feed;
import com.oshineye.aggrevator.components.tasks.Task;
import com.oshineye.aggrevator.util.StringUtils;

public class EntryViewImpl extends AbstractTableView implements EntryView, Listener {
	private static final String[] COLUMN_HEADERS = new String[]{"Entry Title", "Date", "Feed Title", "Score"};
	private static final int TITLE_COLUMN_INDEX = 0;
	private static final int DATE_COLUMN_INDEX = 1;
	private static final int FEED_TITLE_COLUMN_INDEX = 2;
	private static final int SCORE_COLUMN_INDEX = 3;
	private static final String LONGEST_POSSIBLE_DATE = "Wednesday 2004-29-30";
	private Table table;
	private EntryViewController entryController;
	private EntryModel entryModel;
	private Composite parent;
	
	public EntryViewImpl(EntryModel entryModel) {
		this.entryModel = entryModel;
		entryModel.addObserver(this);
	}

	public EntryViewImpl(EntryModel entryModel, Composite parent) {		
		this(entryModel);
		this.parent = parent;
		this.table = createTable(parent, COLUMN_HEADERS, this);
		this.table.addListener(SWT.SetData, this);
	}

	public EntryViewImpl(EntryModel entryModel, Composite parent, EntryViewController entryController) {
		this(entryModel, parent);
		this.entryController = entryController;
	}

	public void notifyEntriesLoaded(final List entries) {
		//this is synchronous because we really do want everything else to wait for this
		Display display = parent.getDisplay();
		display.syncExec(new Task() {
			public void doWork() {
				table.removeAll();
				table.setItemCount(entries.size());
                selectTableItem(table, entryModel.getSelectedEntryIndex());
			}
		});
	}

	public void widgetSelected(SelectionEvent event) {
		if (event.getSource() == table) {
			TableItem[] selectedItems = table.getSelection();
			TableItem item = selectedItems[0];
			entryController.handleEntrySelected((Entry)item.getData());
			setFontToPlain(item);
		} else {//it's a column
			sortColumns(event);
			notifyEntriesLoaded(entryModel.getCurrentEntries());
		}
	}

	private void sortColumns(SelectionEvent event) {
		TableColumn selectedColumn = (TableColumn) event.widget;
		
		if (selectedColumn == table.getColumn(TITLE_COLUMN_INDEX)){
			entryModel.sort(ComparatorFactory.getEntryTitleComparator());
		} else if (selectedColumn == table.getColumn(DATE_COLUMN_INDEX)){
			entryModel.sort(ComparatorFactory.getEntryDateComparator());
		} else if (selectedColumn == table.getColumn(FEED_TITLE_COLUMN_INDEX)) {
			entryModel.sort(ComparatorFactory.getEntryScoreComparator());
		} else if (selectedColumn == table.getColumn(SCORE_COLUMN_INDEX)) {
			entryModel.sort(ComparatorFactory.getEntryScoreComparator());
		}
	}

	private void populateItem(Entry entry, TableItem item) {
		item.setText(getElements(entry));
		item.setData(entry);
		
		if (entry.isRead()) {
			setFontToPlain(item);
		} else {
			setFontToBold(item);
		}
	}

	private String[] getElements(Entry entry) {
		String title = StringUtils.valueOfWithDefault(entry.getTitle(), Entry.MINIMAL_CONTENT);
		String date = StringUtils.valueOfWithDefault(entry.getFormattedDate(), Entry.MINIMAL_CONTENT);
		String feedTitle = StringUtils.valueOfWithDefault(entry.getFeedTitle(), Entry.MINIMAL_CONTENT);
		String score = String.valueOf(entry.getScore());
		
		return new String[]{title, date, feedTitle, score};
	}
	
	public void notifyEntriesDeleted(Feed feed) {
		List currentEntries = entryModel.getCurrentEntries();
		notifyEntriesLoaded(currentEntries);
	}

	public void handleEvent(Event event) {
		TableItem item = (TableItem) event.item;
		int itemLocation = table.indexOf(item);
		Entry currentEntry = (Entry) entryModel.getCurrentEntries().get(itemLocation);
		populateItem(currentEntry, item);
	}

	public int getItemCount() {
		return table.getItemCount();
	}

	public void addSelectionListener(SelectionListener listener) {
		table.addSelectionListener(listener);
	}

	protected Table getTable() {
		return table;
	}

	public void notifyEntryRead(final Entry entry) {
		notifyEntryRefreshed(entry);
	}

	protected void configure(int index, TableColumn column, Table table) {
		if (index == DATE_COLUMN_INDEX) {
			int width = calculateStringWidthInPixels(table, LONGEST_POSSIBLE_DATE);
			column.setWidth(width);
		} else if (index == SCORE_COLUMN_INDEX) {
			setWidthForNumericColumn(column, table);
		}
	}

	public void notifyEntryRefreshed(final Entry entry) {
		Display display = parent.getDisplay();
		display.asyncExec(new Task() {
			public void doWork() {
				List currentEntries = entryModel.getCurrentEntries();
				int indexOfEntry = currentEntries.indexOf(entry);
				table.clear(indexOfEntry);
			}
		});
	}
}
