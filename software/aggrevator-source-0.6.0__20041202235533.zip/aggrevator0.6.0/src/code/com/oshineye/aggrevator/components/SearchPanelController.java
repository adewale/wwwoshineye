package com.oshineye.aggrevator.components;

import java.util.List;

import org.eclipse.swt.events.KeyEvent;
import org.eclipse.swt.events.KeyListener;
import org.eclipse.swt.widgets.Text;

import com.oshineye.aggrevator.store.ContentContainsPredicate;
import com.oshineye.aggrevator.store.EntryStore;

/**
 * @author aoshineye
 */
public class SearchPanelController implements KeyListener {

	private EntryModel searchEntryModel;
	private Text textInput;
	private EntryStore entryStore;

	public SearchPanelController(EntryModel searchEntryModel, EntryStore entryStore, Text textInput) {
		this.searchEntryModel = searchEntryModel;
		this.entryStore = entryStore;
		this.textInput = textInput;
		textInput.addKeyListener(this);
	}

	public void keyPressed(KeyEvent e) {
		//do nothing
	}

	public void keyReleased(KeyEvent e) {
		if (e.keyCode == 13) {//enter key
			doSearch(textInput.getText());
		}
	}

	private void doSearch(String text) {
		ContentContainsPredicate contentContainsPredicate = new ContentContainsPredicate(text);
		List entriesMatching = entryStore.findEntriesMatching(contentContainsPredicate);
		searchEntryModel.loadEntries(entriesMatching);
	}

}
