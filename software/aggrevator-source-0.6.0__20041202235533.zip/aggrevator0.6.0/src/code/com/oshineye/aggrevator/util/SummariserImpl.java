package com.oshineye.aggrevator.util;

import java.util.ArrayList;
import java.util.List;

import com.oshineye.aggrevator.Feed;

/**
 * @author aoshineye
 */
public class SummariserImpl implements Summariser {
	
	private int importedFeedsCount;
	private List addedFeeds;

	public SummariserImpl() {
		this.addedFeeds = new ArrayList();
	}
	
	public void feedImported(Feed feed) {
		this.importedFeedsCount++;
	}

	public void feedStored(Feed feed) {
		addedFeeds.add(feed);
	}

	public int getStoredFeedsCount() {
		return addedFeeds.size();
	}

	public int getImportedFeedsCount() {
		return importedFeedsCount;
	}

	public List getNewlyAddedFeeds() {
		return addedFeeds;
	}

}
