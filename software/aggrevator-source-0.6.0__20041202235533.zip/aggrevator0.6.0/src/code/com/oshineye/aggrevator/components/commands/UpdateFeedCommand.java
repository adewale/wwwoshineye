package com.oshineye.aggrevator.components.commands;

import com.oshineye.aggrevator.Feed;
import com.oshineye.aggrevator.components.FeedModel;
import com.oshineye.aggrevator.store.EntryStore;
import com.oshineye.aggrevator.store.FeedStore;

/**
 * @author aoshineye
 *
 */
public class UpdateFeedCommand implements Command {

	private final FeedModel feedModel;
	private final Feed selectedFeed;
	private final String newFeedTitle;
	private final String newFeedUrl;

	public UpdateFeedCommand(FeedModel feedModel, Feed selectedFeed, String newFeedTitle, String newFeedUrl) {
		this.feedModel = feedModel;
		this.selectedFeed = selectedFeed;
		this.newFeedTitle = newFeedTitle;
		this.newFeedUrl = newFeedUrl;
	}

	public void execute(FeedStore feedStore, EntryStore entryStore) {
		selectedFeed.setTitle(newFeedTitle);
		selectedFeed.setUrl(newFeedUrl);
		feedModel.refreshFeed(selectedFeed);
		feedStore.update(selectedFeed);
	}

}
