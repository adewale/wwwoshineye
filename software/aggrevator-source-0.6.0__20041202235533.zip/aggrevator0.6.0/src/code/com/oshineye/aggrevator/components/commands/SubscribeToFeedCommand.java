package com.oshineye.aggrevator.components.commands;

import java.util.List;

import com.oshineye.aggrevator.Feed;
import com.oshineye.aggrevator.FeedFactory;
import com.oshineye.aggrevator.components.FeedModel;
import com.oshineye.aggrevator.store.DuplicateFeedException;
import com.oshineye.aggrevator.store.EntryStore;
import com.oshineye.aggrevator.store.FeedStore;

public class SubscribeToFeedCommand implements Command {
	private String feedUrl;
	private FeedModel feedModel;

	public SubscribeToFeedCommand(String feedUrl, FeedModel feedModel) {
		this.feedUrl = feedUrl;
		this.feedModel = feedModel;
	}

	public void execute(FeedStore feedStore, EntryStore entryStore) {
		Feed feed = FeedFactory.createFeedFromUrl(feedUrl);
		List feeds = feedModel.getCurrentFeeds();
		if (feeds.contains(feed)) {
			throw new DuplicateFeedException(feed);
		}
		
		feedStore.add(feed);
		feedModel.addFeed(feed);
	}

}
