package com.oshineye.aggrevator.util;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;

/**
 * @author aoshineye
 *
 * This class exists so that we can express the dependency other classes have on the IO sub-system
 * by passing instances of this class and it's sub-classes in as constructor arguments.
 * This should also make it easier to mock or stub out IO functionality in tests by passing in a 
 * StringWriterFactory
 */
public class BufferedWriterFactory implements WriterFactory {
	public Writer getWriter(File file) throws IOException {
		FileWriter fileWriter = new FileWriter(file, true);

		BufferedWriter writer = new BufferedWriter(fileWriter);
		return writer;
	}
}
