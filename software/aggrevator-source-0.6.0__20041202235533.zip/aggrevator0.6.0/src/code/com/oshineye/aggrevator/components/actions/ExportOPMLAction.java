package com.oshineye.aggrevator.components.actions;

import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;

import org.apache.log4j.Logger;
import org.eclipse.jface.action.Action;
import org.eclipse.jface.window.ApplicationWindow;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.FileDialog;
import org.eclipse.swt.widgets.Shell;

import com.oshineye.aggrevator.components.FeedModel;
import com.oshineye.aggrevator.components.OPMLExporter;
import com.oshineye.aggrevator.components.StatusRecorder;
import com.oshineye.aggrevator.util.IOUtils;

/**
 * @author aoshineye
 */
public class ExportOPMLAction extends Action {
	private static final Logger LOG = Logger.getLogger(ExportOPMLAction.class);
	private ApplicationWindow window;
	private FeedModel feedModel;
	private StatusRecorder recorder;

	public ExportOPMLAction(ApplicationWindow window, FeedModel feedModel, StatusRecorder recorder) {
		this.window = window;
		this.feedModel = feedModel;
		this.recorder = recorder;
		this.setText("&Export OPML File@Ctrl+S");
	}

	public void run() {
		String fileToExport = getFileToExport();
		if (fileToExport == null) {
			return;
		}
		
		Writer writer = null;
		try {
			writer = getWriter(fileToExport);
			OPMLExporter exporter = new OPMLExporter(feedModel);
			exporter.exportFeeds(writer);
		} finally {
			IOUtils.close(writer);
		}
		recorder.setStatus("Finished export of " + feedModel.getCurrentFeeds().size() + " feeds");
	}

	String getFileToExport() {
		Shell shell = window.getShell();
		FileDialog dialog = new FileDialog(shell, SWT.SAVE);
		dialog.setFilterExtensions(new String[]{"*.opml", "*.*"});
		dialog.setFilterNames(new String[]{"OPML Files (*.opml)", "All Files (*.*)"});
		String fileToExport = dialog.open();
		return fileToExport;
	}

	Writer getWriter(String fileToExport) {
		Writer writer = null;
		try {
			writer = new FileWriter(fileToExport);
		} catch (IOException e) {
			LOG.warn(e.toString());
		}
		return writer;
	}
}
