package com.oshineye.aggrevator.components;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import junit.framework.TestCase;

import com.mockobjects.dynamic.C;
import com.mockobjects.dynamic.Mock;
import com.oshineye.aggrevator.ComparatorFactory;
import com.oshineye.aggrevator.Feed;
import com.oshineye.aggrevator.StubFeed;
import com.oshineye.aggrevator.components.FeedModel;
import com.oshineye.aggrevator.components.FeedModelImpl;
import com.oshineye.aggrevator.components.FeedModelObserver;
import com.oshineye.aggrevator.store.StubFixture;

public class FeedModelTest extends TestCase {
	private FeedModel model;

	protected void setUp() throws Exception {
		model = new FeedModelImpl(new ArrayList());
	}

	public void testNewlyCreatedFeedModelHasValidCurrentFeeds() {
		Feed feed = StubFixture.getStubFeed();
		List feeds = new ArrayList();
		feeds.add(feed);
		model = new FeedModelImpl(feeds);
		assertEquals(1, model.getCurrentFeeds().size());
	}
	
	public void testModelNotifiesObserversOfAddedFeed() {
		Feed feed = StubFixture.getStubFeed();
		Mock mockObserver = new Mock(FeedModelObserver.class);
		mockObserver.expect("notifyFeedAdded", C.same(feed));
		Mock mockObserver2 = new Mock(FeedModelObserver.class);
		mockObserver2.expect("notifyFeedAdded", C.same(feed));

		model.addObserver((FeedModelObserver)mockObserver.proxy());
		model.addObserver((FeedModelObserver)mockObserver2.proxy());
		model.addFeed(feed);
		
		mockObserver.verify();
		mockObserver2.verify();
	}
	
	public void testModelNotifiesObserversOfAppendedFeeds() {
		StubFeed stubFeed = StubFixture.getStubFeed();
		StubFeed stubFeedWithUrl = StubFixture.getStubFeedWithUrl("url2");
		List feeds = new ArrayList();
		feeds.add(stubFeed);
		feeds.add(stubFeedWithUrl);
		Mock mockObserver = new Mock(FeedModelObserver.class);
		mockObserver.expect("notifyFeedAdded", C.same(stubFeed));
		mockObserver.expect("notifyFeedAdded", C.same(stubFeedWithUrl));
		Mock mockObserver2 = new Mock(FeedModelObserver.class);
		mockObserver2.expect("notifyFeedAdded", C.same(stubFeed));
		mockObserver2.expect("notifyFeedAdded", C.same(stubFeedWithUrl));

		model.addObserver((FeedModelObserver)mockObserver.proxy());
		model.addObserver((FeedModelObserver)mockObserver2.proxy());
		
		model.appendFeeds(feeds);
		
		mockObserver.verify();
		mockObserver2.verify();
	}
	
	public void testModelNotifiesObserverOfLoadedFeeds() {
		List feeds = new ArrayList();
		model = new FeedModelImpl(feeds);
		Mock mockObserver = new Mock(FeedModelObserver.class);
		mockObserver.expect("notifyFeedsLoaded", C.eq(feeds));
		Mock mockObserver2 = new Mock(FeedModelObserver.class);
		mockObserver2.expect("notifyFeedsLoaded", C.eq(feeds));
		model.addObserver((FeedModelObserver)mockObserver.proxy());
		model.addObserver((FeedModelObserver)mockObserver2.proxy());
		
		model.loadFeeds();
		
		mockObserver.verify();
		mockObserver2.verify();
	}
	
	public void testModelNotifiesObserversOfDeletedFeed() {
		Feed feed = StubFixture.getStubFeed();
		model.addFeed(feed);
		Mock mockObserver = new Mock(FeedModelObserver.class);
		mockObserver.expect("notifyFeedDeleted", C.args(C.same(feed), C.IS_ANYTHING));
		Mock mockObserver2 = new Mock(FeedModelObserver.class);
		mockObserver2.expect("notifyFeedDeleted", C.args(C.same(feed), C.IS_ANYTHING));
		model.addObserver((FeedModelObserver)mockObserver.proxy());
		model.addObserver((FeedModelObserver)mockObserver2.proxy());
		
		model.deleteFeed(feed);
		
		mockObserver.verify();
		mockObserver2.verify();
	}
	
	public void testModelNotifiesObserversOfRefreshedFeed() {
		Feed feed = StubFixture.getStubFeed();
		model.addFeed(feed);
		Mock mockObserver = new Mock(FeedModelObserver.class);
		mockObserver.expect("notifyFeedRefreshed", C.same(feed));
		Mock mockObserver2 = new Mock(FeedModelObserver.class);
		mockObserver2.expect("notifyFeedRefreshed", C.same(feed));
		model.addObserver((FeedModelObserver)mockObserver.proxy());
		model.addObserver((FeedModelObserver)mockObserver2.proxy());
		
		model.refreshFeed(feed);
		
		mockObserver.verify();
		mockObserver2.verify();
	}
	
	public void testModelDoesNotNotifyObserversOfRefreshedFeedsThatHaveNotBeenLoadedOrAdded() {
		Feed feed = StubFixture.getStubFeed();
		Mock mockObserver = new Mock(FeedModelObserver.class);
		Mock mockObserver2 = new Mock(FeedModelObserver.class);
		model.addObserver((FeedModelObserver)mockObserver.proxy());
		model.addObserver((FeedModelObserver)mockObserver2.proxy());
		
		model.refreshFeed(feed);
		
		mockObserver.verify();
		mockObserver2.verify();
	}	
	
	public void testModelNotifiesObserversOfRefreshedFeedsWhenFeedHasEntryRead() {
		int unreadEntriesCount = 1;
		Feed stubFeed = StubFixture.getStubFeedWithUnreadEntriesCount(unreadEntriesCount);
		List relatedFeeds = Arrays.asList(new Feed[]{stubFeed});
		model.addFeed(stubFeed);
		Mock mockObserver = new Mock(FeedModelObserver.class);
		mockObserver.expect("notifyFeedRefreshed", C.same(stubFeed));
		Mock mockObserver2 = new Mock(FeedModelObserver.class);
		mockObserver2.expect("notifyFeedRefreshed", C.same(stubFeed));
		model.addObserver((FeedModelObserver)mockObserver.proxy());
		model.addObserver((FeedModelObserver)mockObserver2.proxy());
		
		model.entryRead(relatedFeeds);
		
		mockObserver.verify();
		mockObserver2.verify();
	}

	public void testModelEnsuresFeedIsUpdatedWhenFeedHasEntryRead() {
		int unreadEntriesCount = 1;
		Feed stubFeed = StubFixture.getStubFeedWithUnreadEntriesCount(unreadEntriesCount);
		List relatedFeeds = Arrays.asList(new Feed[]{stubFeed});
		int score = stubFeed.getScore();
		model.addFeed(stubFeed);
		Mock mockObserver = new Mock(FeedModelObserver.class);
		mockObserver.expect("notifyFeedRefreshed", C.same(stubFeed));
		Mock mockObserver2 = new Mock(FeedModelObserver.class);
		mockObserver2.expect("notifyFeedRefreshed", C.same(stubFeed));
		model.addObserver((FeedModelObserver)mockObserver.proxy());
		model.addObserver((FeedModelObserver)mockObserver2.proxy());
		
		model.entryRead(relatedFeeds);
		
		assertEquals(unreadEntriesCount-1, stubFeed.getUnreadEntriesCount());
		assertEquals(score+Feed.ENTRY_READ_SCORE, stubFeed.getScore());
		assertTrue(stubFeed.isRead());
	}
	
	public void testModelHandlesBeingAskedToDeleteNonExistentFeed() {
		Feed feed = StubFixture.getStubFeedWithKeyAndUrl(new Long(1), "some url");
		model.addFeed(feed);
		model.select(feed);
		int selectedFeedIndex = model.getSelectedFeedIndex();
		
		model.deleteFeed(StubFixture.getStubFeedWithUrl("some non-existent feed string"));
		
		assertEquals(selectedFeedIndex, model.getSelectedFeedIndex());
	}
	
	public void testModelHandlesBeingAskedToDeleteLastRemainingFeed() {
		StubFeed feed = StubFixture.getStubFeed();
		model.addFeed(feed);
		model.select(feed);
		
		model.deleteFeed(feed);
		
		assertEquals(-1, model.getSelectedFeedIndex());
	}
	
	public void testModelDeletesLastFeedAndSelectsFeedAboveIt() {
		Feed feedA = StubFixture.getStubFeed();
		model.addFeed(feedA);
		StubFeed feedB = StubFixture.getStubFeedWithUrl("url2");
		model.addFeed(feedB);

		model.select(feedB);
		assertEquals(feedB, model.getSelectedFeed());
		
		model.deleteFeed(feedB);
		
		int selectedFeedIndex = model.getSelectedFeedIndex();
		assertEquals(0, selectedFeedIndex);
		assertEquals(feedA, model.getCurrentFeeds().get(selectedFeedIndex));
		assertEquals(feedA, model.getSelectedFeed());
	}
	
	public void testModelDeletesFeedAndSelectsFeedBelowIt() {
		Feed feedA = StubFixture.getStubFeedWithKeyAndUrl(new Long(1), "url1");
		model.addFeed(feedA);
		StubFeed feedB = StubFixture.getStubFeedWithKeyAndUrl(new Long(2), "url2");
		model.addFeed(feedB);
		StubFeed feedC = StubFixture.getStubFeedWithKeyAndUrl(new Long(2), "url3");
		model.addFeed(feedC);
		
		model.select(feedB);
		assertTrue(model.isSelected(feedB));
		
		model.deleteFeed(feedB);
		
		int selectedFeedIndex = model.getSelectedFeedIndex();
		assertEquals(1, selectedFeedIndex);
		assertTrue(model.isSelected(feedC));
		assertEquals(feedC, model.getSelectedFeed());
	}
	
	public void testModelCanReturnSelectedFeed() {
		Feed feedA = StubFixture.getStubFeed();
		model.addFeed(feedA);
		StubFeed feedB = StubFixture.getStubFeedWithUrl("url2");
		model.addFeed(feedB);
		StubFeed feedC = StubFixture.getStubFeedWithUrl("url3");
		model.addFeed(feedC);
		
		model.select(feedB);
		assertTrue(model.isSelected(feedB));
		
		assertEquals(feedB, model.getSelectedFeed());
	}

	public void testModelReturnsNullWhenNoFeedSelected() {
		Feed feedA = StubFixture.getStubFeed();
		model.addFeed(feedA);
		StubFeed feedB = StubFixture.getStubFeedWithUrl("url2");
		model.addFeed(feedB);
		StubFeed feedC = StubFixture.getStubFeedWithUrl("url3");
		model.addFeed(feedC);
		
		assertNull(model.getSelectedFeed());
	}
	
	public void testModelReturnsFalseWhenNoFeedsSelected() {
		Feed feedA = StubFixture.getStubFeed();
		assertFalse(model.isSelected(feedA));
		
		StubFeed feedB = StubFixture.getStubFeedWithUrl("url2");
		model.addFeed(feedB);
		assertFalse(model.isSelected(feedA));
	}
	
	public void testNotifiesObserversWithEmptyListWhenNoFeedsMatch() {
		String searchText = "no match";
		Feed nonMatchingFeed1 = StubFixture.getStubFeedWithTitleAndUrl("nonMatchingFeedTitle", StubFixture.TEST_URL);
		Feed nonMatchingFeed2 = StubFixture.getStubFeedWithTitleAndUrl("nonMatchingFeedTitle", StubFixture.TEST_URL2);
		model.addFeed(nonMatchingFeed1);
		model.addFeed(nonMatchingFeed2);
		Mock mockObserver = new Mock(FeedModelObserver.class);
		model.addObserver((FeedModelObserver)mockObserver.proxy());
		mockObserver.expect("notifyFeedsLoaded", C.eq(new ArrayList()));
		
		model.loadMatchingItems(searchText);
		
		mockObserver.verify();
	}
	
	public void testNotifiesObserversOfFeedsWithTextInTitle() {
		String searchText = "title";
		Feed matchingFeed = StubFixture.getStubFeedWithTitleAndUrl("title that matches", StubFixture.TEST_URL);
		Feed nonMatchingFeed = StubFixture.getStubFeedWithTitleAndUrl("something else that doesn't match", StubFixture.TEST_URL2);
		model.addFeed(matchingFeed);
		model.addFeed(nonMatchingFeed);
		List matchingFeeds = new ArrayList();
		matchingFeeds.add(matchingFeed);
		Mock mockObserver = new Mock(FeedModelObserver.class);
		model.addObserver((FeedModelObserver)mockObserver.proxy());
		mockObserver.expect("notifyFeedsLoaded", C.eq(matchingFeeds));
		
		model.loadMatchingItems(searchText);
		
		mockObserver.verify();
	}
	
	public void testNotifiesObserversOfFeedsWithTextInUrl() {
		String searchText = "url";
		Feed matchingFeed = StubFixture.getStubFeedWithTitleAndUrl("title that matches", "url");
		Feed nonMatchingFeed = StubFixture.getStubFeedWithTitleAndUrl("something else that doesn't match", "not u r l");
		model.addFeed(matchingFeed);
		model.addFeed(nonMatchingFeed);
		List matchingFeeds = new ArrayList();
		matchingFeeds.add(matchingFeed);
		Mock mockObserver = new Mock(FeedModelObserver.class);
		model.addObserver((FeedModelObserver)mockObserver.proxy());
		mockObserver.expect("notifyFeedsLoaded", C.eq(matchingFeeds));
		
		model.loadMatchingItems(searchText);
		
		mockObserver.verify();
	}
	
	public void testNotifiesObserversWithEmptyListIfFeedsHaveNullTitles() {
		String searchText = "no match";
		Feed nonMatchingFeed1 = StubFixture.getStubFeedWithTitleAndUrl(null, StubFixture.TEST_URL);
		Feed nonMatchingFeed2 = StubFixture.getStubFeedWithTitleAndUrl(null, StubFixture.TEST_URL2);
		model.addFeed(nonMatchingFeed1);
		model.addFeed(nonMatchingFeed2);
		List matchingFeeds = new ArrayList();
		Mock mockObserver = new Mock(FeedModelObserver.class);
		model.addObserver((FeedModelObserver)mockObserver.proxy());
		mockObserver.expect("notifyFeedsLoaded", C.eq(matchingFeeds));
		
		model.loadMatchingItems(searchText);
		
		mockObserver.verify();
	}
	
	public void testFindsFeedCaseInsensitively() {
		String lower = "match";
		String upper = "MATCH";
		Feed matchingFeed1 = StubFixture.getStubFeedWithTitleAndUrl("title that matches", StubFixture.TEST_URL);
		Feed matchingFeed2 = StubFixture.getStubFeedWithTitleAndUrl("title that MAtCHeS", StubFixture.TEST_URL2);
		Feed nonMatchingFeed = StubFixture.getStubFeedWithTitleAndUrl("title", StubFixture.TEST_URL_CLONE_WITH_ONE_LESS_ENTRY);
		model.addFeed(matchingFeed1);
		model.addFeed(matchingFeed2);
		model.addFeed(nonMatchingFeed);
		
		List matchingFeeds = Arrays.asList(new Feed[]{matchingFeed1, matchingFeed2});
		Mock mockObserver = new Mock(FeedModelObserver.class);
		model.addObserver((FeedModelObserver)mockObserver.proxy());
		mockObserver.expect("notifyFeedsLoaded", C.eq(matchingFeeds));
		
		model.loadMatchingItems(lower);
		model.loadMatchingItems(upper);
		
		mockObserver.verify();
	}
	
	public void testLeavesObserversAloneIfMatchingItemsHaveNotChanged() {
		String searchText = "matches";
		Feed matchingFeed = StubFixture.getStubFeedWithTitleAndUrl("title that matches", StubFixture.TEST_URL);
		model.addFeed(matchingFeed);
		List matchingFeeds = new ArrayList();
		matchingFeeds.add(matchingFeed);
		
		Mock mockObserver = new Mock(FeedModelObserver.class);
		model.addObserver((FeedModelObserver)mockObserver.proxy());
		
		model.loadMatchingItems(searchText);
		
		mockObserver.verify();
	}
	
	public void testNotifiesObserversIfMatchingItemsHaveChanged() {
		String searchText = "matches";
		Feed matchingFeed = StubFixture.getStubFeedWithTitleAndUrl("title that matches", StubFixture.TEST_URL);
		model.addFeed(matchingFeed);
		Feed nonMatchingFeed = StubFixture.getStubFeedWithTitleAndUrl("title", StubFixture.TEST_URL_CLONE_WITH_ONE_LESS_ENTRY);
		model.addFeed(nonMatchingFeed);
		List matchingFeeds = new ArrayList();
		matchingFeeds.add(matchingFeed);
		
		Mock mockObserver = new Mock(FeedModelObserver.class);
		model.addObserver((FeedModelObserver)mockObserver.proxy());
		mockObserver.expect("notifyFeedsLoaded", C.eq(matchingFeeds));
		
		model.loadMatchingItems(searchText);
		
		mockObserver.verify();
	}
	
	public void testLoadingMatchingItemsAltersCurrentFeeds() {
		String searchText = "title";
		Feed matchingFeed = StubFixture.getStubFeedWithTitleAndUrl("title that matches", StubFixture.TEST_URL);
		model.addFeed(matchingFeed);
		model.addFeed(StubFixture.getStubFeedWithTitleAndUrl("not matching", StubFixture.TEST_URL2));
		
		List matchingFeeds = new ArrayList();
		matchingFeeds.add(matchingFeed);
		Mock mockObserver = new Mock(FeedModelObserver.class);
		model.addObserver((FeedModelObserver)mockObserver.proxy());
		mockObserver.expect("notifyFeedsLoaded", C.eq(matchingFeeds));
		
		model.loadMatchingItems(searchText);
		assertEquals(matchingFeeds, model.getCurrentFeeds());
		
		mockObserver.verify();
	}
	
	public void testMatchingItemsRetainTheirOriginalOrder() {
		String searchText = "title";
		
		//in order of score ascending
		Feed nonMatchingFeed = StubFixture.getStubFeedWithKeyTitleUrlAndScore(new Long(1), "Z", StubFixture.TEST_URL_CLONE_WITH_ONE_LESS_ENTRY, 0);
		Feed feedY = StubFixture.getStubFeedWithKeyTitleUrlAndScore(new Long(2), "Y title", StubFixture.TEST_URL2, 5);
		Feed feedX = StubFixture.getStubFeedWithKeyTitleUrlAndScore(new Long(3), "X title", StubFixture.TEST_URL, 10);
		
		//in alphabetical order of title ascending
		model.addFeed(feedX);
		model.addFeed(feedY);
		model.addFeed(nonMatchingFeed);
		
		model.sort(ComparatorFactory.createReverseComparator(ComparatorFactory.getFeedScoreComparator()));
		assertEquals(Arrays.asList(new Feed[]{nonMatchingFeed, feedY, feedX}), model.getCurrentFeeds());
		
		List matchingFeeds = Arrays.asList(new Feed[]{feedY, feedX});
		Mock mockObserver = new Mock(FeedModelObserver.class);
		model.addObserver((FeedModelObserver)mockObserver.proxy());
		mockObserver.expect("notifyFeedsLoaded", C.eq(matchingFeeds));
		
		model.loadMatchingItems(searchText);
		
		mockObserver.verify();
	}

	public void testFeedModelRefreshesAllRelatedFeedsWhenEntryRead() {
		Feed feed1 = StubFixture.getStubFeedWithUrl(StubFixture.TEST_URL);
		Feed feed2 = StubFixture.getStubFeedWithUrl(StubFixture.TEST_URL2);
		List feeds = Arrays.asList(new Feed[]{feed1, feed2});
		model.appendFeeds(feeds);
		
		Mock mockObserver = new Mock(FeedModelObserver.class);
		mockObserver.expect("notifyFeedRefreshed", C.same(feed1));
		mockObserver.expect("notifyFeedRefreshed", C.same(feed2));
		model.addObserver((FeedModelObserver)mockObserver.proxy());
		
		model.entryRead(feeds);
		
		mockObserver.verify();
	}
	
	public void testSelectedFeedRemainsSelectedEvenWhenItIsFilteredOut() {
		Feed feed = StubFixture.getStubFeedWithUrl(StubFixture.TEST_URL);
		model.addFeed(feed);
		model.select(feed);
		model.loadMatchingItems("some text that doesn't match the feed");
		assertEquals(0, model.getCurrentFeeds().size());
		assertEquals(feed, model.getSelectedFeed());
	}
	
	public void testSelectedFeedIsStillSelectedWhenItIsFilteredOutAndThenFilteredBackIn() {
		Feed feed = StubFixture.getStubFeedWithUrl(StubFixture.TEST_URL);
		model.addFeed(feed);
		model.select(feed);
		model.loadMatchingItems("some text that doesn't match the feed");
		assertEquals(0, model.getCurrentFeeds().size());
		
		model.loadMatchingItems(StubFixture.TEST_URL);
		assertEquals(feed, model.getSelectedFeed());
	}
}