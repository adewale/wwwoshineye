package com.oshineye.aggrevator.store;


/**
 * @author aoshineye
 */
public class MySqlFeedStoreTest extends AbstractFeedStoreTest {
	protected EntryStore createEntryStore() {
		return StubFixture.getEntryStore();
	}

	protected FeedStore createFeedStore() {
		return StubFixture.getFeedStore();
	}
	
	public void testNewMySqlFeedStorePopulatesFeedIdentityMap() {
		FeedIdentityMap map = new FeedIdentityMap();
		
		new MySqlFeedStore(StubFixture.TEST_DATABASE_NAME, map, StubFixture.QUERY_LOADER);
		
		assertTrue(map.isPopulated());
	}
	
}
