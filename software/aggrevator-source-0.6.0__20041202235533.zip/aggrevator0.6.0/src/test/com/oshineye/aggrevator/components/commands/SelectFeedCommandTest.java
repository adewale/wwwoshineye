package com.oshineye.aggrevator.components.commands;

import java.util.ArrayList;
import java.util.List;

import junit.framework.TestCase;

import com.mockobjects.dynamic.C;
import com.mockobjects.dynamic.Mock;
import com.oshineye.aggrevator.Feed;
import com.oshineye.aggrevator.components.EntryModel;
import com.oshineye.aggrevator.components.FeedModel;
import com.oshineye.aggrevator.components.commands.Command;
import com.oshineye.aggrevator.components.commands.SelectFeedCommand;
import com.oshineye.aggrevator.store.EntryStore;
import com.oshineye.aggrevator.store.FeedStore;
import com.oshineye.aggrevator.store.StubFixture;

/**
 * @author aoshineye
 *
 */
public class SelectFeedCommandTest extends TestCase {
	public void testUpdatesEntryModelWithEntriesInSelectedFeed() {
		Feed feed = StubFixture.getStubFeed();
		
		List entriesInFeed = new ArrayList();
		Mock mockEntryStore = new Mock(EntryStore.class);
		mockEntryStore.expectAndReturn("findEntriesInFeed", C.eq(feed.getId()), entriesInFeed);
		
		Mock mockFeedStore = new Mock(FeedStore.class);
		Mock mockFeedModel = new Mock(FeedModel.class);
		mockFeedModel.expect("select", C.same(feed));
		
		Mock mockEntryModel = new Mock(EntryModel.class);
		mockEntryModel.expect("loadEntries", C.same(entriesInFeed));
		mockEntryModel.expect("selectNone");

				
		Command cmd = new SelectFeedCommand(feed, (FeedModel)mockFeedModel.proxy(), (EntryModel)mockEntryModel.proxy());
		cmd.execute((FeedStore)mockFeedStore.proxy(), (EntryStore)mockEntryStore.proxy());
		
		mockFeedModel.verify();
		mockEntryModel.verify();
		mockEntryStore.verify();
	}
}
