package com.oshineye.aggrevator;

import com.oshineye.aggrevator.Feed;
import com.oshineye.aggrevator.FeedFactory;
import com.oshineye.aggrevator.store.StubFixture;

import junit.framework.TestCase;

/**
 * @author aoshineye
 */
public class FeedFactoryTest extends TestCase {
	public void testCanCreateNewFeedFromUrl() {
		Feed feed = FeedFactory.createFeedFromUrl(StubFixture.TEST_URL);
		assertNotNull(feed);
	}

	public void testCanCreateNewFeedFromStore() {
		Feed feed = FeedFactory.createFeedFromStore(0, "url", "title", 0, 0, "etag", "lastModified");
		assertNotNull(feed);
	}
}
