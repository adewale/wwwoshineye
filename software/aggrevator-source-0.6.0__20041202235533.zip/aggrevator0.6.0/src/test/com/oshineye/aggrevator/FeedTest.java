package com.oshineye.aggrevator;

import java.util.Collections;
import java.util.Date;
import java.util.List;

import junit.framework.TestCase;

import org.apache.commons.lang.time.DateFormatUtils;

import com.mockobjects.dynamic.C;
import com.mockobjects.dynamic.Mock;
import com.oshineye.aggrevator.store.StubFixture;

/**
 * @author aoshineye
 *
 */
public class FeedTest extends TestCase {
	public void testNullIsNotAValidUrl() {
		try {
			FeedFactory.createFeedFromUrl(null);
			fail("Created feed with a null url");
		} catch (InvalidUrlException e) {
			//ignore
		}
	}
	
	public void testEmptyStringIsNotAValidUrl() {
		try {
			FeedFactory.createFeedFromUrl("");
			fail("Created feed with an empty string as the url");
		} catch (InvalidUrlException e) {
			//ignore
		}
	}
	
	public void testEffectivelyEmptyStringIsNotAValidUrl() {
		try {
			FeedFactory.createFeedFromUrl("      ");
			fail("Created feed with an empty string as the url");
		} catch (InvalidUrlException e) {
			//ignore
		}
	}
	
	public void testFeedURISyntaxGetsNormalisedAccordingToSpec() {
		//first 3 examples are taken from the specification at: http://www.25hoursaday.com/draft-obasanjo-feed-URI-scheme-02.html#rfc.section.3
		assertEquals("http://example.com/rss.xml", FeedFactory.createFeedFromUrl("feed:http://example.com/rss.xml").getUrl());
		assertEquals("https://example.com/rss.xml", FeedFactory.createFeedFromUrl("feed:https://example.com/rss.xml").getUrl());
		assertEquals("http://example.com/rss.xml", FeedFactory.createFeedFromUrl("feed://example.com/rss.xml").getUrl());
		assertEquals("http://support.journurl.com/users/admin/index.cfm?template=rss&rssuser=5D53F295-3048-424F-429C567A44CA987D", FeedFactory.createFeedFromUrl("feed:http://support.journurl.com/users/admin/index.cfm?template=rss&rssuser=5D53F295-3048-424F-429C567A44CA987D").getUrl());
	}
	
	public void testNormalisationHasNoEffectWhenFeedURISyntaxIsNotUsed() {
		String url = "http://example.com/rss.xml";
		assertEquals(url, FeedFactory.createFeedFromUrl(url).getUrl());
	}
	
	public void testUrlsAreTrimmedOfExcessWhiteSpace() {
		String url = "http://example.com/rss.xml";
		assertEquals(url, FeedFactory.createFeedFromUrl("\t" +url + " ").getUrl());
	}
	
	public void testCreatingFeedCreatesValidObject() {
		Feed feed = FeedFactory.createFeedFromStore(0, "url", "title", 0, 0, null, null);
		assertEquals("url", feed.getUrl());
		assertEquals("title", feed.getTitle());
		assertEquals(0, feed.getUnreadEntriesCount());
		assertTrue(feed.isRead());
	}
	
	public void testCreatingFeedUnescapesTitle() {
		Feed feed = FeedFactory.createFeedFromStore(0, "url", "title &amp; title", 0, 0, null, null);
		assertEquals("url", feed.getUrl());
		assertEquals("title & title", feed.getTitle());
		assertEquals(0, feed.getUnreadEntriesCount());
		assertTrue(feed.isRead());
	}
	
	public void testCreatingFeedDoesNotUnescapeTitleIfItContainsIllegalHtmlEntities() {
		String title = "title &amp; title&#x92;";
		Feed feed = FeedFactory.createFeedFromStore(0, "url", title, 0, 0, null, null);
		assertEquals(title, feed.getTitle());
	}
	
	public void testCreatingFeedCreatesValidObjectUsingSingleArgumentConstructor() {
		Feed feed = FeedFactory.createFeedFromUrl("url");
		assertEquals("url", feed.getUrl());
		assertNotNull(feed.getTitle());
		assertEquals(0, feed.getUnreadEntriesCount());
		assertTrue(feed.isRead());
	}
	
	public void testPrimaryKeyCanOnlyBeSetOnce() {
		Feed feed = FeedFactory.createFeedFromUrl("url");
		feed.setId(new Long(1));
		
		try {
			feed.setId(new Long(1));
			fail("Allowed primary key to be set more than once");
		} catch (IllegalStateException e) {
			//expected
		}
	}
	
	public void testFetchingContentsRetrievesEntries() {
		int expectedNumberOfEntries = 6;
		Feed feed = StubFixture.getStubFeed();
		List entries = feed.fetchNewEntries();
		assertNotNull(entries);
		assertEquals(expectedNumberOfEntries, entries.size());
	}

	public void testFetchingContentsRetrievesEntriesWithContent() {
		Feed feed = StubFixture.getStubFeed();
		List entries = feed.fetchNewEntries();
		Entry entry = (Entry) entries.get(0);
		
		assertEquals("WorldOS is a framework on which to build programs that work like Freenet or Gnutella -allowing distributed applications using peer-to-peer routing.", entry.getContent());
	}
	
	public void testFetchingContentsForFeedsThatUseDublinCoreDatesGetsDate() {
		Feed feed = StubFixture.getStubFeedWithUrl("/validRss20FeedWithDcDates.xml");
		List entries = feed.fetchNewEntries();
		Entry entry = (Entry) entries.get(0);
		
		assertNotNull(entry.getDate());
	}
	
	public void testFetchingContentsForFeedsWithLinkButNoGuidHasCorrectPermalink() {
		Feed feed = StubFixture.getStubFeedWithUrl("/missingGuid.xml");
		List entries = feed.fetchNewEntries();
		
		Entry entry2 = (Entry) entries.get(1);
		assertNotNull(entry2.getUrl());
	}
	
	public void testFetchingContentsForFeedsWithNoLinkOrGuidHasValue() {
		Feed feed = StubFixture.getStubFeedWithUrl("/missingGuid.xml");
		List entries = feed.fetchNewEntries();
		Entry entry = (Entry) entries.get(0);
		assertNotNull(entry.getUrl());
		assertEquals(Entry.NO_LINK, entry.getUrl());
	}

	public void testFetchesContentInsteadOfDescriptionFromFeedsUsingContentEncoded() {
		Feed feed = StubFixture.getStubFeedWithUrl("/davidcrow.ca.rdf");
		List entries = feed.fetchNewEntries();
		Entry entry = (Entry) entries.get(0);
		assertTrue(entry.getContent().length() > 150);
		assertTrue(entry.getContent().endsWith("reading other books because it will be there for a little while longer.</p>"));
	}
	
	public void testFetchingContentsForFeedsThatUsesAtomFormatGetsAllEntries() {
		Feed feed = StubFixture.getStubFeedWithUrl("/valid_atom_feed.xml");
		List entries = feed.fetchNewEntries();
		assertEquals(3, entries.size());
	}
	
	public void testFetchingContentForAtomFeedGetsContentOfEntries() {
		Feed feed = StubFixture.getStubFeedWithUrl("/blojsom-atom.xml");
		List entries = feed.fetchNewEntries();
		Entry entry = (Entry) entries.get(0);
		String content = entry.getContent();
		assertFalse("Got: " + content,"".equals(content));
	}
	
	public void testFetchesCorrectPermaLinkForBloggerAtomFeeds() {
		Feed feed = StubFixture.getStubFeedWithUrl("/uncommentedBytes.xml");
		List entries = feed.fetchNewEntries();
		Entry entry = (Entry) entries.get(0);
		assertEquals("http://uncommentedbytes.blogspot.com/2004/07/yahoo-mail-is-making-me-want-gmail.html", entry.getUrl());
	}
	
	public void testNullTitleFetchedFromFeedIsNormalisedToEmptyString() {
		Feed feed = StubFixture.getStubFeedWithUrl("/feedWithNullTitle.xml");
		feed.fetchNewEntries();
		assertNotNull("Feed's title has become null after being updated from file", feed.getTitle());
	}
	
	public void testFetchesCorrectPermaLinkFromFeedsThatUseGUID() {
		Feed feed = StubFixture.getStubFeedWithUrl("/cpurdy.xml");
		List entries = feed.fetchNewEntries();
		Entry entry = (Entry) entries.get(0);
		assertEquals("http://jroller.com/page/cpurdy/20040716#a_new_web_log", entry.getUrl());
	}
	
	public void testFetchesCorrectNumberOfEntriesFromKingsleysFeed() {
	    Feed feed = StubFixture.getStubFeedWithUrl("/kingsleysBlogBug.xml");
		List entries = feed.fetchNewEntries();
		assertEquals(8, entries.size());
	}
	
	//FIXME this can't be fixed without improving the namespaces support in the underlying JDOM parser
	//so that we can access a child element that declares it's own namespace.
	//JDOM only handles situations where the namespaces are declared on the root element.
//	public void testGetsEntryContentFromRss2FeedThatUsesContentEncodedButOnlyDeclaresTheNamespaceOnTheContentTag() {
//		Feed feed = StubFixture.getStubFeedWithUrl("/rssFeedWithContentEncoded.xml");
//		List entries = feed.fetchNewEntries();
//		Entry entry = (Entry) entries.get(1);
//		String content = entry.getContent();
//		assertTrue("Didn't retrieve content", content.length() > 0);
//	}

	public void testFetchingContentForKnownWeirdRSS20FeedGetsContentOfEntries() {
		Feed feed = StubFixture.getStubFeedWithUrl("/nslog.rss");
		List entries = feed.fetchNewEntries();
		Entry entry = (Entry) entries.get(0);
		assertFalse("".equals(entry.getContent()));
	}
	
	public void testFeedsCanBeComparedForEqualityWithNull() {
		Feed feed = FeedFactory.createFeedFromUrl(StubFixture.TEST_URL);
		assertFalse(feed.equals(null));
		assertTrue(feed.equals(feed));
	}
	
	public void testFeedsWithTheSameUrlButDifferentCaseAreConsideredEqual() {
		Feed feed = FeedFactory.createFeedFromUrl(StubFixture.TEST_URL.toLowerCase());
		Feed upperCaseFeed = FeedFactory.createFeedFromUrl(StubFixture.TEST_URL.toUpperCase());
		assertTrue(feed.equals(upperCaseFeed));
	}

	public void testFeedsAreConsideredEqualOnlyIfTheyHaveTheSameId() {
	    Long key = new Long(1);
	    String url = "some url";
        String title = "some title";
        Feed feed1 = FeedFactory.createFeedFromIdUrlAndTitle(key, url, title);
	    Feed feed2 = FeedFactory.createFeedFromIdUrlAndTitle(key, url + " modified", title + " modified");
	    assertEquals(feed1, feed2);
	    
	    Feed feed3 = FeedFactory.createFeedFromIdUrlAndTitle(new Long(2), url, title);
	    assertFalse(feed1.equals(feed3));
	}
	
	public void testFeedsNeverHaveTheSameUrlAsNull() {
	    Feed feed = FeedFactory.createFeedFromUrl(StubFixture.TEST_URL);
	    assertFalse(feed.hasSameUrl(null));
	}
	
	public void testRefreshingFeedRetrievesOnlyNewEntries() {
	    Feed feed = StubFixture.getStubFeed();
		List entries = feed.fetchNewEntries();
		
		//remove an entry that will be seen as new later on
		entries.remove(0);

		Mock mockEntryFinder = new Mock(EntryFinder.class);
		mockEntryFinder.expectAndReturn("findMatchingEntriesInFeed", C.args(C.eq(feed.getId()), C.IS_NOT_NULL), entries);
		List newEntries = feed.fetchNewEntries((EntryFinder)mockEntryFinder.proxy());
		assertNotNull(newEntries);
		assertEquals(1, newEntries.size());
		assertFalse(entries.removeAll(newEntries));
		assertFalse(Feed.NO_TITLE.equals(feed.getTitle()));
	}

	public void testRefreshingNewFeedRetrievesEntriesAndUpdatesTitle() {
		Feed feed = StubFixture.getStubFeed();
		assertTrue(feed.isRead());
		assertTrue(Feed.NO_TITLE.equals(feed.getTitle()));

		Mock mockEntryFinder = new Mock(EntryFinder.class);
		mockEntryFinder.expectAndReturn("findMatchingEntriesInFeed", C.args(C.eq(feed.getId()), C.IS_NOT_NULL), Collections.EMPTY_LIST);
		
		List newEntries = feed.fetchNewEntries((EntryFinder)mockEntryFinder.proxy());

		assertNotNull(newEntries);
		assertEquals(6, newEntries.size());
		assertFalse(feed.isRead());
		assertFalse(Feed.NO_TITLE.equals(feed.getTitle()));
	}
	
	public void testFeedHasValidTitleIfEntriesHaveBeenFetched() {
		Feed feed = StubFixture.getStubFeed();
		assertEquals(Feed.NO_TITLE, feed.getTitle());
		
		feed.fetchNewEntries();
		
		assertNotNull(feed.getTitle());
		assertEquals("WriteTheWeb", feed.getTitle());
	}
	
	public void testFeedsTitleIsNotChangedIfItIsDifferentToNoTitle() {
		String expectedTitle = "some title";
		Feed feed = StubFixture.getStubFeedWithTitle(expectedTitle);
		assertEquals(expectedTitle, feed.getTitle());
		
		feed.fetchNewEntries();
		
		assertEquals(expectedTitle, feed.getTitle());
	}
	
	public void testFetchingEntriesUpdatesUnreadEntryCountAndFeedReadStatus() {
	    Feed feed = StubFixture.getStubFeed();
	    
	    Mock mockEntryFinder = new Mock(EntryFinder.class);
		mockEntryFinder.expectAndReturn("findMatchingEntriesInFeed", C.args(C.eq(feed.getId()), C.IS_NOT_NULL), Collections.EMPTY_LIST);

		int oldUnreadEntriesCount = feed.getUnreadEntriesCount();
		List newEntries = feed.fetchNewEntries((EntryFinder)mockEntryFinder.proxy());
		assertEquals(newEntries.size() + oldUnreadEntriesCount, feed.getUnreadEntriesCount());
		assertTrue(feed.getUnreadEntriesCount() > 0);
		assertFalse(feed.isRead());
	}
	
	public void testExtractCorrectNumberOfEntriesFromFeed() {
		Feed feed = StubFixture.getStubFeed();
		List entries = feed.fetchNewEntries();
		assertEquals(6, entries.size());
	}
	
	public void testFeedConvertsToMeaningfulString() {
		Feed feed = StubFixture.getStubFeed();
		String expected = "Feed: " + StubFixture.TEST_URL;
		assertEquals(expected, feed.toString());
	}
	
	public void testIncrementReadEntryCountDecreasesUnreadEntryCount() {
		int unreadEntriesCount = 5;
		Feed feed = FeedFactory.createFeedFromStore(0, StubFixture.TEST_URL, StubFixture.FEED_TITLE, unreadEntriesCount, 0, null, null);
		feed.incrementReadEntryCount();
		assertEquals(unreadEntriesCount - 1, feed.getUnreadEntriesCount());
	}
	
	public void testWhenUnreadEntryCountReachesZeroFeedIsConsideredRead() {
		int unreadEntriesCount = 1;
		Feed feed = FeedFactory.createFeedFromStore(0, StubFixture.TEST_URL, StubFixture.FEED_TITLE, unreadEntriesCount, 0, null, null);
		feed.incrementReadEntryCount();
		assertTrue(feed.isRead());
	}
	
	public void testUnreadEntryCountCanNeverDropBelowZero() {
		int unreadEntriesCount = 1;
		Feed feed = FeedFactory.createFeedFromStore(0, StubFixture.TEST_URL, StubFixture.FEED_TITLE, unreadEntriesCount, 0, null, null);
		feed.incrementReadEntryCount();
		assertEquals(0, feed.getUnreadEntriesCount());
		
		feed.incrementReadEntryCount();
		assertEquals(0, feed.getUnreadEntriesCount());
		
		feed.update(-5, 5);
		assertEquals(0, feed.getUnreadEntriesCount());
	}
	
	public void testDerivedValuesInFeedCanBeUpdated() {
		int unreadEntriesCount = 1;
		Feed feed = FeedFactory.createFeedFromStore(0, StubFixture.TEST_URL, StubFixture.FEED_TITLE, unreadEntriesCount, 0, null, null);
		
		int newUnreadEntriesCount = 15;
		int newScore = 9;
		feed.update(newUnreadEntriesCount, newScore);
		
		assertEquals(newUnreadEntriesCount, feed.getUnreadEntriesCount());
		assertEquals(newScore, feed.getScore());
	}
	
	public void testIncrementingFeedScore() {
		int unreadEntriesCount = 1;
		Feed feed = FeedFactory.createFeedFromStore(0, StubFixture.TEST_URL, StubFixture.FEED_TITLE, unreadEntriesCount, 0, null, null);
		assertEquals(0, feed.getScore());
		
		feed.incrementScore();
		assertEquals(0 + Feed.SCORE_UNITS, feed.getScore());
		
		feed.incrementScore();
		assertEquals(0 + (Feed.SCORE_UNITS * 2), feed.getScore());
	}
	
	public void testDecrementingFeedScore() {
		int unreadEntriesCount = 1;
		Feed feed = FeedFactory.createFeedFromStore(0, StubFixture.TEST_URL, StubFixture.FEED_TITLE, unreadEntriesCount, 0, null, null);
		assertEquals(0, feed.getScore());
		
		feed.decrementScore();
		assertEquals(0 - Feed.SCORE_UNITS, feed.getScore());
		
		feed.decrementScore();
		assertEquals(0 - (Feed.SCORE_UNITS * 2), feed.getScore());
	}
	
	public void testConcurrentRefreshesAreNotPermitted() {
		int unreadEntriesCount = 1;
		Feed feed = FeedFactory.createFeedFromStore(0, StubFixture.TEST_URL, StubFixture.FEED_TITLE, unreadEntriesCount, 0, null, null);
		try {
			feed.setRefreshStarted();
			feed.setRefreshStarted();
			fail("Permitted multiple refreshes to be started concurrently");
		} catch (RefreshInProgressException e) {
			//expected
		}
	}
	
	public void testSequentialRefreshesArePermitted() throws Exception {
		int unreadEntriesCount = 1;
		Feed feed = FeedFactory.createFeedFromStore(0, StubFixture.TEST_URL, StubFixture.FEED_TITLE, unreadEntriesCount, 0, null, null);
		
		assertFalse(feed.isRefreshing());
		feed.setRefreshStarted();
		assertTrue(feed.isRefreshing());
		feed.setRefreshFinished();
		assertFalse(feed.isRefreshing());
		
		assertFalse(feed.isRefreshing());
		feed.setRefreshStarted();
		assertTrue(feed.isRefreshing());
		feed.setRefreshFinished();
		assertFalse(feed.isRefreshing());
	}
	
	public void testMarkingFeedReadResetsUnreadEntriesCount() {
		int unreadEntriesCount = 1;
		Feed feed = FeedFactory.createFeedFromStore(0, StubFixture.TEST_URL, StubFixture.FEED_TITLE, unreadEntriesCount, 0, null, null);
		feed.markRead();
		
		assertEquals(0, feed.getUnreadEntriesCount());
	}
	
	public void testFeedFormatsLastModifiedDateToShortForm() {
		Date date = new Date();
		String lastModifiedDate = DateFormatUtils.SMTP_DATETIME_FORMAT.format(date);
		Feed feed = FeedFactory.createFeedFromStore(0, StubFixture.TEST_URL, StubFixture.FEED_TITLE, 0, 0, null, lastModifiedDate);
		String dateText = feed.getFormattedDate();
		assertEquals(DateFormatUtils.format(date, Configuration.DATE_FORMAT), dateText);
	}
	
	public void testFeedReturnsNullIfFormattedDateUnavailable() {
		Feed feed = FeedFactory.createFeedFromStore(0, StubFixture.TEST_URL, StubFixture.FEED_TITLE, 01, 0, null, null);
		assertNull(feed.getFormattedDate());
	}
	
	public void testFeedReturnsNullIfLastModifiedDateIsInvalid() {
		String invalid = "invalid last modified date";
		Feed feed = FeedFactory.createFeedFromStore(0, StubFixture.TEST_URL, StubFixture.FEED_TITLE, 01, 0, null, invalid);
		assertEquals(invalid, feed.getLastModified());
		assertNull(feed.getFormattedDate());
	}
}
