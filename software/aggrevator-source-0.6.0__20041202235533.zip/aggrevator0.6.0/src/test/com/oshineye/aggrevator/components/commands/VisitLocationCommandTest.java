package com.oshineye.aggrevator.components.commands;

import java.util.ArrayList;
import java.util.List;

import junit.framework.TestCase;

import com.mockobjects.dynamic.C;
import com.mockobjects.dynamic.Mock;
import com.oshineye.aggrevator.components.EntryModel;
import com.oshineye.aggrevator.components.FeedModel;
import com.oshineye.aggrevator.store.EntryStore;
import com.oshineye.aggrevator.store.FeedStore;

/**
 * @author aoshineye
 */
public class VisitLocationCommandTest extends TestCase {
	
	public void testUpdatesEntryStoreAndModelsWithVisitedLocation() {
		String location = "Some location";
		List relatedFeeds = new ArrayList();
		Mock mockFeedModel = new Mock(FeedModel.class);
		mockFeedModel.expect("entryRead", C.same(relatedFeeds));
		Mock mockEntryModel = new Mock(EntryModel.class);
		mockEntryModel.expect("markRead", location);
		Mock mockFeedStore = new Mock(FeedStore.class);
		Mock mockEntryStore = new Mock(EntryStore.class);
		mockEntryStore.expectAndReturn("markRead", location, true);
		mockEntryStore.expectAndReturn("getRelatedFeeds", C.eq(location), relatedFeeds);
		
		Command cmd = new VisitLocationCommand((FeedModel)mockFeedModel.proxy(), (EntryModel)mockEntryModel.proxy(), location);
		cmd.execute((FeedStore)mockFeedStore.proxy(), (EntryStore)mockEntryStore.proxy());
		
		mockFeedModel.verify();
		mockEntryModel.verify();
		mockEntryStore.verify();
	}
	
	public void testLocationThatIsAlreadyReadDoesNotUpdateFeedModelOrEntryModel() {
		String location = "Some location";
		Mock mockFeedModel = new Mock(FeedModel.class);
		Mock mockEntryModel = new Mock(EntryModel.class);
		Mock mockFeedStore = new Mock(FeedStore.class);
		Mock mockEntryStore = new Mock(EntryStore.class);
		mockEntryStore.expectAndReturn("markRead", location, false);
		mockEntryStore.expectAndReturn("markRead", location, false);
		
		Command cmd = new VisitLocationCommand((FeedModel)mockFeedModel.proxy(), (EntryModel)mockEntryModel.proxy(), location);
		cmd.execute((FeedStore)mockFeedStore.proxy(), (EntryStore)mockEntryStore.proxy());
		
		Command cmd2 = new VisitLocationCommand((FeedModel)mockFeedModel.proxy(), (EntryModel)mockEntryModel.proxy(), location);
		cmd2.execute((FeedStore)mockFeedStore.proxy(), (EntryStore)mockEntryStore.proxy());
		
		mockFeedModel.verify();
		mockEntryModel.verify();
		mockEntryStore.verify();
	}
}
