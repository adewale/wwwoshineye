package com.oshineye.aggrevator.store;

import java.util.Arrays;
import java.util.List;

import junit.framework.TestCase;

import com.oshineye.aggrevator.Feed;
import com.oshineye.aggrevator.store.FeedIdentityMap;

/**
 * @author aoshineye
 */
public class FeedIdentityMapTest extends TestCase {
	public void testMapReturnsEmptyListWhenEmpty() {
		FeedIdentityMap map = new FeedIdentityMap();
		List ids = Arrays.asList(new Object[]{null});
		
		assertEquals(0, map.findByIds(ids).size());
	}
	
	public void testMapDoesNotReturnNullWhenGivenMissingId() {
		FeedIdentityMap map = new FeedIdentityMap();
		List ids = Arrays.asList(new Object[]{new Long(-1)});
		
		assertEquals(0, map.findByIds(ids).size());
	}
	
	public void testAddedFeedsCanBeFoundById() {
		FeedIdentityMap map = new FeedIdentityMap();
		Feed feed = StubFixture.getStubFeed();
		List feeds = Arrays.asList(new Feed[]{feed});
		map.addAll(feeds);
		List ids = Arrays.asList(new Object[]{feed.getId()});
		List foundFeeds = map.findByIds(ids);
		
		assertEquals(1, foundFeeds.size());
		assertSame(feed, foundFeeds.get(0));
	}
	
	public void testMapCanDetectIfAFeedWithTheSameUrlExists() {
		FeedIdentityMap map = new FeedIdentityMap();
		Feed feed1 = StubFixture.getStubFeedWithUrl("url1");
		Feed feed2 = StubFixture.getStubFeedWithUrl("url2");
		List feeds = Arrays.asList(new Feed[]{feed1, feed2});
		map.addAll(feeds);
		
		assertTrue(map.feedExists("url1"));
		assertFalse(map.feedExists("not__url1"));
		assertTrue(map.feedExists("url2"));
	}
	
	public void testMapCanCaseInsensitivelyDetectIfAFeedWithTheSameUrlExists() {
		FeedIdentityMap map = new FeedIdentityMap();
		Feed feed1 = StubFixture.getStubFeedWithUrl("url1");
		Feed feed2 = StubFixture.getStubFeedWithUrl("url2");
		List feeds = Arrays.asList(new Feed[]{feed1, feed2});
		map.addAll(feeds);
		
		assertTrue(map.feedExists("url1"));
		assertTrue(map.feedExists("URL1"));
		assertTrue(map.feedExists("uRl1"));
		assertTrue(map.feedExists("UrL1"));
		assertTrue(map.feedExists("url2"));
	}
}
