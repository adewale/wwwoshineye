package com.oshineye.aggrevator;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.Reader;

public class StubFeed extends FeedImpl {
	private static final String TEST_DATA_FOLDER = "testData";

    public StubFeed(Long id, String title, String url, int score) {
    	super(id, url, title, 0, score, "etag", "lastModified");
	}
	
	public StubFeed(String url) {
		super(url, Feed.NO_TITLE, 0, 0, "etag", "lastModified");
	}
	
	public StubFeed(Long id, String url) {
	    super(id, url, Feed.NO_TITLE, 0, 0, "etag", "lastModified");
    }
	
    public StubFeed(Long id, String title, String url) {
        super(id, url, title, 0, 0, "etag", "lastModified");
    }
	
	public StubFeed(String url, int unreadEntriesCount, int score) {
		super(url, "title", unreadEntriesCount, score, null, null);
	}

	public StubFeed(String url, String title, int unreadEntriesCount, int score) {
		super(url, title, unreadEntriesCount, score, null, null);
	}

	public StubFeed(Feed feed) {
		super(feed.getUrl(), feed.getTitle(), feed.getUnreadEntriesCount(), feed.getScore(), feed.getEtag(), feed.getLastModified());
	}

	public StubFeed(Long id, String title, String url, String etag, String lastModified) {
		super(id, url, title, 0, 0, etag, lastModified);
	}

	protected Reader getReader() throws FileNotFoundException {
		String fileName = convertToLocalFileName();
		return new FileReader(TEST_DATA_FOLDER + fileName);
	}

	private String convertToLocalFileName() {
		int lastSlashPosition = this.getUrl().lastIndexOf("/");
		String fileName = this.getUrl().substring(lastSlashPosition);
		return fileName;
	}
	
	public boolean hasChanged() {
		return true;
	}
}