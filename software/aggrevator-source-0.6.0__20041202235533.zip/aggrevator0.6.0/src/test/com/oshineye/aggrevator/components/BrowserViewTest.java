package com.oshineye.aggrevator.components;

import org.eclipse.swt.browser.WindowEvent;
import org.jmock.Mock;
import org.jmock.MockObjectTestCase;

/**
 * @author aoshineye
 *
 */
public class BrowserViewTest extends MockObjectTestCase {
	public void testBrowserViewRegistersAsObserverOnEntryModel() {
		Mock mockBrowserModel = new Mock(BrowserModel.class);
		mockBrowserModel.expects(once()).method("addObserver").withAnyArguments();
		Mock mockBrowserController = new Mock(BrowserController.class);
		new BrowserViewImpl((BrowserModel) mockBrowserModel.proxy(), (BrowserController)mockBrowserController.proxy());
		
		mockBrowserModel.verify();
	}
	
	public void testBrowserControllerIsInvokedWhenNewWindowOpened() {
		final String locationToVisit = "location visited";
		Mock mockBrowserModel = new Mock(BrowserModel.class);
		mockBrowserModel.stubs().method("addObserver").withAnyArguments();
		Mock mockBrowserController = new Mock(BrowserController.class);
		mockBrowserController.expects(once()).method("handleLocationVisited").with(eq(locationToVisit));
				
		BrowserViewImpl view = new BrowserViewImpl((BrowserModel) mockBrowserModel.proxy(), (BrowserController)mockBrowserController.proxy()) {
			protected String getEventUrl(WindowEvent event) {
				return locationToVisit;
			}
		};
		view.open(null);
		mockBrowserController.verify();
	}
}
