package com.oshineye.aggrevator.components.commands;

import org.jmock.Mock;
import org.jmock.MockObjectTestCase;

import com.oshineye.aggrevator.Feed;
import com.oshineye.aggrevator.components.EntryModel;
import com.oshineye.aggrevator.components.FeedModel;
import com.oshineye.aggrevator.store.EntryStore;
import com.oshineye.aggrevator.store.FeedStore;
import com.oshineye.aggrevator.store.StubFixture;

/**
 * @author aoshineye
 *
 */
public class DeleteFeedCommandTest extends MockObjectTestCase {
	private Feed feed;
	private Mock mockFeedModel;
	private Mock mockEntryModel;
	private DeleteFeedCommand command;
	private Mock mockFeedStore;
	private Mock mockEntryStore;

	public void setUp() {
		setupExpectations();
	}
	
	private void setupExpectations() {
		feed = StubFixture.getStubFeed();
		mockFeedModel = new Mock(FeedModel.class);
		mockFeedModel.expects(once()).method("deleteFeed").with(same(feed));
		mockEntryModel = new Mock(EntryModel.class);
		mockEntryModel.expects(once()).method("deleteEntriesFromFeed").with(same(feed));
		Mock mockNextCommand = new Mock(Command.class);
		mockNextCommand.expects(once()).method("execute").withAnyArguments();
		command = new DeleteFeedCommand(feed, (FeedModel)mockFeedModel.proxy(),
			(EntryModel)mockEntryModel.proxy());
		
		mockFeedStore = new Mock(FeedStore.class);
		mockFeedStore.expects(once()).with(same(feed));
		mockEntryStore = new Mock(EntryStore.class);
		mockEntryStore.expects(once()).method("delete").with(same(feed));
		command.execute((FeedStore)mockFeedStore.proxy(), (EntryStore)mockEntryStore.proxy());
	}
	
	public void testDeletingFeedFromViewDeletesItFromFeedStore() {
		mockFeedStore.verify();
	}

	public void testDeletingFeedFromViewDeletesAllItsEntriesFromEntryStore() {
		mockEntryStore.verify();
	}
	
	public void testDeletingFeedFromViewUpdatesFeedModel() {
		mockFeedModel.verify();
	}
	
	public void testDeletingFeedFromViewUpdatesEntryModel() {
		mockEntryModel.verify();
	}
}
