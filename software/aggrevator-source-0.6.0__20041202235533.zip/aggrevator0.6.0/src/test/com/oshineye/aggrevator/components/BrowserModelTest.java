package com.oshineye.aggrevator.components;

import org.jmock.Mock;
import org.jmock.MockObjectTestCase;

import com.oshineye.aggrevator.Entry;
import com.oshineye.aggrevator.components.BrowserModel;
import com.oshineye.aggrevator.components.BrowserModelImpl;
import com.oshineye.aggrevator.components.BrowserObserver;
import com.oshineye.aggrevator.store.StubFixture;

/**
 * @author aoshineye
 *
 */
public class BrowserModelTest extends MockObjectTestCase {
	public void testModelNotifiesObserversOfLoadedEntry() {
		Entry entry = StubFixture.getStubEntry();
		Mock mockObserver = new Mock(BrowserObserver.class);
		mockObserver.expects(once()).method("notifyEntryLoaded").with(same(entry));
		Mock mockObserver2 = new Mock(BrowserObserver.class);
		mockObserver2.expects(once()).method("notifyEntryLoaded").with(same(entry));
		
		BrowserModel model = new BrowserModelImpl();
		model.addObserver((BrowserObserver) mockObserver.proxy());
		model.addObserver((BrowserObserver) mockObserver2.proxy());
		
		model.loadEntry(entry);
		
		mockObserver.verify();
		mockObserver2.verify();
	}
}
