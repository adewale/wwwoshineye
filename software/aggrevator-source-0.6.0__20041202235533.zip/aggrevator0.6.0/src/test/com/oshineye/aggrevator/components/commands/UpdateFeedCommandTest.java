package com.oshineye.aggrevator.components.commands;

import org.jmock.Mock;
import org.jmock.MockObjectTestCase;

import com.oshineye.aggrevator.Feed;
import com.oshineye.aggrevator.components.FeedModel;
import com.oshineye.aggrevator.store.FeedStore;

/**
 * @author aoshineye
 *
 */
public class UpdateFeedCommandTest extends MockObjectTestCase {
	public void testUpdatesTitleOfFeed() {
		String newTitle = "new title";
		Mock mockFeed = new Mock(Feed.class);
		mockFeed.expects(once()).method("setTitle").with(eq(newTitle));
		mockFeed.stubs().method("setUrl").withAnyArguments();
		Mock mockFeedModel = new Mock(FeedModel.class);
		mockFeedModel.stubs().method("refreshFeed").withAnyArguments();
		
		Mock mockFeedStore = new Mock(FeedStore.class);
		mockFeedStore.stubs().method("update").withAnyArguments();
		
		Command cmd = new UpdateFeedCommand((FeedModel)mockFeedModel.proxy(), (Feed)mockFeed.proxy(), newTitle, null);
		cmd.execute((FeedStore)mockFeedStore.proxy(), null);
		
		mockFeed.verify();
	}
	
	public void testUpdatesUrlOfFeed() {
		String newUrl = "new url";
		Mock mockFeed = new Mock(Feed.class);
		mockFeed.stubs().method("setTitle").withAnyArguments();
		mockFeed.expects(once()).method("setUrl").with(eq(newUrl));
		Mock mockFeedModel = new Mock(FeedModel.class);
		mockFeedModel.stubs().method("refreshFeed").withAnyArguments();
		
		Mock mockFeedStore = new Mock(FeedStore.class);
		mockFeedStore.stubs().method("update").withAnyArguments();
		
		Command cmd = new UpdateFeedCommand((FeedModel)mockFeedModel.proxy(), (Feed)mockFeed.proxy(), null, newUrl);
		cmd.execute((FeedStore)mockFeedStore.proxy(), null);
		
		mockFeed.verify();
	}
	
	public void testRefreshesSelectedFeedInFeedModel() {
		Mock mockFeed = new Mock(Feed.class);
		mockFeed.stubs().method("setTitle").withAnyArguments();
		mockFeed.stubs().method("setUrl").withAnyArguments();
		Feed feed = (Feed) mockFeed.proxy();
		Mock mockFeedModel = new Mock(FeedModel.class);
		mockFeedModel.expects(once()).method("refreshFeed").with(eq(feed));
		
		Mock mockFeedStore = new Mock(FeedStore.class);
		mockFeedStore.stubs().method("update").withAnyArguments();
		
		Command cmd = new UpdateFeedCommand((FeedModel)mockFeedModel.proxy(), (Feed)mockFeed.proxy(), null, null);
		cmd.execute((FeedStore)mockFeedStore.proxy(), null);
		
		mockFeedModel.verify();
	}
	
	public void testUpdatesFeedStoreWithSelectedFeed() {
		Mock mockFeed = new Mock(Feed.class);
		mockFeed.stubs().method("setTitle").withAnyArguments();
		mockFeed.stubs().method("setUrl").withAnyArguments();
		Feed feed = (Feed) mockFeed.proxy();
		Mock mockFeedModel = new Mock(FeedModel.class);
		mockFeedModel.stubs().method("refreshFeed").with(eq(feed));
		
		Mock mockFeedStore = new Mock(FeedStore.class);
		mockFeedStore.expects(once()).method("update").with(eq(feed));
		
		Command cmd = new UpdateFeedCommand((FeedModel)mockFeedModel.proxy(), (Feed)mockFeed.proxy(), null, null);
		cmd.execute((FeedStore)mockFeedStore.proxy(), null);
		
		mockFeedStore.verify();
	}
}
