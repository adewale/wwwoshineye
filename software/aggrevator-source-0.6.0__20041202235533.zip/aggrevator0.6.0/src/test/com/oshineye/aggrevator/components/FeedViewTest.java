package com.oshineye.aggrevator.components;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import junit.framework.TestCase;

import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.TableItem;

import com.mockobjects.dynamic.C;
import com.mockobjects.dynamic.Mock;
import com.oshineye.aggrevator.Feed;
import com.oshineye.aggrevator.components.Block;
import com.oshineye.aggrevator.components.EntryModel;
import com.oshineye.aggrevator.components.EntryModelImpl;
import com.oshineye.aggrevator.components.FeedModel;
import com.oshineye.aggrevator.components.FeedModelImpl;
import com.oshineye.aggrevator.components.FeedView;
import com.oshineye.aggrevator.components.FeedViewController;
import com.oshineye.aggrevator.components.FeedViewControllerImpl;
import com.oshineye.aggrevator.components.FeedViewImpl;
import com.oshineye.aggrevator.store.StubFixture;


public class FeedViewTest extends TestCase {
	public void testViewRegistersAsObserverOnModel() {
		Mock mockModel = new Mock(FeedModel.class);
		mockModel.expect("addObserver", C.IS_NOT_NULL);
		new FeedViewImpl((FeedModel) mockModel.proxy());
		
		mockModel.verify();
	}
	
	public void testFeedsLoadedEventPopulatesViewsTable() {
		final List feeds = new ArrayList();
		feeds.add(StubFixture.getStubFeed());
		Mock mockModel = new Mock(FeedModel.class);
		mockModel.expect("addObserver", C.IS_NOT_NULL);
		mockModel.expectAndReturn("getSelectedFeedIndex", -1);
		
		final MyApplicationWindow window = new MyApplicationWindow((FeedModel) mockModel.proxy());
		
		window.execute(new Block() {
			public void execute() {
				FeedView view = window.getView();
				view.notifyFeedsLoaded(feeds);
				TableItem[] items = view.getItems();

				assertEquals(feeds.size(), items.length);
			}
		});
		
		mockModel.verify();
	}

	public void testFeedsLoadedEventPopulatesViewsTableByReplacingAllExistingItems() {
		final List firstFeeds = new ArrayList();
		firstFeeds.add(StubFixture.getStubFeed());
		
		final List secondFeeds = new ArrayList();
		secondFeeds.add(StubFixture.getStubFeedWithUrl(StubFixture.TEST_URL2));
		
		Mock mockModel = new Mock(FeedModel.class);
		mockModel.expect("addObserver", C.IS_NOT_NULL);
		mockModel.expectAndReturn("getSelectedFeedIndex", -1);
		mockModel.expectAndReturn("getSelectedFeedIndex", -1);
		
		final MyApplicationWindow window = new MyApplicationWindow((FeedModel) mockModel.proxy());
		
		window.execute(new Block() {
			public void execute() {
				FeedView view = window.getView();
				view.notifyFeedsLoaded(firstFeeds);
				view.notifyFeedsLoaded(secondFeeds);
				TableItem[] items = view.getItems();

				assertEquals(1, items.length);
			}
		});
		
		mockModel.verify();
	}
	
	public void testFeedAddedEventAddsNewItemToViewsTable() {
		List feeds = new ArrayList();
		feeds.add(StubFixture.getStubFeed());
		Mock mockFeedModel = new Mock(FeedModel.class);
		mockFeedModel.expect("addObserver", C.IS_NOT_NULL);
		mockFeedModel.expectAndReturn("getCurrentFeeds", feeds);
		final MyApplicationWindow window = new MyApplicationWindow((FeedModel) mockFeedModel.proxy());
		
		window.execute(new Block() {
			public void execute() {
				FeedView view = window.getView();
				TableItem[] items = view.getItems();
				
				view.notifyFeedAdded(StubFixture.getStubFeed());

				TableItem[] newItems = view.getItems();
				assertEquals(items.length + 1, newItems.length);
				assertTrue(Arrays.asList(newItems).containsAll(Arrays.asList(items)));
			}
		});
		
		mockFeedModel.verify();
	}

	public void testFeedDeletedEventRemovesItemFromViewsTable() {
		List feeds = new ArrayList();
		feeds.add(StubFixture.getStubFeed());
		Mock mockFeedModel = new Mock(FeedModel.class);
		mockFeedModel.expect("addObserver", C.IS_NOT_NULL);
		mockFeedModel.expectAndReturn("getCurrentFeeds", feeds);
		mockFeedModel.expect("deleteFeed", C.IS_NOT_NULL);
		mockFeedModel.expectAndReturn("getCurrentFeeds", new ArrayList());
		mockFeedModel.expectAndReturn("getSelectedFeedIndex", 0);
		final MyApplicationWindow window = new MyApplicationWindow((FeedModel) mockFeedModel.proxy());
		
		window.execute(new Block() {
			public void execute() {
				FeedView view = window.getView();
				FeedModel model = window.getModel();
				view.notifyFeedAdded(StubFixture.getStubFeed());
				TableItem[] items = view.getItems();
				assertEquals(1, items.length);
				
				Feed feed = StubFixture.getStubFeed();
				model.deleteFeed(feed);
				view.notifyFeedDeleted(feed, 0);

				TableItem[] newItems = view.getItems();
				assertEquals(items.length - 1, newItems.length);
				assertFalse(Arrays.asList(newItems).containsAll(Arrays.asList(items)));
				for (int index = 0; index < newItems.length; index++) {
					TableItem item = newItems[index];
					assertFalse(feed.equals(item.getData()));
				}
			}
		});
		
		mockFeedModel.verify();
	}

	private static class MyApplicationWindow extends StubApplicationWindow {
		private FeedView view;
		private FeedModel model;
		
		protected Control createContents(Composite parent) {
			EntryModel entryModel = new EntryModelImpl();
			FeedModel feedModel = new FeedModelImpl(new ArrayList());
			FeedViewController feedViewController = new FeedViewControllerImpl(feedModel, entryModel);
			view = new FeedViewImpl(model, parent, feedViewController);
			return null;										
		}

		public FeedModel getModel() {
			return model;
		}

		public FeedView getView() {
			return view;
		}

		public MyApplicationWindow(FeedModel model) {
			this.model = model;
		}
	}

}
