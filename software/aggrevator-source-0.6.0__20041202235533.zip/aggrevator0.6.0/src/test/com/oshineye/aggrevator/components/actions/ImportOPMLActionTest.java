package com.oshineye.aggrevator.components.actions;

import org.jmock.Mock;
import org.jmock.MockObjectTestCase;

import com.oshineye.aggrevator.components.FeedModel;
import com.oshineye.aggrevator.components.OPMLImporter;
import com.oshineye.aggrevator.components.StatusRecorder;
import com.oshineye.aggrevator.util.Summariser;

/**
 * @author aoshineye
 *  
 */
public class ImportOPMLActionTest extends MockObjectTestCase {
	public void testActionImportsFeeds() {
		Mock mockFeedModel = new Mock(FeedModel.class);
		mockFeedModel.expects(once()).method("appendFeeds").withAnyArguments();
		final String expectedFileToImport = "someFileToImport";
		final Mock mockImporter = new Mock(OPMLImporter.class);
		mockImporter.stubs().method("importFeeds").withNoArguments();
		Mock mockStatusRecorder = new Mock(StatusRecorder.class);
		mockStatusRecorder.stubs().method("setStatus").withAnyArguments();
		
		ImportOPMLAction action = new ImportOPMLAction(null, null, (FeedModel) mockFeedModel.proxy(), (StatusRecorder)mockStatusRecorder.proxy()) {
			protected String getFileToImport() {
				return expectedFileToImport;
			}
			protected OPMLImporter getSubscriptionSet(String fileToImport, Summariser summariser) {
				assertEquals(expectedFileToImport, fileToImport);
				return (OPMLImporter)mockImporter.proxy();
			}
		};
		action.run();
		
		mockFeedModel.verify();
	}
	
	public void testActionDoesNotImportFeedsIfUserCancelsImport() {
		final Mock mockImporter = new Mock(OPMLImporter.class);
		Mock mockStatusRecorder = new Mock(StatusRecorder.class);
		mockStatusRecorder.stubs().method("setStatus").withAnyArguments();
		
		ImportOPMLAction action = new ImportOPMLAction(null, null, null, (StatusRecorder)mockStatusRecorder.proxy()) {
			protected String getFileToImport() {
				return null;
			}
			protected OPMLImporter getSubscriptionSet(String fileToImport, Summariser summariser) {
				return (OPMLImporter)mockImporter.proxy();
			}
		};
		action.run();
		
		mockImporter.verify();
	}
	
	public void testActionUpdatesFeedModelIfFeedsWereAddedToStore() {
		Mock mockFeedModel = new Mock(FeedModel.class);
		mockFeedModel.expects(once()).method("appendFeeds").withAnyArguments();
		
		final String expectedFileToImport = "someFileToImport";
		final Mock mockImporter = new Mock(OPMLImporter.class);
		mockImporter.stubs().method("importFeeds");
		Mock mockStatusRecorder = new Mock(StatusRecorder.class);
		mockStatusRecorder.stubs().method("setStatus").withAnyArguments();
		
		ImportOPMLAction action = new ImportOPMLAction(null, null, (FeedModel) mockFeedModel.proxy(), (StatusRecorder)mockStatusRecorder.proxy()) {
			protected String getFileToImport() {
				return expectedFileToImport;
			}
			protected OPMLImporter getSubscriptionSet(String fileToImport, Summariser summariser) {
				assertEquals(expectedFileToImport, fileToImport);
				return (OPMLImporter)mockImporter.proxy();
			}
		};
		action.run();
		
		mockFeedModel.verify();
	}
}