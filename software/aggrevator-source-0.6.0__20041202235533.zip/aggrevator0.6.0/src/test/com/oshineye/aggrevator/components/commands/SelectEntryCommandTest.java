package com.oshineye.aggrevator.components.commands;

import java.util.ArrayList;
import java.util.List;

import org.jmock.Mock;
import org.jmock.MockObjectTestCase;

import com.oshineye.aggrevator.Entry;
import com.oshineye.aggrevator.Feed;
import com.oshineye.aggrevator.components.BrowserModel;
import com.oshineye.aggrevator.components.EntryModel;
import com.oshineye.aggrevator.components.FeedModel;
import com.oshineye.aggrevator.store.EntryStore;
import com.oshineye.aggrevator.store.FeedStore;
import com.oshineye.aggrevator.store.StubFixture;

/**
 * @author aoshineye
 *
 */
public class SelectEntryCommandTest extends MockObjectTestCase {
	public void testUpdatesBrowserModelWithSelectedEntry() {
		Entry stubEntry = StubFixture.getStubEntry();
		Mock mockEntryStore = mock(EntryStore.class);
		Mock mockFeedStore = mock(FeedStore.class);
		Mock mockFeedModel = mock(FeedModel.class);
		Mock mockEntryModel = mock(EntryModel.class);
		Mock mockBrowserModel =  mock(BrowserModel.class);
		List relatedFeeds = new ArrayList();
		
		Command cmd = new SelectEntryCommand(stubEntry, (FeedModel)mockFeedModel.proxy(),
			(EntryModel)mockEntryModel.proxy(), (BrowserModel)mockBrowserModel.proxy());
		mockEntryStore.stubs().method("markRead").with(NOT_NULL);
		mockEntryStore.stubs().method("getRelatedFeeds").with(eq(stubEntry.getUrl()))
			.will(returnValue(relatedFeeds));
		mockFeedModel.stubs().method("entryRead").with(eq(relatedFeeds));
		mockEntryModel.stubs().method("select").with(same(stubEntry));
		mockEntryModel.stubs().method("markRead").with(eq(stubEntry.getUrl()));
		mockBrowserModel.expects(once()).method("loadEntry").with(same(stubEntry));
		
		cmd.execute((FeedStore)mockFeedStore.proxy(), (EntryStore)mockEntryStore.proxy());
		mockBrowserModel.verify();
	}

	public void testMarksSelectedEntryAsReadInEntryStore() {
		Entry stubEntry = StubFixture.getStubEntry();
		Mock mockEntryStore = new Mock(EntryStore.class);
		Mock mockFeedStore = new Mock(FeedStore.class);
		Mock mockFeedModel = new Mock(FeedModel.class);
		Mock mockEntryModel = new Mock(EntryModel.class);
		Mock mockBrowserModel = new Mock(BrowserModel.class);
		
		Command cmd = new SelectEntryCommand(stubEntry, (FeedModel)mockFeedModel.proxy(),
				(EntryModel)mockEntryModel.proxy(), (BrowserModel)mockBrowserModel.proxy());
		mockEntryStore.expects(once()).method("markRead").with(same(stubEntry));
		mockEntryStore.expects(once()).method("getRelatedFeeds").with(eq(stubEntry.getUrl()))
			.will(returnValue(new ArrayList()));
		mockFeedModel.stubs().method("entryRead");
		mockEntryModel.stubs().method("select").with(same(stubEntry));
		mockEntryModel.stubs().method("markRead").with(eq(stubEntry.getUrl()));
		mockBrowserModel.stubs().method("loadEntry").with(same(stubEntry));

		cmd.execute((FeedStore)mockFeedStore.proxy(), (EntryStore)mockEntryStore.proxy());
		mockEntryStore.verify();
	}

	public void testMarksSelectedEntryAsReadInFeedThatOwnsIt() {
		int unreadEntriesCount = 1;
		Feed feed = StubFixture.getStubFeedWithUnreadEntriesCount(unreadEntriesCount);
		List expectedRelatedFeeds = new ArrayList();
		expectedRelatedFeeds.add(feed);
		
		Entry stubEntry = StubFixture.getStubEntry(feed);
		Mock mockEntryStore = mock(EntryStore.class);
		Mock mockFeedStore = new Mock(FeedStore.class);
		Mock mockFeedModel = new Mock(FeedModel.class);
		Mock mockEntryModel = new Mock(EntryModel.class);
		Mock mockBrowserModel = new Mock(BrowserModel.class);
		
		Command cmd = new SelectEntryCommand(stubEntry, (FeedModel)mockFeedModel.proxy(),
				(EntryModel)mockEntryModel.proxy(), (BrowserModel)mockBrowserModel.proxy());
		mockEntryStore.expects(once()).method("markRead").with(same(stubEntry));
		mockEntryStore.expects(once()).method("getRelatedFeeds").with(eq(stubEntry.getUrl()))
			.will(returnValue(expectedRelatedFeeds));
		mockFeedModel.expects(once()).method("entryRead").with(eq(expectedRelatedFeeds));
		mockEntryModel.stubs().method("select").with(same(stubEntry));
		mockEntryModel.stubs().method("markRead").with(eq(stubEntry.getUrl()));
		mockBrowserModel.stubs().method("loadEntry").with(same(stubEntry));

		cmd.execute((FeedStore)mockFeedStore.proxy(), (EntryStore)mockEntryStore.proxy());
	}
	
	public void testMarksSelectedEntryAsReadInEntryModel() {
		Entry stubEntry = StubFixture.getStubEntry();
		Mock mockEntryStore = new Mock(EntryStore.class);
		Mock mockFeedStore = new Mock(FeedStore.class);
		Mock mockFeedModel = new Mock(FeedModel.class);
		Mock mockEntryModel = new Mock(EntryModel.class);
		Mock mockBrowserModel = new Mock(BrowserModel.class);
		List relatedFeeds = new ArrayList();
		
		Command cmd = new SelectEntryCommand(stubEntry, (FeedModel)mockFeedModel.proxy(),
				(EntryModel)mockEntryModel.proxy(), (BrowserModel)mockBrowserModel.proxy());
		mockEntryStore.stubs().method("markRead").with(NOT_NULL);
		mockEntryStore.stubs().method("getRelatedFeeds").withAnyArguments()
			.will(returnValue(relatedFeeds));
		mockFeedModel.stubs().method("entryRead").with(eq(relatedFeeds));
		mockEntryModel.stubs().method("select").with(same(stubEntry));
		mockEntryModel.expects(once()).method("markRead").with(eq(stubEntry.getUrl()));
		mockBrowserModel.stubs().method("loadEntry").with(same(stubEntry));
		
		cmd.execute((FeedStore)mockFeedStore.proxy(), (EntryStore)mockEntryStore.proxy());
		mockEntryModel.verify();
	}
	
	public void testDoesNotMarkSelectedEntryAsReadIfItsAlreadyRead() {
		Entry stubEntry = StubFixture.getStubEntry();
		stubEntry.markRead();
		Mock mockEntryStore = new Mock(EntryStore.class);
		Mock mockFeedStore = new Mock(FeedStore.class);
		Mock mockFeedModel = new Mock(FeedModel.class);
		Mock mockEntryModel = new Mock(EntryModel.class);
		Mock mockBrowserModel = new Mock(BrowserModel.class);
		
		Command cmd = new SelectEntryCommand(stubEntry, (FeedModel)mockFeedModel.proxy(),
				(EntryModel)mockEntryModel.proxy(), (BrowserModel)mockBrowserModel.proxy());
		mockFeedModel.stubs().method("entryRead");
		mockEntryModel.stubs().method("select").with(same(stubEntry));
		mockEntryModel.stubs().method("markRead").with(eq(stubEntry.getUrl()));
		mockBrowserModel.stubs().method("loadEntry").with(same(stubEntry));

		cmd.execute((FeedStore)mockFeedStore.proxy(), (EntryStore)mockEntryStore.proxy());
		mockEntryStore.verify();
	}
}
