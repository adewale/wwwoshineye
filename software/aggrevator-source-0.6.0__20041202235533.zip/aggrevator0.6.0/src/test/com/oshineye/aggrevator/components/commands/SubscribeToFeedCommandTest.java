package com.oshineye.aggrevator.components.commands;

import java.util.ArrayList;
import java.util.List;

import junit.framework.TestCase;

import com.mockobjects.dynamic.C;
import com.mockobjects.dynamic.Mock;
import com.oshineye.aggrevator.Feed;
import com.oshineye.aggrevator.components.FeedModel;
import com.oshineye.aggrevator.components.commands.Command;
import com.oshineye.aggrevator.components.commands.SubscribeToFeedCommand;
import com.oshineye.aggrevator.store.DuplicateFeedException;
import com.oshineye.aggrevator.store.FeedStore;
import com.oshineye.aggrevator.store.StubFixture;


public class SubscribeToFeedCommandTest extends TestCase {
	public void testCommandSubscribesToFeedUsingEventData() {
		Mock mockFeedModel = new Mock(FeedModel.class);
		mockFeedModel.expectAndReturn("getCurrentFeeds", new ArrayList());
		mockFeedModel.expect("addFeed", C.ANY_ARGS);
		
		Feed expectedFeed = StubFixture.getStubFeedWithUrl(StubFixture.TEST_URL);
		Mock mockFeedStore = new Mock(FeedStore.class);
		mockFeedStore.expect("add", C.args(C.eq(expectedFeed)));
		
		Command cmd = new SubscribeToFeedCommand(StubFixture.TEST_URL, (FeedModel)mockFeedModel.proxy());
		cmd.execute((FeedStore) mockFeedStore.proxy(), null);
		
		mockFeedStore.verify();
	}
	
	public void testUpdatesFeedModelUsingEventData() {
		Feed expectedFeed = StubFixture.getStubFeedWithUrl(StubFixture.TEST_URL);
		Mock mockFeedStore = new Mock(FeedStore.class);
		mockFeedStore.expect("add", C.ANY_ARGS);

		Mock mockFeedModel = new Mock(FeedModel.class);
		mockFeedModel.expectAndReturn("getCurrentFeeds", new ArrayList());
		mockFeedModel.expect("addFeed", C.eq(expectedFeed));
	
		Command cmd = new SubscribeToFeedCommand(StubFixture.TEST_URL, (FeedModel)mockFeedModel.proxy());
		cmd.execute((FeedStore) mockFeedStore.proxy(), null);

		mockFeedModel.verify();
	}

	public void testCommandFinishesEarlyWhenDuplicateFeedPassedIn() {
		List storedFeeds = new ArrayList();
		storedFeeds.add(StubFixture.getStubFeedWithUrl(StubFixture.TEST_URL));
		
		Mock mockFeedStore = new Mock(FeedStore.class);
		
		Mock mockFeedModel = new Mock(FeedModel.class);
		mockFeedModel.expectAndReturn("getCurrentFeeds", storedFeeds);
		
		Command cmd = new SubscribeToFeedCommand(StubFixture.TEST_URL, (FeedModel)mockFeedModel.proxy());
		try {
			cmd.execute((FeedStore) mockFeedStore.proxy(), null);
			fail("Didn't throw an exception when given a duplicate feed");
		} catch (DuplicateFeedException e) {
			//expected
		}
		mockFeedModel.verify();
	}
}
