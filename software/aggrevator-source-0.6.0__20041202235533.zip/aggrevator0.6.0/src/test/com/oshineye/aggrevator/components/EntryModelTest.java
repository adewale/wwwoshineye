package com.oshineye.aggrevator.components;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import junit.framework.TestCase;

import com.mockobjects.dynamic.C;
import com.mockobjects.dynamic.Mock;
import com.oshineye.aggrevator.ComparatorFactory;
import com.oshineye.aggrevator.Entry;
import com.oshineye.aggrevator.Feed;
import com.oshineye.aggrevator.components.EntryModel;
import com.oshineye.aggrevator.components.EntryModelImpl;
import com.oshineye.aggrevator.components.EntryModelObserver;
import com.oshineye.aggrevator.store.StubFixture;


public class EntryModelTest extends TestCase {
	private EntryModel model;

	public void setUp() {
		this.model = new EntryModelImpl();
	}
	
	public void testModelNotifiesObserversOfLoadedEntries() {
		List entries = new ArrayList();
		entries.add(StubFixture.getStubEntry());
		Mock mockObserver = new Mock(EntryModelObserver.class);
		mockObserver.expect("notifyEntriesLoaded", C.eq(entries));
		Mock mockObserver2 = new Mock(EntryModelObserver.class);
		mockObserver2.expect("notifyEntriesLoaded", C.eq(entries));
		
		model.addObserver((EntryModelObserver) mockObserver.proxy());
		model.addObserver((EntryModelObserver) mockObserver2.proxy());
		
		model.loadEntries(entries);
		
		mockObserver.verify();
		mockObserver2.verify();
	}
	
	public void testModelNotifiesObserversOfDeletedFeed() {
		Feed feed = StubFixture.getStubFeed();
		List entries = new ArrayList();
		entries.add(StubFixture.getStubEntry(feed));
		Mock mockObserver = new Mock(EntryModelObserver.class);
		mockObserver.expect("notifyEntriesDeleted", C.same(feed));
		Mock mockObserver2 = new Mock(EntryModelObserver.class);
		mockObserver2.expect("notifyEntriesDeleted", C.same(feed));

		model.loadEntries(entries);
		model.addObserver((EntryModelObserver) mockObserver.proxy());
		model.addObserver((EntryModelObserver) mockObserver2.proxy());

		model.deleteEntriesFromFeed(feed);
		
		mockObserver.verify();
		mockObserver2.verify();
	}
	
	public void testModelDeletesEntriesFromFeed() {
		Feed feed = StubFixture.getStubFeed();
		List entries = new ArrayList();
		entries.add(StubFixture.getStubEntry(feed));
		
		model.loadEntries(entries);
		model.deleteEntriesFromFeed(feed);
		
		assertEquals(0, model.getCurrentEntries().size());
	}
	
	public void testSelectedEntryCanBeRetrievedFromModel() {
		Feed feed = StubFixture.getStubFeed();
		List entries = new ArrayList();
		entries.add(StubFixture.getStubEntry(feed));
		
		model.loadEntries(entries);
		Entry selectedEntry = (Entry) entries.get(0);
		model.select(selectedEntry);
		
		assertEquals(selectedEntry, model.getSelectedEntry());
	}
	
	public void testModelReturnsNullWhenSelectedEntryIsDeleted() {
		Feed feed = StubFixture.getStubFeed();
		List entries = new ArrayList();
		entries.add(StubFixture.getStubEntry(feed));
		
		model.loadEntries(entries);
		Entry selectedEntry = (Entry) entries.get(0);
		model.select(selectedEntry);
		model.deleteEntriesFromFeed(feed);
		
		assertNull(model.getSelectedEntry());
	}

	public void testNotifiesObserversOfEntriesMatchedUsingTitle() {
		List entries = new ArrayList();
		entries.add(StubFixture.getStubEntryWithTitle("not matching"));
		Entry matchingEntry = StubFixture.getStubEntryWithTitle("matching title");
		entries.add(matchingEntry);
		model.loadEntries(entries);
		
		List matchingEntries = new ArrayList();
		matchingEntries.add(matchingEntry);
		Mock mockObserver = new Mock(EntryModelObserver.class);
		model.addObserver((EntryModelObserver) mockObserver.proxy());
		mockObserver.expect("notifyEntriesLoaded", C.eq(matchingEntries));
		
		model.loadMatchingItems("title");
		
		mockObserver.verify();
	}
	
	public void testNotifiesObserversOfEntriesMatchedUsingUrl() {
		List entries = new ArrayList();
		entries.add(StubFixture.getStubEntryWithPermaLinkAndFeedId("not matching", new Long(-1)));
		Entry matchingEntry = StubFixture.getStubEntryWithPermaLinkAndFeedId("matching url", new Long(-1));
		entries.add(matchingEntry);
		model.loadEntries(entries);
		
		List matchingEntries = new ArrayList();
		matchingEntries.add(matchingEntry);
		Mock mockObserver = new Mock(EntryModelObserver.class);
		model.addObserver((EntryModelObserver) mockObserver.proxy());
		mockObserver.expect("notifyEntriesLoaded", C.eq(matchingEntries));
		
		model.loadMatchingItems("url");
		
		mockObserver.verify();
	}
	
	public void testLoadsEmptyListIfNoEntriesMatch() {
		List entries = new ArrayList();
		entries.add(StubFixture.getStubEntryWithPermaLinkAndFeedId("not matching", new Long(-1)));
		entries.add(StubFixture.getStubEntryWithPermaLinkAndFeedId("not matching", new Long(-1)));
		model.loadEntries(entries);
		
		List matchingEntries = new ArrayList();
		Mock mockObserver = new Mock(EntryModelObserver.class);
		model.addObserver((EntryModelObserver) mockObserver.proxy());
		mockObserver.expect("notifyEntriesLoaded", C.eq(matchingEntries));
		
		model.loadMatchingItems("url");
		
		mockObserver.verify();
	}
	
	public void testFindsEntriesCaseInsensitively() {
		List entries = new ArrayList();
		Entry matchingEntry1 = StubFixture.getStubEntryWithPermaLinkAndFeedId("maTching url", new Long(-1));
		Entry matchingEntry2 = StubFixture.getStubEntryWithPermaLinkAndFeedId("MatchinG url", new Long(-1));
		Entry nonMatchingEntry = StubFixture.getStubEntryWithPermaLinkAndFeedId("just a url", new Long(-1));
		entries.add(matchingEntry1);
		entries.add(matchingEntry2);
		entries.add(nonMatchingEntry);
		model.loadEntries(entries);
		
		List matchingEntries = Arrays.asList(new Entry[]{matchingEntry1, matchingEntry2});
		Mock mockObserver = new Mock(EntryModelObserver.class);
		model.addObserver((EntryModelObserver) mockObserver.proxy());
		mockObserver.expect("notifyEntriesLoaded", C.eq(matchingEntries));

		model.loadMatchingItems("matching");
		model.loadMatchingItems("MATCHING");
		
		mockObserver.verify();
	}
	
	public void testLeavesObserversAloneIfMatchingItemsHaveNotChanged() {
		String searchText = "matching";
		List entries = new ArrayList();
		Entry matchingEntry = StubFixture.getStubEntryWithPermaLinkAndFeedId("matching url", new Long(-1));
		entries.add(matchingEntry);
		model.loadEntries(entries);
		
		List matchingEntries = new ArrayList();
		matchingEntries.add(matchingEntry);
		Mock mockObserver = new Mock(EntryModelObserver.class);
		model.addObserver((EntryModelObserver) mockObserver.proxy());
		
		model.loadMatchingItems(searchText);
		
		mockObserver.verify();
	}
	
	public void testNotifiesObserversIfMatchingItemsHaveChanged() {
		String searchText = "matching";
		List entries = new ArrayList();
		Entry matchingEntry = StubFixture.getStubEntryWithPermaLinkAndFeedId("matching url", new Long(-1));
		entries.add(matchingEntry);
		Entry nonMatchingEntry = StubFixture.getStubEntryWithPermaLinkAndFeedId("just a url", new Long(-1));
		entries.add(nonMatchingEntry);
		model.loadEntries(entries);
		
		List matchingEntries = new ArrayList();
		matchingEntries.add(matchingEntry);
		Mock mockObserver = new Mock(EntryModelObserver.class);
		model.addObserver((EntryModelObserver) mockObserver.proxy());
		mockObserver.expect("notifyEntriesLoaded", C.eq(matchingEntries));
		
		model.loadMatchingItems(searchText);
		
		mockObserver.verify();
	}
	
	public void testModelNotifiesObserversWithEntriesMatchingCurrentSearchText() {
		String searchText = "matching";
		List entries = new ArrayList();
		Entry matchingEntry = StubFixture.getStubEntryWithPermaLinkAndFeedId("matching url", new Long(-1));
		entries.add(matchingEntry);
		Entry nonMatchingEntry = StubFixture.getStubEntryWithPermaLinkAndFeedId("just a url", new Long(-1));
		entries.add(nonMatchingEntry);
		model.loadMatchingItems(searchText);
		
		List matchingEntries = new ArrayList();
		matchingEntries.add(matchingEntry);
		Mock mockObserver = new Mock(EntryModelObserver.class);
		model.addObserver((EntryModelObserver) mockObserver.proxy());
		mockObserver.expect("notifyEntriesLoaded", C.eq(matchingEntries));
		
		model.loadEntries(entries);
		
		mockObserver.verify();
	}

	public void testModelNotifiesObserversWithAllEntriesIfSearchTextAbsent() {
		String searchText = "";
		List entries = new ArrayList();
		Entry matchingEntry1 = StubFixture.getStubEntryWithPermaLinkAndFeedId("matching url 1", new Long(-1));
		entries.add(matchingEntry1);
		Entry matchingEntry2 = StubFixture.getStubEntryWithPermaLinkAndFeedId("matching url 2", new Long(-1));
		entries.add(matchingEntry2);
		model.loadMatchingItems(searchText);
		
		Mock mockObserver = new Mock(EntryModelObserver.class);
		model.addObserver((EntryModelObserver) mockObserver.proxy());
		mockObserver.expect("notifyEntriesLoaded", C.eq(entries));
		
		model.loadEntries(entries);
		
		mockObserver.verify();
	}
	
	public void testModelNotifiesObserversWhenGoingFromSearchTextToAbsentSearchText() {
		String searchText = "matching";
		List entries = new ArrayList();
		Entry matchingEntry = StubFixture.getStubEntryWithPermaLinkAndFeedId("matching url", new Long(-1));
		entries.add(matchingEntry);
		Entry nonMatchingEntry = StubFixture.getStubEntryWithPermaLinkAndFeedId("just a url", new Long(-1));
		entries.add(nonMatchingEntry);
		model.loadEntries(entries);
		model.loadMatchingItems(searchText);
		
		Mock mockObserver = new Mock(EntryModelObserver.class);
		model.addObserver((EntryModelObserver) mockObserver.proxy());
		mockObserver.expect("notifyEntriesLoaded", C.eq(entries));
		
		model.loadMatchingItems("");
		
		mockObserver.verify();
		assertEquals(entries, model.getCurrentEntries());
	}
	
	public void testModelNotifiesObserversWithEmptyListOfMatchingEntriesForEmptyFeeds() {
		String searchText = "matching";
		List entries = new ArrayList();
		Entry matchingEntry = StubFixture.getStubEntryWithPermaLinkAndFeedId("matching url", new Long(-1));
		entries.add(matchingEntry);
		model.loadEntries(entries);
		model.loadMatchingItems(searchText);
		assertEquals(1, model.getCurrentEntries().size());
		
		List emptyEntriesListForEmptyFeed = new ArrayList();
		Mock mockObserver = new Mock(EntryModelObserver.class);
		model.addObserver((EntryModelObserver) mockObserver.proxy());
		mockObserver.expect("notifyEntriesLoaded", C.eq(emptyEntriesListForEmptyFeed));
		
		model.loadEntries(emptyEntriesListForEmptyFeed);
		mockObserver.verify();
	}
	
	public void testLoadingMatchingItemsAltersCurrentEntries() {
		String searchText = "url";
		List entries = new ArrayList();
		Entry matchingEntry = StubFixture.getStubEntryWithPermaLinkAndFeedId("matching url", new Long(-1));
		entries.add(matchingEntry);
		entries.add(StubFixture.getStubEntryWithPermaLinkAndFeedId("not matching", new Long(-1)));
		model.loadEntries(entries);
		
		List matchingEntries = new ArrayList();
		matchingEntries.add(matchingEntry);
		Mock mockObserver = new Mock(EntryModelObserver.class);
		model.addObserver((EntryModelObserver) mockObserver.proxy());
		mockObserver.expect("notifyEntriesLoaded", C.eq(matchingEntries));
		
		model.loadMatchingItems(searchText);
		assertEquals(matchingEntries, model.getCurrentEntries());
		
		mockObserver.verify();
	}
	
	public void testNarrowingSearchFollowedByWideningSearchFindsMoreEntries() {
		String narrowSearchText = "url";
		String wideSearchText = "matching";
		List entries = new ArrayList();
		Entry matchingEntry = StubFixture.getStubEntryWithPermaLinkAndFeedId("matching url", new Long(-1));
		entries.add(matchingEntry);
		Entry nonMatchingEntry = StubFixture.getStubEntryWithPermaLinkAndFeedId("not matching", new Long(-1));
		entries.add(nonMatchingEntry);
		model.loadEntries(entries);
		
		Mock mockObserver = new Mock(EntryModelObserver.class);
		model.addObserver((EntryModelObserver) mockObserver.proxy());
		mockObserver.expect("notifyEntriesLoaded", C.eq(Arrays.asList(new Entry[]{matchingEntry})));
		mockObserver.expect("notifyEntriesLoaded", C.eq(Arrays.asList(new Entry[]{matchingEntry, nonMatchingEntry})));
		
		model.loadMatchingItems(narrowSearchText);
		model.loadMatchingItems(wideSearchText);
		
		mockObserver.verify();
	}

	public void testMatchingItemsRetainTheirOriginalOrder() {
		String searchText = "match";
		
		//in reverse order of url
		Entry e1 = StubFixture.getStubEntryWithPermaLinklTitleAndContent("Z url", "Z title", "Z");
		Entry e2 = StubFixture.getStubEntryWithPermaLinklTitleAndContent("Y url match", "Y title", "Y");
		Entry e3 = StubFixture.getStubEntryWithPermaLinklTitleAndContent("X url match", "X title", "X");
		List entries = Arrays.asList(new Entry[]{e1, e2, e3});
		
		model.loadEntries(entries);
		model.sort(ComparatorFactory.getEntryTitleComparator());
		assertEquals(e3, model.getCurrentEntries().get(0));
		assertEquals(e2, model.getCurrentEntries().get(1));
		assertEquals(e1, model.getCurrentEntries().get(2));

		List matchingEntries = new ArrayList();
		matchingEntries.add(e3);
		matchingEntries.add(e2);
		Mock mockObserver = new Mock(EntryModelObserver.class);
		model.addObserver((EntryModelObserver) mockObserver.proxy());
		mockObserver.expect("notifyEntriesLoaded", C.eq(matchingEntries));
		
		model.loadMatchingItems(searchText);
		assertEquals(e3, model.getCurrentEntries().get(0));
		assertEquals(e2, model.getCurrentEntries().get(1));
		
		mockObserver.verify();
	}
	
	public void testSelectingNoneDeselectsCurrentEntry() {
		Feed feed = StubFixture.getStubFeed();
		List entries = new ArrayList();
		entries.add(StubFixture.getStubEntry(feed));
		model.loadEntries(entries);
		Entry selectedEntry = (Entry) entries.get(0);
		model.select(selectedEntry);
		assertNotNull(model.getSelectedEntry());
		assertTrue(model.entrySelected());
		
		model.selectNone();
		
		assertNull(model.getSelectedEntry());
		assertEquals(-1, model.getSelectedEntryIndex());
		assertFalse(model.entrySelected());
	}
	
	public void testMarksEntryWithMatchingUrlRead() {
		Feed feed = StubFixture.getStubFeed();
		List entries = feed.fetchNewEntries();
		model.loadEntries(entries);
		Entry targetEntry = (Entry) entries.get(0);
		String location = targetEntry.getUrl();
		
		assertFalse(targetEntry.isRead());
		model.markRead(location);
		assertTrue(targetEntry.isRead());
	}
	
	public void testModelNotifiesObserversOfMatchingUrlRead() {
		Feed feed = StubFixture.getStubFeed();
		List entries = feed.fetchNewEntries();
		model.loadEntries(entries);
		Entry targetEntry = (Entry) entries.get(0);
		String location = targetEntry.getUrl();
		
		Mock mockObserver = new Mock(EntryModelObserver.class);
		mockObserver.expect("notifyEntryRead", C.same(targetEntry));
		Mock mockObserver2 = new Mock(EntryModelObserver.class);
		mockObserver2.expect("notifyEntryRead", C.same(targetEntry));
		
		model.addObserver((EntryModelObserver) mockObserver.proxy());
		model.addObserver((EntryModelObserver) mockObserver2.proxy());
		
		model.markRead(location);
		
		mockObserver.verify();
		mockObserver2.verify();
	}
	
	public void testModelNotifiesObserversOfRefreshedEntry() {
		Feed feed = StubFixture.getStubFeed();
		List entries = feed.fetchNewEntries();
		model.loadEntries(entries);
		Entry targetEntry = (Entry) entries.get(0);
		
		Mock mockObserver = new Mock(EntryModelObserver.class);
		mockObserver.expect("notifyEntryRefreshed", C.same(targetEntry));
		Mock mockObserver2 = new Mock(EntryModelObserver.class);
		mockObserver2.expect("notifyEntryRefreshed", C.same(targetEntry));
		
		model.addObserver((EntryModelObserver) mockObserver.proxy());
		model.addObserver((EntryModelObserver) mockObserver2.proxy());
		
		model.refreshEntry(targetEntry);
		
		mockObserver.verify();
		mockObserver2.verify();
	}
}
