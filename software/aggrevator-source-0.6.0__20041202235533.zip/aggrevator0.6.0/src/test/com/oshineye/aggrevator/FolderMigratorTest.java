package com.oshineye.aggrevator;

import java.io.StringReader;
import java.io.StringWriter;
import java.io.Writer;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.jmock.Mock;
import org.jmock.MockObjectTestCase;

import com.oshineye.aggrevator.components.FeedModel;
import com.oshineye.aggrevator.store.EntryStore;
import com.oshineye.aggrevator.store.FeedStore;
import com.oshineye.aggrevator.store.StubFixture;
import com.oshineye.aggrevator.util.StringWriterFactory;

/**
 * @author aoshineye
 */
public class FolderMigratorTest extends MockObjectTestCase {
	
	private FeedStore feedStore;
	private EntryStore entryStore;

	public void setUp() {
		this.feedStore = StubFixture.getFeedStore();
		this.entryStore = StubFixture.getEntryStore();
		
		feedStore.deleteAll();
		entryStore.deleteAll();
	}
	
	public void tearDown() {
		feedStore.deleteAll();
		entryStore.deleteAll();
	}
	
	public void testDumpsAllFeedAndEntries() {
		Feed feed = StubFixture.getStubFeedWithTitleAndUrl("title", StubFixture.TEST_URL);
		feedStore.add(feed);
		
		List fetchedEntries = feed.fetchNewEntries();
		entryStore.addEntries(fetchedEntries);
		Feed feed2 = StubFixture.getStubFeedWithTitleAndUrl("feed2 title", StubFixture.TEST_URL2);
		feedStore.add(feed2);
		
		StringWriterFactory factory = new StringWriterFactory(new StringWriter());
		Writer writer = factory.getWriter(null);
		FolderMigrator migrator = new FolderMigrator(feedStore, entryStore, factory, null);
		migrator.dumpFeed(writer, feed, fetchedEntries);
		
		
		String dumpString = writer.toString();
		assertTrue(StringUtils.contains(dumpString, "<feed"));
		assertEquals(fetchedEntries.size(), StringUtils.countMatches(dumpString, "<com.oshineye.aggrevator.Entry>"));
		assertTrue(StringUtils.contains(dumpString, feed.getTitle()));
		
		StringWriter writer2 = new StringWriter();
		migrator.dumpFeed(writer2, feed2, new ArrayList());
		assertTrue(StringUtils.contains(writer2.toString(), StubFixture.TEST_URL2));
	}

	public void testLoadsAllFeedsAndEntries() throws Exception {
		Feed feed = StubFixture.getStubFeedWithTitleAndUrl("title", StubFixture.TEST_URL);
		Mock mockFeedModel = new Mock(FeedModel.class);
		mockFeedModel.stubs().method("addFeed").withAnyArguments();
		feedStore.add(feed);
		
		List fetchedEntries = feed.fetchNewEntries();
		entryStore.addEntries(fetchedEntries);
		
		StringWriterFactory factory = new StringWriterFactory(new StringWriter());
		Writer writer = factory.getWriter(null);
		FolderMigrator migrator = new FolderMigrator(feedStore, entryStore, factory, (FeedModel)mockFeedModel.proxy());
		migrator.dumpFeed(writer, feed, fetchedEntries);
		String dumpString = writer.toString();
		feedStore.delete(feed);
		entryStore.delete(feed);
		
		migrator.loadFeed(new StringReader(dumpString));
		
		List feeds = feedStore.findAllFeeds();
		Feed newFeed = (Feed) feeds.get(0);
		assertTrue(feed.hasSameUrl(newFeed));
		
		List entries = entryStore.findEntriesInFeed(newFeed.getId());
		assertEquals(fetchedEntries.size(), entries.size());
		assertTrue(fetchedEntries.containsAll(entries));
		assertTrue(entries.containsAll(fetchedEntries));
	}
	
	public void testSkipsLoadingFeedIfAlreadyInStore() throws Exception {
		Feed feed = StubFixture.getStubFeedWithTitleAndUrl("title", StubFixture.TEST_URL);
		feedStore.add(feed);
		
		List fetchedEntries = feed.fetchNewEntries();
		entryStore.addEntries(fetchedEntries);
		
		StringWriterFactory factory = new StringWriterFactory(new StringWriter());
		Writer writer = factory.getWriter(null);
		FolderMigrator migrator = new FolderMigrator(feedStore, entryStore, factory, null);
		migrator.dumpFeed(writer, feed, fetchedEntries);
		String dumpString = writer.toString();
		
		migrator.loadFeed(new StringReader(dumpString));
		
		List feeds = feedStore.findAllFeeds();
		assertEquals(1, feeds.size());
		Feed newFeed = (Feed) feeds.get(0);
		assertEquals(feed, newFeed);
		
		List entries = entryStore.findEntriesInFeed(newFeed.getId());
		assertEquals(fetchedEntries.size(), entries.size());
		assertTrue(fetchedEntries.containsAll(entries));
		assertTrue(entries.containsAll(fetchedEntries));
	}
	
	public void testLoadsNewFeedsIntoFeedModel() {
		Feed feed = StubFixture.getStubFeedWithTitleAndUrl("title", StubFixture.TEST_URL);
		Mock mockFeedModel = new Mock(FeedModel.class);
		mockFeedModel.expects(once()).method("addFeed").withAnyArguments();
		feedStore.add(feed);
		
		List fetchedEntries = feed.fetchNewEntries();
		entryStore.addEntries(fetchedEntries);
		
		StringWriterFactory factory = new StringWriterFactory(new StringWriter());
		Writer writer = factory.getWriter(null);
		FolderMigrator migrator = new FolderMigrator(feedStore, entryStore, factory, (FeedModel)mockFeedModel.proxy());
		migrator.dumpFeed(writer, feed, fetchedEntries);
		String dumpString = writer.toString();
		feedStore.delete(feed);
		entryStore.delete(feed);
		
		migrator.loadFeed(new StringReader(dumpString));
		mockFeedModel.verify();
	}
}
