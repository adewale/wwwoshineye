INTRODUCTION
Aggrevator is an RSS/Atom aggregator. But with a few features that, hopefully, distinguish it from the rest. 

The main advantage of Aggrevator is that it is scalable. The corpus of feeds I've used for testing is over 4000 feeds from a variety of sources. That's more than I expect most people will be using but it ensures that Aggrevator is scalable enough to handle just about anyone's needs. 

Aggrevator is cross-platform (I have tested it using Linux and Windows). In fact once your database is set up you can connect to it from any running instance of Aggrevator (assuming your username and password are valid) so you no longer have to manually synchronise different installations of the same aggregator.


WHAT PROBLEMS DOES AGGREVATOR SOLVE FOR ME?
Are you finding it difficult to manage the large number of blogs you have subscribed to?
Do you feel overwhelmed when it comes to deciding which blog to read first?
Do you need to find an article somebody posted a while ago but can't remember which of the many blogs you've subscribed to it was in?


FEATURES
- All entries are stored permanently so that you can always find that interesting article you read last month.
- The user is encouraged to subscribe to lots of feeds 
- The scoring feature lets the system learn which feeds you like to read and you can sort the list so that you ones you like are at the top
- Dynamic filtering is provided to make it easy to find the feed or entry you're looking for.
- It contains an embedded browser which means you can read entries and seamlessly follow their links onto the web.


FEATURES IN DETAIL
- The content is stored in a MySql 4.1 database
- OPML import and export are supported so you're not locked into this aggregator
- Proxy suppport is provided using HttpClient so it should pick up your standard proxy settings

