package com.oshineye.aggrevator.store;

import com.oshineye.aggrevator.Configuration;
import com.oshineye.aggrevator.db.JdbcProcessFactory;

/**
 * @author aoshineye
 *
 */
public abstract class MySqlStore {
	private String databaseName;

	public MySqlStore(String databaseName) {
		this.databaseName = databaseName;
	}

	protected JdbcProcessFactory getJdbcProcessFactory() {
		String driver = "org.gjt.mm.mysql.Driver";
		String url = Configuration.getDatabaseServer() + databaseName;
		String user = Configuration.getUserName();
		String passWord = Configuration.getPassword();
		
		//there should be enough connections if the entire http pool is busy and
		//the user initiates other work on new threads so 20 extra 
		//connections can be created to provide breathing room
		int connectionPoolSize = Configuration.getNumberOfThreadsInPool() + 20;
		return new JdbcProcessFactory(driver, url, user, passWord, connectionPoolSize);
	}
}
