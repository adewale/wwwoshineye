package com.oshineye.aggrevator;

import java.util.Collections;

import com.oshineye.aggrevator.components.FeedModel;
import com.oshineye.aggrevator.components.FeedModelImpl;
import com.oshineye.aggrevator.store.EntryStore;
import com.oshineye.aggrevator.store.FeedIdentityMap;
import com.oshineye.aggrevator.store.FeedStore;
import com.oshineye.aggrevator.store.MySqlEntryStore;
import com.oshineye.aggrevator.store.MySqlFeedStore;
import com.oshineye.aggrevator.util.BufferedWriterFactory;
import com.oshineye.aggrevator.util.QueryLoader;

/**
 * @author aoshineye
 *
 */
public class FolderMigratorMain {
	public static void main(String[] args) throws Exception {
		if (args.length != 2) {
			System.out.println("Usage: java com.oshineye.aggrevator.util.FolderMigratorMain dump|load dumpFolder");
			System.exit(1);
		}
		
		if (invalidCommand(args[0])) {
			System.out.println("Invalid command: " + args[0]);
			System.out.println("Usage: java com.oshineye.aggrevator.util.FolderMigratorMain dump|load dumpFolder");
			System.exit(1);
		}
		String command = args[0];
		String folderName = args[1];

		Configuration.load();
		FeedIdentityMap feedIdentityMap = new FeedIdentityMap();
		QueryLoader queryLoader = new QueryLoader();
		FeedStore feedStore = new MySqlFeedStore(Configuration.getDatabaseName(), feedIdentityMap, queryLoader);
		EntryStore entryStore = new MySqlEntryStore(Configuration.getDatabaseName(), feedIdentityMap, queryLoader);

		FeedModel feedModel = new FeedModelImpl(Collections.EMPTY_LIST);
		FolderMigrator migrator = new FolderMigrator(feedStore, entryStore, new BufferedWriterFactory(), feedModel);
		if ("dump".equals(command)) {
			migrator.dump(folderName);
		} else if ("load".equals(command)) {
			migrator.load(folderName);
		}
	}
	
	private static boolean invalidCommand(String command) {
		if (!"dump".equals(command) && !"load".equals(command)) {
			return true;
		}
		return false;
	}
}
