package com.oshineye.aggrevator.components.actions;

import org.eclipse.jface.dialogs.IInputValidator;
import org.eclipse.jface.dialogs.InputDialog;
import org.eclipse.jface.window.ApplicationWindow;
import org.eclipse.swt.widgets.Shell;

import com.oshineye.aggrevator.components.FeedModel;
import com.oshineye.aggrevator.components.StatusRecorder;
import com.oshineye.aggrevator.store.FeedStore;
import com.oshineye.aggrevator.util.StringInputValidator;
import com.oshineye.aggrevator.util.URLUtils;

/**
 * @author aoshineye
 *
 */
public class NewFeedsterSearchFeedAction extends NewFeedAction {

	public NewFeedsterSearchFeedAction(ApplicationWindow window, FeedModel feedModel, FeedStore feedStore, StatusRecorder recorder) {
		super(window, feedModel, feedStore, recorder);
	}

	protected void initialiseVisibleAttributes() {
		this.setText("Feedster Feed");
		this.setToolTipText("Add a new Feedster feed");
	}
	
	protected String getUrl(InputDialog input) {
		return URLUtils.generateFeedsterSearchUrl(input.getValue());
	}
	
	protected InputDialog createInputDialog(Shell shell) {
		String initialValue = getClipboardTextIfSuitable(shell);
		String errorMessage = "You need to enter a search term that isn't blank";
		String dialogTitle = "Add New Feedster Feed";
		String message = "Please enter the search term";
		IInputValidator inputValidator = new StringInputValidator(errorMessage);
		InputDialog dialog = new InputDialog(shell, dialogTitle, message, initialValue, inputValidator);
		return dialog;
	}
}
