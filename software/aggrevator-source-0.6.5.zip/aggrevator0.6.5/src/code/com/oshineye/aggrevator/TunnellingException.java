package com.oshineye.aggrevator;


/**
 * @author aoshineye
 * A runtime exception that enables exceptions to propagate from the lower tiers
 * up to a tier where the exception can be dealt with. The idea is that actual
 * exception that occurred is caught, wrapped in a TunnellingException and then
 * the TunnellingException is thrown up to user-oriented tier where sensible
 * measures can be taken to deal with it based on information in the original
 * exception.
 */
public class TunnellingException extends RuntimeException {
    private String extraInfo;

	public TunnellingException(Exception cause) {
        super(cause);
    }

	public TunnellingException(String extraInfo, Exception cause) {
		this(cause);
		this.extraInfo = extraInfo;
	}
	
	public TunnellingException(String message) {
		super(message);
	}

	public String getMessage() {
		String message = super.getMessage();
		if (extraInfo != null) {
			message = message + "\n" + "Extra info: " + extraInfo;
		}
		return message;
	}
	
	public String toString() {
		return super.getMessage();
	}
}
