package com.oshineye.aggrevator.components.executors;

import org.apache.log4j.Logger;

import EDU.oswego.cs.dl.util.concurrent.PooledExecutor;
import EDU.oswego.cs.dl.util.concurrent.Slot;

/**
 * @author aoshineye
 * Execute Runnables in the background but use a slot to help ensure that
 * only one thing can take place at a time. Any work that is currently queued
 * is evicted when new work turns up.
 */
public class SlottedBackgroundExecutor {
	private static final Logger LOG = Logger.getLogger(SlottedBackgroundExecutor.class);
	private PooledExecutor backgroundExecutor;

	public SlottedBackgroundExecutor() {
        backgroundExecutor = new PooledExecutor(new Slot());
        //discard the oldest unhandled request on the queue when blocked
        backgroundExecutor.discardOldestWhenBlocked();
        backgroundExecutor.setMaximumPoolSize(1);
        backgroundExecutor.setMinimumPoolSize(1);
        backgroundExecutor.setKeepAliveTime(0);
        backgroundExecutor.createThreads(1);
	}
	
	public void executeInBackground(Runnable runnable) {
		try {
			backgroundExecutor.execute(runnable);
		} catch (InterruptedException e) {
			LOG.warn(e.toString());
		}
	}

	public void shutDown() {
		backgroundExecutor.interruptAll();
		backgroundExecutor.shutdownNow();
	}
}
