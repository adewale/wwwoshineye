package com.oshineye.aggrevator.util;

import java.util.Date;

import org.apache.commons.lang.time.DateFormatUtils;


import com.oshineye.aggrevator.Configuration;

/**
 * @author aoshineye
 *
 */
public class DateUtils {
	public static String getFormattedDate(Date date) {
		return DateFormatUtils.format(new Date(), Configuration.DATE_FORMAT);
	}
}
