package com.oshineye.aggrevator.components;

import java.io.IOException;
import java.io.Writer;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.lang.StringEscapeUtils;
import org.apache.log4j.Logger;

import com.oshineye.aggrevator.Feed;

/**
 * @author aoshineye
 *
 */
public class OPMLExporter {
	private static final Logger LOG = Logger.getLogger(OPMLExporter.class);
	private final FeedModel feedModel;

	public OPMLExporter(FeedModel feedModel) {
		this.feedModel = feedModel;
		
	}

	public void exportFeeds(Writer writer) {
		StringBuffer result = new StringBuffer();
		result.append("<?xml version=\"1.0\" encoding=\"utf-8\"?>\n");
		result.append("<opml version=\"1.0\">\n");
		result.append("<head><title>Aggrevator export</title></head>\n");
		result.append("  <body>\n");
		
		List feeds = feedModel.getCurrentFeeds();
		for (Iterator iter = feeds.iterator(); iter.hasNext();) {
			Feed feed = (Feed) iter.next();
			result.append("    <outline title=\""+ StringEscapeUtils.escapeXml(feed.getTitle()) 
				+"\" " + "xmlUrl=\"" + StringEscapeUtils.escapeXml(feed.getUrl()) + "\" />\n");
		}
		
		result.append("  </body>\n");
		result.append("</opml>");
		
		try {
			writer.write(result.toString());
			writer.flush();
			writer.close();
		} catch (IOException e) {
			LOG.warn(e.getMessage(), e);
		}
	}
}
