package com.oshineye.aggrevator.util;

/**
 * @author aoshineye
 *
 */
public class Timer {
	private long startTimeInMilliseconds;

	public Timer() {
		this.startTimeInMilliseconds = System.currentTimeMillis();
	}

	public String getDuration() {
		long duration = System.currentTimeMillis() - startTimeInMilliseconds;
		long seconds = duration / 1000;
		return "" + seconds;
	}

}
