package com.oshineye.aggrevator.components;

import org.eclipse.swt.widgets.Display;

import com.oshineye.aggrevator.components.tasks.Task;
import com.oshineye.aggrevator.util.ThreadingUtils;

/**
 * @author aoshineye
 *
 * Enables status messages to be sent from Commands being executed on worker
 * threads to a StatusRecorder on the UI thread but just runs them directly
 * if we'ere already on the UI thread.
 */
public class WorkerThreadStatusRecorder implements StatusRecorder {
	private final StatusRecorder recorder;
	private Display display;

	public WorkerThreadStatusRecorder(StatusRecorder recorder, Display display) {
		this.recorder = recorder;
		this.display = display;
	}

	public void setStatus(final String message) {
		if (ThreadingUtils.inUIThread()) {
			recorder.setStatus(message);
			return;
		}
		
		display.asyncExec(new Task() {
			public void doWork() {
				recorder.setStatus(message);
			}
		});
	}

}
