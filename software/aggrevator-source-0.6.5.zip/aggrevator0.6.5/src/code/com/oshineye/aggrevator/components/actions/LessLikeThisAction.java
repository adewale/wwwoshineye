package com.oshineye.aggrevator.components.actions;

import java.util.Iterator;
import java.util.List;

import org.eclipse.jface.resource.ImageDescriptor;

import com.oshineye.aggrevator.Entry;
import com.oshineye.aggrevator.Feed;
import com.oshineye.aggrevator.components.EntryModel;
import com.oshineye.aggrevator.components.FeedModel;
import com.oshineye.aggrevator.store.EntryStore;

/**
 * @author aoshineye
 */
public class LessLikeThisAction extends AbstractEntrySelectedAction {
	private EntryStore entryStore;

	public LessLikeThisAction(EntryStore entryStore, FeedModel feedModel, EntryModel entryModel) {
		super(feedModel, entryModel);
		this.entryStore = entryStore;
		this.setText("&Less Like This@Ctrl+L");
		this.setToolTipText("Less like this");
		this.setImageDescriptor(ImageDescriptor.createFromFile(NewFeedAction.class, "/lessLikeThis.png"));
	}

	public void run() {
		EntryModel entryModel = getEntryModel();
		Entry entry = entryModel.getSelectedEntry();
		entryStore.decrementScore(entry);
		
		List relatedFeeds = entryStore.getRelatedFeeds(entry);
		for (Iterator iter = relatedFeeds.iterator(); iter.hasNext();) {
			Feed feed = (Feed) iter.next();
			feed.decrementScore();
		}
		
		refresh(relatedFeeds);
		entryModel.refreshEntry(entry);
	}
}
