package com.oshineye.aggrevator.components;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.oshineye.aggrevator.Entry;

/**
 * @author aoshineye
 *
 */
public class BrowserModelImpl implements BrowserModel {

	private static final String ABOUT_BLANK = "about:blank";
	private List observers;
	private String location;
	private Entry lastVisitedEntry;

	public BrowserModelImpl() {
		this.observers = new ArrayList();
	}
	
	public void loadEntry(Entry entry) {
		for (Iterator iter = observers.iterator(); iter.hasNext();) {
			BrowserObserver observer = (BrowserObserver) iter.next();
			observer.notifyEntryLoaded(entry);
		}
		this.lastVisitedEntry = entry;
	}

	public void addObserver(BrowserObserver observer) {
		observers.add(observer);
	}

	public void setLocation(String location) {
		if (ABOUT_BLANK.equals(location)) {
			this.location = lastVisitedEntry.getUrl();
			return;
		}
		this.location = location;
	}

	public String getLocation() {
		return location;
	}
}
