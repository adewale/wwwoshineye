package com.oshineye.aggrevator.util;

import org.apache.commons.lang.StringEscapeUtils;
import org.apache.log4j.Logger;

/**
 * @author aoshineye
 *
 * This class exists to provide exception safe version of the standard 
 * apache-commons libraries for manipulating strings
 */
public class StringUtils {
	private static final Logger LOG = Logger.getLogger(StringUtils.class);
	public static String unescapeHtml(String html) {
		try {
			return StringEscapeUtils.unescapeHtml(html);
		} catch (NumberFormatException e) {
			//this is what happens if the string doesn't contain escaped html
			LOG.debug(e.getMessage(), e);
			return html;
		}
	}

	public static String valueOfWithDefault(Object object, String defaultString) {
		if (object == null) {
			return defaultString;
		}
		return String.valueOf(object);
	}
}
