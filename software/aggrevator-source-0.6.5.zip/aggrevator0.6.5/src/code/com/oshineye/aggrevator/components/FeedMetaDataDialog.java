package com.oshineye.aggrevator.components;

import org.apache.commons.lang.StringUtils;
import org.eclipse.jface.dialogs.Dialog;
import org.eclipse.jface.dialogs.IDialogConstants;
import org.eclipse.jface.dialogs.IInputValidator;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.ModifyEvent;
import org.eclipse.swt.events.ModifyListener;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;

import com.oshineye.aggrevator.Feed;
import com.oshineye.aggrevator.util.StringInputValidator;

/**
 * @author aoshineye
 *
 */
public class FeedMetaDataDialog extends Dialog implements ModifyListener {

	private final Feed feed;
	private Text titleInput;
	private Text urlInput;
	private String newFeedTitle;
	private String newFeedUrl;
	private StringInputValidator titleValidator;
	private StringInputValidator urlValidator;

	protected FeedMetaDataDialog(Shell parentShell, Feed feed) {
		super(parentShell);
		this.feed = feed;
	}

	protected void configureShell(Shell shell) {
		super.configureShell(shell);
		shell.setText("Feed metadata");
	}
	
	protected Control createDialogArea(Composite parent) {
		Composite composite = (Composite) super.createDialogArea(parent);
		
		Group feedMetaDataGroup = new Group(composite, SWT.NONE);
		GridLayout layout = new GridLayout();
		layout.numColumns = 2;
		feedMetaDataGroup.setLayout(layout);
		
		titleValidator = new StringInputValidator("You need to enter a valid title for the feed");
		urlValidator = new StringInputValidator("You need to enter a valid url for the feed");
		
		titleInput = createInputRow(feedMetaDataGroup, "Feed title: ", titleValidator, feed.getTitle());
		urlInput = createInputRow(feedMetaDataGroup, "Feed url: ", urlValidator, feed.getUrl());
		
		titleInput.addModifyListener(this);
		urlInput.addModifyListener(this);
		return composite;
	}
	
	protected void buttonPressed(int buttonId) {
		if (IDialogConstants.OK_ID == buttonId) {
			newFeedTitle = titleInput.getText();
			newFeedUrl = urlInput.getText();
		}
		super.buttonPressed(buttonId);
	}
	
	public String getNewFeedTitle() {
		return newFeedTitle;
	}

	public String getNewFeedUrl() {
		return newFeedUrl;
	}
	
	private Text createInputRow(Group feedMetaDataGroup, String labelTitle, IInputValidator validator, String defaultText) {
		Label title = new Label(feedMetaDataGroup, SWT.NONE);
		title.setText(labelTitle);
		Text input = new Text(feedMetaDataGroup, SWT.SINGLE | SWT.BORDER);
		input.setText(defaultText);
		input.setLayoutData(new GridData(GridData.GRAB_HORIZONTAL | GridData.HORIZONTAL_ALIGN_FILL));
		
		return input;
	}

	public void modifyText(ModifyEvent event) {
		//the ok button has to be retrieved here in this fashion because 
		//it's not available when the input row is created
		Button okButton = getButton(IDialogConstants.OK_ID);
		okButton.setEnabled(allInputsValid());
	}
	
	private boolean allInputsValid() {
		return StringUtils.isEmpty(titleValidator.isValid(titleInput.getText())) 
			&& StringUtils.isEmpty(urlValidator.isValid(urlInput.getText()));
	}
}
