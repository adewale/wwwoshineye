package com.oshineye.aggrevator;

/**
 * @author aoshineye
 *
 */
public class FeedRecord {
	private final Long id;
	private final String url;
	private final String title;
	private final String etag;
	private final String lastModified;

	public FeedRecord(Long id, String url, String title, String etag, String lastModified) {
		this.id = id;
		this.url = url;
		this.title = title;
		this.etag = etag;
		this.lastModified = lastModified;
	}

	public Long getId() {
		return id;
	}
	
	public String getTitle() {
		return title;
	}

	public String getUrl() {
		return url;
	}

	public String getEtag() {
		return etag;
	}

	public String getLastModified() {
		return lastModified;
	}

	public boolean isEquivalent(Feed feed) {
		return id.equals(feed.getId()) && url.equals(feed.getUrl()) 
			&& title.equals(feed.getTitle()) && isEqualEvenWhenNull(etag, feed.getEtag())
			&& isEqualEvenWhenNull(lastModified, feed.getLastModified());
	}
	
	private boolean isEqualEvenWhenNull(String first, String second) {
		if (first == null) {
			return second == null;
		}
		return first.equals(second);
	}
}
