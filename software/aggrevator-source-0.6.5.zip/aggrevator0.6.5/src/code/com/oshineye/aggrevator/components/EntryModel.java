package com.oshineye.aggrevator.components;

import java.util.List;

import com.oshineye.aggrevator.Entry;
import com.oshineye.aggrevator.Feed;


public interface EntryModel extends FilterableModel, SortableModel {
	public static final int ENTRY_NOT_SELECTED = -1;

	void addObserver(EntryModelObserver observer);

	void loadEntries(List entries);

	void clear(Feed feed);

	void select(Entry entry);

	Entry getSelectedEntry();

	int getSelectedEntryIndex();
	
	boolean entrySelected();
	
	List getCurrentEntries();

	void markRead(String location);

	void refreshEntry(Entry entry);

}
