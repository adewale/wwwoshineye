package com.oshineye.aggrevator.db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.apache.log4j.Logger;

import com.oshineye.aggrevator.TunnellingException;

/**
 * Instances of this class are used to access databases when we want to ensure that resources
 * are acquired and released in the canonical manner.
 * @author aoshineye
 */
public class JdbcProcess {
	private static final Logger LOG = Logger.getLogger(JdbcProcess.class);
	private Connection conn;

	public JdbcProcess(Connection conn) {
		this.conn = conn;
	}

	protected Connection getConnection() {
		return this.conn;
	}

	public static void release(Connection conn, Statement stmt, ResultSet rset) {
		if (rset != null) {
			try {
				rset.close();
			} catch (SQLException sqle) {
				LOG.warn(sqle.getMessage(), sqle);
			}
		}

		if (stmt != null) {
			try {
				stmt.close();
			} catch (SQLException sqle) {
				LOG.warn(sqle.getMessage(), sqle);
			}
		}

		if (conn != null) {
			try {
				if (conn.isClosed()) {
					LOG.warn("Attempting to close an already closed connection: " + conn);
					return;
				}
				conn.close();
			} catch (SQLException sqle) {
				LOG.warn(sqle.getMessage(), sqle);
			}
		}
	}
	
	public Object executeQuery(String query, QueryBlock block) {
		long startTime = System.currentTimeMillis();
		PreparedStatement stmt = null;
		ResultSet rset = null;
		try {
			stmt = conn.prepareStatement(query);
			block.configure(stmt);
			rset = stmt.executeQuery();
			return block.process(rset);
		} catch (SQLException sqle) {
			throw new TunnellingException(query, sqle);
		} finally {
			logQueryTime(query, startTime, stmt);
			JdbcProcess.release(conn, stmt, rset);
		}
	}
	
	private void logQueryTime(String query, long startTime, Statement stmt) {
		LOG.debug("Query: " + String.valueOf(stmt) + " took: " + (System.currentTimeMillis() - startTime) + " milliseconds");
	}

	public int executeUpdate(String query, JdbcBlock block) {
		long startTime = System.currentTimeMillis();
		PreparedStatement stmt = null;
		try {
			stmt = conn.prepareStatement(query);
			block.configure(stmt);
			return stmt.executeUpdate();
		} catch (SQLException sqle) {
			throw new TunnellingException(query, sqle);
		} finally {
			logQueryTime(query, startTime, stmt);
			JdbcProcess.release(conn, stmt, null);
		}
	}
	
	public Object executeInsert(String query, JdbcBlock block) {
		long startTime = System.currentTimeMillis();
		PreparedStatement stmt = null;
		try {
			stmt = conn.prepareStatement(query);
			block.configure(stmt);
			stmt.executeUpdate();

			ResultSet rset = stmt.getGeneratedKeys();

			//when there are no generated keys in an insert the rset is null
			if (rset!= null && rset.next()) {
				Object generatedKey = rset.getObject(1);
				LOG.debug("Generated key was: " + generatedKey);
				return generatedKey;
			}
			return null;
			
		} catch (SQLException sqle) {
			throw new TunnellingException(query, sqle);
		} finally {
			logQueryTime(query, startTime, stmt);
			JdbcProcess.release(conn, stmt, null);
		}
	}

	public void executeCreate(String createString) {
		long startTime = System.currentTimeMillis();
		Statement stmt = null;
		try {
			stmt = conn.createStatement();// conn.prepareStatement(createString);
			stmt.execute(createString);
		} catch (SQLException sqle) {
			throw new TunnellingException(createString, sqle);
		} finally {
			logQueryTime(createString, startTime, stmt);
			JdbcProcess.release(conn, stmt, null);
		}
	}
}
