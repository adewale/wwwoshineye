package com.oshineye.aggrevator.store;

import java.io.File;
import java.util.List;

import com.oshineye.aggrevator.Feed;

/**
 * @author aoshineye
 *
 */
public class CachingFeedStore implements FeedStore {
	private FeedStore feedStore;
	private Cache cache;

	public CachingFeedStore(Cache cache, FeedStore feedStore, FeedIdentityMap feedIdentityMap) {
		this.cache = cache;
		this.feedStore = feedStore;
		feedIdentityMap.addAll(cache.getFeeds());
	}

	public void add(Feed feed) throws DuplicateFeedException {
		feedStore.add(feed);
	}

	public Feed findFeed(Long id) {
		return feedStore.findFeed(id);
	}

	public List findAllFeeds() {
		return cache.getFeeds();
	}

	public void delete(Feed feed) {
		feedStore.delete(feed);
	}

	public void deleteAll() {
		feedStore.deleteAll();
	}

	public void reconcile(Feed feed) {
		feedStore.reconcile(feed);
	}

	public void markRead(Feed feed) {
		feedStore.markRead(feed);
	}

	public boolean urlExists(Feed feed) {
		return feedStore.urlExists(feed);
	}

	public void update(Feed feed) {
		feedStore.update(feed);
	}

	public void shutDown() {
		cache.shutDown();
	}

	public static CachingFeedStore createCachingFeedStore(FeedStore feedStore, String name, FeedIdentityMap feedIdentityMap) {
		String cacheFile = name + "FeedCache.xml";
		Cache cache = new XStreamCache(new File(cacheFile), feedStore);
		CachingFeedStore cachingFeedStore = new CachingFeedStore(cache, feedStore, feedIdentityMap);
		return cachingFeedStore;
	}

	public List findAllFeedRecords() {
		return feedStore.findAllFeedRecords();
	}

}
