package com.oshineye.aggrevator.components;

import java.util.List;

import com.oshineye.aggrevator.Feed;

public interface FeedModel extends FilterableModel, SortableModel {

	void addObserver(FeedModelObserver observer);

	void loadFeeds();

	void addFeed(Feed feed);

	void deleteFeed(Feed feed);

	void refreshFeed(Feed feed);

	List getCurrentFeeds();

	void select(Feed feed);

	int getSelectedFeedIndex();

	boolean isSelected(Feed feed);
	
	boolean hasFeedSelected();

	Feed getSelectedFeed();

	void appendFeeds(List newFeeds);

	void entryRead(List feeds);

	void refreshFeeds(List feeds);

	boolean contains(Feed feed);
}
