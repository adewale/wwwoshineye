package com.oshineye.aggrevator.components;

import java.util.List;

/**
 * @author aoshineye
 *
 */
public interface RefreshQueue {
	public abstract void enqueue(List feeds);
}
