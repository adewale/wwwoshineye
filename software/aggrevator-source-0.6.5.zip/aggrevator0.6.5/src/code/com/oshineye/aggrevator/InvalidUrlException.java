package com.oshineye.aggrevator;

/**
 * @author aoshineye
 *
 */
public class InvalidUrlException extends RuntimeException {

	public InvalidUrlException(String message) {
		super(message);
	}

}
