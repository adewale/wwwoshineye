package com.oshineye.aggrevator;

/**
 * @author aoshineye
 *
 */
public class NoEntrySelectedException extends RuntimeException {
	//do nothing
}
