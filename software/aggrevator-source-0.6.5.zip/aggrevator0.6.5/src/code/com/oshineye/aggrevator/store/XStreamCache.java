package com.oshineye.aggrevator.store;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;

import org.apache.log4j.Logger;

import com.oshineye.aggrevator.Feed;
import com.oshineye.aggrevator.FeedRecord;
import com.oshineye.aggrevator.TunnellingException;
import com.oshineye.aggrevator.util.IOUtils;
import com.thoughtworks.xstream.XStream;
import com.thoughtworks.xstream.io.StreamException;

/**
 * @author aoshineye
 *
 */
public class XStreamCache implements Cache {
	private static final Logger LOG = Logger.getLogger(XStreamCache.class);
	private final File file;
	private final FeedFinder feedFinder;
	private List cachedFeeds;
	private final XStream xstream;

	public XStreamCache(File file, FeedFinder feedFinder) {
		this.file = file;
		this.feedFinder = feedFinder;
		this.xstream = new XStream();
		loadFeeds();
	}

	public List getFeeds() {
		return cachedFeeds;
	}
	
	private void loadFeeds() {
		FileReader fileReader = null;
		try {
			//ensure file exists
			file.createNewFile();
			
			fileReader = new FileReader(file);
			cachedFeeds = (List)xstream.fromXML(fileReader);
		} catch (StreamException se) {
			LOG.info("Cache file exists but contains invalid content, continuing", se);
		} catch (IOException e) {
			throw new TunnellingException(e);
		} finally {
			IOUtils.close(fileReader);
		}
		if (cachedFeeds == null || isInconsistent()) {
			LOG.warn("Unable to use cache. Loading feeds from store instead.");
			cachedFeeds = feedFinder.findAllFeeds();
		}
	}

	private boolean isInconsistent() {
		List feedRecords = feedFinder.findAllFeedRecords();
		if (cachedFeeds.size() != feedRecords.size()) {
			return true;
		}
		for (Iterator iter = cachedFeeds.iterator(); iter.hasNext();) {
			Feed feed = (Feed) iter.next();
			if (!contains(feedRecords, feed)) {
				return true;
			}
		}
		return false;
	}

	private boolean contains(List feedRecords, Feed feed) {
		for (Iterator iter = feedRecords.iterator(); iter.hasNext();) {
			FeedRecord record = (FeedRecord) iter.next();
			if (record.isEquivalent(feed)) {
				return true;
			}
		}
		return false;
	}

	public void shutDown() {
		//triple file backup system
		//file -> bak -> old
		//so that if the user starts up the system and realises that they've corrupted the cache
		//they can still recover. It might also form the basis of a disaster recovery feature
		//(e.g people who lose their store for some reason and want to do a new 
		//installatation but carry across all their subscriptions with edited names and scores)
		if (file.exists()) {
			File backUpFile = new File(file.getName() + ".bak");
			File oldestBackUpFile = new File(backUpFile.getName() + ".old");
			
			oldestBackUpFile.delete();
			backUpFile.renameTo(oldestBackUpFile);
			file.renameTo(backUpFile);
		}
		
		FileWriter fileWriter = null;
		try {
			fileWriter = new FileWriter(file);
			xstream.toXML(cachedFeeds, fileWriter);
		} catch (IOException e) {
			LOG.warn("Something went wrong whilst persisting the cache", e);
		} finally {
			IOUtils.close(fileWriter);
		}
	}

}
