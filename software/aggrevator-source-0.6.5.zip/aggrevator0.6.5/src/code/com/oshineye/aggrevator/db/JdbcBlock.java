package com.oshineye.aggrevator.db;

import java.sql.PreparedStatement;
import java.sql.SQLException;

/**
 * @author aoshineye
 * 
 * Implementations of this interface provide a block of code that can be run by the framework
 * to perform arbitrary SQL queries when we don't get a resultset back.
 */
public interface JdbcBlock {
	/**
	 * @param stmt
	 */
	public void configure(PreparedStatement stmt) throws SQLException;

}
