package com.oshineye.aggrevator.components;

import java.util.List;

import com.oshineye.aggrevator.store.EntryStore;

/**
 * @author aoshineye
 */
public class BrowserControllerImpl implements BrowserController {

	private FeedModel feedModel;
	private EntryModel entryModel;
	private EntryStore entryStore;
	private BrowserModel browserModel;

	public BrowserControllerImpl(FeedModel feedModel, EntryModel entryModel, BrowserModel browserModel, EntryStore entryStore) {
		this.feedModel = feedModel;
		this.entryModel = entryModel;
		this.entryStore = entryStore;
		this.browserModel = browserModel;
	}

	public void handleLocationVisited(String location) {
		if (entryStore.markRead(location)) {
			List relatedFeeds = entryStore.getRelatedFeeds(location);
			feedModel.entryRead(relatedFeeds);
			entryModel.markRead(location);
		}
		browserModel.setLocation(location);
	}

}
