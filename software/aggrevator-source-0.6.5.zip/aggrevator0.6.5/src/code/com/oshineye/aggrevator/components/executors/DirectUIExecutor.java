package com.oshineye.aggrevator.components.executors;

import com.oshineye.aggrevator.components.tasks.Task;

/**
 * @author aoshineye
 *
 * Execute Task directly on the current thread on the assumption that this thread
 * is the SWT UI thread
 */
public class DirectUIExecutor implements UserInterfaceExecutor {

	public void execute(Task task) {
		task.run();
	}

}
