package com.oshineye.aggrevator.components;

import org.apache.commons.lang.StringEscapeUtils;

import com.oshineye.aggrevator.Entry;

/**
 * @author aoshineye
 * Format content into html format for display
 */
public class ContentFormatter {
	private static final String HTML_START = "<html><head><title></title></head><body>" 
	+ "<div><span style=\"background-color:#cccccc;display:block;\">";
	private static final String HTML_END = "</div></body></html>";
	private Entry entry;

	public ContentFormatter(Entry entry) {
		this.entry = entry;
	}
	
	public String getFormattedContent() {
		String content = HTML_START
			+ entry.getFeedTitle()
			+ " :: " + createLink(entry.getTitle(), entry.getUrl())
			+ "</span>" + entry.getContent() + HTML_END;
		
		content = content.replaceAll("&quot;", "\"");
		return content;
	}
	
	private String createLink(String text, String url) {
		if (Entry.NO_LINK == url) {
			return "";
		}
		return "<a href=\"" + url + "\">" + StringEscapeUtils.escapeHtml(text) + "</a>";
	}
}
