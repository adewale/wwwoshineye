package com.oshineye.aggrevator.components;

import org.eclipse.swt.events.ModifyEvent;
import org.eclipse.swt.events.ModifyListener;
import org.eclipse.swt.widgets.Text;

/**
 * @author aoshineye
 */
public class Filter implements ModifyListener {
	private FilterableModel model;
	private Text searchInput;

	public Filter(FilterableModel model, Text searchInput) {
		this.model = model;
		this.searchInput = searchInput;
	}

	public void modifyText(ModifyEvent e) {
		model.loadMatchingItems(searchInput.getText());
	}

}
