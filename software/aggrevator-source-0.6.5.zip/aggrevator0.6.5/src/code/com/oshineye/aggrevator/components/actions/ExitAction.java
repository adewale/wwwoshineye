package com.oshineye.aggrevator.components.actions;

import org.eclipse.jface.action.Action;
import org.eclipse.jface.window.ApplicationWindow;

import com.oshineye.aggrevator.components.ThreadPool;

/**
 * @author aoshineye
 *
 */
public class ExitAction extends Action {
	private ApplicationWindow window;
	private ThreadPool threadPool;

	public ExitAction(ApplicationWindow window, ThreadPool threadPool) {
		this.window = window;
		this.threadPool = threadPool;
		this.setText("E&xit@Ctrl+Q");
	}
	
	public void run() {
		threadPool.shutDownNow();
		window.close();
	}
}
