package com.oshineye.aggrevator.util;

import java.net.URLEncoder;

/**
 * @author aoshineye
 *
 */
public class URLUtils {
	public static String generateFeedsterSearchUrl(String searchTerm) {
		return "http://feedster.com/search.php?q=" + URLEncoder.encode(searchTerm) + "&sort=&ie=UTF-8&hl=&content=full&type=rss&limit=15";
	}
	
	
	public static String generateBlogDiggerSearchUrl(String searchTerm) {
		//FIXME implement blogdigger search feeds
		//two keywords
		//http://www.blogdigger.com/rss.jsp?q=aggrevator+mysql&sortby=date
		//phrase
		//http://www.blogdigger.com/rss.jsp?q=%22aggrevator+mysql%22&sortby=date
		return null;
	}
}
