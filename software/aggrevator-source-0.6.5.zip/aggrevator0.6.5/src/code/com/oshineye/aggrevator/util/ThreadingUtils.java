package com.oshineye.aggrevator.util;

import org.apache.log4j.Logger;
import org.eclipse.swt.widgets.Display;

/**
 * @author aoshineye
 *
 */
public class ThreadingUtils {
	private static Logger LOG = Logger.getLogger(ThreadingUtils.class);
	
	//A verbose equivalent of Thread.sleep() intended for debugging threading 
	//issues which doesn't require any exception
	//handling but which announces it's presence in the hope that
	//it's less likely to end up in released code
	public static void sleep(long milliSeconds) {
		try {
			LOG.warn("Thread: " + Thread.currentThread() + " sleeping for " + milliSeconds + " milliseconds");
			Thread.sleep(milliSeconds);
			LOG.warn("Finished sleeping");
		} catch (InterruptedException e) {
			//throwing this means that code that's expecting an exception to
			//indicate thread interruption/cancellation still works
			throw new RuntimeException(e);
		}
	}
	
	public static boolean inUIThread() {
		return Display.getCurrent() != null;
	}
}
