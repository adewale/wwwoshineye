package com.oshineye.aggrevator.components.commands.worker.background;

import com.oshineye.aggrevator.Feed;
import com.oshineye.aggrevator.store.EntryStore;
import com.oshineye.aggrevator.store.FeedStore;

/**
 * @author aoshineye
 *
 */
public class DeleteFeedCommand implements Runnable {
	private Feed feed;
	private FeedStore feedStore;
	private EntryStore entryStore;

	public DeleteFeedCommand(Feed feed, FeedStore feedStore, EntryStore entryStore) {
		this.feed = feed;
		this.feedStore = feedStore;
		this.entryStore = entryStore;
	}

	public void run() {
		feedStore.delete(feed);
		entryStore.delete(feed);
	}
}
