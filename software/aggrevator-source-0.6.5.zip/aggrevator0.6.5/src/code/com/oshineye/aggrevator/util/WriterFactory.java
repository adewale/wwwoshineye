package com.oshineye.aggrevator.util;

import java.io.File;
import java.io.IOException;
import java.io.Writer;

/**
 * @author aoshineye
 *
 */
public interface WriterFactory {
	public Writer getWriter(File file) throws IOException ;
}
