package com.oshineye.aggrevator;

/**
 * @author aoshineye
 */
public class NothingReadException extends RuntimeException {
	//do nothing
}
