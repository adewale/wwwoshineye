package com.oshineye.aggrevator.components;

import java.lang.reflect.InvocationTargetException;

import org.apache.log4j.Logger;
import org.eclipse.jface.dialogs.ProgressMonitorDialog;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.MessageBox;
import org.eclipse.swt.widgets.Shell;

import com.oshineye.aggrevator.components.commands.worker.foreground.SearchCommand;
import com.oshineye.aggrevator.components.tasks.Task;
import com.oshineye.aggrevator.store.EntryStore;
import com.oshineye.aggrevator.store.SearchSpecification;

/**
 * @author aoshineye
 */
public class SearchController {
	private static final Logger LOG = Logger.getLogger(SearchController.class);
	private EntryModel entryModel;
	private EntryStore entryStore;
	private SearchSpecification searchSpecification;
	private Shell shell;
	private StatusRecorder recorder;

	public SearchController(EntryModel entryModel, SearchSpecification searchSpecification,
		EntryStore entryStore, Shell shell, StatusRecorder recorder) {
		this.entryModel = entryModel;
		this.entryStore = entryStore;
		this.searchSpecification = searchSpecification;
		this.shell = shell;
		this.recorder = recorder;
	}

	public void handleSearch() {
		if (searchSpecification.isPopulated()) {
			search();
			return;
		}
		Display display = shell.getDisplay();
		display.syncExec(new Task() {//invoke and wait
			public void doWork() {
				MessageBox messageBox = new MessageBox(shell, SWT.YES|SWT.NO|SWT.ICON_QUESTION);
				messageBox.setText("Searching with no parameters will bring back all entries");
				messageBox.setMessage("Do you want to continue with this search?");
				if (messageBox.open() == SWT.NO) {
					return;
				}
				search();
			}
		});
	}

	private void search() {
		try {
			ProgressMonitorDialog dialog = new ProgressMonitorDialog(shell);
			
			//dialog runs in the UI thread with a new worker thread being started for the command
			SearchCommand command = new SearchCommand(entryModel, searchSpecification, entryStore, recorder);
			dialog.run(true, true, command);
		} catch (InvocationTargetException e) {
			LOG.warn(e.getMessage(), e);
		} catch (InterruptedException e) {
			LOG.warn(e.getMessage(), e);
		}
	}
}
