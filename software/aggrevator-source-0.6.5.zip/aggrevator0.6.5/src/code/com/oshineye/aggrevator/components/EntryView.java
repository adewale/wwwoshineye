package com.oshineye.aggrevator.components;

/**
 * @author aoshineye
 */
public interface EntryView extends EntryModelObserver, ListView {

	int getItemCount();

}
