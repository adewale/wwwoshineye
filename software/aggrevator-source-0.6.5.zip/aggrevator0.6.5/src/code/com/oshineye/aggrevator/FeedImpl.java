package com.oshineye.aggrevator;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.lang.time.DateFormatUtils;
import org.apache.log4j.Logger;

import com.oshineye.aggrevator.util.StringUtils;

/**
 * An RSS/RDF/ATOM feed
 *
 * @author aoshineye
 */
public class FeedImpl implements Feed {
	private static final Logger LOG = Logger.getLogger(FeedImpl.class);

	private String title;
	private boolean read;
	private int unreadEntriesCount;
	private int score;
	
	//this field should never be serialized or permanently stored
	private transient boolean refreshing;
	
	private Long id;
	private String formattedLastModified;
	private Date lastModifiedDate;
	private HttpLocation httpLocation;
	
	//this field should never be serialized or permanently stored
	private final transient InformaParser parser;
	
	/**
	 * Construct a feed pointing to the file at the url.
	 * Throws InvalidUrlException if url is null or an empty string.
	 * @param newUrl
	 * @param parser
	 */
	public FeedImpl(String newUrl, InformaParser parser) {
		if ((null == newUrl) || ((newUrl = newUrl.trim()).equals(""))) {
			throw new InvalidUrlException("Attempted to create feed with an invalid url: " + newUrl);
		}
		this.httpLocation = createLocation(newUrl, null, null);
		this.setUrl(normalise(newUrl));
		this.setTitle(Feed.NO_TITLE);
		this.updateFeedReadStatus(0);
		this.id = PLACE_HOLDER_ID;
		this.parser = parser;
	}
	
	protected FeedImpl(Long id, String url, String title, int unreadEntriesCount, int score, String etag, String lastModified, InformaParser parser) {
		this.httpLocation = createLocation(url, etag, lastModified);
		this.id = id;
		this.setUrl(url);
		this.setTitle(title);
		this.updateFeedReadStatus(unreadEntriesCount);
		this.score = score;
		this.setLastModified(lastModified);
		this.parser = parser;
	}
	
	protected HttpLocation createLocation(String locationUrl, String locationEtag, String locationLastModified) {
		return new HttpLocation(locationUrl, locationEtag, locationLastModified);
	}
	
	private String normalise(String unnormalisedUrl) {
		if (unnormalisedUrl.startsWith("feed://")) {
			return "http://" + unnormalisedUrl.substring("feed://".length());
		}
		if (unnormalisedUrl.startsWith("feed:")) {
			return unnormalisedUrl.substring("feed:".length());
		}
		return unnormalisedUrl;
	}

	public void setTitle(String newTitle) {
		String unescapedHtmlTitle = StringUtils.unescapeHtml(newTitle);
		this.title = StringUtils.valueOfWithDefault(unescapedHtmlTitle, "");
	}
	
	public List fetchNewEntries() {
		List newEntries = parser.fetchNewEntries(httpLocation, getId());
		if (Feed.NO_TITLE.equals(this.getTitle())) {
			this.setTitle(parser.getFeedTitle());
		}
		return newEntries;
	}

	public List fetchNewEntries(EntryFinder finder) {
	    List newEntries = this.fetchNewEntries();
		if (newEntries.isEmpty()) {
			return newEntries;
		}
		List oldEntries = finder.findMatchingEntriesInFeed(getId(), newEntries);
		filterOutOldEntries(oldEntries, newEntries);
		LOG.info(this + " had " + newEntries.size() + " new entries");
		
		updateFeedReadStatus(unreadEntriesCount + newEntries.size());
		return newEntries;
	}

	private void filterOutOldEntries(List oldEntries, List fetchedEntries) {
        for (Iterator iter = fetchedEntries.iterator(); iter.hasNext();) {
			Entry element = (Entry) iter.next();
			if (oldEntries.contains(element)) {
				iter.remove();
			}
		}
    }

	public boolean hasChanged() throws IOException {
	    return httpLocation.hasLocationBeenModified();
	}

	public boolean equals(Object other) {
		if (other == null) {
			return false;
		}

		//actual equality testing takes place here
		Feed otherFeed = (Feed) other;
		return this.id.equals(otherFeed.getId());
	}
	
	public int hashCode() {
		/*
		The valueOf was added because when using reflection to create a FeedImpl
		inside XStream it is possible to call hashCode even though the object hasn't been properly
		constructed yet. This only happens on Linux using java 1.4.2_05.
		*/
		return getId() == null ? String.valueOf(getId()).hashCode() : getId().hashCode();
	}

	public String getTitle() {
		return title;
	}

	public boolean isRead() {
		return read;
	}
	
	public String toString() {
		return "Feed: " + getUrl();
	}

	public void incrementReadEntryCount() {
		updateFeedReadStatus(unreadEntriesCount - 1);
	}

	private void updateFeedReadStatus(int newValueForUnreadEntriesCount) {
		setUnreadEntriesCount(newValueForUnreadEntriesCount);
		read = (unreadEntriesCount == 0);
	}

	public int getUnreadEntriesCount() {
		return unreadEntriesCount;
	}

	public void incrementScore() {
		score += Feed.SCORE_UNITS;
	}

	public int getScore() {
		return score;
	}

	public void decrementScore() {
		score -= Feed.SCORE_UNITS;
	}

	public synchronized void setRefreshStarted() throws RefreshInProgressException {
		if (refreshing) {
			throw new RefreshInProgressException();
		}
		refreshing = true;
	}

	public boolean isRefreshing() {
		return refreshing;
	}

	public synchronized void setRefreshFinished() {
		refreshing = false;
	}

	public void setUrl(String newUrl) {
		httpLocation.setUrl(newUrl);
	}
	
	public String getUrl() {
		return httpLocation.getUrl();
	}
	
	public String getEtag() {
		return httpLocation.getEtag();
	}

	public void setLastModified(String value) {
        this.formattedLastModified = formatLastModified();
		this.lastModifiedDate = parseDate();
    }
	
	private String formatLastModified() {
		Date date = parseDate();
		if (date == null) {
			return null;
		}
		return DateFormatUtils.format(date, Configuration.DATE_FORMAT);
	}
	
	private Date parseDate() {
		if (httpLocation.getLastModified() == null) {
			return null;
		}
		Date date = null;
		try {
			SimpleDateFormat simpleDateFormat = new SimpleDateFormat("EE, d MMM yyyy HH:mm:ss");
			date = simpleDateFormat.parse(httpLocation.getLastModified());
		} catch (java.text.ParseException e) {
			//this will happen a lot and is to be expected
			LOG.debug(e.toString() + " " + "Last Modified: " + httpLocation.getLastModified() + " was malformed");
		}
		return date;
	}

	public String getLastModified() {
		return httpLocation.getLastModified();
	}

	public Date getLastModifiedDate() {
		return lastModifiedDate;
	}
	
	public String getFormattedDate() {
		return formattedLastModified;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		if (isStored()) {
			throw new IllegalStateException("Attempting to set primary key more than once");
		}
		this.id = id;
	}

	public boolean isStored() {
		return !PLACE_HOLDER_ID.equals(id);
	}

	public void markRead() {
		read = true;
		setUnreadEntriesCount(0);
	}

	public void entryRead() {
		incrementReadEntryCount();
		score += Feed.ENTRY_READ_SCORE;
	}

    public boolean hasSameUrl(Object object) {
        if (object == null) {
            return false;
        }
        Feed otherFeed = (Feed) object;
        return getUrl().equalsIgnoreCase(otherFeed.getUrl());
    }

	public void update(int unreadEntriesCount, int score) {
		this.updateFeedReadStatus(unreadEntriesCount);
		this.score = score;
	}
	
	private void setUnreadEntriesCount(int newValueForUnreadEntriesCount) {
		if (newValueForUnreadEntriesCount < 0) {
			this.unreadEntriesCount = 0;
			return;
		}
		this.unreadEntriesCount = newValueForUnreadEntriesCount;
	}
	
	protected void setLocation(HttpLocation location) {
		this.httpLocation = location;
	}

}
