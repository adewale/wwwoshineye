package com.oshineye.aggrevator.store;

import org.apache.commons.lang.StringUtils;

/**
 * @author aoshineye
 *
 */
public class SearchSpecification {

	private String titleField;
	private String contentField;
	private String feedTitleField;
	private boolean multipleFieldsPopulated;
	
	public SearchSpecification() {
		clear();
	}

	public void setTitleField(String text) {
		this.titleField = text;
	}

	public void setContentField(String text) {
		this.contentField = text;
	}
	
	public void setFeedTitleField(String text) {
		this.feedTitleField = text;
	}

	public String getTitleField() {
		return titleField;
	}
	
	public String getContentField() {
		return contentField;
	}

	public String getFeedTitleField() {
		return feedTitleField;
	}

	public boolean contentFieldPopulated() {
		return !StringUtils.isEmpty(contentField);
	}

	public boolean titleFieldPopulated() {
		return !StringUtils.isEmpty(titleField);
	}

	public boolean feedTitleFieldPopulated() {
		return !StringUtils.isEmpty(feedTitleField);
	}

	public String toString() {
		StringBuffer representation = new StringBuffer();

		if (feedTitleFieldPopulated()) {
			appendFirst(representation, "feedTitleContains", feedTitleField);
		}

		if (titleFieldPopulated()) {
			append(representation, "titleContains", titleField);
		}

		if (contentFieldPopulated()) {
			append(representation, "contentContains", contentField);
		}
		return representation.toString();
	}

	private void appendFirst(StringBuffer representation, String fieldName, String field) {
		representation.append(fieldName + "(" + field + ")");
		multipleFieldsPopulated = true;
	}
	
	private void append(StringBuffer representation, String fieldName, String field) {
		appendAndIfMultipleFeedsPopulated(representation);
		representation.append(fieldName + "(" + field + ")");
		multipleFieldsPopulated = true;
	}
	
	private void appendAndIfMultipleFeedsPopulated(StringBuffer representation) {
		if (multipleFieldsPopulated) {
			representation.append(" AND ");
			multipleFieldsPopulated = false;
		}
	}

	public boolean isPopulated() {
		return feedTitleFieldPopulated() || titleFieldPopulated() 
			|| contentFieldPopulated();
	}

	public void clear() {
		this.feedTitleField = null;
		this.titleField = null;
		this.contentField = null;
		this.multipleFieldsPopulated = false;
	}
}
