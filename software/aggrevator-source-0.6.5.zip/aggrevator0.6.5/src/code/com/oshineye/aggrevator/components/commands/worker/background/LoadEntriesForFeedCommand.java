package com.oshineye.aggrevator.components.commands.worker.background;

import java.util.List;

import com.oshineye.aggrevator.Feed;
import com.oshineye.aggrevator.components.EntryModel;
import com.oshineye.aggrevator.components.StatusRecorder;
import com.oshineye.aggrevator.components.executors.UserInterfaceExecutor;
import com.oshineye.aggrevator.components.tasks.Task;
import com.oshineye.aggrevator.store.EntryStore;


public class LoadEntriesForFeedCommand implements Runnable {

	private EntryModel entryModel;
	private Feed feed;
	private EntryStore entryStore;
	private final UserInterfaceExecutor uiExecutor;
	private StatusRecorder recorder;

	public LoadEntriesForFeedCommand(Feed feed, EntryModel entryModel, EntryStore entryStore, UserInterfaceExecutor uiExecutor, StatusRecorder recorder) {
		this.feed = feed;
		this.entryModel = entryModel;
		this.entryStore = entryStore;
		this.uiExecutor = uiExecutor;
		this.recorder = recorder;
	}

	public void run() {
		recorder.setStatus("Loading " + feed);
		final List entriesInFeed = entryStore.findEntriesInFeed(feed.getId());
		uiExecutor.execute(new Task() {
			public void doWork() {
				entryModel.loadEntries(entriesInFeed);
				recorder.setStatus("Loaded " + feed);
			}
		});
	}

}
