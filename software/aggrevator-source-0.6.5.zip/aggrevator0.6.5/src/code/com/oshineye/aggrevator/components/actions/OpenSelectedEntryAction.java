package com.oshineye.aggrevator.components.actions;

import java.lang.reflect.InvocationTargetException;

import org.apache.log4j.Logger;
import org.eclipse.jface.dialogs.ProgressMonitorDialog;
import org.eclipse.jface.window.ApplicationWindow;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.MessageBox;
import org.eclipse.swt.widgets.Shell;

import com.oshineye.aggrevator.Entry;
import com.oshineye.aggrevator.components.EntryModel;
import com.oshineye.aggrevator.components.FeedModel;
import com.oshineye.aggrevator.components.commands.worker.foreground.OpenInBrowserCommand;

/**
 * @author aoshineye
 *
 */
public class OpenSelectedEntryAction extends AbstractEntrySelectedAction {
	private static final Logger LOG = Logger.getLogger(OpenSelectedEntryAction.class);
	private ApplicationWindow window;

	public OpenSelectedEntryAction(FeedModel feedModel, EntryModel entryModel, ApplicationWindow window) {
		super(feedModel, entryModel);
		this.window = window;
		this.setText("&Open Selected Entry");
		this.setToolTipText("Open selected entry in external browser");
	}
	
	public void run() {
		final String url = getUrlToOpen();
		final Shell shell = window.getShell();
		ProgressMonitorDialog dialog = new ProgressMonitorDialog(shell);
		
		try {
			dialog.run(true, true, new OpenInBrowserCommand(url));
		} catch (InvocationTargetException e) {
			informUserOfError(shell, e, url);
		} catch (InterruptedException e) {
			informUserOfError(shell, e, url);
		}
	}

	protected String getUrlToOpen() {
		EntryModel entryModel = getEntryModel();
		Entry entry = entryModel.getSelectedEntry();
		return entry.getUrl();
	}

	private void informUserOfError(Shell shell, Exception exception, String url) {
		LOG.warn(exception.getMessage(), exception);
		MessageBox messageBox = new MessageBox(shell, SWT.ICON_ERROR);
		messageBox.setText("Error launching browser");
		messageBox.setMessage("Unable to launch external browser for " + url);
		messageBox.open();
	}	
}
