package com.oshineye.aggrevator.store;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.oshineye.aggrevator.Feed;
import com.oshineye.aggrevator.FeedFactory;
import com.oshineye.aggrevator.FeedRecord;
import com.oshineye.aggrevator.TunnellingException;
import com.oshineye.aggrevator.db.AbstractQueryBlock;
import com.oshineye.aggrevator.db.JdbcBlock;
import com.oshineye.aggrevator.db.JdbcProcess;
import com.oshineye.aggrevator.db.JdbcProcessFactory;
import com.oshineye.aggrevator.util.QueryLoader;

/**
 * @author aoshineye
 *
 */
public class MySqlFeedStore extends MySqlStore implements FeedStore {
	private static final int SCORE_INDEX = 1;
	private static final int UNREAD_ENTRIES_COUNT_INDEX = 0;
	private static final String SCORE = "score";
	private static final String UNREAD = "unread";
	private static final String LAST_MODIFIED = "last_modified";
	private static final String ETAG = "etag";
	private static final String FEED_TITLE = "title";
	private static final String URL = "url";
	private static final String ID = "feed_id";
	private JdbcProcessFactory factory;
	protected FeedIdentityMap feedIdentityMap;
	private QueryLoader queryLoader;

	public MySqlFeedStore(String databaseName, FeedIdentityMap feedIdentityMap, QueryLoader queryLoader) {
		super(databaseName);
		this.queryLoader = queryLoader;
		factory = getJdbcProcessFactory();
		this.feedIdentityMap = feedIdentityMap;
	}

	public void add(final Feed feed) {
	    if (feed.isStored() || urlExists(feed)) {
	    	throw new DuplicateFeedException(feed);
		}

		JdbcProcess process = factory.createProcess();
		Long id = (Long) process.executeInsert(queryLoader.getQuery("ADD_FEED"), new JdbcBlock() {
			public void configure(PreparedStatement stmt) throws SQLException {
				stmt.setString(1, feed.getUrl());
				stmt.setString(2, feed.getTitle());
				stmt.setString(3, feed.getEtag());
				stmt.setString(4, feed.getLastModified());
			}
		});
		
		feed.setId(id);
		
		feedIdentityMap.add(feed);
	}

	private void loadAllFeeds() {
		//FIXME are there situations where this N+1 query code is preferrable 
		//to 1 query with a very large timeout?
		//This approach does have the advantage that the timeout won't have to
		//keep being increased as we get more data so it's arguably more scalable
//		List allFeeds = new ArrayList();
//		List feedRecords = findAllFeedRecords();
//		for (Iterator iter = feedRecords.iterator(); iter.hasNext();) {
//			FeedRecord record = (FeedRecord) iter.next();
//			int[] feedState = getFeedState(record.getId());
//			Feed newFeed = FeedFactory.createFeedFromStore(record.getId().longValue(), record.getUrl(), record.getTitle(),
//				feedState[UNREAD_ENTRIES_COUNT_INDEX], feedState[SCORE_INDEX], record.getEtag(), record.getLastModified());
//			allFeeds.add(newFeed);
//		}
		
       JdbcProcess process = factory.createProcess();
		List allFeeds = (List) process.executeQuery(queryLoader.getQuery("GET_ALL_FEEDS"), new AbstractQueryBlock() {
			public Object process(ResultSet rset) throws SQLException {
				List feeds = new ArrayList();
				while (rset.next()) {
					Feed feed = makeFeed(rset);
					feeds.add(feed);
				}
				return feeds;
			}
		});
		
		feedIdentityMap.addAll(allFeeds);
	}

	private Feed makeFeed(ResultSet rset) throws SQLException {
		int id = rset.getInt(ID);
		String url = rset.getString(URL);
		String title = rset.getString(FEED_TITLE);
		String etag = rset.getString(ETAG);
		String lastModified = rset.getString(LAST_MODIFIED);
		int unreadEntryCount = rset.getInt(UNREAD);
		int score = rset.getInt(SCORE);
		
		return FeedFactory.createFeedFromStore(id, url, title, unreadEntryCount, score, etag, lastModified);
	}

	public List findAllFeedRecords() {
		JdbcProcess process = factory.createProcess();
		List allFeedRecords = (List) process.executeQuery(queryLoader.getQuery("GET_ALL_FEEDRECORDS"), new AbstractQueryBlock(){
			public Object process(ResultSet rset) throws SQLException {
				List records = new ArrayList();
				while (rset.next()) {
					FeedRecord record = makeFeedRecord(rset);
					records.add(record);
				}
				return records;
			}
		});
		return allFeedRecords;
	}
	
	protected FeedRecord makeFeedRecord(ResultSet rset) throws SQLException {
		int id = rset.getInt(ID);
		String url = rset.getString(URL);
		String title = rset.getString(FEED_TITLE);
		String etag = rset.getString(ETAG);
		String lastModified = rset.getString(LAST_MODIFIED);
		
		return FeedFactory.createFeedRecordFromStore(id, url, title, etag, lastModified);
	}

	public List findAllFeeds() {
		if (!feedIdentityMap.isPopulated()) {
			loadAllFeeds();
		}
		return feedIdentityMap.findAllFeeds();
	}

	public void delete(final Feed feed) {
		JdbcProcess process = factory.createProcess();
		process.executeUpdate(queryLoader.getQuery("DELETE_FEED"), new JdbcBlock() {
			public void configure(PreparedStatement stmt) throws SQLException {
				stmt.setLong(1, feed.getId().longValue());
			}
		});
		feedIdentityMap.remove(feed);
	}

	public void deleteAll() {
		JdbcProcess process = factory.createProcess();
		process.executeUpdate(queryLoader.getQuery("DELETE_ALL_FEEDS"), new JdbcBlock() {
			public void configure(PreparedStatement stmt) {
				//do nothing
			}
		});
		feedIdentityMap.removeAll();
	}

	public void reconcile(final Feed feed) {
		update(feed);
		
		int[] feedState = getFeedState(feed.getId());
		int unreadEntriesCount = feedState[UNREAD_ENTRIES_COUNT_INDEX];
		int score = feedState[SCORE_INDEX]; 
		feed.update(unreadEntriesCount, score);
	}

	private int[] getFeedState(final Long id) {
		JdbcProcess process = factory.createProcess();
		int[] feedState = (int[]) process.executeQuery(queryLoader.getQuery("GET_FEED_STATE"), new AbstractQueryBlock() {
			public void configure(PreparedStatement stmt) throws SQLException {
				stmt.setLong(1, id.longValue());
			}
			
			public Object process(ResultSet rset) throws SQLException {
				int[] feedState = new int[2];
				if (rset.next()) {
					feedState[UNREAD_ENTRIES_COUNT_INDEX] = rset.getInt(1);
					feedState[SCORE_INDEX] = rset.getInt(2);
					return feedState;
				}
				throw new TunnellingException(id + " not found");
			}
		});
		return feedState;
	}

	public void update(final Feed feed) {
		JdbcProcess process = factory.createProcess();
		process.executeUpdate(queryLoader.getQuery("UPDATE_FEED"), new JdbcBlock() {
			public void configure(PreparedStatement stmt) throws SQLException {
				stmt.setString(1, feed.getUrl());
				stmt.setString(2, feed.getTitle());
				stmt.setString(3, feed.getEtag());
				stmt.setString(4, feed.getLastModified());
				stmt.setLong(5, feed.getId().longValue());
			}
		});
	}

	public void markRead(final Feed feed) {
		JdbcProcess process = factory.createProcess();
		process.executeUpdate(queryLoader.getQuery("UPDATE_FEED_MARKING_ALL_ENTRES_AS_READ"), new JdbcBlock() {
			public void configure(PreparedStatement stmt) throws SQLException {
				stmt.setLong(1, feed.getId().longValue());
			}
		});
		feed.markRead();
	}

	public boolean urlExists(Feed feed) {
		return feedIdentityMap.urlExists(feed.getUrl());
	}

	public Feed findFeed(final Long id) {
		JdbcProcess process = factory.createProcess();
		Feed storedFeed = (Feed) process.executeQuery(queryLoader.getQuery("GET_FEED"), new AbstractQueryBlock(){
			public void configure(PreparedStatement stmt) throws SQLException {
				stmt.setLong(1, id.longValue());
				stmt.setLong(2, id.longValue());
			}
			
			public Object process(ResultSet rset) throws SQLException {
				if (rset.next()) {
					return makeFeed(rset);
				}
				throw new TunnellingException("Feed with id: " + id + " not found");
			}
		});
		return storedFeed;
	}
}