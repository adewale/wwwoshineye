package com.oshineye.aggrevator.util;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;

import org.apache.log4j.Logger;

/**
 * @author aoshineye
 *
 */
public class IOUtils {
	private static final Logger LOG = Logger.getLogger(IOUtils.class);
	public static void close(Reader reader) {
		try {
			if (reader == null) {
				LOG.warn("Attempted to close null reader");
				return;
			}
			reader.close();
		} catch (IOException e) {
			LOG.warn(e.getMessage(), e);
		}
	}
	public static void close(Writer writer) {
		try {
			if (writer == null) {
				LOG.warn("Attempted to close null writer");
				return;
			}
			writer.close();
		} catch (IOException e) {
			LOG.warn(e.getMessage(), e);
		}
	}

}
