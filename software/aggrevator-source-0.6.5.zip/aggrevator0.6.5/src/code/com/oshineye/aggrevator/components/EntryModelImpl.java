package com.oshineye.aggrevator.components;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

import com.oshineye.aggrevator.Entry;
import com.oshineye.aggrevator.Feed;
import com.oshineye.aggrevator.NoEntrySelectedException;


public class EntryModelImpl extends AbstractModel implements EntryModel {
	private Entry selectedEntry;
	private List observers;
	private List currentEntries;
	private List allEntries;
	private String currentSearchText;
	
	public EntryModelImpl() {
		observers = new ArrayList();
		ensureEntriesCleared();
		currentSearchText = "";
	}

	public void addObserver(EntryModelObserver observer) {
		observers.add(observer);
	}

	public void loadEntries(List loadedEntries) {
		allEntries = new ArrayList(loadedEntries);
		loadMatchingItems(currentSearchText);
	}

	private void notifyObserversEntriesLoaded(List entriesLoaded) {
		for (Iterator iter = observers.iterator(); iter.hasNext();) {
			EntryModelObserver observer = (EntryModelObserver) iter.next();
			observer.notifyEntriesLoaded(entriesLoaded);
		}
	}

	public void clear(Feed feed) {
		ensureEntriesCleared();
		selectNone();
		
		for (Iterator iter = observers.iterator(); iter.hasNext();) {
			EntryModelObserver observer = (EntryModelObserver) iter.next();
			observer.notifyEntriesCleared();
		}
	}
	
	private void ensureEntriesCleared() {
		//this is more efficient than calling list.clear()
		//and safer because they lists are now immutable until replaced
		currentEntries = Collections.EMPTY_LIST;
		allEntries = Collections.EMPTY_LIST;
	}

	public void select(Entry entry) {
		this.selectedEntry = entry;
	}

	private void selectNone() {
		select(null);
	}
	
	public Entry getSelectedEntry() {
		if (selectedEntry == null) {
			throw new NoEntrySelectedException();
		}
		return selectedEntry;
	}

	public int getSelectedEntryIndex() {
		return currentEntries.indexOf(selectedEntry);
	}
	
	public boolean entrySelected() {
		if (selectedEntry == null) {
			return false;
		}
		return true;
	}

	public void loadMatchingItems(String searchText) {
		currentSearchText = searchText;
		
		if (searchText.equals("")) {
			updateWithMatchingItems(allEntries);
			return;
		}

		List matchingItems = findMatchingItems(searchText, allEntries);
		if (isAlreadyShowing(matchingItems)) {
			return;
		}
		sortWithPreviousComparator(matchingItems);
		updateWithMatchingItems(matchingItems);
	}

	private void updateWithMatchingItems(List matchingItems) {
		currentEntries = matchingItems;
		notifyObserversEntriesLoaded(matchingItems);
	}

	public List getCurrentEntries() {
		return Collections.unmodifiableList(currentEntries);
	}
	
	public List getItems() {
		return currentEntries;
	}

	public void markRead(String location) {
		for (Iterator iter = currentEntries.iterator(); iter.hasNext();) {
			Entry entry = (Entry) iter.next();
			if (entry.getUrl().equalsIgnoreCase(location)) {
				entry.markRead();
				notifyObserversEntryRead(entry);
			}
		}
	}

	private void notifyObserversEntryRead(Entry entry) {
		for (Iterator iter = observers.iterator(); iter.hasNext();) {
			EntryModelObserver observer = (EntryModelObserver) iter.next();
			observer.notifyEntryRead(entry);
		}
	}

	public void refreshEntry(Entry entry) {
		for (Iterator iter = observers.iterator(); iter.hasNext();) {
			EntryModelObserver observer = (EntryModelObserver) iter.next();
			observer.notifyEntryRefreshed(entry);
		}
	}
}
