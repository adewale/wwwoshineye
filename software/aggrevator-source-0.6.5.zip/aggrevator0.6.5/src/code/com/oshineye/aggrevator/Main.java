package com.oshineye.aggrevator;

import org.apache.log4j.Logger;
import org.eclipse.swt.widgets.Display;

import com.oshineye.aggrevator.store.CachingFeedStore;
import com.oshineye.aggrevator.store.EntryStore;
import com.oshineye.aggrevator.store.FeedIdentityMap;
import com.oshineye.aggrevator.store.FeedStore;
import com.oshineye.aggrevator.store.MySqlEntryStore;
import com.oshineye.aggrevator.store.MySqlFeedStore;
import com.oshineye.aggrevator.util.QueryLoader;

/**
 * @author aoshineye
 */
public class Main {
	private static final Logger LOG = Logger.getLogger(Main.class);
	public static void main(String[] args) throws Exception {
		if (args.length > 1 && ("--version".equals(args[1]))) {
			System.out.println(Constants.APPLICATION_NAME_AND_VERSION_NUMBER);
		}
		
		String startMessage = "Starting " + Constants.APPLICATION_NAME_AND_VERSION_NUMBER;
		System.out.println(startMessage);
		
		Configuration.load();
		LOG.info(startMessage);
		
		QueryLoader queryLoader = new QueryLoader();
		FeedIdentityMap feedIdentityMap = new FeedIdentityMap();
		String databaseName = Configuration.getDatabaseName();
		FeedStore feedStore = new MySqlFeedStore(databaseName, feedIdentityMap, queryLoader);
		EntryStore entryStore = new MySqlEntryStore(databaseName, feedIdentityMap, queryLoader);
		CachingFeedStore cachingFeedStore = CachingFeedStore.createCachingFeedStore(feedStore, databaseName, feedIdentityMap);
		
		MainWindow harvester = new MainWindow(cachingFeedStore, entryStore);
		harvester.setBlockOnOpen(true);
		
		harvester.open();
		
		harvester.dispose();
		Display.getCurrent().dispose();
		cachingFeedStore.shutDown();
		System.exit(0);
	}
}
