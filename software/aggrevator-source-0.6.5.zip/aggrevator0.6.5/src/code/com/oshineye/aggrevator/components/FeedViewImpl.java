package com.oshineye.aggrevator.components;

import java.util.List;

import org.apache.commons.lang.ArrayUtils;
import org.apache.log4j.Logger;
import org.eclipse.jface.dialogs.Dialog;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.KeyEvent;
import org.eclipse.swt.events.MouseEvent;
import org.eclipse.swt.events.MouseListener;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.swt.widgets.TableItem;

import com.oshineye.aggrevator.ComparatorFactory;
import com.oshineye.aggrevator.Feed;
import com.oshineye.aggrevator.components.tasks.Task;
import com.oshineye.aggrevator.util.StringUtils;

public class FeedViewImpl extends AbstractTableView implements FeedView, Listener, MouseListener {
	private static final Logger LOG = Logger.getLogger(FeedViewImpl.class);
	private static final int LEFT_MOUSE_BUTTON = 1;
	private static final String[] COLUMN_HEADERS = new String[]{"Feed Title", "To Read", "Url", "Score", "Last Updated"};
	private static final int LAST_MODIFIED_COLUMN = 4;
	private static final int SCORE_COLUMN_INDEX = 3;
	private static final int URL_COLUMN = 2;
	private static final int UNREAD_ENTRIES_COUNT_COLUMN_INDEX = 1;
	private static final int TITLE_COLUMN = 0;

	private Table table;
	private FeedViewController controller;
	private FeedModel feedModel;
	private Composite parent;

	public FeedViewImpl(FeedModel feedModel) {
		this.feedModel = feedModel;
		feedModel.addObserver(this);
	}
	
	public FeedViewImpl(FeedModel feedModel, Composite parent, FeedViewController controller) {
		this(feedModel);
		this.table = createTableWithListener(parent, COLUMN_HEADERS, this);
		this.table.addListener(SWT.SetData, this);
		this.table.addKeyListener(this);
		this.table.addMouseListener(this);
		this.parent = parent;
		this.controller = controller;
	}
	
	protected void configure(int index, TableColumn column, Table tableControl) {
		if ((index == UNREAD_ENTRIES_COUNT_COLUMN_INDEX) || (index == SCORE_COLUMN_INDEX)){
			setWidthForNumericColumn(column, tableControl);
		}
	}
	
	public void notifyFeedAdded(Feed feed) {
		final List currentFeeds = feedModel.getCurrentFeeds();
		Display display = parent.getDisplay();
		display.syncExec(new Task() {
			public void doWork() {
				table.setItemCount(currentFeeds.size());
			}
		});
	}

	public void notifyFeedsLoaded(final List feeds) {
		Display display = parent.getDisplay();
		display.syncExec(new Task() {
			public void doWork() {
				/*
				 * removeAll is the only way to ensure that the feeds in the view are always updated
				 * clearAll looks like it will do the same thing but you always end up with feeds that
				 * aren't being updated and you can't tell till you select them and unexpected entries load up
				 */
				table.removeAll();
				table.setItemCount(feeds.size());
				
				//this is meant to ensure that the feed that was selected before we loaded these items
				//is still the selected feed afterwards, but only when it is visible.
				//So we must always use the current feeds and not all feeds to choose the index.
				if (feedModel.hasFeedSelected()) {
					selectTableItem(table, feedModel.getSelectedFeedIndex());
				}
			}
		});
	}

	public void notifyFeedDeleted(Feed feed, final int indexOfDeletedFeed) {
		Display display = parent.getDisplay();
		display.syncExec(new Task() {
			public void doWork() {
				List currentFeeds = feedModel.getCurrentFeeds();
				table.remove(indexOfDeletedFeed);
				table.setItemCount(currentFeeds.size());
				selectTableItem(table, feedModel.getSelectedFeedIndex());
			}
		});
	}
	
	public void notifyFeedRefreshed(final Feed feed) {
		//resolves situation where worker threads are still runnning after the GUI's been disposed
		if (parent.isDisposed()) {
			return;
		}
		
		//FIXME I'm not sure this still applies
		/*
		_a_synchronously update the ui
		if it's done synchronously we have a concurrency bug which means that the wrong feed
		gets updated by the table.clear() call. This is because the current thread gets suspended
		whilst the _sync_ call gets made
		*/
		Display display = parent.getDisplay();
		display.asyncExec(new Task() {
			public void doWork() {
				List feeds = feedModel.getCurrentFeeds();
				int indexOfFeed = feeds.indexOf(feed);
				if (indexOfFeed < 0) {
					LOG.warn("Can't find feed: " + feed + " at: " + indexOfFeed);
					return;
				}
				LOG.debug("Updating view of feed: " + feed + " at position: " + indexOfFeed);
				populateItem(feed, table.getItem(indexOfFeed));
			}
		});
	}
	
	public TableItem[] getItems() {
		return table.getItems();
	}

	private void populateItem(Feed feed, TableItem item) {
		String[] elements = getFeedElements(feed);
		
		boolean isSameFeed = feed.equals(item.getData()) && elementsAreDuplicated(elements, item);
		if (!isSameFeed) {
			item.setText(elements);
			item.setData(feed);
		}
		
		if (feed.isRefreshing()) {
			setFontToItalic(item);
		} else if (feed.isRead()) {
			setFontToPlain(item, isSameFeed);
		} else {
			setFontToBold(item, isSameFeed);
		}
	}
	
	private String[] getFeedElements(Feed feed) {
		int unreadEntriesCount = feed.getUnreadEntriesCount();
		String feedTitle = feed.getTitle();
		String score = String.valueOf(feed.getScore());
		String lastModified = StringUtils.valueOfWithDefault(feed.getFormattedDate(), "");
		String[] elements = new String[]{feedTitle, String.valueOf(unreadEntriesCount), feed.getUrl(), score, lastModified};
		return elements;
	}
	
	private boolean elementsAreDuplicated(String[] elements, TableItem item) {
	    String[] itemElements = new String[]{item.getText(0), item.getText(1), item.getText(2), item.getText(3), item.getText(4)};
	    return ArrayUtils.isEquals(elements, itemElements);
    }

	public void widgetSelected(SelectionEvent event) {
		if (event.getSource() == table) {
			/*
			 This fixes a bug under Linux (Fedora Core 2) wherein when the user scrubs through the list
			 of feeds quickly enough that there is a nullpointerexception because the selected item
			 hasn't been populated with a data object yet.
			 */
			Feed selectedFeed = getSelectedFeedFromView();
			if (selectedFeed == null) {
				LOG.debug("Selected feed is still null despite using getSelectedFeedFromView()");
				return;
			}
			LOG.debug("Handling: " + selectedFeed);
			controller.handleFeedSelected(selectedFeed);
		} else {//it's a column
			sortColumns(event);
			notifyFeedsLoaded(feedModel.getCurrentFeeds());
		}
	}

	private void sortColumns(SelectionEvent event) {
		TableColumn selectedColumn = (TableColumn) event.widget;
		if (selectedColumn == table.getColumn(TITLE_COLUMN)) {
			feedModel.sort(ComparatorFactory.getFeedTitleComparator());
		} else  if (selectedColumn == table.getColumn(UNREAD_ENTRIES_COUNT_COLUMN_INDEX)) {
			feedModel.sort(ComparatorFactory.getFeedUnreadEntriesCountComparator());
		} else if (selectedColumn == table.getColumn(URL_COLUMN)) {
			feedModel.sort(ComparatorFactory.getFeedUrlComparator());
		} else if (selectedColumn == table.getColumn(SCORE_COLUMN_INDEX)) {
			feedModel.sort(ComparatorFactory.getFeedScoreComparator());
		} else if (selectedColumn == table.getColumn(LAST_MODIFIED_COLUMN)) {
			feedModel.sort(ComparatorFactory.getFeedDateComparator());
		}
	}

	public void keyPressed(KeyEvent event) {
		//do nothing
	}

	public void keyReleased(KeyEvent event) {
		if (event.keyCode == SWT.DEL) {
			controller.handleFeedDeleted(feedModel.getSelectedFeed());
		}
	}
	
	public void handleEvent(Event event) {
		TableItem item = (TableItem) event.item;
		int itemLocation = table.indexOf(item);
		Feed currentFeed = (Feed) feedModel.getCurrentFeeds().get(itemLocation);
		populateItem(currentFeed, item);
	}

	public void addSelectionListener(SelectionListener listener) {
		table.addSelectionListener(listener);
	}

	protected Table getTable() {
		return table;
	}

	public void mouseDoubleClick(MouseEvent event) {
		//listen only for the double click from the left mouse button
		if (event.button != LEFT_MOUSE_BUTTON) {
			return;
		}
		
		Feed selectedFeed = null;
		if (!feedModel.hasFeedSelected()) {
			
			if (table.getSelectionCount() == 0) {
				//user has double-clicked on an empty part of the table
				return;
			}
			selectedFeed = getSelectedFeedFromView();
		} else {
			selectedFeed = feedModel.getSelectedFeed();
		}
		
		FeedMetaDataDialog dialog = new FeedMetaDataDialog(parent.getShell(), selectedFeed);
		int result = dialog.open();
		if (result == Dialog.CANCEL) {
			return;
		}
		
		String newFeedTitle = dialog.getNewFeedTitle();
		String newFeedUrl = dialog.getNewFeedUrl();
		controller.handleFeedUpdated(selectedFeed, newFeedTitle, newFeedUrl);
	}
	
	private Feed getSelectedFeedFromView() {
		TableItem[] selectedItems = table.getSelection();
		TableItem item = selectedItems[0];
		
		return (Feed)item.getData();
	}

	public void mouseDown(MouseEvent e) {
		//ignore
	}

	public void mouseUp(MouseEvent e) {
		//ignore
	}
}
