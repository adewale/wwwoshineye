package com.oshineye.aggrevator.components;

import java.util.List;

import com.oshineye.aggrevator.Entry;


public interface EntryModelObserver {
	void notifyEntriesLoaded(List entries);

	void notifyEntryRefreshed(Entry entry);
	
	void notifyEntriesCleared();

	void notifyEntryRead(Entry entry);
}
