package com.oshineye.aggrevator.components.actions;

import org.eclipse.jface.window.ApplicationWindow;

import com.oshineye.aggrevator.components.BrowserModel;
import com.oshineye.aggrevator.components.EntryModel;
import com.oshineye.aggrevator.components.FeedModel;

/**
 * @author aoshineye
 *
 */
public class OpenCurrentLocationAction extends OpenSelectedEntryAction{

	private BrowserModel browserModel;

	public OpenCurrentLocationAction(FeedModel feedModel, EntryModel entryModel, ApplicationWindow window, BrowserModel browserModel) {
		super(feedModel, entryModel, window);
		this.browserModel = browserModel;
		this.setText("&Open Current Location");
		this.setToolTipText("Open current location in external browser");
	}
	
	protected String getUrlToOpen() {
		return browserModel.getLocation();
	}

}
