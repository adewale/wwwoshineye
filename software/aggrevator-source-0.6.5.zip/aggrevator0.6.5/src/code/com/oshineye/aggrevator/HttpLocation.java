package com.oshineye.aggrevator;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.StringReader;
import java.util.zip.GZIPInputStream;

import org.apache.commons.httpclient.Header;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpMethod;
import org.apache.commons.httpclient.HttpStatus;
import org.apache.commons.httpclient.methods.GetMethod;
import org.apache.commons.httpclient.methods.HeadMethod;
import org.apache.commons.httpclient.params.HttpClientParams;
import org.apache.log4j.Logger;

import com.oshineye.aggrevator.util.IOUtils;


/**
 * @author aoshineye
 *
 */
public class HttpLocation {
	private static final Logger LOG = Logger.getLogger(HttpLocation.class);
	private String url;
	private String etag;
	private String lastModified;
	private String originalEtag;
	private String originalLastModified;
	
	public HttpLocation(String url, String etag, String lastModified) {
		this.url = url;
		this.etag = etag;
		this.lastModified = lastModified;
	}
	
	protected Reader createReader() throws IOException {
		HttpClient client = createHttpClient();
		HttpMethod method = createGetMethod();
		try {
			method.setFollowRedirects(true);
			method.setRequestHeader("Accept-encoding", "gzip");
			
			int statusCode = client.executeMethod(method);
			if (statusCode == HttpStatus.SC_NOT_FOUND) {//handle 404
				LOG.warn("Requested url: " + url + " can not be found");
				throw new NothingReadException();
			}
			
			if (statusCode == HttpStatus.SC_MOVED_PERMANENTLY) {
				Header responseHeader = method.getResponseHeader("location");
				String newUrl = responseHeader.getValue();
				LOG.info("Changing url from: " + url + " to: " + newUrl);
				setUrl(newUrl);
				return getReaderWithoutFollowingRedirects();
			}
			
			LOG.debug("Requested url: " + url + " and status code was: " + statusCode);
			return getReader(method);
		} finally {
			LOG.debug("Retrieved content for: " + url);
			method.releaseConnection();
			LOG.debug("Released connection for: " + url);
		}
	}

	public boolean hasLocationBeenModified() throws IOException {
	    //servers that don't support either of these standards should be treated as always having new content
	    if (etag == null && lastModified == null) {
	        return true;
	    }
		HttpClient client = createHttpClient();//time in milliseconds
		HttpMethod method = createHeadMethod();
		
		method.setRequestHeader("Accept-encoding", "gzip");
		method.setRequestHeader("If-None-Match", etag);
		method.setRequestHeader("If-Modified-Since", lastModified);
		int statusCode = client.executeMethod(method);
		return (statusCode != HttpStatus.SC_NOT_MODIFIED);
	}

	private String getGzippedContent(HttpMethod method) throws IOException {
		LOG.debug(this.toString() + " is being retrieved as gzipped content");
		GZIPInputStream stream = new GZIPInputStream(method.getResponseBodyAsStream());
		BufferedReader reader = null;
		StringBuffer result = new StringBuffer();
		try {
			reader = new BufferedReader(new InputStreamReader(stream));
			String line = null;
			while (null != (line = reader.readLine())) {
				result.append(line);
			}
		} finally {
			IOUtils.close(reader);
		}
		return result.toString();
	}
	
	private Reader getReader(HttpMethod method) throws IOException {
		updateStatus(method);
		
		Header responseHeader = method.getResponseHeader("content-encoding");
		
		if (responseHeader == null) {
			return getStringReader(method, method.getResponseBodyAsString());
		}
		return getStringReader(method, getGzippedContent(method));
	}
	
	private HttpClient createHttpClient() {
		HttpClientParams params = new HttpClientParams();
		params.setSoTimeout(Configuration.getHttpTimeoutInMilliseconds());
		HttpClient client = new HttpClient(params);
		return client;
	}
	
	private Reader getReaderWithoutFollowingRedirects() throws IOException {
		HttpClient client = createHttpClient();//time in milliseconds
		HttpMethod method = createGetMethod();
		try {
			setUserAgent(method);
			method.setRequestHeader("Accept-encoding", "gzip");
			
			int statusCode = client.executeMethod(method);
			
			LOG.debug("Requested url: " + url + " and status code was: " + statusCode);
			return getReader(method);
		} finally {
			LOG.debug("Retrieved content for: " + url);
			method.releaseConnection();
			LOG.debug("Released connection for: " + url);
		}
	}
	
	private void updateStatus(HttpMethod method) {
		//we assume that httpclient will do the right thing should there be more
		//than 1 etag or last modified header returned by a client
		LOG.debug(this + " values were-> etag: " + etag + " lastModified: " + lastModified);
		
		Header etagHeader = method.getResponseHeader("ETag");
		if (etagHeader != null) {
			setEtag(etagHeader.getValue());
		}
		Header lastModifiedHeader = method.getResponseHeader("Last-Modified");
		if (lastModifiedHeader != null) {
			setLastModified(lastModifiedHeader.getValue());
		}
		
		LOG.debug(this + " values are now-> etag: " + etag + " lastModified: " + lastModified);
	}
	
	private void setEtag(String newEtag) {
		originalEtag = etag;
		etag = newEtag;
	}
	
	private void setLastModified(String newLastModified) {
		originalLastModified = lastModified;
		lastModified = newLastModified;
	}
	
	public void resetStatus() {
		etag = originalEtag;
		lastModified = originalLastModified;
	}
	
	private GetMethod createGetMethod() {
		GetMethod method = new GetMethod(url);
		setUserAgent(method);
		return method;
	}
	
	private void setUserAgent(HttpMethod method) {
		method.setRequestHeader("User-Agent", Constants.APPLICATION_NAME + "/" + Constants.VERSION_NUMBER);
	}
	
	private Reader getStringReader(HttpMethod method, String result) {
		if (result == null) {//when the connection times out then the result is null
			throw new NothingReadException();
		}
		return new StringReader(result);
	}

	private HeadMethod createHeadMethod() {
		HeadMethod method = new HeadMethod(url);
		setUserAgent(method);
		return method;
	}

	public String getLastModified() {
		return lastModified;
	}

	public String getEtag() {
		return etag;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getUrl() {
		return url;
	}
}
