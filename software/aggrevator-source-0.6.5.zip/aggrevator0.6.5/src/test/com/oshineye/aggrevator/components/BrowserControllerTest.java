package com.oshineye.aggrevator.components;

import java.util.ArrayList;
import java.util.List;

import org.jmock.Mock;
import org.jmock.MockObjectTestCase;

import com.oshineye.aggrevator.store.EntryStore;

/**
 * @author aoshineye
 *
 */
public class BrowserControllerTest extends MockObjectTestCase {
	public void testUpdatesEntryStoreAndModelsWithVisitedLocation() {
		String location = "Some location";
		List relatedFeeds = new ArrayList();
		
		Mock mockFeedModel = new Mock(FeedModel.class);
		mockFeedModel.expects(once()).method("entryRead").with(same(relatedFeeds));
		Mock mockEntryModel = new Mock(EntryModel.class);
		mockEntryModel.expects(once()).method("markRead").with(eq(location));
		Mock mockBrowserModel = new Mock(BrowserModel.class);
		mockBrowserModel.expects(once()).method("setLocation");
		Mock mockEntryStore = new Mock(EntryStore.class);
		mockEntryStore.expects(once()).method("markRead").with(eq(location)).will(returnValue(true));
		mockEntryStore.expects(once()).method("getRelatedFeeds").with(eq(location)).will(returnValue(relatedFeeds));
		
		BrowserController controller = new BrowserControllerImpl((FeedModel)mockFeedModel.proxy(), (EntryModel)mockEntryModel.proxy(),
			(BrowserModel)mockBrowserModel.proxy(), (EntryStore)mockEntryStore.proxy());
		controller.handleLocationVisited(location);
		
		mockFeedModel.verify();
		mockEntryModel.verify();
		mockBrowserModel.verify();
		mockEntryStore.verify();
	}
	
	public void testIfLocationHasAlreadyBeenReadOnlyBrowserModelGetsUpdated() {
		String location = "Some location";
		Mock mockFeedModel = new Mock(FeedModel.class);
		Mock mockEntryModel = new Mock(EntryModel.class);
		Mock mockBrowserModel = new Mock(BrowserModel.class);
		mockBrowserModel.expects(exactly(2)).method("setLocation");
		Mock mockEntryStore = new Mock(EntryStore.class);
		mockEntryStore.expects(exactly(2)).method("markRead").with(eq(location)).will(returnValue(false));
		
		BrowserController controller = new BrowserControllerImpl((FeedModel)mockFeedModel.proxy(), (EntryModel)mockEntryModel.proxy(),
				(BrowserModel)mockBrowserModel.proxy(), (EntryStore)mockEntryStore.proxy());
		controller.handleLocationVisited(location);
		controller.handleLocationVisited(location);
		
		mockBrowserModel.verify();
	}
}
