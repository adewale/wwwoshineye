package com.oshineye.aggrevator;

import java.io.PrintWriter;
import java.io.StringWriter;

import org.apache.commons.lang.StringUtils;

import junit.framework.TestCase;

/**
 * @author aoshineye
 *
 */
public class TunnellingExceptionTest extends TestCase {
	public void testExtraInfoOnlyShowsUpInMessageNotInStackTrace() {
		String extraInfo = "expected information";
		NullPointerException ne = new NullPointerException();
		TunnellingException te = new TunnellingException(extraInfo, ne);
		
		StringWriter stringWriter = new StringWriter();
		PrintWriter writer = new PrintWriter(stringWriter);
		te.printStackTrace(writer);
		String stackTrace = stringWriter.toString();
		
		assertEquals(1, StringUtils.countMatches(te.getMessage(), extraInfo));
		assertEquals(0, StringUtils.countMatches(stackTrace, extraInfo));
	}
}
