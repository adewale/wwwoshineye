package com.oshineye.aggrevator.components;

import java.io.StringWriter;
import java.util.ArrayList;
import java.util.List;

import org.jmock.Mock;
import org.jmock.MockObjectTestCase;

import com.oshineye.aggrevator.Feed;
import com.oshineye.aggrevator.store.StubFixture;

/**
 * @author aoshineye
 *
 */
public class OPMLExporterTest extends MockObjectTestCase {
	private Feed abcFeed;
	private Feed adamConnorFeed;
	private Feed chalstFeed;
	
	public void setUp() {
		abcFeed = StubFixture.getStubFeedWithKeyTitleAndUrl(new Long(1), "Agile Business Coach", "http://abc.truemesh.com/index.rdf");
		adamConnorFeed = StubFixture.getStubFeedWithKeyTitleAndUrl(new Long(2), "Adam Connor's Notebook", "http://adamconnor.org/index.rdf");
		chalstFeed = StubFixture.getStubFeedWithKeyTitleAndUrl(new Long(3), "Advogato diary for chalst", "http://advogato.org/person/chalst/rss.xml");
	}

	public void testExportsAllFeedsInStoreToWriter() {
		List allFeeds = new ArrayList();
		allFeeds.add(abcFeed);
		allFeeds.add(adamConnorFeed);
		allFeeds.add(chalstFeed);
		
		Mock mockFeedModel = new Mock(FeedModel.class);
		mockFeedModel.expects(once()).method("getCurrentFeeds").withNoArguments().will(returnValue(allFeeds));
		String expectedOPMLFile = "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n" +
		"<opml version=\"1.0\">\n" +
		"<head><title>Aggrevator export</title></head>\n" +
		"  <body>\n" +
		"    <outline title=\"Agile Business Coach\" xmlUrl=\"http://abc.truemesh.com/index.rdf\" />\n" +
		"    <outline title=\"Adam Connor&apos;s Notebook\" xmlUrl=\"http://adamconnor.org/index.rdf\" />\n" +
		"    <outline title=\"Advogato diary for chalst\" xmlUrl=\"http://advogato.org/person/chalst/rss.xml\" />\n" +
		"  </body>\n" +
		"</opml>";
		StringWriter writer = new StringWriter();
		OPMLExporter exporter = new OPMLExporter((FeedModel)mockFeedModel.proxy());
		exporter.exportFeeds(writer);
		
		assertEquals(expectedOPMLFile, writer.getBuffer().toString());
		mockFeedModel.verify();
	}
	
	public void testExportsFeedsAndEscapesXmlEntities() {
		List allFeeds = new ArrayList();
		allFeeds.add(StubFixture.getStubFeedWithTitleAndUrl("1&1", "http://support.journurl.com/users/admin/index.cfm?mode=article&entry=948&template=rss-full&rssuser=04B43AC0-3048-424F-42C1F61B0EECED0F"));
		allFeeds.add(StubFixture.getStubFeedWithTitleAndUrl("2&2", "http://example&example.org"));
		
		Mock mockFeedModel = new Mock(FeedModel.class);
		mockFeedModel.expects(once()).method("getCurrentFeeds").withNoArguments().will(returnValue(allFeeds));
		String expectedOPMLFile = "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n" +
		"<opml version=\"1.0\">\n" +
		"<head><title>Aggrevator export</title></head>\n" +
		"  <body>\n" +
		"    <outline title=\"1&amp;1\" xmlUrl=\"http://support.journurl.com/users/admin/index.cfm?mode=article&amp;entry=948&amp;template=rss-full&amp;rssuser=04B43AC0-3048-424F-42C1F61B0EECED0F\" />\n" +
		"    <outline title=\"2&amp;2\" xmlUrl=\"http://example&amp;example.org\" />\n" +
		"  </body>\n" +
		"</opml>";
		StringWriter writer = new StringWriter();
		
		OPMLExporter exporter = new OPMLExporter((FeedModel)mockFeedModel.proxy());
		exporter.exportFeeds(writer);
		
		assertEquals(expectedOPMLFile, writer.getBuffer().toString());
		mockFeedModel.verify();
	}
}
