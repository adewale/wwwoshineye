package com.oshineye.aggrevator;

import org.apache.log4j.Logger;
import org.eclipse.swt.widgets.Display;

import com.oshineye.aggrevator.store.CachingFeedStore;
import com.oshineye.aggrevator.store.EntryStore;
import com.oshineye.aggrevator.store.FeedIdentityMap;
import com.oshineye.aggrevator.store.FeedStore;
import com.oshineye.aggrevator.store.StubFixture;

/**
 * @author aoshineye
 *
 * A Main class that points to the test database so that we can quickly start the whole
 * application to manually verify complex functionality albeit with an empty database.
 */
public class ManualAcceptanceTestMain {
	private static final Logger LOG = Logger.getLogger(Main.class);
	public static void main(String[] args) throws Exception {
		if (args.length > 1 && ("--version".equals(args[1]))) {
			System.out.println(Constants.APPLICATION_NAME_AND_VERSION_NUMBER);
			return;
		}
		
		String startMessage = "Starting " + Constants.APPLICATION_NAME_AND_VERSION_NUMBER;
		System.out.println(startMessage);
		
		Configuration.load();
		LOG.info(startMessage);

		FeedStore feedStore = StubFixture.getFeedStore();
		EntryStore entryStore = StubFixture.getEntryStore();
		FeedIdentityMap feedIdentityMap = StubFixture.getFeedIdentityMap();
		CachingFeedStore cachingFeedStore = CachingFeedStore.createCachingFeedStore(feedStore, StubFixture.TEST_DATABASE_NAME, feedIdentityMap);
		MainWindow harvester = new MainWindow(cachingFeedStore, entryStore);
		harvester.setBlockOnOpen(true);
		
		harvester.open();
		
		harvester.dispose();
		Display.getCurrent().dispose();
		
		cachingFeedStore.shutDown();
		System.exit(0);
	}
}
