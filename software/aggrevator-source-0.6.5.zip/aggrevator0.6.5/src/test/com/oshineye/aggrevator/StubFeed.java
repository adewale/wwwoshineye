package com.oshineye.aggrevator;

import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;

public class StubFeed extends FeedImpl {
	private final class StubLocation extends HttpLocation {
		private final String TEST_DATA_FOLDER;

		private final String fileName;

		private StubLocation(String url, String etag, String lastModified, String TEST_DATA_FOLDER, String fileName) {
			super(url, etag, lastModified);
			this.TEST_DATA_FOLDER = TEST_DATA_FOLDER;
			this.fileName = fileName;
		}

		protected Reader createReader() throws IOException {
			return new FileReader(TEST_DATA_FOLDER + fileName);
		}
	}

	private static final String TEST_DATA_FOLDER = "testData";

    public StubFeed(Long id, String title, String url, int score) {
    	super(id, url, title, 0, score, "etag", "lastModified", new InformaParser());
	}
	
	public StubFeed(String url) {
		super(Feed.PLACE_HOLDER_ID, url, Feed.NO_TITLE, 0, 0, "etag", "lastModified", new InformaParser());
	}
	
	public StubFeed(Long id, String url) {
	    super(id, url, Feed.NO_TITLE, 0, 0, "etag", "lastModified", new InformaParser());
    }
	
    public StubFeed(Long id, String title, String url) {
        super(id, url, title, 0, 0, "etag", "lastModified", new InformaParser());
    }
	
	public StubFeed(String url, int unreadEntriesCount, int score) {
		super(Feed.PLACE_HOLDER_ID, url, "title", unreadEntriesCount, score, null, null, new InformaParser());
	}

	public StubFeed(String url, String title, int unreadEntriesCount, int score) {
		super(Feed.PLACE_HOLDER_ID, url, title, unreadEntriesCount, score, null, null, new InformaParser());
	}

	public StubFeed(Feed feed) {
		super(Feed.PLACE_HOLDER_ID, feed.getUrl(), feed.getTitle(), feed.getUnreadEntriesCount(),
			feed.getScore(), feed.getEtag(), feed.getLastModified(), new InformaParser());
	}

	public StubFeed(Long id, String title, String url, String etag, String lastModified) {
		super(id, url, title, 0, 0, etag, lastModified, new InformaParser());
	}

	protected HttpLocation createLocation(String locationUrl, String locationEtag, String locationLastModified) {
		final String fileName = convertToLocalFileName(locationUrl);
		return new StubLocation(locationUrl, locationEtag, locationLastModified, TEST_DATA_FOLDER, fileName);
	}
	
	protected HttpLocation getLocation() {
		final String fileName = convertToLocalFileName(getUrl());
		return new StubLocation(getUrl(), getEtag(), getLastModified(), TEST_DATA_FOLDER, fileName);
	}

	private String convertToLocalFileName(String locationUrl) {
		int lastSlashPosition = locationUrl.lastIndexOf("/");
		if (lastSlashPosition < 0) {
			//dummy file name that isn't meant to be used
			//returning null means that attempts to use this filename will fail-fast
			return null;
		}
		String fileName = locationUrl.substring(lastSlashPosition);
		return fileName;
	}
	
	public boolean hasChanged() {
		return true;
	}
}