package com.oshineye.aggrevator.store;

import org.apache.commons.lang.StringUtils;

import com.oshineye.aggrevator.store.SearchSpecification;

import junit.framework.TestCase;

/**
 * @author aoshineye
 *
 */
public class SearchSpecificationTest extends TestCase {
	public void testSpecificationHasStringRepresentationThatContainsAllSearchTerms() {
		String feedTitleContainsSearchTerm = "feedTitleContainsSearchTerm";
		String titleContainsSearchTerm = "titleContainsSearchTerm";
		String contentContainsSearchTerm = "contentContainsSearchTerm";
		
		SearchSpecification specification = new SearchSpecification();
		specification.setFeedTitleField(feedTitleContainsSearchTerm);
		specification.setTitleField(titleContainsSearchTerm);
		specification.setContentField(contentContainsSearchTerm);
		
		assertTrue("Feed title search term missing", StringUtils.contains(specification.toString(), feedTitleContainsSearchTerm));
		assertTrue("Title search term missing", StringUtils.contains(specification.toString(), titleContainsSearchTerm));
		assertTrue("Content search term missing", StringUtils.contains(specification.toString(), contentContainsSearchTerm));
		assertEquals("feedTitleContains(feedTitleContainsSearchTerm) AND titleContains(titleContainsSearchTerm) AND contentContains(contentContainsSearchTerm)", specification.toString());
	}
	
	public void testSpecificationCanBeCreatedThatOnlyContainsOneSearchTerm() {
		String feedTitleContainsSearchTerm = "feedTitleContainsSearchTerm";
		String titleContainsSearchTerm = "titleContainsSearchTerm";
		String setContentField = "contentContainsSearchTerm";
		
		SearchSpecification specification = new SearchSpecification();
		specification.setFeedTitleField(feedTitleContainsSearchTerm);
		assertEquals("feedTitleContains(" + feedTitleContainsSearchTerm + ")", specification.toString());
		
		specification = new SearchSpecification();
		specification.setTitleField(titleContainsSearchTerm);
		assertEquals("titleContains(" + titleContainsSearchTerm + ")", specification.toString());
		
		specification = new SearchSpecification();
		specification.setContentField(setContentField);
		assertEquals("contentContains(" + setContentField + ")", specification.toString());
	}
	
	public void testClearingSpecificationResetsItToOriginalState() {
		String feedTitleContainsSearchTerm = "feedTitleContainsSearchTerm";
		String titleContainsSearchTerm = "titleContainsSearchTerm";
		String setContentField = "contentContainsSearchTerm";
		
		SearchSpecification specification = new SearchSpecification();
		specification.setFeedTitleField(feedTitleContainsSearchTerm);
		assertEquals("feedTitleContains(" + feedTitleContainsSearchTerm + ")", specification.toString());
		
		specification.clear();
		String different = "different ";
		specification.setFeedTitleField(different + feedTitleContainsSearchTerm);
		assertEquals("feedTitleContains(" + different + feedTitleContainsSearchTerm + ")", specification.toString());
		
		specification.clear();
		specification.setTitleField(titleContainsSearchTerm);
		assertEquals("titleContains(" + titleContainsSearchTerm + ")", specification.toString());
		
		specification.clear();
		specification.setContentField(setContentField);
		assertEquals("contentContains(" + setContentField + ")", specification.toString());
	}
	
	public void testSpecificationResetsToOriginalStateFromPopulatedState() {
		String feedTitleContainsSearchTerm = "feedTitleContainsSearchTerm";
		String titleContainsSearchTerm = "titleContainsSearchTerm";
		SearchSpecification specification = new SearchSpecification();
		specification.setFeedTitleField(feedTitleContainsSearchTerm);
		specification.setTitleField(titleContainsSearchTerm);
		String expectedWhenPopulated = "feedTitleContains(" + feedTitleContainsSearchTerm + ")" 
			+  " AND " + "titleContains(" + titleContainsSearchTerm + ")";
		assertEquals(expectedWhenPopulated, specification.toString());
		
		specification.clear();
		specification.setTitleField(titleContainsSearchTerm);
		String expectedWhenNotPopulated = "titleContains(" + titleContainsSearchTerm + ")";
		assertEquals(expectedWhenNotPopulated, specification.toString());
	}

	public void testSpecificationHasStringRepresentationThatOnlyContainsPopulatedSearchTerms() {
		String feedTitleContainsSearchTerm = "feedTitleContainsSearchTerm";
		String titleContainsSearchTerm = "titleContainsSearchTerm";
		String contentContainsSearchTerm = "contentContainsSearchTerm";

		SearchSpecification specification = new SearchSpecification();
		assertEquals("", specification.toString());
		
		specification.setFeedTitleField(feedTitleContainsSearchTerm);
		assertTrue("Feed title search term missing", StringUtils.contains(specification.toString(), feedTitleContainsSearchTerm));
		
		specification.setTitleField(titleContainsSearchTerm);
		assertTrue("Title search term missing", StringUtils.contains(specification.toString(), titleContainsSearchTerm));
		
		specification.setContentField(contentContainsSearchTerm);
		assertTrue("Content search term missing", StringUtils.contains(specification.toString(), contentContainsSearchTerm));
	}
	
	public void testSpecificationHasStringRepresentationThatOnlyContainsAndClauseForPopulatedSearchTerms() {
		String feedTitleContainsSearchTerm = "feedTitleContainsSearchTerm";
		String contentContainsSearchTerm = "contentContainsSearchTerm";

		SearchSpecification specification = new SearchSpecification();
		specification.setFeedTitleField(feedTitleContainsSearchTerm);
		specification.setContentField(contentContainsSearchTerm);
		
		assertEquals("feedTitleContains(feedTitleContainsSearchTerm) AND contentContains(contentContainsSearchTerm)", specification.toString());
	}
	
	public void testSpecificationCanTellIfAnyFieldsPopulated() {
		SearchSpecification specification = new SearchSpecification();
		assertFalse(specification.isPopulated());
		specification.setFeedTitleField("text");
		assertTrue(specification.isPopulated());
		
		specification = new SearchSpecification();
		specification.setTitleField("text");
		assertTrue(specification.isPopulated());
		
		specification = new SearchSpecification();
		specification.setContentField("text");
		assertTrue(specification.isPopulated());
	}
}
