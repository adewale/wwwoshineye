package com.oshineye.aggrevator.components;

import junit.framework.TestCase;

import com.oshineye.aggrevator.Entry;
import com.oshineye.aggrevator.components.ContentFormatter;
import com.oshineye.aggrevator.store.StubFixture;

/**
 * @author aoshineye
 */
public class ContentFormatterTest extends TestCase {
	public void testFormattedContentContainsEntryData() {
		String entryTitle = "entry title";
		String entryContent = "entry content";
		Entry entry = StubFixture.getStubEntry(-1, entryTitle, entryContent);
		ContentFormatter cf = new ContentFormatter(entry);
		
		String formattedContent = cf.getFormattedContent();
		
		assertTrue(formattedContent.indexOf(entryTitle) >= 0);
		assertTrue(formattedContent.indexOf(entryContent) >= 0);
	}
	
	public void testFormattedContentHasNoLinkWhenEntryHasNoLink() {
		Entry entry = StubFixture.getStubEntryWithPermaLinkAndFeedId(null, new Long(-1));
		ContentFormatter cf = new ContentFormatter(entry);
		
		String formattedContent = cf.getFormattedContent();
		
		assertTrue("Link tag exists in entry that shouldn't have links", formattedContent.indexOf("href") < 0);
	}
	
	public void testFormattedContentEscapesTitle() {
		Entry entry = StubFixture.getStubEntryWithTitle("<No Title>");
		ContentFormatter cf = new ContentFormatter(entry);
		
		String formattedContent = cf.getFormattedContent();
		assertTrue("Did not html escape title", formattedContent.indexOf("&lt;No Title&gt;") >= 0);
	}
	
	public void testFormattedContentConvertsQuoteEntityIntoQuote() {
		String title = "No Title but a ";
		Entry entry = StubFixture.getStubEntryWithTitle(title + "&quot;");
		ContentFormatter cf = new ContentFormatter(entry);
		
		String formattedContent = cf.getFormattedContent();
		assertTrue("Did not convert quote", formattedContent.indexOf(title + "\"") >= 0);
	}
}
