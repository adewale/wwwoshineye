package com.oshineye.aggrevator.util;

import junit.framework.TestCase;

/**
 * @author aoshineye
 *
 */
public class StringUtilsTest extends TestCase {
	public void testUnescapingBadHtmlReturnsOriginalString() {
		String badHtml = "&#x92;";
		String result = StringUtils.unescapeHtml(badHtml);
		assertEquals(badHtml, result);
	}
	
	public void testValueOfWithDefaultReturnsTheDefaultIfTheObjectIsNull() {
		Object object = null;
		String expected = "expected";
		assertEquals(expected, StringUtils.valueOfWithDefault(object, expected));
	}
	
	public void testValueOfWithDefaultReturnsTheTheObjectAsAStringIfItIsNotNull() {
		Object object = new Integer(445);
		String someOtherString = "someOtherString";
		String result = StringUtils.valueOfWithDefault(object, someOtherString);
		assertEquals("445", result);
	}
}
