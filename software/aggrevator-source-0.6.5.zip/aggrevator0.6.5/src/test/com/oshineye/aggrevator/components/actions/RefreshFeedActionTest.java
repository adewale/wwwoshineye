package com.oshineye.aggrevator.components.actions;

import org.eclipse.jface.action.Action;
import org.jmock.Mock;
import org.jmock.MockObjectTestCase;

import EDU.oswego.cs.dl.util.concurrent.Executor;

import com.oshineye.aggrevator.Feed;
import com.oshineye.aggrevator.components.EntryModel;
import com.oshineye.aggrevator.components.FeedModel;
import com.oshineye.aggrevator.store.EntryStore;
import com.oshineye.aggrevator.store.FeedStore;

/**
 * @author aoshineye
 *
 */
public class RefreshFeedActionTest extends MockObjectTestCase {
	public void testActionExecutesTaskUsingSelectedFeed() {
		Mock mockFeed = new Mock(Feed.class);
		Feed feed = (Feed)mockFeed.proxy();
		Mock mockExecutor = new Mock(Executor.class);
		mockExecutor.expects(once()).method("execute").withAnyArguments();
		
		Mock mockFeedStore = new Mock(FeedStore.class);
		Mock mockEntryStore = new Mock(EntryStore.class);
		Mock mockFeedModel = new Mock(FeedModel.class);
		mockFeedModel.expects(once()).method("getSelectedFeed").withNoArguments().will(returnValue(feed));
		
		Mock mockEntryModel = new Mock(EntryModel.class);
		Action action = new RefreshFeedAction((Executor)mockExecutor.proxy(), (FeedStore)mockFeedStore.proxy(),
				(EntryStore)mockEntryStore.proxy(), (FeedModel)mockFeedModel.proxy(), (EntryModel)mockEntryModel.proxy());
		action.run();
		
		mockExecutor.verify();
		mockFeedModel.verify();
	}
}
