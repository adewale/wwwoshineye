package com.oshineye.aggrevator.util;

import junit.framework.TestCase;

/**
 * @author aoshineye
 *
 */
public class URLUtilsTest extends TestCase {
	public void testGeneratesCorrectFeedsterUrlForSearchTerm() {
		String searchTerm = "aggrevator";
		String expectedUrl = "http://feedster.com/search.php?q=aggrevator&sort=&ie=UTF-8&hl=&content=full&type=rss&limit=15";
		assertEquals(expectedUrl, URLUtils.generateFeedsterSearchUrl(searchTerm));
	}
	
	public void testGeneratesCorrectFeedsterUrlForSearchTermWithEmbeddedSpaces() {
		String searchTerm = "theory of constraints";
		String expectedUrl = "http://feedster.com/search.php?q=theory+of+constraints&sort=&ie=UTF-8&hl=&content=full&type=rss&limit=15";
		assertEquals(expectedUrl, URLUtils.generateFeedsterSearchUrl(searchTerm));
	}
	
	public void testGeneratesCorrectFeedsterUrlForSearchTermEnclosedInQuotesWithEmbeddedSpaces() {
		String searchTerm = "\"theory of constraints\"";
		String expectedUrl = "http://feedster.com/search.php?q=%22theory+of+constraints%22&sort=&ie=UTF-8&hl=&content=full&type=rss&limit=15";
		assertEquals(expectedUrl, URLUtils.generateFeedsterSearchUrl(searchTerm));
	}
}
