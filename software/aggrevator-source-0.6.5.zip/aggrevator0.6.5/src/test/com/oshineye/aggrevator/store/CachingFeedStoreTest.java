package com.oshineye.aggrevator.store;

import java.io.File;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.List;

import org.jmock.Mock;
import org.jmock.MockObjectTestCase;

import com.thoughtworks.xstream.XStream;


/**
 * @author aoshineye
 *
 */
public class CachingFeedStoreTest extends MockObjectTestCase {

	private File tempFile;

	public void testPopulatesFeedIdentityMapWhenItRetrievesAllFeedsFromCache() throws Exception {
		FeedIdentityMap feedIdentityMap = new FeedIdentityMap();

		tempFile = File.createTempFile("" + System.currentTimeMillis(), "tmp");
		tempFile.deleteOnExit();
		List feeds = new ArrayList();
		feeds.add(StubFixture.getStubFeed());
		XStream xstream = new XStream();
		FileWriter fileWriter = new FileWriter(tempFile);
		xstream.toXML(feeds, fileWriter);
		fileWriter.close();
		
		Mock mockFeedStore = new Mock(FeedStore.class);
		mockFeedStore.expects(once()).method("findAllFeedRecords").will(returnValue(StubFixture.createFeedRecords(feeds)));
		
		FeedStore feedStore = (FeedStore)mockFeedStore.proxy();
		
		Cache cache = new XStreamCache(tempFile, feedStore);
		CachingFeedStore cachingFeedStore = new CachingFeedStore(cache, feedStore, feedIdentityMap);
		cachingFeedStore.findAllFeeds();
		
		assertTrue(feedIdentityMap.isPopulated());
		mockFeedStore.verify();
	}
	
	public void tearDown() {
		if (tempFile != null) {
			File newFile = new File(tempFile.getName() + ".bak");
			tempFile.delete();
			newFile.delete();
		}
	}
}
