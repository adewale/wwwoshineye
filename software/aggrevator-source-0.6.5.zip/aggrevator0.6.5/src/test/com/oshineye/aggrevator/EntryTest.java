package com.oshineye.aggrevator;

import java.util.Date;
import java.util.List;

import junit.framework.TestCase;

import com.oshineye.aggrevator.Configuration;
import com.oshineye.aggrevator.Entry;
import com.oshineye.aggrevator.Feed;
import com.oshineye.aggrevator.store.StubFixture;

import org.apache.commons.lang.time.DateFormatUtils;

/**
 * @author aoshineye
 *
 */
public class EntryTest extends TestCase {
	private String title;
	private String content;
	private Date date;
	private boolean read;
	private String feedTitle = "";
	private String url = "";
	private Entry entry;

	public void setUp() {
		Long feedId = new Long(-1);
		this.title = "title";
		this.content = "content";
		this.date = new Date();
		this.read = false;
		this.entry = new Entry(title, content, date, url, feedTitle, feedId, read, 0);
	}
	
	public void testCreatingEntryWithNullDateResultsInCurrentDateBeingUsed() throws Exception {
		date = new Date();
		entry = new Entry(title, content, null, url, feedTitle, new Long(-1), read, 0);
		
		Date storedDate = entry.getDate();
		
		assertNotNull(storedDate);
		assertTrue((date.getTime()/1000) <= (storedDate.getTime()/1000));
	}
	
	public void testEntriesHaveEntitiesInTitlesCleanedUp() {
		entry = new Entry("&gt;&gt;&quot;&amp;&quot;&lt;&lt;", content, null, url, feedTitle, new Long(-1), read, 0);
		assertEquals(">>\"&\"<<", entry.getTitle());
	}
	
	public void testEntriesHaveEntitiesInFeedTitlesCleanedUp() {
		entry = new Entry(title, content, null, url, "&gt;&gt;&quot;&amp;&quot;&lt;&lt;", new Long(-1), read, 0);
		assertEquals(">>\"&\"<<", entry.getFeedTitle());
	}
	
	public void testEntriesDoNotHaveTitlesCleanedUpIfTheyContainIllegalHtmlEntities() {
		String originalTitle = "&gt;&gt;&quot;&amp;&quot;&lt;&lt;&#x92;";
		entry = new Entry(originalTitle, content, null, url, feedTitle, new Long(-1), read, 0);
		assertEquals(originalTitle, entry.getTitle());
	}
	
	public void testEntriesDoNotHaveFeedTitlesCleanedUpIfTheyContainIllegalHtmlEntities() {
		String originalFeedTitle = "&gt;&gt;&quot;&amp;&quot;&lt;&lt;&#x92;";
		entry = new Entry(title, content, null, url, originalFeedTitle, new Long(-1), read, 0);
		assertEquals(originalFeedTitle, entry.getFeedTitle());
	}

	public void testEntryFormatsDateToShortForm() {
		String dateText = entry.getFormattedDate();
		assertEquals(DateFormatUtils.format(date, Configuration.DATE_FORMAT), dateText);
	}

	public void testMarkingEntryAsReadChangesIt() {
		entry.markRead();
		assertTrue(entry.isRead());
		assertEquals(Feed.ENTRY_READ_SCORE, entry.getScore());
	}
	
	public void testMarkingEntryAsReadMultipleTimesOnlyChangesTheScoreOnce() {
		entry.markRead();
		entry.markRead();
		entry.markRead();
		entry.markRead();
		assertTrue(entry.isRead());
		assertEquals(Feed.ENTRY_READ_SCORE, entry.getScore());
	}
	
	public void testEntryThatAlreadyHasAScorePreservesThatScoreIfItIsMarkedReadAgain() {
		entry.markRead();
		assertEquals(Feed.ENTRY_READ_SCORE, entry.getScore());
		
		entry.incrementScore();
		entry.markRead();
		
		assertEquals(Feed.SCORE_UNITS + Feed.ENTRY_READ_SCORE, entry.getScore());
	}
	
	public void testScoreCanBeIncreasedAndDecreased() {
		int score = entry.getScore();
		
		entry.incrementScore();
		assertEquals(score + Feed.SCORE_UNITS, entry.getScore());
		
		entry.decrementScore();
		assertEquals(score, entry.getScore());
		
		entry.decrementScore();
		assertEquals(score - Feed.SCORE_UNITS, entry.getScore());
	}
	
	public void testEntriesCanBeMeaningfullyComparedForEquality() {
		Feed feed = StubFixture.getStubFeed();
		List entries = feed.fetchNewEntries();
		Entry zero = (Entry) entries.get(0);
		Entry one = (Entry) entries.get(1);
		Entry otherZero = (Entry) feed.fetchNewEntries().get(0);
		
		assertFalse(zero.equals(one));
		assertNotSame(zero, otherZero);
		assertEquals(zero, otherZero);
	}
	
	public void testEntriesWithSamePermaLinkButDifferentContentConsideredEqual() {
		String content2 = "Dummy entry's content 2";
		String permaLink = "some permaLink";
		Entry e1 = new Entry(title, content, date, permaLink, feedTitle, new Long(-1), read, 0);
		Entry e2 = new Entry(title, content2, date, permaLink, feedTitle, new Long(-1), read, 0);
		assertEquals(e1, e2);
	}
	
	public void testEntriesWithNullPermaLinkButSameContentConsideredEqual() {
		String content2 = "Dummy entry's content 2";
		String permaLink = null;
		Entry e1 = new Entry(title, content, date, permaLink, feedTitle, new Long(-1), read, 0);
		Entry e2 = new Entry(title, content2, date, permaLink, feedTitle, new Long(-1), read, 0);
		assertEquals(e1, e2);
	}
	
	public void testEntriesWithDifferentPermaLinksButSameContentNotConsideredEqual() {
		Entry e1 = new Entry(title, content, date, "permaLink1", feedTitle, new Long(-1), read, 0);
		Entry e2 = new Entry(title, content, date, "permaLink2", feedTitle, new Long(-1), read, 0);
		assertEquals(e1, e2);
	}
	
	public void testEntryObjectsConvertToStringContainingTitleAndPermaLink() {
		String permaLink = "some permaLink";
		Entry e1 = new Entry(title, content, date, permaLink, feedTitle, new Long(-1), read, 0);
		
		assertEquals("Entry::" + title + "::" + permaLink, e1.toString());
		
	}
}
