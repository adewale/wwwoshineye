package com.oshineye.aggrevator.components.actions;

import java.util.ArrayList;

import junit.framework.TestCase;

import org.eclipse.jface.action.Action;

import com.mockobjects.dynamic.C;
import com.mockobjects.dynamic.Mock;
import com.oshineye.aggrevator.components.EntryModel;
import com.oshineye.aggrevator.components.FeedModel;
import com.oshineye.aggrevator.components.actions.MarkFeedReadAction;
import com.oshineye.aggrevator.store.EntryStore;
import com.oshineye.aggrevator.store.FeedStore;
import com.oshineye.aggrevator.store.StubFixture;

/**
 * @author aoshineye
 */
public class MarkFeedReadActionTest extends TestCase {
	public void testActionUpdatesFeedModelAfterMarkingFeedRead() {
		Mock mockFeedStore = new Mock(FeedStore.class);
		mockFeedStore.expect("markRead", C.IS_NOT_NULL);
		Mock mockEntryStore = new Mock(EntryStore.class);
		mockEntryStore.expectAndReturn("findEntriesInFeed", C.IS_ANYTHING, new ArrayList());
		Mock mockFeedModel = new Mock(FeedModel.class);
		mockFeedModel.expectAndReturn("getSelectedFeed", StubFixture.getStubFeed());
		mockFeedModel.expect("refreshFeed", C.IS_NOT_NULL);
		mockFeedModel.expectAndReturn("isSelected", C.IS_NOT_NULL, true);
		Mock mockEntryModel = new Mock(EntryModel.class);
		mockEntryModel.expect("loadEntries", C.IS_NOT_NULL);
		
		Action action = new MarkFeedReadAction((FeedStore) mockFeedStore.proxy(), (EntryStore) mockEntryStore.proxy(), 
			(FeedModel) mockFeedModel.proxy(), (EntryModel) mockEntryModel.proxy());
		action.run();
		
		mockFeedStore.verify();
		mockFeedModel.verify();
		mockEntryModel.verify();
	}
	
	public void testActionDoesNotUpdateEntryModelIfFeedNoLongerSelected() {
		Mock mockFeedStore = new Mock(FeedStore.class);
		mockFeedStore.expect("markRead", C.IS_NOT_NULL);
		Mock mockEntryStore = new Mock(EntryStore.class);
		mockEntryStore.expectAndReturn("getEntriesInFeed", C.ANY_ARGS, new ArrayList());
		Mock mockFeedModel = new Mock(FeedModel.class);
		mockFeedModel.expectAndReturn("getSelectedFeed", StubFixture.getStubFeed());
		mockFeedModel.expect("refreshFeed", C.IS_NOT_NULL);
		mockFeedModel.expectAndReturn("isSelected", C.IS_NOT_NULL, false);
		Mock mockEntryModel = new Mock(EntryModel.class);
		
		Action action = new MarkFeedReadAction((FeedStore) mockFeedStore.proxy(), (EntryStore) mockEntryStore.proxy(), 
			(FeedModel) mockFeedModel.proxy(), (EntryModel) mockEntryModel.proxy());
		action.run();
		
		mockEntryModel.verify();
	}

}
