package com.oshineye.aggrevator.components.actions;

import java.io.StringWriter;
import java.io.Writer;
import java.util.ArrayList;
import java.util.List;

import org.jmock.Mock;
import org.jmock.MockObjectTestCase;

import com.oshineye.aggrevator.components.FeedModel;
import com.oshineye.aggrevator.components.StatusRecorder;
import com.oshineye.aggrevator.store.StubFixture;

/**
 * @author aoshineye
 */
public class ExportOPMLActionTest extends MockObjectTestCase {
	public void testExportedFileContainsFeedsFromStore() {
		String expectedUrl = "expectedUrl";
		List feedsToExport = new ArrayList();
		feedsToExport.add(StubFixture.getStubFeedWithUrl(expectedUrl));
		Mock mockFeedModel = new Mock(FeedModel.class);
		mockFeedModel.expects(atLeastOnce()).method("getCurrentFeeds").withNoArguments().will(returnValue(feedsToExport));
		final StringWriter writer = new StringWriter();
		final String expectedFileToExport = "expectedFileToExport";
		Mock mockStatusRecorder = new Mock(StatusRecorder.class);
		mockStatusRecorder.stubs().method("setStatus").withAnyArguments();
		
		
		ExportOPMLAction action = new ExportOPMLAction(null, (FeedModel) mockFeedModel.proxy(), (StatusRecorder)mockStatusRecorder.proxy()) {
			Writer getWriter(String fileToExport) {
				assertEquals(expectedFileToExport, fileToExport);
				return writer;
			}
			
			String getFileToExport() {
				return expectedFileToExport;
			}
		};
		action.run();
		
		String writtenOut = writer.getBuffer().toString();
		
		assertTrue(writtenOut.indexOf(expectedUrl) > 0);
		mockFeedModel.verify();
	}
}
