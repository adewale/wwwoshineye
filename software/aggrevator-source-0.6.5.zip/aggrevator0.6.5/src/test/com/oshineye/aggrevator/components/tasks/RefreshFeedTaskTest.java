package com.oshineye.aggrevator.components.tasks;

import java.util.ArrayList;
import java.util.List;

import junit.framework.TestCase;

import com.mockobjects.dynamic.C;
import com.mockobjects.dynamic.Mock;
import com.oshineye.aggrevator.Feed;
import com.oshineye.aggrevator.RefreshInProgressException;
import com.oshineye.aggrevator.components.EntryModel;
import com.oshineye.aggrevator.components.FeedModel;
import com.oshineye.aggrevator.store.EntryStore;
import com.oshineye.aggrevator.store.FeedStore;
import com.oshineye.aggrevator.store.StubFixture;

/**
 * @author aoshineye
 *
 */
public class RefreshFeedTaskTest extends TestCase {

	public void testDoesNotUpdateStoreWhenNewEntriesListIsEmpty() {
		Mock mockFeed = new Mock(Feed.class);
		mockFeed.expect("setRefreshStarted");
		mockFeed.expect("setRefreshFinished");
		mockFeed.matchAndReturn("toString", "MockFeed");
		mockFeed.expectAndReturn("fetchNewEntries", C.IS_NOT_NULL, new ArrayList());
		mockFeed.matchAndReturn("getUnreadEntriesCount", 0);
		mockFeed.matchAndReturn("hasChanged", true);
		
		Mock mockFeedStore = new Mock(FeedStore.class);
		Mock mockEntryStore = new Mock(EntryStore.class);

		Mock mockFeedModel = new Mock(FeedModel.class);
		mockFeedModel.expect("refreshFeed", C.IS_NOT_NULL);
		mockFeedModel.expect("refreshFeed", C.IS_NOT_NULL);
		
		Mock mockEntryModel = new Mock(EntryModel.class);
		
		RefreshFeedTask task = new RefreshFeedTask((Feed)mockFeed.proxy(), (FeedStore) mockFeedStore.proxy(), 
			(EntryStore)mockEntryStore.proxy(), (FeedModel)mockFeedModel.proxy(), (EntryModel)mockEntryModel.proxy());

		task.run();
		mockEntryStore.verify();
		mockFeed.verify();
	}
	
	public void testDoesNotUpdateStoreWhenFeedHasNotChanged() {		
		Mock mockFeed = new Mock(Feed.class);
		mockFeed.expect("setRefreshStarted");
		mockFeed.expect("setRefreshFinished");
		mockFeed.matchAndReturn("toString", "MockFeed");
		mockFeed.matchAndReturn("getUnreadEntriesCount", 0);
		mockFeed.matchAndReturn("hasChanged", false);
		
		Mock mockFeedStore = new Mock(FeedStore.class);
		Mock mockEntryStore = new Mock(EntryStore.class);

		Mock mockFeedModel = new Mock(FeedModel.class);
		mockFeedModel.expect("refreshFeed", C.IS_NOT_NULL);
		mockFeedModel.expect("refreshFeed", C.IS_NOT_NULL);
		
		Mock mockEntryModel = new Mock(EntryModel.class);
		
		RefreshFeedTask task = new RefreshFeedTask((Feed)mockFeed.proxy(), (FeedStore) mockFeedStore.proxy(), 
			(EntryStore)mockEntryStore.proxy(), (FeedModel)mockFeedModel.proxy(), (EntryModel)mockEntryModel.proxy());

		task.run();
		mockEntryStore.verify();
		mockFeed.verify();
	}
	
	public void testDoesNotUpdateStoreOrModelIfRefreshInProgress() throws RefreshInProgressException {		
		Feed feed = StubFixture.getStubFeed();
		feed.setRefreshStarted();
		
		Mock mockFeedStore = new Mock(FeedStore.class);
		Mock mockEntryStore = new Mock(EntryStore.class);
		Mock mockFeedModel = new Mock(FeedModel.class);
		Mock mockEntryModel = new Mock(EntryModel.class);
		
		RefreshFeedTask task = new RefreshFeedTask(feed, (FeedStore) mockFeedStore.proxy(), 
			(EntryStore)mockEntryStore.proxy(), (FeedModel)mockFeedModel.proxy(), (EntryModel)mockEntryModel.proxy());

		task.run();
		mockEntryStore.verify();
		mockFeedModel.verify();
		mockEntryModel.verify();
	}
	
	public void testUpdatesStoreWhenNewEntriesListHasContent() {
		List newEntries = new ArrayList();
		newEntries.add(StubFixture.getStubEntry());
		
		Mock mockFeed = new Mock(Feed.class);
		mockFeed.expect("setRefreshStarted");
		mockFeed.expect("setRefreshFinished");
		mockFeed.expectAndReturn("toString", "MockFeed");
		mockFeed.expectAndReturn("toString", "MockFeed");
		mockFeed.expectAndReturn("fetchNewEntries", C.IS_NOT_NULL, newEntries);
		mockFeed.expectAndReturn("getUnreadEntriesCount", 0);
		mockFeed.expectAndReturn("getUnreadEntriesCount", 0);
		mockFeed.matchAndReturn("hasChanged", true);
		
		Mock mockFeedStore = new Mock(FeedStore.class);
		mockFeedStore.expect("reconcile", C.ANY_ARGS);
		Mock mockEntryStore = new Mock(EntryStore.class);
		mockEntryStore.expect("addEntries", C.same(newEntries));
		
		Mock mockFeedModel = new Mock(FeedModel.class);
		mockFeedModel.expect("refreshFeed", C.IS_NOT_NULL);
		mockFeedModel.expect("refreshFeed", C.IS_NOT_NULL);
		mockFeedModel.expectAndReturn("isSelected", C.IS_NOT_NULL, false);

		Mock mockEntryModel = new Mock(EntryModel.class);
		
		RefreshFeedTask task = new RefreshFeedTask((Feed)mockFeed.proxy(), (FeedStore) mockFeedStore.proxy(), 
			(EntryStore)mockEntryStore.proxy(), (FeedModel)mockFeedModel.proxy(), (EntryModel)mockEntryModel.proxy());

		task.run();
		
		mockFeedModel.verify();
		mockEntryStore.verify();
		mockFeed.verify();
	}
	
	public void testUpdatesEntryModelWhenNewEntriesListHasContentFromSelectedFeed() {		
		List entriesInStore = new ArrayList();
		List newEntries = new ArrayList();
		newEntries.add(StubFixture.getStubEntry());
		List finalEntries = new ArrayList();
		finalEntries.addAll(entriesInStore);
		finalEntries.addAll(newEntries);
		
		Mock mockFeed = new Mock(Feed.class);
		mockFeed.expect("setRefreshStarted");
		mockFeed.expect("setRefreshFinished");
		mockFeed.expectAndReturn("toString", "MockFeed");
		mockFeed.expectAndReturn("toString", "MockFeed");
		mockFeed.expectAndReturn("fetchNewEntries", C.IS_NOT_NULL, newEntries);
		mockFeed.expectAndReturn("getId", new Long(1));
		mockFeed.expectAndReturn("getUnreadEntriesCount", 0);
		mockFeed.expectAndReturn("getUnreadEntriesCount", 0);
		mockFeed.matchAndReturn("hasChanged", true);
		
		Mock mockFeedStore = new Mock(FeedStore.class);
		mockFeedStore.expect("reconcile", C.ANY_ARGS);
		Mock mockEntryStore = new Mock(EntryStore.class);
		mockEntryStore.expectAndReturn("findEntriesInFeed", C.IS_NOT_NULL, finalEntries);
		mockEntryStore.expect("addEntries", C.same(newEntries));
		
		Mock mockFeedModel = new Mock(FeedModel.class);
		mockFeedModel.expectAndReturn("isSelected", mockFeed.proxy(), true);
		mockFeedModel.expect("refreshFeed", C.IS_NOT_NULL);
		mockFeedModel.expect("refreshFeed", C.IS_NOT_NULL);

		Mock mockEntryModel = new Mock(EntryModel.class);
		mockEntryModel.expect("loadEntries", C.eq(finalEntries));
		
		RefreshFeedTask task = new RefreshFeedTask((Feed)mockFeed.proxy(), (FeedStore) mockFeedStore.proxy(), 
			(EntryStore)mockEntryStore.proxy(), (FeedModel)mockFeedModel.proxy(), (EntryModel)mockEntryModel.proxy());

		task.run();
		
		mockFeedModel.verify();
		mockEntryStore.verify();
		mockFeed.verify();
		mockEntryModel.verify();
	}
	
	public void testUpdatesFeedStoreWhenNewEntriesListHasContent() {
		List entriesInStore = new ArrayList();
		List newEntries = new ArrayList();
		newEntries.add(StubFixture.getStubEntry());
		
		Mock mockFeed = new Mock(Feed.class);
		mockFeed.expect("setRefreshStarted");
		mockFeed.expect("setRefreshFinished");
		mockFeed.expectAndReturn("toString", "MockFeed");
		mockFeed.expectAndReturn("toString", "MockFeed");
		mockFeed.expectAndReturn("fetchNewEntries", C.IS_NOT_NULL, newEntries);
		mockFeed.expectAndReturn("getUnreadEntriesCount", 0);
		mockFeed.expectAndReturn("getUnreadEntriesCount", 0);
		mockFeed.matchAndReturn("hasChanged", true);
		
		Mock mockFeedStore = new Mock(FeedStore.class);
		mockFeedStore.expect("reconcile", C.ANY_ARGS);
		Mock mockEntryStore = new Mock(EntryStore.class);
		mockEntryStore.expectAndReturn("findEntriesInFeed", C.args(C.IS_NOT_NULL, C.eq(newEntries)), entriesInStore);
		mockEntryStore.expect("addEntries", C.same(newEntries));
		
		Mock mockFeedModel = new Mock(FeedModel.class);
		mockFeedModel.expect("refreshFeed", C.IS_NOT_NULL);
		mockFeedModel.expect("refreshFeed", C.IS_NOT_NULL);
		mockFeedModel.expectAndReturn("isSelected", C.IS_NOT_NULL, false);

		Mock mockEntryModel = new Mock(EntryModel.class);
		
		RefreshFeedTask task = new RefreshFeedTask((Feed)mockFeed.proxy(), (FeedStore) mockFeedStore.proxy(), 
			(EntryStore)mockEntryStore.proxy(), (FeedModel)mockFeedModel.proxy(), (EntryModel)mockEntryModel.proxy());

		task.run();
		
		mockFeedStore.verify();
		mockFeed.verify();
		mockFeedModel.verify();
	}
}
