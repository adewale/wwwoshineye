package com.oshineye.aggrevator;

import java.util.Comparator;
import java.util.Date;

import junit.framework.TestCase;

import org.apache.commons.lang.time.DateFormatUtils;

import com.oshineye.aggrevator.ComparatorFactory;
import com.oshineye.aggrevator.Entry;
import com.oshineye.aggrevator.Feed;
import com.oshineye.aggrevator.FeedFactory;
import com.oshineye.aggrevator.store.StubFixture;

/**
 * @author aoshineye
 */
public class ComparatorFactoryTest extends TestCase {
	public void testComparatorDoesCaseInsensitiveComparisonOfFeedTitles() {
		Comparator comparator = ComparatorFactory.getFeedTitleComparator();
		Feed firstFeed = StubFixture.getStubFeedWithTitle("hello");
		Feed secondFeed = StubFixture.getStubFeedWithTitle("Hello");
		
		assertEquals(0, comparator.compare(firstFeed, secondFeed));
	}
	
	public void testComparatorCanCorrectlyOrderFeedTitles() {
		Comparator comparator = ComparatorFactory.getFeedTitleComparator();
		Feed firstFeed = StubFixture.getStubFeedWithTitle("alpha");
		Feed secondFeed = StubFixture.getStubFeedWithTitle("beta");
		
		assertTrue(comparator.compare(firstFeed, secondFeed) < 0);
		assertTrue(comparator.compare(secondFeed, firstFeed) > 0);
	}
	
	public void testComparatorCanCorrectlyHandleNullTitles() {
		Comparator comparator = ComparatorFactory.getFeedTitleComparator();
		Feed firstFeed = StubFixture.getStubFeedWithTitle(null);
		Feed secondFeed = StubFixture.getStubFeedWithTitle("beta");
		
		assertTrue(comparator.compare(firstFeed, secondFeed) < 0);
		assertTrue(comparator.compare(secondFeed, firstFeed) > 0);
	}
	
	public void testComparatorCanCorrectlyOrderUnreadEntriesCount() {
		Comparator comparator = ComparatorFactory.getFeedUnreadEntriesCountComparator();
		Feed firstFeed = StubFixture.getStubFeedWithUnreadEntriesCount(1);
		Feed secondFeed = StubFixture.getStubFeedWithUnreadEntriesCount(2);
		
		assertTrue(comparator.compare(firstFeed, secondFeed) < 0);
		assertTrue(comparator.compare(secondFeed, firstFeed) > 0);
	}
	
	public void testComparatorCanCorrectlyOrderUnreadEntriesCountEvenWhenEqual() {
		Comparator comparator = ComparatorFactory.getFeedUnreadEntriesCountComparator();
		Feed firstFeed = StubFixture.getStubFeedWithUnreadEntriesCount(1);
		Feed secondFeed = StubFixture.getStubFeedWithUnreadEntriesCount(1);
		
		assertEquals(0, comparator.compare(firstFeed, secondFeed));
	}
	
	public void testComparatorDoesCaseInsensitiveComparisonOfFeedUrls() {
		Comparator comparator = ComparatorFactory.getFeedUrlComparator();
		Feed firstFeed = StubFixture.getStubFeedWithUrl("http://hello");
		Feed secondFeed = StubFixture.getStubFeedWithUrl("http://Hello");
		
		assertEquals(0, comparator.compare(firstFeed, secondFeed));
	}
	
	public void testComparatorCanCorrectlyOrderFeedUrls() {
		Comparator comparator = ComparatorFactory.getFeedUrlComparator();
		Feed firstFeed = StubFixture.getStubFeedWithUrl("http://alpha");
		Feed secondFeed = StubFixture.getStubFeedWithUrl("http://beta");
		
		assertTrue(comparator.compare(firstFeed, secondFeed) < 0);
		assertTrue(comparator.compare(secondFeed, firstFeed) > 0);
	}
	
	public void testComparatorCanCorrectlyOrderFeedsBasedOnScores() {
		Comparator comparator = ComparatorFactory.getFeedScoreComparator();
		Feed firstFeed = StubFixture.getStubFeedWithTitleAndScore("alpha", 2);
		Feed secondFeed = StubFixture.getStubFeedWithTitleAndScore("beta",  1);
		
		assertTrue(comparator.compare(firstFeed, secondFeed) < 0);
		assertTrue(comparator.compare(secondFeed, firstFeed) > 0);
	}
	
	public void testComparatorCanCorrectlyOrderFeedsBasedOnDates() {
		Comparator comparator = ComparatorFactory.getFeedDateComparator();
		long time = 0;
		Date date = new Date(time);
		Date secondDate = new Date(time + 10000);
		Feed firstFeed = FeedFactory.createFeedFromStore(1, "url", "alpha", 0, 0, null, DateFormatUtils.SMTP_DATETIME_FORMAT.format(date)); 
		Feed secondFeed = FeedFactory.createFeedFromStore(1, "url", "beta", 0, 0, null, DateFormatUtils.SMTP_DATETIME_FORMAT.format(secondDate));
		
		assertTrue(comparator.compare(firstFeed, secondFeed) < 0);
		assertTrue(comparator.compare(secondFeed, firstFeed) > 0);
	}
	
	public void testComparatorCanCorrectlyHandleNullDates() {
		Comparator comparator = ComparatorFactory.getFeedDateComparator();
		long time = 0;
		Date secondDate = new Date(time + 10000);
		Feed firstFeed = FeedFactory.createFeedFromStore(1, "url", "alpha", 0, 0, null, null); 
		Feed secondFeed = FeedFactory.createFeedFromStore(1, "url", "beta", 0, 0, null, DateFormatUtils.SMTP_DATETIME_FORMAT.format(secondDate));
		
		assertTrue(comparator.compare(firstFeed, secondFeed) < 0);
		assertTrue(comparator.compare(secondFeed, firstFeed) > 0);
	}
	
	public void testReverseComparatorInvertsResults() {
		Comparator comparator = ComparatorFactory.getFeedScoreComparator();
		Comparator reverseComparator = ComparatorFactory.createReverseComparator(comparator);
		Comparator reverseReverseComparator = ComparatorFactory.createReverseComparator(reverseComparator);
		Feed firstFeed = StubFixture.getStubFeedWithTitleAndScore("alpha", 2);
		Feed secondFeed = StubFixture.getStubFeedWithTitleAndScore("beta",  1);

		assertFalse(comparator.compare(firstFeed, secondFeed) == reverseComparator.compare(firstFeed, secondFeed));
		assertFalse(comparator.compare(secondFeed, firstFeed) == reverseComparator.compare(secondFeed, firstFeed));
		assertEquals(comparator.compare(firstFeed, secondFeed), reverseReverseComparator.compare(firstFeed, secondFeed));
		assertEquals(comparator.compare(secondFeed, firstFeed), reverseReverseComparator.compare(secondFeed, firstFeed));
	}

	public void testComparatorCanCorrectlyOrderEntryTitles() {
		Comparator comparator = ComparatorFactory.getEntryTitleComparator();
		Entry firstEntry = StubFixture.getStubEntryWithTitle("alpha");
		Entry secondEntry = StubFixture.getStubEntryWithTitle("beta");
		
		assertTrue(comparator.compare(firstEntry, secondEntry) < 0);
		assertTrue(comparator.compare(secondEntry, firstEntry) > 0);
	}
	
	public void testComparatorDoesCaseInsensitiveComparisonOfEntryTitles() {
		Comparator comparator = ComparatorFactory.getEntryTitleComparator();
		Entry firstEntry = StubFixture.getStubEntryWithTitle("hello");
		Entry secondEntry = StubFixture.getStubEntryWithTitle("HELLO");
		
		assertEquals(0, comparator.compare(secondEntry, firstEntry));
	}

	public void testComparatorCanCorrectlyOrderFeedTitlesFromEntry() {
		Feed firstFeed = StubFixture.getStubFeedWithTitle("alpha");
		Feed secondFeed = StubFixture.getStubFeedWithTitle("beta");
		Comparator comparator = ComparatorFactory.getEntryFeedTitleComparator();
		Entry firstEntry = StubFixture.getStubEntry(firstFeed);
		Entry secondEntry = StubFixture.getStubEntry(secondFeed);
		
		assertTrue(comparator.compare(firstEntry, secondEntry) < 0);
		assertTrue(comparator.compare(secondEntry, firstEntry) > 0);
	}

	public void testComparatorDoesCaseInsensitiveComparisonOfFeedTitlesFromEntry() {
		Feed firstFeed = StubFixture.getStubFeedWithTitle("hello");
		Feed secondFeed = StubFixture.getStubFeedWithTitle("hello");
		Comparator comparator = ComparatorFactory.getEntryFeedTitleComparator();
		Entry firstEntry = StubFixture.getStubEntry(firstFeed);
		Entry secondEntry = StubFixture.getStubEntry(secondFeed);
		assertEquals(0, comparator.compare(secondEntry, firstEntry));
	}
	
	public void testComparatorCanCorrectlyOrderEntryDates() {
		Comparator comparator = ComparatorFactory.getEntryDateComparator();
		Date date = new Date();
		Entry firstEntry = StubFixture.getStubEntryWithTime(null, date.getTime());
		Entry secondEntry = StubFixture.getStubEntryWithTime(null, date.getTime() + 1000);
		
		assertTrue(comparator.compare(firstEntry, secondEntry) < 0);
		assertTrue(comparator.compare(secondEntry, firstEntry) > 0);
	}
	
	public void testComparatorCanCorrectlyOrderEntriessBasedOnScores() {
		Comparator comparator = ComparatorFactory.getEntryScoreComparator();
		Entry firstEntry = StubFixture.getStubEntryWithTitleAndScore("alpha", 2);
		Entry secondEntry = StubFixture.getStubEntryWithTitleAndScore("beta", 1);
		
		assertTrue(comparator.compare(firstEntry, secondEntry) < 0);
		assertTrue(comparator.compare(secondEntry, firstEntry) > 0);
	}
}
