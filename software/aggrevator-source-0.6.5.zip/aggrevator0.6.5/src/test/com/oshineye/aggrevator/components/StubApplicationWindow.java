package com.oshineye.aggrevator.components;

import org.eclipse.jface.window.ApplicationWindow;
import org.eclipse.swt.widgets.Display;

import com.oshineye.aggrevator.components.Block;


public class StubApplicationWindow extends ApplicationWindow {

	public StubApplicationWindow() {
		super(null);
	}

	public void execute(Block test) {
		this.setBlockOnOpen(false);
		this.open();
		test.execute();
		Display.getCurrent().dispose();
	}
}
