package com.oshineye.aggrevator;

import junit.framework.TestCase;

/**
 * @author aoshineye
 *
 */
public class FeedRecordTest extends TestCase {
	public void testCanDetectEquivalenceWhenEtagIsNull() {
		FeedRecord record = FeedFactory.createFeedRecordFromStore(99, "some url", "some title", null, "some last modified");
		Feed feed = FeedFactory.createFeedFromStore(99, "some url", "some title", 0, 0, null, "some last modified");
		assertTrue(record.isEquivalent(feed));
	}
	
	public void testCanDetectEquivalenceWhenLastModifiedIsNull() {
		FeedRecord record = FeedFactory.createFeedRecordFromStore(99, "some url", "some title", "some etag", null);
		Feed feed = FeedFactory.createFeedFromStore(99, "some url", "some title", 0, 0, "some etag", null);
		assertTrue(record.isEquivalent(feed));
	}
}
