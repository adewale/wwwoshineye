package com.oshineye.aggrevator.store;


/**
 * @author aoshineye
 */
public class MySqlFeedStoreTest extends AbstractFeedStoreTest {
	protected EntryStore createEntryStore() {
		return StubFixture.getEntryStore();
	}

	protected FeedStore createFeedStore() {
		return StubFixture.getFeedStore();
	}

	public void testFeedIdentityMapIsPopulatedByFirstCallToFindAllFeeds() {
		FeedIdentityMap map = new FeedIdentityMap();
		
		FeedStore mySqlFeedStore = new MySqlFeedStore(StubFixture.TEST_DATABASE_NAME, map, StubFixture.QUERY_LOADER);
		assertFalse(map.isPopulated());
		
		mySqlFeedStore.findAllFeeds();
		assertTrue(map.isPopulated());
	}
	
}
