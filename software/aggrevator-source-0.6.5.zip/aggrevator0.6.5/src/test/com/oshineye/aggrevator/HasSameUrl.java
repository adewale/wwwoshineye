package com.oshineye.aggrevator;

import com.mockobjects.constraint.Constraint;


public class HasSameUrl implements Constraint {
    private Feed feed;
    
    public HasSameUrl(Feed feed) {
        this.feed = feed;
    }
    
    public boolean eval(Object arg) {
        if (!(arg instanceof Feed)) {
            return false;
        }
        Feed otherFeed = (Feed) arg;
        return feed.hasSameUrl(otherFeed);
    }
    
    public String toString() {
        return "has same url <" + feed + ">";
    }
}