package com.oshineye.aggrevator.util;

import java.util.List;

import junit.framework.TestCase;

import com.oshineye.aggrevator.Feed;
import com.oshineye.aggrevator.store.StubFixture;
import com.oshineye.aggrevator.util.Summariser;
import com.oshineye.aggrevator.util.SummariserImpl;

/**
 * @author aoshineye
 */
public class SummariserTest extends TestCase {
	public void testRecordsNumberOfImportedFeeds() {
		Summariser s = new SummariserImpl();
		int count = 3;
		for (int i=0; i<count; i++) {
			s.feedImported(null);
		}
		assertEquals(count, s.getImportedFeedsCount());
	}
	
	public void testRecordsNumberOfStoredFeeds() {
		Summariser s = new SummariserImpl();
		int count = 3;
		for (int i=0; i<count; i++) {
			s.feedStored(null);
		}
		assertEquals(count, s.getStoredFeedsCount());
	}
	
	public void testRecordsNewlyAddedFeeds() {
		Feed f1 = StubFixture.getStubFeedWithUrl(StubFixture.TEST_URL);
		Feed f2 = StubFixture.getStubFeedWithUrl(StubFixture.TEST_URL2);
		Summariser s = new SummariserImpl();
		s.feedImported(f1);
		s.feedStored(f1);
		s.feedImported(f2);
		s.feedStored(f2);
		
		List feeds = s.getNewlyAddedFeeds();
		assertEquals(f1, feeds.get(0));
		assertEquals(f2, feeds.get(1));
	}
}
