package com.oshineye.aggrevator.store;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

import junit.framework.TestCase;

import com.oshineye.aggrevator.Entry;
import com.oshineye.aggrevator.Feed;
import com.oshineye.aggrevator.FeedRecord;
import com.oshineye.aggrevator.store.DuplicateFeedException;
import com.oshineye.aggrevator.store.EntryStore;
import com.oshineye.aggrevator.store.FeedStore;
/**
 * @author aoshineye
 *
 */
public abstract class AbstractFeedStoreTest extends TestCase {
	protected Feed feed;
	protected FeedStore feedStore;
	protected EntryStore entryStore;

	protected abstract EntryStore createEntryStore();
	
	protected abstract FeedStore createFeedStore();
	
	public void setUp() {
		feed = StubFixture.getStubFeed();
		entryStore = createEntryStore();
		feedStore = createFeedStore();
	}

	public void tearDown() {
		entryStore.deleteAll();
		feedStore.deleteAll();
	}

	public void testAddingAndRetrievingFeed() {
		feedStore.add(feed);
		Feed retrievedFeed = feedStore.findFeed(feed.getId());
		assertNotNull("Retrieved feed was null", retrievedFeed);
		assertEquals(feed, retrievedFeed);
		assertTrue(feed.hasSameUrl(retrievedFeed));
	}
	
	public void testAddingFeedStoresAllItsPropertiesNotJustUserSpecifiedProperties() {
		//this is necessary for the data migration code because it adds a feed
		//that already has an etag and last-modified
		feedStore.add(feed);
		Feed retrievedFeed = feedStore.findFeed(feed.getId());
		
		assertNotNull("Retrieved feed was null", retrievedFeed);
		assertEquals(feed, retrievedFeed);
		assertTrue(feed.hasSameUrl(retrievedFeed));
		
		assertNotNull(feed.getEtag());
		assertNotNull(retrievedFeed.getEtag());
		assertEquals(feed.getEtag(), retrievedFeed.getEtag());
		assertEquals(feed.getLastModified(), retrievedFeed.getLastModified());
	}

	public void testAddingDuplicateFeedObjectFails() {
		feedStore.add(feed);
		try {
			feedStore.add(feed);
			fail("Store allowed same feed object to be added twice");
		} catch (DuplicateFeedException dfe) {
			//ignore
		}
	}

	public void testAddingDuplicateFeedUrlFails() {
		feedStore.add(feed);
		try {
			feedStore.add(StubFixture.getStubFeedWithUrl(StubFixture.TEST_URL));
			fail("Store allowed feed with the same url to be added twice");
		} catch (DuplicateFeedException dfe) {
			//ignore
		}
	}
	
	public void testAddingDuplicateFeedUrlWithDifferentTitleFails() {
		feedStore.add(feed);
		try {
			feedStore.add(StubFixture.getStubFeedWithTitleAndUrl("some other title", StubFixture.TEST_URL));
			fail("Store allowed feed with the same url but a different title to be added twice");
		} catch (DuplicateFeedException dfe) {
			//ignore
		}
	}

	public void testAddingDuplicateUrlWithDifferentCaseFails() {
		feedStore.add(feed);
		try {
			feedStore.add(StubFixture.getStubFeedWithUrl(StubFixture.TEST_URL.toUpperCase()));
			fail("Store allowed url to be added twice with different case");
		} catch (DuplicateFeedException e) {
			//ignore
		}
	}
	
	public void testAddingDuplicateFeedThrowsExceptionWithMeaningfulMessage() {
		feedStore.add(feed);
		try {
			feedStore.add(StubFixture.getStubFeed());
		} catch (DuplicateFeedException e) {
			assertTrue(e.getMessage().indexOf(StubFixture.TEST_URL) != -1);
		}
	}
	
	public void testRetrievingAllFeedRecordsGetsRecordsThatMatchStoredFeeds() {
		feedStore.add(feed);
		Feed testFeed = StubFixture.getStubFeedWithUrl(StubFixture.TEST_URL2);
		feedStore.add(testFeed);
		
		List records = feedStore.findAllFeedRecords();
		assertNotNull(records);
		assertEquals(2, records.size());
		
		FeedRecord record1 = (FeedRecord)records.get(0);
		assertEquals(feed.getId(), record1.getId());
		assertEquals(feed.getTitle(), record1.getTitle());
		assertEquals(feed.getUrl(), record1.getUrl());
		assertEquals(feed.getEtag(), record1.getEtag());
		assertEquals(feed.getLastModified(), record1.getLastModified());
		
		FeedRecord record2 = (FeedRecord)records.get(1);
		assertEquals(testFeed.getId(), record2.getId());
		assertEquals(testFeed.getTitle(), record2.getTitle());
		assertEquals(testFeed.getUrl(), record2.getUrl());
		assertEquals(testFeed.getEtag(), record2.getEtag());
		assertEquals(testFeed.getLastModified(), record2.getLastModified());
	}
	
	
	public void testRetrievingAllFeeds() {
		feedStore.add(feed);
		Feed testFeed = StubFixture.getStubFeedWithUrl(StubFixture.TEST_URL2);
		feedStore.add(testFeed);
		
		List feeds = feedStore.findAllFeeds();
		
		assertNotNull(feeds);
		assertEquals(2, feeds.size());
		assertTrue(feeds.contains(feed));
		assertTrue(feeds.contains(testFeed));
	}
	
	public void testRetrievingAllFeedsCanBringBackFeedWithNoEntries() {
		String url = "new url that doesn't already exist in the system";
		feedStore.add(StubFixture.getStubFeedWithUrl(url));
		
		List feeds = feedStore.findAllFeeds();
		
		assertNotNull(feeds);
		assertEquals(1, feeds.size());
		
		Feed storedFeed = (Feed)feeds.get(0);
		assertEquals(url, storedFeed.getUrl());
	}
	
	public void testRetrievingAllFeedsBringsBackEmptyListWhenThereAreNoFeedsAvailable() {
		List feeds = feedStore.findAllFeeds();
		
		assertNotNull(feeds);
		assertEquals(0, feeds.size());
	}
	
	public void testRetrievingAllFeedsBringsBackValidFeedObjects() {
		Feed testFeed = StubFixture.getStubFeedWithUrl(StubFixture.TEST_URL);
		feedStore.add(testFeed);
		Feed testFeed2 = StubFixture.getStubFeedWithUrl(StubFixture.TEST_URL2);
		feedStore.add(testFeed2);
		entryStore.addEntries(testFeed.fetchNewEntries());
		entryStore.addEntries(testFeed2.fetchNewEntries());
		
		List feeds = feedStore.findAllFeeds();
		Feed retrievedFeed1 = (Feed) feeds.get(0);
		Feed retrievedFeed2 = (Feed) feeds.get(1);
		
		assertFalse(retrievedFeed1.equals(retrievedFeed2));
		assertEquals(testFeed, retrievedFeed1);
		assertEquals(testFeed2, retrievedFeed2);
	}
	
	public void testRetrievingAllFeedsBringsBackValidFeedObjectEvenWhenThereAreNoUnreadEntries() {
		feedStore.add(feed);
		Feed testFeed = StubFixture.getStubFeedWithUrl(StubFixture.TEST_URL2);
		feedStore.add(testFeed);
		
		List feeds = feedStore.findAllFeeds();

		Feed retrievedFeed1 = (Feed) feeds.get(0);
		assertEquals(0, retrievedFeed1.getUnreadEntriesCount());
		
		Feed retrievedFeed2 = (Feed) feeds.get(1);
		assertEquals(0, retrievedFeed2.getUnreadEntriesCount());
		assertFalse(retrievedFeed1.equals(retrievedFeed2));
	}
	
	public void testRetrievingAllFeedsBringsBackValidFeedObjectsWhenMultipleFeedsHaveSameTitle() {
		Feed testFeed = StubFixture.getStubFeedWithUrl(StubFixture.TEST_URL);
		feedStore.add(testFeed);
		Feed testFeed2 = StubFixture.getStubFeedWithUrl(StubFixture.TEST_URL_CLONE_WITH_ONE_LESS_ENTRY);
		feedStore.add(testFeed2);
		entryStore.addEntries(testFeed.fetchNewEntries());
		entryStore.addEntries(testFeed2.fetchNewEntries());
		
		markEntryRead(testFeed);
		markEntryRead(testFeed2);
		
		List feeds = feedStore.findAllFeeds();
		assertEquals(2, feeds.size());

		Feed retrievedFeed = (Feed) feeds.get(feeds.indexOf(testFeed));
		Feed retrievedFeed2 = (Feed) feeds.get(feeds.indexOf(testFeed2));
		
		assertFalse(retrievedFeed.equals(retrievedFeed2));
		assertEquals(testFeed, retrievedFeed);
		assertEquals(testFeed2, retrievedFeed2);
	}

	public void testRetrievingAllFeedsTwiceReturnsSameObjectsInSameOrder() {
		feedStore.add(feed);
		Feed testFeed = StubFixture.getStubFeedWithUrl(StubFixture.TEST_URL2);
		feedStore.add(testFeed);
		
		List feeds = feedStore.findAllFeeds();
		List cachedFeeds = feedStore.findAllFeeds();
		
		assertSame(feeds.get(0), cachedFeeds.get(0));
		assertSame(feeds.get(1), cachedFeeds.get(1));
	}
	
	public void testDeletingFeedRemovesItFromStore() {
		feedStore.add(feed);
		assertNotNull(feedStore.findFeed(feed.getId()));
		assertEquals(1, feedStore.findAllFeeds().size());
		
		feedStore.delete(feed);
		assertEquals(0, feedStore.findAllFeeds().size());
	}
	
	public void testMarkingAllEntriesInFeedAsReadDoesNotAffectScore() {
		Feed testFeed = StubFixture.getStubFeedWithUrl(StubFixture.TEST_URL);
		feedStore.add(testFeed);
		List fetchedEntries = testFeed.fetchNewEntries();
		entryStore.addEntries(fetchedEntries);
		
		assertEquals(0, testFeed.getScore());
		
		feedStore.markRead(testFeed);

		assertEquals(0, testFeed.getScore());
		assertTrue(testFeed.isRead());
	}
	
	public void testMarkingAllEntriesInFeedAsReadPersists() {
		feedStore.add(feed);
		List fetchedEntries = feed.fetchNewEntries();
		entryStore.addEntries(fetchedEntries);

		feedStore.markRead(feed);
		List entries = entryStore.findEntriesInFeed(feed.getId());
		for (Iterator iter = entries.iterator(); iter.hasNext();) {
			Entry entry = (Entry) iter.next();
			assertTrue(entry.isRead());
		}
		assertEquals(0, feed.getUnreadEntriesCount());
	}
	
	public void testMarkingAllEntriesInFeedAsReadMarksThoseEntriesAsReadWhenTheyBelongToOtherFeeds() {
		//we should mark all entries as read using the link field of all those entries
		feedStore.add(feed);
		List fetchedEntries = feed.fetchNewEntries();
		entryStore.addEntries(fetchedEntries);
		Entry entry1 = (Entry) fetchedEntries.get(0);
		String sharedLink = entry1.getUrl();
		
		Feed testFeed = StubFixture.getStubFeedWithUrl(StubFixture.TEST_URL2);
		feedStore.add(testFeed);
		Entry entry2 = StubFixture.getStubEntryWithPermaLinkAndFeedId(sharedLink, testFeed.getId());
		entryStore.addEntries(Arrays.asList(new Entry[]{entry2}));
		
		feedStore.markRead(feed);
		
		List entries = entryStore.findEntriesInFeed(testFeed.getId());
		Entry entryThatShouldBeRead = (Entry) entries.get(0);
		assertEquals(sharedLink, entryThatShouldBeRead.getUrl());
		assertTrue(entryThatShouldBeRead.isRead());
	}
	
	public void testCanTellIfFeedUrlAlreadyExistsInStore() {
		feedStore.add(feed);
		assertTrue(feedStore.urlExists(feed));
		
		feedStore.delete(feed);
		assertFalse(feedStore.urlExists(feed));
	}
	
	public void testFeedCanBeUpdated() {
		Feed testFeed = StubFixture.getStubFeed();
		feedStore.add(testFeed);

		String updateString = "UPDATED";
		Long id = testFeed.getId();
		String url = testFeed.getUrl() + updateString;
		String title = testFeed.getTitle() + updateString;
		String etag = testFeed.getEtag() + updateString;
		String lastModified = testFeed.getLastModified() + updateString;
		
		Feed updatedFeed = StubFixture.getStubFeedWithKeyTitleUrlEtagAndLastModified(id, title, url, etag, lastModified);
		assertEquals(testFeed.getId(), updatedFeed.getId());
		feedStore.reconcile(updatedFeed);
		
		Feed fetchedFeed = feedStore.findFeed(updatedFeed.getId());
		assertEquals(id, fetchedFeed.getId());
		assertEquals(url, fetchedFeed.getUrl());
		assertEquals(title, fetchedFeed.getTitle());
		
		assertEquals(etag, fetchedFeed.getEtag());
		assertEquals(lastModified, fetchedFeed.getLastModified());
	}
	
	private void markEntryRead(Feed testFeed) {
		List entries = entryStore.findEntriesInFeed(testFeed.getId());
		assertFalse(entries.isEmpty());

		Entry entry = (Entry)entries.get(0);
		entry.markRead();
		testFeed.entryRead();
	}
}

