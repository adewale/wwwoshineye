package com.oshineye.aggrevator.util;

import org.eclipse.jface.dialogs.IInputValidator;

import junit.framework.TestCase;

/**
 * @author aoshineye
 *
 */
public class StringInputValidatorTest extends TestCase {
	public void testEmptyStringIsInvalidText() {
		String invalidText = "";
		String errorMessage = "error message";
		IInputValidator inputValidator = new StringInputValidator(errorMessage);
		assertNotNull(inputValidator.isValid(invalidText));
	}

	public void testStringThatOnlyContainsWhitespaceIsInvalidText() {
		String invalidText = "   ";
		String errorMessage = "error message";
		IInputValidator inputValidator = new StringInputValidator(errorMessage);
		assertNotNull(inputValidator.isValid(invalidText));
	}

	public void testReturnsErrorMessageForInvalidText() {
		String invalidText = "";
		String errorMessage = "error message";
		IInputValidator inputValidator = new StringInputValidator(errorMessage);
		assertEquals(errorMessage, inputValidator.isValid(invalidText));
	}
	
	public void testReturnsNullForValidText() {
		String validText = "valid text";
		String errorMessage = "error message";
		IInputValidator inputValidator = new StringInputValidator(errorMessage);
		assertNull(inputValidator.isValid(validText));
	}

}
