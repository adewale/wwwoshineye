package com.oshineye.kwikwiki.wikibase;

import com.oshineye.kwikwiki.TunnellingException;
import com.oshineye.kwikwiki.markup.MarkUpEngine;
import com.oshineye.kwikwiki.page.WikiPage;
import com.oshineye.kwikwiki.page.Page;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.FilenameFilter;
import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;
import java.util.Collections;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class FileBase extends WikiBase {
	private static final String FILE_SEPARATOR = System.getProperty("file.separator");

	private static final String WIKI_DIR_NAME= System.getProperty("user.home")
		+ FILE_SEPARATOR + "kwikwiki-data" + FILE_SEPARATOR;
	private static final File WIKI_DIR = new File(WIKI_DIR_NAME);

	private static final String METADATA_DIR_NAME = WIKI_DIR_NAME
		+ FILE_SEPARATOR + "metadata" + FILE_SEPARATOR;

	private static final String CHANGES_DIR_NAME = METADATA_DIR_NAME
		+ FILE_SEPARATOR + "changelogs" + FILE_SEPARATOR;
    private static final File CHANGES_DIR = new File(CHANGES_DIR_NAME);

	private static final TextFilter TEXT_FILTER = new TextFilter();
	private static final String TEXT_EXTENSION = ".txt";
	private static final int TEXT_EXTENSION_LENGTH = 4;//includes the dot

    private static final SortedSet EMPTY_SET = Collections.unmodifiableSortedSet(new TreeSet());

	private HashMap reverseFileIndex;


	public FileBase() {
		this.reverseFileIndex = new HashMap();
		this.buildIndex();
	}

	public SortedSet getOrphanedPages() {
		SortedSet wikiNames = super.getAllTitles();

		SortedSet orphanedPages = new TreeSet();
		for (Iterator it=wikiNames.iterator(); it.hasNext();) {
			String wikiName = (String)it.next();
			if (isOrphanedPage(wikiName)) {
				orphanedPages.add(wikiName);
			}
		}
		return orphanedPages;
	}

    private boolean isOrphanedPage(String wikiName) {
        SortedSet occurrences = locateWord(wikiName);
        boolean hasOccurrences = occurrences.size() == 0;
        boolean isNotSpecial = !Page.isSpecialPage(wikiName);
        return (hasOccurrences && (pageExists(wikiName)) && isNotSpecial);
    }

    public SortedSet getWantedPages() {
		Set wikiNames = extractWikiNamesFromIndex();

		//retrieve wanted wikinames
		SortedSet wantedPages = new TreeSet();
        for (Iterator it=wikiNames.iterator(); it.hasNext();) {
			String wikiName = (String) it.next();
			if (!this.pageExists(wikiName)) {
				wantedPages.add(wikiName);
			}
        }
        return wantedPages;
	}

	public SortedSet locateWord(String word) {
		if (this.reverseFileIndex.containsKey(word)) {
			return (SortedSet)this.reverseFileIndex.get(word);
		} else {
			return EMPTY_SET;
		}
	}

	public SortedSet getTitlesStartingWith(String word) {
		//obtain set of titles that begin with the word
		SortedSet shareWord = new TreeSet();
		for (Iterator it=this.getAllTitles().iterator(); it.hasNext();) {
			String candidateTitle = (String) it.next();
			if (candidateTitle.startsWith(word)) {
				shareWord.add(candidateTitle);
			}
		}
		return	shareWord;
	}

	public SortedSet getTitlesEndingWith(String word) {
		//obtain set of titles that end with the word
		SortedSet shareWord = new TreeSet();
		for (Iterator it=this.getAllTitles().iterator(); it.hasNext();) {
			String candidateTitle = (String) it.next();
			if (candidateTitle.endsWith(word)) {
				shareWord.add(candidateTitle);
			}
		}
		return shareWord;
	}

	public SortedSet loadTitles() {
		File[] files = WIKI_DIR.listFiles(TEXT_FILTER);

		SortedSet set = new TreeSet();
		int directoryNameLength = WIKI_DIR_NAME.length();
		for (int i=0; i<files.length; i++) {
			String temp = files[i].toString();
			int titleLength = temp.length() - TEXT_EXTENSION_LENGTH;

			//we only want the title not including the wiki directory or file extension
			String title = temp.substring(directoryNameLength, titleLength);
			set.add(title);
		}
		return set;
	}

	static class TextFilter implements FilenameFilter {
		public boolean accept(File file, String name) {
			return name.endsWith(".txt");
		}
	}
	
	public void deletePage(String title) {
		//FIXME
		/*
		Deleting requires updating of titleIndex and wantedPagesIndex
		1 step process
		*/
		File file = new File(WIKI_DIR_NAME + title + TEXT_EXTENSION);
		if (file.exists()) {
			//remove it's content from the reverse file index
			String oldText = this.loadPage(title).getText();
			String newText = "";
			this.updatePageIndex(title, oldText, newText);

			//delete the file
			file.delete();

			//remove it from the list of pages
			super.removeTitle(title);
		}
	}

	protected WikiPage loadPage(String title) {
		//assume file always exists
		File file = new File(WIKI_DIR_NAME + title + TEXT_EXTENSION);

		CharSequence rawText = this.readText(file);

		Date lastEdited = new Date(file.lastModified());

		return new WikiPage(title, rawText.toString(), lastEdited);
	}

	protected void storePage(WikiPage rawPage) {
		String title = rawPage.getTitle();
		String newText = rawPage.getText();
		String oldText = this.loadPage(title).getText();

		//1 argument constructor chosen for performance
		File file = new File(WIKI_DIR_NAME + title + TEXT_EXTENSION);

		this.writeText(file, newText, false);

		//update the reverse file index
		updatePageIndex(title, oldText, newText);
	}

	protected void storeNewPage(WikiPage rawPage) {
		String title = rawPage.getTitle();
		String text = rawPage.getText();

		//1 argument constructor chosen for performance
		File file = new File(WIKI_DIR_NAME + title + TEXT_EXTENSION);

		this.writeText(file, text, false);

		//add this page to the reverse file index
		indexPage(title);
	}

	protected void storeChange(Change change) {
		String day = change.getDay();

		//1 argument constructor chosen for performance
		File file = new File(CHANGES_DIR_NAME + day + TEXT_EXTENSION);

		String newChangeLine = MarkUpEngine.LINE_ENDING + "title:" + change.getTitle()
		+ ",date:" 	+ change.getDate().getTime() + ",editor:" + change.getEditor() + ",";

		writeText(file, newChangeLine, true);
	}

	public ChangeLog[] getRecentChanges(int numberOfDays) {
		//load all the names of all the changelog files
		String[] changeLogFiles = CHANGES_DIR.list();
        int numberOfLogs = changeLogFiles.length;

		Date[] times = convertToDates(changeLogFiles);

		//sort the names by time
		Arrays.sort(times);

		//create an array of logs no bigger than numberOfDays
		ChangeLog[] logs;
        if (numberOfLogs < numberOfDays) {
			logs = new ChangeLog[numberOfLogs];
		} else {
			logs = new ChangeLog[numberOfDays];
		}

		//populate the array with ChangeLog objects representing each day
		for (int i=numberOfLogs-logs.length, j=0; i<numberOfLogs; i++,j++) {
			String currentDay = Change.formatChangeDate(times[i]);
			File currentChangeFile = new File(CHANGES_DIR_NAME + currentDay + TEXT_EXTENSION);
			CharSequence changeText = readText(currentChangeFile);
			Change[] temp = parseChanges(changeText);
			logs[j] = new ChangeLog(temp);
		}

		//return the array of ChangeLogs
        return logs;
	}

	private void writeText(File file, CharSequence text, boolean shouldAppend) {
		BufferedWriter bw;
		try {
			bw = new BufferedWriter(new FileWriter(file, shouldAppend));
			bw.write(text.toString());
			bw.close();
		} catch (IOException ioe) {
			throw new TunnellingException(ioe);
		}
	}

	private CharSequence readText(File file) {
		/*
		potential exists for performance optimisation by specifying buffer
		sizes for the BufferedReader and StringBuffer based on the file's
		length. Although that might lead to problems with very large files.
		*/
		try {
			BufferedReader br = new BufferedReader(new FileReader(file));
			StringBuffer sb = new StringBuffer();
	
			String line;
			while ((line = br.readLine()) != null) {
				sb.append(line);
				sb.append(MarkUpEngine.LINE_ENDING);//avoid concatenation penalty
			}
			
			br.close();
			return sb;
		} catch (IOException ioe) {
			throw new TunnellingException(ioe);
		}
	}

	private Date[] convertToDates(String[] fileNames) {
		int numberOfLogs = fileNames.length;
		//convert the names to dates
		Date[] times = new Date[numberOfLogs];
		try {
			for(int i=0; i<numberOfLogs; i++) {
				String currentName = fileNames[i];
				String temp = currentName.substring(0, currentName.length() - TEXT_EXTENSION_LENGTH);
				times[i] = Change.parseChangeDay(temp);
			}
		} catch (ParseException pe) {
			throw new TunnellingException(pe);
		}
		return times;
	}

	private Change[] parseChanges(CharSequence changeLines) {
		Pattern pattern = Pattern.compile("(title:(.*),date:(.*),editor:(.*),)", Pattern.MULTILINE);
		Matcher matcher = pattern.matcher(changeLines);
		List changeList = new ArrayList();

		while(matcher.find()) {
			String tempTitle = matcher.group(2);
			String tempDate = matcher.group(3);
			String tempEditor = matcher.group(4);
			long tempTime = Long.parseLong(tempDate);
			Change temp = new Change(tempTitle, new Date(tempTime), tempEditor);
			changeList.add(temp);
		}

		//convert to an array of Changes
		Change[] changes = new Change[changeList.size()];
		for (int i=0; i<changes.length;i++) {
			changes[i] = (Change) changeList.get(i);
		}

		return changes;
	}

	private void buildIndex() {
        for(Iterator it=super.getAllTitles().iterator(); it.hasNext();) {
			String title = (String) it.next();
			if (!Page.isSpecialPage(title)) {
				indexPage(title);
			}
        }
	}

	private void indexPage(String title) {
		WikiPage rawPage = this.loadPage(title);
		String text = rawPage.getText();
		Set words = tokenize(text);
		
		addPageToIndexes(title, words);
	}
	
	private Set tokenize(String text) {
		String[] words = text.split("\\W");

		Set set = new HashSet();
		for (int i = 0; i < words.length; i++) {
			set.add(words[i]);
		}
		return set;
	}
	
	private void updatePageIndex(String title, String oldText, String newText) {
		HashSet oldWords = tokenize(oldText);
		HashSet newWords = tokenize(newText);
		
		//identify set of words that are in old text but not in new text
		Set oldWordsToRemove = (Set) oldWords.clone();
		oldWordsToRemove.removeAll(newWords);
		
		//remove this page from the indexes for those pages
		for (Iterator it=oldWordsToRemove.iterator(); it.hasNext();) {
			String word = (String) it.next();
			Set titles = (Set)this.reverseFileIndex.get(word);
			titles.remove(title);			
		}
		
		//identify words that are in new text but not in old text
		newWords.removeAll(oldWords);
		
		//add this page to their indexes
		addPageToIndexes(title, newWords);
	}
	
	private void addPageToIndexes(String title, Set words) {
		for (Iterator it = words.iterator(); it.hasNext();) {
			Object word = it.next();
			if (this.reverseFileIndex.containsKey(word)) {
				Set titles = (Set)this.reverseFileIndex.get(word);
				titles.add(title);
			} else {
				Set titles = new TreeSet();
				titles.add(title);
				this.reverseFileIndex.put(word, titles);
			}
		}
	}

	private Set extractWikiNamesFromIndex() {
		Set wikiNames = new HashSet();
		for (Iterator it=reverseFileIndex.keySet().iterator(); it.hasNext();) {
			String word = (String) it.next();

			if (MarkUpEngine.isWikiName(word)) {
				wikiNames.add(word);
			}
		}
		return wikiNames;
	}
}
