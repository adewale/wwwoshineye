package com.oshineye.kwikwiki.markup.rules;

public class BoldItalicRule extends MarkUpRule {
    private static final String PATTERN = "'{5}(.*?)'{5}";
    private static final String REPLACEMENT_TEXT = "<b><i>$1</i></b>";

    public BoldItalicRule() {
        super(BoldItalicRule.PATTERN, BoldItalicRule.REPLACEMENT_TEXT);
    }
}
