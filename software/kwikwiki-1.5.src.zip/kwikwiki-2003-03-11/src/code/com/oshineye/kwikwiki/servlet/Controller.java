package com.oshineye.kwikwiki.servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.oshineye.kwikwiki.command.Command;
import com.oshineye.kwikwiki.command.CommandFactory;



public class Controller extends HttpServlet {
    public void service(HttpServletRequest req, HttpServletResponse resp)
        throws ServletException, IOException {
        System.err.println("<====================");

        long timeBefore = System.currentTimeMillis();

        //skip the leading slash
        String command = req.getServletPath().substring(1);

        try {
            Command action = CommandFactory.getCommand(command);
            resp.setContentType("text/html");
            action.execute(req, resp, this.getServletContext());
        } catch (Exception ex) {
            System.err.println(ex.getCause());
            ex.printStackTrace(System.err);

            RequestDispatcher rd = req.getRequestDispatcher("/error.jsp");
            rd.include(req, resp);
        }

        long timeAfter = System.currentTimeMillis();
        System.err.println("====================>");
        System.err.println("Request took:: " + (timeAfter - timeBefore) + " milliseconds");
        System.err.println("====================>");
    }
}
