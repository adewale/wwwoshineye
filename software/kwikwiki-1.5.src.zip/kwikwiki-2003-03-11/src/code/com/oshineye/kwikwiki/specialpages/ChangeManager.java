/*
 * An abstract super class for pages which manipulate changes.
 */
package com.oshineye.kwikwiki.specialpages;

import java.util.Collection;

import com.oshineye.kwikwiki.config.Config;
import com.oshineye.kwikwiki.markup.MarkUpEngine;
import com.oshineye.kwikwiki.wikibase.ChangeLog;
import com.oshineye.kwikwiki.wikibase.WikiBase;

/**
 * @author aoshineye
 */
public abstract class ChangeManager {
	protected abstract int getNumberOfChanges();
	
	public String getText() {
		ChangeLog[] log = WikiBase.getInstance().getRecentChanges(this.getNumberOfChanges());

		StringBuffer sb = new StringBuffer();

		//go through logs in reverse chronological order
		for (int i = log.length - 1; i >= 0; i--) {
			ChangeLog currentLog = log[i];
			Collection changes = currentLog.getFilteredChanges();
			sb.append(MarkUpEngine.convertToBold(currentLog.getDay()) + Config.LINE_ENDING);
			sb.append(MarkUpEngine.convertChanges(changes));
		}

		return sb.toString();
	}
}
