package com.oshineye.kwikwiki.wikibase;

import java.sql.PreparedStatement;
import java.sql.SQLException;

/**
 * @author aoshineye
 */
public interface JdbcBlock {
	/**
	 * @return String
	 */
	public String getQuery();

	/**
	 * @param stmt
	 */
	public void configure(PreparedStatement stmt) throws SQLException;

}
