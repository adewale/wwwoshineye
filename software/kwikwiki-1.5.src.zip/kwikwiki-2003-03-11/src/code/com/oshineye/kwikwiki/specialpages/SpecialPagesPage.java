package com.oshineye.kwikwiki.specialpages;

import com.oshineye.kwikwiki.markup.MarkUpEngine;


public class SpecialPagesPage implements SpecialPage {
    public String getText() {
        return MarkUpEngine.convertToWikiList(PageFactory.getAllSpecialPages());
    }
}
