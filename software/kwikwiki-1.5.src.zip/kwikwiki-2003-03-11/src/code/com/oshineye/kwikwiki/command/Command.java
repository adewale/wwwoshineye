package com.oshineye.kwikwiki.command;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


/**
 * An abstract factory that is used to instantiate it's various sub-classes.
 * It defines the contract that all commands must fulfill.
 */
public abstract class Command {
    protected static final String INVALID_TITLE = "/invalidTitle.jsp";
    protected static final String ERROR = "/error.jsp";
    protected static final String EDIT = "/editTemplate.jsp";

    protected static void include(String resource, HttpServletRequest req,
        HttpServletResponse resp, ServletContext sc) throws IOException, ServletException {
        RequestDispatcher rd = sc.getRequestDispatcher(resource);
        rd.include(req, resp);
    }

    public abstract void execute(HttpServletRequest req, HttpServletResponse resp, ServletContext sc)
        throws Exception;
}
