package com.oshineye.kwikwiki.command;

import com.oshineye.kwikwiki.markup.MarkUpEngine;
import com.oshineye.kwikwiki.markup.ViewBean;
import com.oshineye.kwikwiki.wikibase.WikiBase;

import java.util.Iterator;
import java.util.SortedSet;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class Like extends Command {
    private static final String LIKE = "/likeTemplate.jsp";
    private static final String EMPTY_TABLE_CELL = "<td></td>";
    private static final Pattern FIRST_WORD_PATTERN = Pattern.compile("(^[A-Z][a-z0-9]+)");
    private static final Pattern LAST_WORD_PATTERN = Pattern.compile("([A-Z][a-z0-9]+)$");

    public void execute(HttpServletRequest req, HttpServletResponse resp, ServletContext sc)
        throws Exception {
        System.err.println("==Executing like command==");

        String title = req.getParameter("title");

        if (MarkUpEngine.isWikiName(title)) {
            String firstWord = extractFirstWord(title);
            String lastWord = extractLastWord(title);
			WikiBase wikiBase = WikiBase.getInstance();
			
            SortedSet firstWordMatches = wikiBase.getTitlesStartingWith(firstWord);
            SortedSet lastWordMatches = wikiBase.getTitlesEndingWith(lastWord);
            firstWordMatches.remove(title);
            lastWordMatches.remove(title);

            StringBuffer text = new StringBuffer();
            Iterator firstWords = firstWordMatches.iterator();
            Iterator lastWords = lastWordMatches.iterator();

            int loopLength = Math.max(firstWordMatches.size(), lastWordMatches.size());
            text.append("<tr><td class=\"header\"> Titles beginning with ");
            text.append(firstWord);
            text.append("</td><td class=\"header\">Titles ending with ");
            text.append(lastWord);
            text.append("</td></tr>");

            for (int i = 0; i < loopLength; i++) {
                text.append("<tr>");
                populateTableCell(firstWords, text);
                populateTableCell(lastWords, text);
                text.append("</tr>");
            }

            ViewBean page = new ViewBean(title, text.toString());
            req.setAttribute("pageBean", page);
            Command.include(Like.LIKE, req, resp, sc);
            Command.include("/readOnlyFooter.jsp", req, resp, sc);
        } else {
            //go to invalid page title error page
            Command.include(Command.INVALID_TITLE, req, resp, sc);
        }
    }

    private void populateTableCell(Iterator it, StringBuffer text) {
        if (it.hasNext()) {
            String title = (String) it.next();
            text.append("<td><a href=\"View?title=" + title + "\">" + title + "</a></td>");
        } else {
            text.append(EMPTY_TABLE_CELL);
        }
    }

    private String extractFirstWord(String title) {
        Matcher firstWordMatcher = FIRST_WORD_PATTERN.matcher(title);
        firstWordMatcher.find();

        return firstWordMatcher.group(1);
    }

    private String extractLastWord(String title) {
        Matcher lastWordMatcher = LAST_WORD_PATTERN.matcher(title);
        lastWordMatcher.find();

        return lastWordMatcher.group(1);
    }
}
