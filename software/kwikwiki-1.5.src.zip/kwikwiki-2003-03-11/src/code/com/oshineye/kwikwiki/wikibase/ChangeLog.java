package com.oshineye.kwikwiki.wikibase;

import java.text.SimpleDateFormat;

import java.util.Arrays;
import java.util.Collection;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

/**
 * A representation of all the changes that happened on a particular day.
 */
public class ChangeLog {
	//format is Thursday 30 May 2002
	private static final SimpleDateFormat DAY_FORMATTER = new SimpleDateFormat("EEEE dd MMMM yyyy");
	private static final ChangeComparator CHANGE_COMPARATOR = new ChangeComparator();
	private final String day;
	private final List changes;

	/**
	* @param changes An array of Change objects for a particular day. This
	* array must have at least one element or a NullPointException will be
	* thrown. Days without changes can't have ChangeLogs.
	*
	*/
	public ChangeLog(Change[] changes) {
		//sort the changes in ascending order, earliest first
		Arrays.sort(changes, CHANGE_COMPARATOR);

		this.changes = Arrays.asList(changes);
		Change firstDay = (Change) this.changes.get(0);
		this.day = DAY_FORMATTER.format(firstDay.getDate());
	}

	public String getDay() {
		return this.day;
	}

	public List getChanges() {
		return this.changes;
	}

	public Collection getFilteredChanges() {
		Map filteredChanges = new HashMap();
		for (Iterator it = this.changes.iterator(); it.hasNext();) {
			Change change = (Change) it.next();
			String title = change.getTitle();
			if (filteredChanges.containsKey(title)) {
				Change existingChange = (Change) filteredChanges.get(title);
				if (existingChange.getDate().before(change.getDate())) {
					filteredChanges.put(title, change);
				}
			} else {
				filteredChanges.put(title, change);
			}

		}
		return filteredChanges.values();
	}

	static class ChangeComparator implements Comparator {
		public int compare(Object obj1, Object obj2) {
			Change c1 = (Change) obj1;
			Change c2 = (Change) obj2;

			int result = c1.compareTo(c2);

			//flip the results
			if (result < 0) {
				return 1;
			} else if (result == 0) {
				return 0;
			} else {
				return -1;
			}
		}
	}
}
