package com.oshineye.kwikwiki.command;

import com.oshineye.kwikwiki.markup.MarkUpEngine;
import com.oshineye.kwikwiki.wikibase.WikiBase;
import com.oshineye.kwikwiki.wikibase.WikiPage;

import java.util.Date;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class Create extends Command {
    private static final String INITIAL_TEXT = "Please add your text here.";

    public void execute(HttpServletRequest req, HttpServletResponse resp, ServletContext sc)
        throws Exception {
        System.err.println("==Executing create command==");

        String title = req.getParameter("title");

        if (MarkUpEngine.isWikiName(title)) {
			WikiBase wikiBase = WikiBase.getInstance();
            if (!wikiBase.pageExists(title)) {
                WikiPage page = new WikiPage(title, INITIAL_TEXT, new Date());
                req.setAttribute("pageBean", page);
                Command.include(Command.EDIT, req, resp, sc);
            } else {
                Command action = CommandFactory.getCommand("Edit");
                action.execute(req, resp, sc);
            }
        } else {
            //go to invalid page title error page
            Command.include(Command.INVALID_TITLE, req, resp, sc);
        }
    }
}
