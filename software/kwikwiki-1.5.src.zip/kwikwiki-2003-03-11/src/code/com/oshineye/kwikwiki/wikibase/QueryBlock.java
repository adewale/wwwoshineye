package com.oshineye.kwikwiki.wikibase;

import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * @author aoshineye
 */
public interface QueryBlock extends JdbcBlock {
	/**
	 * @param set
	 * @return Object
	 */
	public Object process(ResultSet rset) throws SQLException;

}
