package com.oshineye.kwikwiki.specialpages;

public class TodaysChangesPage extends ChangeManager implements SpecialPage {
	private static final int NUMBER_OF_CHANGES = 1;
	protected int getNumberOfChanges() {
		return TodaysChangesPage.NUMBER_OF_CHANGES;
	}
}
