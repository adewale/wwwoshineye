package com.oshineye.kwikwiki.command;

import java.util.HashMap;
import java.util.Map;


/**
 * @author aoshineye
 *
 * A factory for Commands.
 */
public class CommandFactory {
    private static final Map INSTANCE_CACHE = new HashMap();

    //preload all the command class instances we'll be re-using
    static {
        INSTANCE_CACHE.put("View", new View());
        INSTANCE_CACHE.put("Edit", new Edit());
        INSTANCE_CACHE.put("Save", new Save());
        INSTANCE_CACHE.put("Create", new Create());
        INSTANCE_CACHE.put("Search", new Search());
        INSTANCE_CACHE.put("Like", new Like());
    }

    public static Command getCommand(String commandName) {
        return (Command) INSTANCE_CACHE.get(commandName);
    }
}
