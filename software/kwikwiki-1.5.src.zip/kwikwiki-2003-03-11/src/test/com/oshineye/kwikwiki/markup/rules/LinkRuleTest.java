package com.oshineye.kwikwiki.markup.rules;

import junit.framework.TestCase;

public class LinkRuleTest extends TestCase {
    public void testRule() {
        CharSequence linkText = " StartingPoints ";
        CharSequence processedLink = " <a href=\"View?title=StartingPoints\">StartingPoints</a> ";
        LinkRule rule = new LinkRule();
        assertEquals(processedLink.toString(), rule.apply(linkText).toString());
        assertEquals("".toString(), rule.apply("").toString());
    }
}
