/*
 * WikiBaseTest.java
 * JUnit based test
 *
 * 
 */

package com.oshineye.kwikwiki.wikibase;

import junit.framework.*;
import com.oshineye.kwikwiki.markup.MarkUpEngine;
import com.oshineye.kwikwiki.page.RawPage;
import java.util.Date;
import java.util.SortedSet;
/**
 *
 * @author aoshineye
 */
public class WikiBaseTest extends TestCase {
	/*
	A private instance variable is being used till I work out how to use the setUp method from JUnit.
	*/
	private WikiBase wikiBase;
	
    public WikiBaseTest(java.lang.String testName) {
        super(testName);
    }
    
    public static void main(java.lang.String[] args) {
        junit.textui.TestRunner.run(suite());
    }
    
    public static Test suite() {
        TestSuite suite = new TestSuite(WikiBaseTest.class);
        
        return suite;
    }
    
	public void setUp() {
		wikiBase = WikiBase.getInstance();
	}
	public void testGetInstance() {
		assertNotNull(WikiBase.getInstance());
	}

	public void testGetPage() {
		assertNotNull(wikiBase.getPage("StartingPoints"));
	}
	
	public void testPageExists() {
		assertTrue("StartingPoints doesn't exist", wikiBase.pageExists("StartingPoints"));
		assertTrue("fake-page actually exists",  !wikiBase.pageExists("fake-page"));
	}
	
	public void testStorePage() {
		RawPage page = new RawPage("KwikWikiTestingTestPage", "This page exists for testing purposes only at:: " + new Date() + "\n");
		wikiBase.storePage(page);
		RawPage page2 = wikiBase.getPage("KwikWikiTestingTestPage");
		
		String text1 = page.getText();
		String text2 = page2.getText();

		assertEquals("Page retrieved was not the same as original page", text1, text2);
	}
	
	public void testGetAllTitles() {
		SortedSet set = wikiBase.getAllTitles();
		String firstTitle = (String)set.first();
		String lastTitle = (String)set.last();
		
		String message = "An invalid title was found in the title set";
		assertTrue(message, MarkUpEngine.isWikiName(firstTitle));
		assertTrue(message, MarkUpEngine.isWikiName(lastTitle));
	}
	
	public void testIsSpecialPage() {
		String should = "Not treating a page as special when it should be";
		String shouldNot = "Treating a page as special when it shouldn't be";
		assertTrue(should, wikiBase.isSpecialPage("TitleIndex"));
		assertTrue(should, wikiBase.isSpecialPage("RecentChanges"));
		assertTrue(shouldNot, !wikiBase.isSpecialPage("AdewaleOshineye"));
	}
}
