package com.oshineye.kwikwiki.wikibase;

import com.oshineye.kwikwiki.page.RawPage;
import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;
import java.util.SortedSet;

/**
A Singleton class which represents the persistence store for this Wiki.
Because it's abstract the actual singleton is an instance of a conrete class.
*/
public abstract class WikiBase {
	private static WikiBase instance;
	private SortedSet allTitles;
	private static final String[] SPECIAL_PAGES = {"TitleIndex", "RecentChanges"};

	protected WikiBase() {
		allTitles = loadTitles();
		
		//sort the special pages
		Arrays.sort(SPECIAL_PAGES);
		
		//add special pages to the set of titles
		for (int i=0; i<SPECIAL_PAGES.length; i++) {
			allTitles.add(SPECIAL_PAGES[i]);
		}
		
	}

	protected abstract SortedSet loadTitles();
		
	public static WikiBase getInstance() {
		if (instance == null) {
			instance = new FileBase();
		}
		return instance;
	}
	
	public abstract RawPage getPage(String title);
		
	public void storePage(RawPage rawPage) {
		//if we're storing a new page add it to the set of titles
		String title = rawPage.getTitle();
		if (!this.pageExists(title)) {
			allTitles.add(title);
		}
		
		savePage(rawPage);
	}
	
	protected abstract void savePage(RawPage rawPage);
	
	/**
	Return an <b>unmodifiable</b> SortedSet of the titles of all the pages
	in this Wiki.
	*/
	public SortedSet getAllTitles() {
		return Collections.unmodifiableSortedSet(allTitles);
	}
	
	public boolean pageExists(String title) {
		return allTitles.contains(title);
	}
	
	public boolean isSpecialPage(String title) {
		//binarySearch returns positive ints if it finds the title and a
		//negative int if it doesn't
		return (Arrays.binarySearch(SPECIAL_PAGES, title) >= 0);
	}
	
	public RawPage getSpecialPage(String title) {
		if (title.equals("TitleIndex")) {
			return getTitleIndexPage();
		} else { //(title.equals("RecentChanges")) {
			return getRecentChangesPage();
		}
	}
	
	private RawPage getTitleIndexPage() {
		StringBuffer sb = new StringBuffer();
		final String prepend = " <br> ";
		final String lineEnding = "\n";
		for (Iterator it = allTitles.iterator(); it.hasNext();) {
			String item = (String)it.next();
			sb.append(prepend + item + lineEnding);
		}
		return new RawPage("TitleIndex", sb.toString());
	}
	
	private RawPage getRecentChangesPage() {
		//FIXME
		return new RawPage("RecentChanges", "This is a place-holder for RecentChanges");
	}

}
