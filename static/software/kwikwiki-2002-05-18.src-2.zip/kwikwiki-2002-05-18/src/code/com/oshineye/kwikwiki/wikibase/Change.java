package com.oshineye.kwikwiki.wikibase;

import java.io.Serializable;
import java.util.Date;

public class Change implements Serializable {
	private String editor;
	private Date date;
	private String title;
		
	public Change(String title, Date date, String editor) {
		this(title, date);
		this.editor = editor;
	}
	
	public Change(String title, Date date) {
		this.title = title;
		this.date = date;
	}
	
	public String getEditor() {
		return this.editor;
	}
	
	public void setEditor(String editor) {
		this.editor = editor;
	}
	
	public Date getDate() {
		return this.date;
	}
	
	public void setDate(Date date) {
		this.date = date;
	}
	
	public String getTitle() {
		return this.title;
	}
	
	public void setTitle(String title) {
		this.title = title;
	}
}