package com.oshineye.kwikwiki.page;

import java.util.Date;

public class RawPage extends Page {
	private Date lastEdited;

	public RawPage() {
	}
	
	public RawPage(String title, String text) {
		super(title, text);
	}
	
	public RawPage(String title, String text, Date lastEdited) {
		super(title, text);
		this.lastEdited = lastEdited;
	}

	public Date getLastEdited() {
		return this.lastEdited;
	}

}
