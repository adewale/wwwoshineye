package com.oshineye.kwikwiki.page;

import java.io.Serializable;

public abstract class Page implements Serializable {
	private String title;
	private String text;

	public Page() {
	}
	
	public Page(String title) {
		this.setTitle(title);
	}
	
	public Page(String title, String text) {
		this(title);
		this.setText(text);
	}
	
	public String getTitle() {
		return title;
	}
	
	protected void setTitle(String title) {
		this.title = title;
	}
	
	public String getText() {
		return text;
	}
	
	protected void setText(String text){
		this.text = text;
	}

}
