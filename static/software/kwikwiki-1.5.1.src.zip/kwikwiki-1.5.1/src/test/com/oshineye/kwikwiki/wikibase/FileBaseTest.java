package com.oshineye.kwikwiki.wikibase;

public class FileBaseTest extends AbstractWikiBaseTest {
    public WikiBase createWikiBase() {
        return new FileBase();
    }
}
