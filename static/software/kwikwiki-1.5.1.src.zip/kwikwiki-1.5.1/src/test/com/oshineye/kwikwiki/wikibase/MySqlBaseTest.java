package com.oshineye.kwikwiki.wikibase;

public class MySqlBaseTest extends AbstractWikiBaseTest {
    public WikiBase createWikiBase() {
        return new MySqlBase();
    }
}
