package com.oshineye.kwikwiki.markup;

import junit.framework.TestCase;


public class MarkUpEngineTest extends TestCase {
    public void testIsWikiName() {
        assertFalse(MarkUpEngine.isWikiName("helloworld"));
        assertFalse(MarkUpEngine.isWikiName(""));
        assertFalse(MarkUpEngine.isWikiName(null));
        assertTrue(MarkUpEngine.isWikiName("HelloWorld"));
    }

    public void testConvertToHtml() {
        String testString = "StartingPoints is a link but thisIsNotALink and ThisPageDoesNotExist.";
        String expectedResult = "<a href=\"View?title=StartingPoints\">StartingPoints</a> is a link" +
            " but thisIsNotALink and ThisPageDoesNotExist<a href=\"Create?title=ThisPageDoesNotExist\">?</a>.\n";
        String realResult = MarkUpEngine.convertToHtml(testString);
        assertEquals("Text wasn't properly converted", expectedResult, realResult);
    }

    public void testConversionToHtmlList() {
        String wikiList = " * test1\n  * test2\n  * test2b\n   * test3\n";
        String expectedHtmlChunk = "<ul>\n" + "<li class=\"listItem1\">test1</li>\n" +
            "<li class=\"listItem2\">test2</li>\n" + "<li class=\"listItem2\">test2b</li>\n" +
            "<li class=\"listItem3\">test3</li>\n" + "</ul>\n";
        String result = MarkUpEngine.convertToHtml(wikiList);
        assertTrue(result.matches(expectedHtmlChunk));
    }

    public void testConversionToHtmlListWithTextBefore() {
        String wikiList = "Testing 1,2,3 \n" + " * test1\n  * test2\n   * test3\n";
        String expectedHtmlChunk = "Testing 1,2,3 \n" + "<ul>\n" +
            "<li class=\"listItem1\">test1</li>\n" + "<li class=\"listItem2\">test2</li>\n" +
            "<li class=\"listItem3\">test3</li>\n" + "</ul>\n";
        String result = MarkUpEngine.convertToHtml(wikiList);
        assertTrue(result.matches(expectedHtmlChunk));
    }
}
