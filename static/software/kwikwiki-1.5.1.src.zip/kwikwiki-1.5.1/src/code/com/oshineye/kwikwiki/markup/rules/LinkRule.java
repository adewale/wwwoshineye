package com.oshineye.kwikwiki.markup.rules;

import com.oshineye.kwikwiki.wikibase.WikiBase;

import java.util.regex.Matcher;


public class LinkRule extends MarkUpRule {
    private static final String LINK_PATTERN = "\\b([A-Z][a-z0-9]+){2,}\\b";
    private static final String LIVE_LINK = "<a href=\"View?title=$0\">$0</a>";
    private static final String DEAD_LINK = "$0<a href=\"Create?title=$0\">?</a>";

    public LinkRule() {
        super(LinkRule.LINK_PATTERN);
    }

    public CharSequence apply(CharSequence text) {
        Matcher matcher = super.getMatcher(text);
        StringBuffer htmlText = new StringBuffer();

        WikiBase wikiBase = WikiBase.getInstance();

        while (matcher.find()) {
            if (wikiBase.pageExists(matcher.group())) {
                matcher.appendReplacement(htmlText, LinkRule.LIVE_LINK);
            } else {
                matcher.appendReplacement(htmlText, LinkRule.DEAD_LINK);
            }
        }

        matcher.appendTail(htmlText);

        return htmlText;
    }

    public boolean isWikiName(String text) {
        return this.getMatcher(text).matches();
    }
}
