package com.oshineye.kwikwiki.wikibase;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.SortedSet;
import java.util.TreeSet;

import com.oshineye.kwikwiki.config.Config;


/**
 * A WikiBase back-end implementation which stores WikiPages and Changes in a MySql Database.
 */
public class MySqlBase extends WikiBase {
    static {
        /*
        Load the database driver.
        Needed for Tomcat. WLS6.1 works fine without it.
        */
        try {
            Class.forName("org.gjt.mm.mysql.Driver");
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    private static final String DELETE_PAGE = "delete from pages where title=?";
    private static final String INSERT_CHANGE = "insert into changes(title, time, last_editor) values(?, ?, ?)";
    private static final String INSERT_PAGE = "insert into pages values(?, ?, ?)";
    private static final String SELECT_CHANGES = "select * from changes where TO_DAYS(NOW()) - TO_DAYS(time) <= ?";
    private static final String SELECT_PAGE = "select * from pages where title=?";
    private static final String SELECT_TITLES = "select title from pages";
    private static final String UPDATE_PAGE = "update pages set title=?, last_edit=?, text=? where title=?";
    private final String dbUrl;
    private final String userName;
    private final String password;

    protected MySqlBase() {
        Config config = Config.getInstance();
        this.dbUrl = config.getProperty("kwikwiki.persistence.mysql.url");
        this.userName = config.getProperty("kwikwiki.persistence.mysql.username");
        this.password = config.getProperty("kwikwiki.persistence.mysql.password");
    }

    public WikiPage loadPage(final String title) {//final for inner class
        return (WikiPage) new JdbcProcess().executeQuery(new QueryBlock() {
			public String getQuery() {
				return SELECT_PAGE;
			}
			
			public void configure(PreparedStatement prep) throws SQLException {
				prep.setString(1, title);
			}
			
			public Object process(ResultSet rset) throws SQLException {
				WikiPage page = null;
				if (rset.next()) {
					page = new WikiPage(rset.getString("title"), rset.getString("text"), 
						rset.getDate("last_edit"));
				}
				return page;
			}
        });
    }

    protected void storePage(final WikiPage page) {
        new JdbcProcess().executeUpdate(new JdbcBlock() {
        	public String getQuery() {
        		return UPDATE_PAGE;
        	}
        	
			public void configure(PreparedStatement prep) throws SQLException {
				prep.setString(1, page.getTitle());
				prep.setDate(2, new Date(page.getDate().getTime()));
				prep.setString(3, page.getText());
				prep.setString(4, page.getTitle());
			}
        });
    }

    protected void storeNewPage(final WikiPage page) {
		new JdbcProcess().executeUpdate(new JdbcBlock() {
			public String getQuery() {
				return INSERT_PAGE;
			}
        	
			public void configure(PreparedStatement prep) throws SQLException {
				prep.setString(1, page.getTitle());
				prep.setDate(2, new Date(page.getDate().getTime()));
				prep.setString(3, page.getText());
			}
		});
    }

    protected void storeChange(final Change change) {
		new JdbcProcess().executeUpdate(new JdbcBlock() {
			public String getQuery() {
				return INSERT_CHANGE;
			}
        	
			public void configure(PreparedStatement prep) throws SQLException {
				prep.setString(1, change.getTitle());
				prep.setTimestamp(2, new Timestamp(change.getDate().getTime()));
				prep.setString(3, change.getEditor());
			}
		});
    }

    protected SortedSet loadTitles() {
        SortedSet titles = new TreeSet();
        titles.addAll(loadAllTitles());

        return titles;
    }

    public ChangeLog[] getRecentChanges(int numberOfDays) {
        Map logMap = new HashMap();
        List allChanges = getChangesFromDb(numberOfDays);

        //create a map of the logs with the days as keys
        for (Iterator it = allChanges.iterator(); it.hasNext();) {
            Change currentChange = (Change) it.next();
            String currentDay = currentChange.getDay();

            List changes = (List) logMap.get(currentDay);

            if (changes == null) {
                changes = new LinkedList();
                logMap.put(currentDay, changes);
            }

            changes.add(currentChange);
        }

        //convert the lists of changes to an array of changelogs
        Collection changeLists = logMap.values();
        ChangeLog[] changeLogs = new ChangeLog[changeLists.size()];
        int i = 0;

        for (Iterator it = changeLists.iterator(); it.hasNext();) {
            List changes = (List) it.next();
            Change[] tempChanges = (Change[]) changes.toArray(new Change[0]);
            changeLogs[i] = new ChangeLog(tempChanges);
            i++;
        }

        return changeLogs;
    }

	private List getChangesFromDb(final int numberOfDays) {
		return (List) new JdbcProcess().executeQuery(new QueryBlock() {
			public String getQuery() {
				return SELECT_CHANGES;
			}
			
			public void configure(PreparedStatement prep) throws SQLException {
				prep.setInt(1, numberOfDays - 1); //0 days is today
			}
			
			public Object process(ResultSet rset) throws SQLException {
				List allChanges = new LinkedList();
				while (rset.next()) {
					String title = rset.getString("title");
					java.util.Date date = new java.util.Date(rset.getTimestamp("time").getTime());
					String lastEditor = rset.getString("last_editor");
					Change change = new Change(title, date, lastEditor);
					allChanges.add(change);
				}
				return allChanges;
			}
		});
	}

    public void deletePage(String title) {
        getIndex().delete(title, this.loadPage(title).getText());

        deleteRow(title);
    }

    private void deleteRow(final String title) {
		new JdbcProcess().executeUpdate(new JdbcBlock() {
			public String getQuery() {
				return DELETE_PAGE;
			}
        	
			public void configure(PreparedStatement prep) throws SQLException {
				prep.setString(1, title);
			}
		});
    }

    private List loadAllTitles() {
		return (List) new JdbcProcess().executeQuery(new QueryBlock() {
			public String getQuery() {
				return SELECT_TITLES;
			}
			
			public void configure(PreparedStatement prep) throws SQLException {
			}
			
			public Object process(ResultSet rset) throws SQLException {
				List titles = new LinkedList();
				while (rset.next()) {
					String title = rset.getString("title");
					titles.add(title);
				}
				return titles;
			}
		});
    }
}
