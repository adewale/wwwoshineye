package com.oshineye.kwikwiki.specialpages;

public class RecentChangesPage extends ChangeManager implements SpecialPage {
    private final int numberOfChanges;

    public RecentChangesPage(int numberOfChanges) {
        this.numberOfChanges = numberOfChanges;
    }

	protected int getNumberOfChanges() {
		return this.numberOfChanges;
	}
}
