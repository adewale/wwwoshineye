package com.oshineye.kwikwiki.wikibase;

import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * @author aoshineye
 * Implementations of this interface provide a block of code that can be run by the framework
 * to perform an SQL query that returns a resultset which needs to be processed.
 */
public interface QueryBlock extends JdbcBlock {
	/**
	 * @param set
	 * @return Object
	 */
	public Object process(ResultSet rset) throws SQLException;

}
