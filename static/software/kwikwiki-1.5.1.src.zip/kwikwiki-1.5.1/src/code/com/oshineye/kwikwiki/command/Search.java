package com.oshineye.kwikwiki.command;

import com.oshineye.kwikwiki.markup.MarkUpEngine;
import com.oshineye.kwikwiki.markup.ViewBean;
import com.oshineye.kwikwiki.wikibase.WikiBase;
import com.oshineye.kwikwiki.wikibase.WikiPage;

import java.util.Collection;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class Search extends Command {
    public void execute(HttpServletRequest req, HttpServletResponse resp, ServletContext sc)
        throws Exception {
        System.err.println("==Executing search command==");

        String word = req.getParameter("word");

        if ((word == null) || (word.equals(""))) {
            Command.include("/defaultSearchHeader.jsp", req, resp, sc);
            Command.include("/searchForm.jsp", req, resp, sc);
        } else {
			WikiBase wikiBase = WikiBase.getInstance();
            Collection items = wikiBase.locateWord(word, req.getParameter("caseSensitive") != null);
            String text = MarkUpEngine.convertToWikiList(items);

            ViewBean page = new ViewBean(WikiPage.createSpecialPage(word, text));
            req.setAttribute("pageBean", page);

            Command.include("/displayingResultsSearchHeader.jsp", req, resp, sc);
            Command.include("/searchForm.jsp", req, resp, sc);
            Command.include("/searchResults.jsp", req, resp, sc);
        }

        Command.include("/readOnlyFooter.jsp", req, resp, sc);
    }
}
