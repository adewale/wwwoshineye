package com.oshineye.kwikwiki.command;

import com.oshineye.kwikwiki.wikibase.WikiBase;
import com.oshineye.kwikwiki.wikibase.WikiPage;

import java.util.Date;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class Save extends Command {
    private static final String SAVE = "/saveTemplate.jsp";

    public void execute(HttpServletRequest req, HttpServletResponse resp, ServletContext sc)
        throws Exception {
        System.err.println("==Executing save command==");

        String title = req.getParameter("title");
        String text = req.getParameter("text");

        if (isValid(title) && isValid(text)) {
			WikiBase wikiBase = WikiBase.getInstance();
            //save page with user identification
            //FIXME we should check for a user name cookie not just use the hostname
            WikiPage rawPage = new WikiPage(title, text, new Date(), req.getRemoteHost());
            wikiBase.savePage(rawPage);

            //go to save successful page
            Command.include(Save.SAVE, req, resp, sc);
        } else {
            //go to generic error page because this indicates programming error
            //not user error and should never happen
            Command.include(Command.ERROR, req, resp, sc);
        }
    }

    private boolean isValid(String toTest) {
        return ((toTest != null) && (!toTest.equals("")));
    }
}
