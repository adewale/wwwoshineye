package com.oshineye.kwikwiki.wikibase;

import java.util.Date;


/**
 A class that represent a page's data wiki format.
 It also keeps track of when it was created and who last edited it.
 This class fulfills all the criteria to be a JavaBean.
 */
public class WikiPage extends Page {
    private Date date;
    private String lastEditor;

    public WikiPage() {
    }

    public WikiPage(String title, String text, Date date) {
        this(title, text, date, null, false);
    }

    public WikiPage(String title, String text, Date date, String lastEditor) {
        this(title, text, date, lastEditor, false);
    }

    public WikiPage(String title, String text, Date date, String lastEditor, boolean special) {
        super(title, text);
        this.date = date;
        this.lastEditor = lastEditor;
        this.setSpecial(special);
    }

    public Date getDate() {
        return this.date;
    }

    public String getLastEditor() {
        return this.lastEditor;
    }

    public static WikiPage createSpecialPage(String title, String text) {
        return new WikiPage(title, text, null, null, true);
    }
    
    public boolean equals(Object otherObject) {
		if ((otherObject == null) || (!(otherObject instanceof WikiPage))) {
			return false;
		}

		WikiPage otherWikipage = (WikiPage) otherObject;
		return this.getTitle().equals(otherWikipage.getTitle()) 
			&& this.date.equals(otherWikipage.date) 
			&& this.getText().equals(otherWikipage.getText());
    }
}
