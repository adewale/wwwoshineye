package com.oshineye.kwikwiki.wikibase;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.oshineye.kwikwiki.TunnellingException;
import com.oshineye.kwikwiki.config.Config;

/**
 * Instances of this class are used to access databases when we want to ensure that resources
 * are acquired and released in the canonical manner.
 * @author aoshineye
 */
public class JdbcProcess {
	static {
		/*
		Load the database driver.
		Needed for Tomcat. WLS6.1 works fine without it.
		*/
		try {
			Class.forName("org.gjt.mm.mysql.Driver");
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	private final String dbUrl;
	private final String userName;
	private final String password;

	public JdbcProcess() {
		Config config = Config.getInstance();
		this.dbUrl = config.getProperty("kwikwiki.persistence.mysql.url");
		this.userName = config.getProperty("kwikwiki.persistence.mysql.username");
		this.password = config.getProperty("kwikwiki.persistence.mysql.password");
	}

	private Connection getConnection() {
		Connection conn;

		try {
			//conn = DriverManager.getConnection("jdbc:mysql://localhost/kwikwiki", "", "");
			conn = DriverManager.getConnection(this.dbUrl, this.userName, this.password);
		} catch (SQLException sqle) {
			throw new TunnellingException(sqle);
		}

		return conn;
	}

	private static void release(Connection conn, Statement stmt, ResultSet rset) {
		if (rset != null) {
			try {
				rset.close();
			} catch (SQLException sqle) {
				throw new TunnellingException(sqle);
			}
		}

		if (stmt != null) {
			try {
				stmt.close();
			} catch (SQLException sqle) {
				throw new TunnellingException(sqle);
			}
		}

		if (conn != null) {
			try {
				conn.close();
			} catch (SQLException sqle) {
				throw new TunnellingException(sqle);
			}
		}
	}
	
	public Object executeQuery(QueryBlock block) {
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rset = null;
		try {
			conn = this.getConnection();
			stmt = conn.prepareStatement(block.getQuery());
			block.configure(stmt);
			rset = stmt.executeQuery();
			return block.process(rset);
		} catch (SQLException sqle) {
			throw new TunnellingException(sqle);
		} finally {
			JdbcProcess.release(conn, stmt, rset);
		}
	}
	
	public int executeUpdate(JdbcBlock block) {
		Connection conn = null;
		PreparedStatement stmt = null;
		try {
			conn = this.getConnection();
			stmt = conn.prepareStatement(block.getQuery());
			block.configure(stmt);
			return stmt.executeUpdate();
		} catch (SQLException sqle) {
			throw new TunnellingException(sqle);
		} finally {
			JdbcProcess.release(conn, stmt, null);
		}
	}
}
