package com.oshineye.kwikwiki.wikibase;

import com.oshineye.kwikwiki.TunnellingException;
import com.oshineye.kwikwiki.config.Config;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.FilenameFilter;
import java.io.IOException;

import java.text.ParseException;

import java.util.Arrays;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;
import java.util.SortedSet;
import java.util.TreeSet;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * A WikiBase back-end implementation which stores WikiPages and Changes in a file system.
 */
public class FileBase extends WikiBase {
	private static final String FILE_SEPARATOR = System.getProperty("file.separator");
	private static final String WIKI_DIR_NAME =
		System.getProperty("user.home") + FILE_SEPARATOR + "kwikwiki-data" + FILE_SEPARATOR;
	private static final File WIKI_DIR = new File(WIKI_DIR_NAME);
	private static final String METADATA_DIR_NAME =
		WIKI_DIR_NAME + FILE_SEPARATOR + "metadata" + FILE_SEPARATOR;
	private static final String CHANGES_DIR_NAME =
		METADATA_DIR_NAME + FILE_SEPARATOR + "changelogs" + FILE_SEPARATOR;
	private static final File CHANGES_DIR = new File(CHANGES_DIR_NAME);
	private static final TextFilter TEXT_FILTER = new TextFilter();
	private static final String TEXT_EXTENSION = ".txt";
	private static final int TEXT_EXTENSION_LENGTH = 4; //includes the dot

	public FileBase() {
	}

	protected SortedSet loadTitles() {
		File[] files = WIKI_DIR.listFiles(TEXT_FILTER);

		SortedSet set = new TreeSet();
		int directoryNameLength = WIKI_DIR_NAME.length();

		for (int i = 0; i < files.length; i++) {
			String temp = files[i].toString();
			int titleLength = temp.length() - TEXT_EXTENSION_LENGTH;

			//we only want the title not including the wiki directory or file extension
			String title = temp.substring(directoryNameLength, titleLength);
			set.add(title);
		}

		return set;
	}

	/**
	* TextFilter only accepts files with names that end in ".txt".
	* A FilenameFilter was used rather than a FileFilter to avoid the ovehead
	* of creating a File object for each file in the directory that will be
	* filtered. This has the side-effect that the <code>file</code> argument is
	* completely redundant.
	*/
	static class TextFilter implements FilenameFilter {
		public boolean accept(File file, String name) {
			return name.endsWith(".txt");
		}
	}

	public void deletePage(String title) {
		File file = new File(WIKI_DIR_NAME + title + TEXT_EXTENSION);

		if (file.exists()) {
			getIndex().delete(title, this.readText(file).toString());

			//delete the file
			file.delete();
		}
	}

	public WikiPage loadPage(String title) {
		File file = new File(WIKI_DIR_NAME + title + TEXT_EXTENSION);

		if (!file.exists()) {
			return null;
		}

		CharSequence rawText = this.readText(file);

		Date lastEdited = new Date(file.lastModified());

		return new WikiPage(title, rawText.toString(), lastEdited);
	}

	protected void storePage(WikiPage rawPage) {
		String title = rawPage.getTitle();
		String newText = rawPage.getText();

		//1 argument constructor chosen for performance
		File file = new File(WIKI_DIR_NAME + title + TEXT_EXTENSION);

		this.writeText(file, newText, false);
	}

	protected void storeNewPage(WikiPage rawPage) {
		this.storePage(rawPage);
	}

	protected void storeChange(Change change) {
		String day = change.getDay();

		//1 argument constructor chosen for performance
		File file = new File(CHANGES_DIR_NAME + day + TEXT_EXTENSION);

		String newChangeLine =
			Config.LINE_ENDING
				+ "title:"
				+ change.getTitle()
				+ ",date:"
				+ change.getDate().getTime()
				+ ",editor:"
				+ change.getEditor()
				+ ",";

		writeText(file, newChangeLine, true);
	}

	public ChangeLog[] getRecentChanges(int numberOfDays) {
		//load all the names of all the changelog files
		String[] changeLogFiles = CHANGES_DIR.list();
		int numberOfLogs = changeLogFiles.length;

		Date[] times = convertToDates(changeLogFiles);

		//sort the names by time
		Arrays.sort(times);

		//create an array of logs no bigger than numberOfDays
		ChangeLog[] logs;
		if (numberOfLogs < numberOfDays) {
			logs = new ChangeLog[numberOfLogs];
		} else {
			logs = new ChangeLog[numberOfDays];
		}

		//populate the array with ChangeLog objects representing each day
		for (int i = numberOfLogs - logs.length, j = 0; i < numberOfLogs; i++, j++) {
			String currentDay = Change.formatChangeDate(times[i]);
			File currentChangeFile = new File(CHANGES_DIR_NAME + currentDay + TEXT_EXTENSION);
			CharSequence changeText = readText(currentChangeFile);
			Change[] temp = parseChanges(changeText);
			logs[j] = new ChangeLog(temp);
		}

		//return the array of ChangeLogs
		return logs;
	}

	private void writeText(File file, CharSequence text, boolean shouldAppend) {
		BufferedWriter bw;

		try {
			bw = new BufferedWriter(new FileWriter(file, shouldAppend));
			bw.write(text.toString());
			bw.close();
		} catch (IOException ioe) {
			throw new TunnellingException(ioe);
		}
	}

	private CharSequence readText(File file) {
		/*
		potential exists for performance optimisation by specifying buffer
		sizes for the BufferedReader and StringBuffer based on the file's
		length. Although that might lead to problems with very large files.
		*/
		try {
			BufferedReader br = new BufferedReader(new FileReader(file));
			StringBuffer sb = new StringBuffer();

			String line;

			while ((line = br.readLine()) != null) {
				sb.append(line);
				sb.append(Config.LINE_ENDING); //avoid concatenation penalty
			}

			br.close();

			return sb;
		} catch (IOException ioe) {
			throw new TunnellingException(ioe);
		}
	}

	private Date[] convertToDates(String[] fileNames) {
		int numberOfLogs = fileNames.length;

		//convert the names to dates
		Date[] times = new Date[numberOfLogs];

		try {
			for (int i = 0; i < numberOfLogs; i++) {
				String currentName = fileNames[i];
				int nameLength = currentName.length() - TEXT_EXTENSION_LENGTH;
				String temp = currentName.substring(0, nameLength);
				times[i] = Change.parseChangeDay(temp);
			}
		} catch (ParseException pe) {
			throw new TunnellingException(pe);
		}

		return times;
	}

	private Change[] parseChanges(CharSequence changeLines) {
		Pattern pattern = Pattern.compile("(title:(.*),date:(.*),editor:(.*),)", Pattern.MULTILINE);
		Matcher matcher = pattern.matcher(changeLines);
		List changeList = new LinkedList();

		while (matcher.find()) {
			String tempTitle = matcher.group(2);
			String tempDate = matcher.group(3);
			String tempEditor = matcher.group(4);
			long tempTime = Long.parseLong(tempDate);
			Change temp = new Change(tempTitle, new Date(tempTime), tempEditor);
			changeList.add(temp);
		}

		//convert to an array of Changes
		Change[] changes = new Change[changeList.size()];

		for (int i = 0; i < changes.length; i++) {
			changes[i] = (Change) changeList.get(i);
		}

		return changes;
	}
}
