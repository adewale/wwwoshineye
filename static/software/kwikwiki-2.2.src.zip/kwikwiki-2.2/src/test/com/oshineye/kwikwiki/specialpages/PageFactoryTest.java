package com.oshineye.kwikwiki.specialpages;

import com.oshineye.kwikwiki.wikibase.WikiPage;

import junit.framework.TestCase;


public class PageFactoryTest extends TestCase {
    public void testIsSpecialPage() {
        String should = "Not treating a page as special when it should be";
        String shouldNot = "Treating a page as special when it shouldn't be";
        assertTrue(should, PageFactory.isSpecialPage("TitleIndex"));
        assertTrue(should, PageFactory.isSpecialPage("RecentChanges"));
        assertTrue(shouldNot, !PageFactory.isSpecialPage("AdewaleOshineye"));
    }

    public void testGetSpecialPage() {
        String titleIndex = "TitleIndex";
        WikiPage titleIndexPage = PageFactory.getPage(titleIndex);
        WikiPage recentChangesPage = PageFactory.getPage("RecentChanges");

        assertTrue(titleIndex.equals(titleIndexPage.getTitle()));
        assertFalse(titleIndex.equals(recentChangesPage.getTitle()));
        assertTrue(titleIndexPage.isSpecial());
        assertTrue(recentChangesPage.isSpecial());
    }

    public void testGetPage() {
        assertNotNull(PageFactory.getPage("StartingPoints"));
        assertNotNull(PageFactory.getPage("TitleIndex"));
        assertNotNull(PageFactory.getPage("RecentChanges"));
        assertTrue(PageFactory.getPage("StartingPoints") instanceof WikiPage);
    }
}
