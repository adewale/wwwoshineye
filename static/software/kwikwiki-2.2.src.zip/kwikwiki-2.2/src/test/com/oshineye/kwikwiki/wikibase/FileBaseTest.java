package com.oshineye.kwikwiki.wikibase;

import java.io.File;
import java.io.IOException;
import java.io.StringReader;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.oshineye.kwikwiki.TunnellingException;

public class FileBaseTest extends AbstractWikiBaseTest {
	public WikiBase createWikiBase() {
		return new FileBase() {
			FileSystem getFileSystem() {
				return new StubFileSystem();
			}
		};
	}

	static class StubFileSystem extends DefaultFileSystem {
		private Map existenceMap = new HashMap();
		private Map fileCache = new HashMap();

		public List readLines(File file) {
			return convertToLines(readText(file));
		}

		public CharSequence readText(File file) {
			CharSequence text = (CharSequence) fileCache.get(file);
			if (text == null) {
				text = super.readText(file);
				fileCache.put(file, text);
			}
			return text;
		}

		public void writeText(File file, CharSequence text, boolean shouldAppend) {
			CharSequence textToWrite = text;
			if (shouldAppend && exists(file)) {
				CharSequence textRead = this.readText(file);
				StringBuffer sb = new StringBuffer();
				sb.append(textRead);
				sb.append(text);
				textToWrite = sb;
			}
			fileCache.put(file, textToWrite);
			existenceMap.put(file, Boolean.TRUE);
		}

		public boolean exists(File file) {
			Boolean exists = (Boolean) existenceMap.get(file);
			if (exists == null) {
				exists = Boolean.valueOf(super.exists(file));
				existenceMap.put(file, exists);
			}
			return exists.booleanValue();
		}

		public void delete(File file) {
			existenceMap.put(file, Boolean.FALSE);
		}

		protected List convertToLines(CharSequence text) {
			try {
				return super.readLines(new StringReader(text.toString()));
			} catch (IOException ioe) {
				throw new TunnellingException(ioe);
			}
		}
	}
}
