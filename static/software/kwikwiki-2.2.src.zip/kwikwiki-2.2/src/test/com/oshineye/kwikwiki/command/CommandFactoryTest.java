package com.oshineye.kwikwiki.command;

import junit.framework.TestCase;

/**
 *
 * @author aoshineye
 */
public class CommandFactoryTest extends TestCase {
    public void testGetCommand() {
        assertTrue(CommandFactory.getCommand("View") instanceof View);
        assertTrue(CommandFactory.getCommand("Edit") instanceof Edit);
        assertTrue(CommandFactory.getCommand("Save") instanceof Save);
        assertTrue(CommandFactory.getCommand("Create") instanceof Create);
        assertTrue(CommandFactory.getCommand("Like") instanceof Like);
        assertTrue(CommandFactory.getCommand("Search") instanceof Search);
    }
}
