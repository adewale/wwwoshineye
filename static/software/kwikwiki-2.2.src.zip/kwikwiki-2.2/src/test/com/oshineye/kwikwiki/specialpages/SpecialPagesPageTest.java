package com.oshineye.kwikwiki.specialpages;

import com.oshineye.kwikwiki.config.Config;

import junit.framework.TestCase;

/**
 * @author aoshineye
 */
public class SpecialPagesPageTest extends TestCase {
	public void testCreationOfSpecialPagesPage() {
		int numberOfSpecialPages = PageFactory.getAllSpecialPages().size();
		String text = new SpecialPagesPage().getText();
		int linesCreated = text.split(Config.LINE_ENDING).length;

		assertEquals(numberOfSpecialPages, linesCreated);
	}
}
