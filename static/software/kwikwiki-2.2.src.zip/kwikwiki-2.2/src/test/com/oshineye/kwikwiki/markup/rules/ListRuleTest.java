package com.oshineye.kwikwiki.markup.rules;

import junit.framework.TestCase;

import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class ListRuleTest extends TestCase {
    public void testListRule() {
        CharSequence listText = " * Level1\n" + "  * Level2\n" + "   * Level3";

        ListRule rule = new ListRule();
        listText = rule.apply(listText);

        String result = listText.toString();
        Pattern pattern = Pattern.compile("listItem\\d", Pattern.MULTILINE);
        Matcher matcher = pattern.matcher(result);
        assertTrue(matcher.find());
    }

    public void testMultiList() {
        String wikiList = "Testing 1,2,3 \n" + " * test1\n  * test2\n   * test3\n" +
            "Mellow world\n" + " * test1\n  * test2\n   * test3\n" + "Mellow world";
        String expectedHtmlChunk = "Testing 1,2,3 \n" + "<ul>\n" +
            "<li class=\"listItem1\">test1</li>\n" + "<li class=\"listItem2\">test2</li>\n" +
            "<li class=\"listItem3\">test3</li>\n" + "</ul>\n" + "Mellow world\n" + "<ul>\n" +
            "<li class=\"listItem1\">test1</li>\n" + "<li class=\"listItem2\">test2</li>\n" +
            "<li class=\"listItem3\">test3</li>\n" + "</ul>\n" + "Mellow world\n";

        String result = new ListRule().apply(wikiList).toString();
        assertEquals(expectedHtmlChunk, result);
    }

    //test for bug when a single item list is converted to html and the ul tag isn't closed
    public void testSingleItemList() {
        String singleItemList = " * Item";
        String expectedHtml = "<ul>\n" + "<li class=\"listItem1\">Item</li>\n" + "</ul>\n";

        assertEquals(expectedHtml, new ListRule().apply(singleItemList));
    }
//
//    public void testListFollowedByText() {
//    	String text = " * Hello world\n test text";
//    	String expectedHtml = "<ul>\n<li class=\"listItem1\">Hello world</li>\n</ul>\n test text\n";
//		assertEquals(expectedHtml, new ListRule().apply(text));
//    }
}
