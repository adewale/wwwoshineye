package com.oshineye.kwikwiki.wikibase;

import java.util.Iterator;
import java.util.List;
import java.util.SortedSet;

import junit.framework.TestCase;

import com.oshineye.kwikwiki.KwikWikiTestUtils;
import com.oshineye.kwikwiki.markup.MarkUpEngine;

/*
 * This test uses the AbstractTest to ensure that sub-classes of WikiBase
 * conform to the contract defined by WikiBase and obey the LSP
*/
public abstract class AbstractWikiBaseTest extends TestCase {
	/*
	An instance variable used by all the tests.
	*/
	private WikiBase wikiBase;

	public final void setUp() {
		this.wikiBase = this.createWikiBase();
	}

	//factory method that sub-classes of this test will need to provide
	protected abstract WikiBase createWikiBase();

	public void testLoadTitles() {
		wikiBase.savePage(KwikWikiTestUtils.createTestPage());
		SortedSet titles = wikiBase.loadTitles();
		String msg = " is not a wiki name but is in the title set";
		assertTrue(titles.size() > 0);

		for (Iterator it = titles.iterator(); it.hasNext();) {
			String title = (String) it.next();
			assertTrue(title + msg, MarkUpEngine.isWikiName(title));
		}
	}

	public void testGetInstance() {
		assertNotNull(WikiBase.getInstance());

		Object obj1 = WikiBase.getInstance();
		Object obj2 = WikiBase.getInstance();
		assertTrue(obj1.equals(obj2));
		assertTrue(obj1 == obj2);
	}

	public void testSavePage() {
		WikiPage page = KwikWikiTestUtils.createTestPage();
		wikiBase.savePage(page);

		WikiPage page2 = wikiBase.loadPage(KwikWikiTestUtils.TEST_PAGE_TITLE);

		String text1 = page.getText();
		String text2 = page2.getText();

		assertEquals(text1.length(), text2.length());
		assertEquals("Page retrieved was not the same as original page", text1, text2);
		assertTrue("Newly saved page is not in titleset", wikiBase.pageExists(page.getTitle()));
		assertEquals(page.getTitle(), this.getLastChange().getTitle());
	}

	public void testSaveNewPage() {
		//ensure test page doesn't exist
		wikiBase.deletePage(KwikWikiTestUtils.TEST_PAGE_TITLE);

		wikiBase.savePage(KwikWikiTestUtils.createTestPage());

		assertTrue(wikiBase.pageExists(KwikWikiTestUtils.TEST_PAGE_TITLE));
	}

	public void testPageExists() {
		//ensure StartingPoints always exists
		if (!wikiBase.pageExists("StartingPoints")) {
			wikiBase.savePage(KwikWikiTestUtils.createStartingPoints());
		}
		
		assertTrue("StartingPoints doesn't exist", wikiBase.pageExists("StartingPoints"));
		assertTrue("fake-page actually exists", !wikiBase.pageExists("fake-page"));
	}

	//Test for bug when mysql code was returning too many changelogs (2 instead of 1) when it was
	//passed 1 and there were changes yesterday
	public void testChangeLogSize() {
		WikiPage rawPage = KwikWikiTestUtils.createTestPage();
		wikiBase.savePage(rawPage);

		int numberOfDaysToRetrieve = 1;
		int lengthOfChangeLog = wikiBase.getChangeLogs(numberOfDaysToRetrieve).size();
		assertEquals("Failed to get only today's changelog", numberOfDaysToRetrieve, 
			lengthOfChangeLog);
	}

	public void testChangeLogging() {
		WikiPage rawPage = KwikWikiTestUtils.createTestPage();
		wikiBase.savePage(rawPage);

		Change createdChange = new Change(rawPage);
		Change retrievedChange = this.getLastChange();

		assertEquals("Titles did not match", rawPage.getTitle(), retrievedChange.getTitle());
		assertEquals("Changes were not equal", createdChange, retrievedChange);
	}

	public void testRetrievingLargeNumberOfChanges() {
		int largeNumberOfChanges = 10;
		List logs = wikiBase.getChangeLogs(largeNumberOfChanges);
		List lastLogs = wikiBase.getChangeLogs(1);
		ChangeLog todaysLog = (ChangeLog) lastLogs.get(0);

		assertNotNull(logs);
		assertNotNull(todaysLog);
		assertTrue(logs.size() <= largeNumberOfChanges);
		assertTrue(logs.size() > 0);
	}
	
	public void testChangesDescendByTime() {
		wikiBase.savePage(KwikWikiTestUtils.createTestPage());
		wikiBase.savePage(KwikWikiTestUtils.createTestPage());
		WikiPage page = KwikWikiTestUtils.createTestPage();
		wikiBase.savePage(page);
		
		List changeLogs = wikiBase.getChangeLogs(1);
		ChangeLog lastLog = (ChangeLog) changeLogs.get(0);
		List changes = lastLog.getChanges();

		Change a = (Change) changes.get(0);
		Change b = (Change) changes.get(1);
		Change c = (Change) changes.get(2);
		String msg = "Changes are not sorted in order of time-> a:" + a.getTime() 
					+ " b:" + b.getTime() + " c:" + c.getTime();
		assertTrue(msg, a.getTime() >= b.getTime() && b.getTime() >= c.getTime());
	}
	
	public void testChangesLogsDescendByTime() {
		wikiBase.savePage(KwikWikiTestUtils.createTestPage());
		wikiBase.savePage(KwikWikiTestUtils.createTestPage());
		WikiPage page = KwikWikiTestUtils.createTestPage();
		wikiBase.savePage(page);
		
		int numberOfLogs = 5;
		List changeLogs = wikiBase.getChangeLogs(numberOfLogs);
		assertEquals(numberOfLogs, changeLogs.size());

		ChangeLog oldest = (ChangeLog) changeLogs.get(4);
		ChangeLog newest = (ChangeLog) changeLogs.get(0);
		
		assertTrue("First changelog isn't the newst", newest.isToday());
		assertTrue(oldest.isOlderThan(newest));
		
		for (int i=1; i<changeLogs.size(); i++) {
			ChangeLog older = (ChangeLog) changeLogs.get(i);
			ChangeLog newer = (ChangeLog) changeLogs.get(i-1);
			assertTrue("Changelogs aren't sorted with newest first", older.isOlderThan(newer));
		}
	}

	public void testLocateWord() {
		WikiPage rawPage = KwikWikiTestUtils.createTestPage();
		wikiBase.savePage(rawPage);

		SortedSet titles = wikiBase.locateWord("testing", true);
		assertTrue(titles.size() >= 1); //"testing" exists on KwikWikiTestingTestPage
		assertTrue(titles.contains(KwikWikiTestUtils.TEST_PAGE_TITLE)); //testing page referred to above
		assertNotNull(wikiBase.locateWord("wordthatdefinitelydoesnotexist-�$%�$%$��%$%%^^", true));
	}

	public void testGetTitlesStartingWith() {
		SortedSet sharedStart = wikiBase.getTitlesStartingWith("Kwik");
		assertNotNull(sharedStart);

		//should get an empty set
		sharedStart = wikiBase.getTitlesStartingWith("");
		assertNotNull(sharedStart);
	}

	public void testGetTitlesEndingWith() {
		SortedSet sharedEnd = wikiBase.getTitlesEndingWith("Wiki");
		assertNotNull(sharedEnd);

		//should get an empty set
		sharedEnd = wikiBase.getTitlesStartingWith("");
		assertNotNull(sharedEnd);
	}

	//bug introduced when searching for the word "http"
	public void testIndexShrinking() {
		String targetWord = "deliberately";

		//create a page with a particular word in it --"deliberately"
		WikiPage rawPage = KwikWikiTestUtils.createTestPage();
		wikiBase.savePage(rawPage);

		//confirm that the word is there
		SortedSet beforeResults = wikiBase.locateWord(targetWord, true);
		String beforeMsg = "Target word " + targetWord + " was not found after initial save";
		assertTrue(beforeMsg, beforeResults.contains(KwikWikiTestUtils.TEST_PAGE_TITLE));

		//save the page again but without the unusual word
		rawPage = new WikiPage(KwikWikiTestUtils.TEST_PAGE_TITLE, "testIndexShrinking");
		wikiBase.savePage(rawPage);

		//the index should no longer say that the page has the unusual word
		SortedSet afterResults = wikiBase.locateWord(targetWord, true);

		String indexRemovalMsg = "Target word " + targetWord + " was found after removal";
		assertTrue(indexRemovalMsg, !afterResults.contains(KwikWikiTestUtils.TEST_PAGE_TITLE));

		//confirm that the word is back
		rawPage = KwikWikiTestUtils.createTestPage();
		wikiBase.savePage(rawPage);
		afterResults = wikiBase.locateWord(targetWord, true);

		String indexReadditionMsg =
			"Target word " + targetWord + " was not found after adding it back to the page";
		assertTrue(indexReadditionMsg, afterResults.contains(KwikWikiTestUtils.TEST_PAGE_TITLE));
	}

	public void testLoadMissingPage() {
		//if the page is missing return a null
		String title = ""; //there shouldn't be any pages with no name
		WikiPage page = wikiBase.loadPage(title);
		assertNull(page);
	}

	public void testDelete() {
		WikiPage page = KwikWikiTestUtils.createTestPage();
		wikiBase.savePage(page);
		wikiBase.deletePage(page.getTitle());

		assertFalse(wikiBase.pageExists(page.getTitle()));
	}

	public void testGetChangeHistory() {
		//create a versionedchange
		WikiPage page = KwikWikiTestUtils.createTestPage();
		wikiBase.savePage(page);
		
		//retrieve that revision
		List revisions = wikiBase.getRevisions(page.getTitle());
		assertNotNull(revisions);
		assertTrue(revisions.size() > 0);
		
		Revision latest = (Revision) revisions.get(0);
		assertEquals(page.getLastEditor(), latest.getEditor());
		assertEquals(page.getDate().getTime(), latest.getTime());
	}

	public void testRevisionSaving() {
		wikiBase.savePage(KwikWikiTestUtils.createTestPage());
		WikiPage page = KwikWikiTestUtils.createTestPage();
		List revisionsBefore = wikiBase.getRevisions(page.getTitle());
		wikiBase.savePage(page);
		
		List revisionsAfter = wikiBase.getRevisions(page.getTitle());
		assertNotSame(revisionsBefore, revisionsAfter);
		assertEquals(revisionsBefore.size()+1, revisionsAfter.size());
		Revision before = (Revision) revisionsBefore.get(0);
		Revision after = (Revision) revisionsAfter.get(1); 
		assertEquals(before.getId(), after.getId());
	}

	public void testRevisionsDescendById() {
		wikiBase.savePage(KwikWikiTestUtils.createTestPage());
		wikiBase.savePage(KwikWikiTestUtils.createTestPage());
		WikiPage page = KwikWikiTestUtils.createTestPage();
		wikiBase.savePage(page);
		
		List revisions = wikiBase.getRevisions(page.getTitle());
		Revision a = (Revision) revisions.get(0);
		Revision b = (Revision) revisions.get(1);
		Revision c = (Revision) revisions.get(2);
		String msg = "Revisions are not sorted in order of id-> a:" + a.getId() 
			+ " b:" + b.getId() + " c:" + c.getId();
		assertTrue(msg, a.getId() > b.getId() && b.getId() > c.getId());
	}

	public void testLoadingHistoricalPage() {
		wikiBase.savePage(KwikWikiTestUtils.createTestPage());
		wikiBase.savePage(KwikWikiTestUtils.createTestPage());
		wikiBase.savePage(KwikWikiTestUtils.createTestPage());

		WikiPage page = KwikWikiTestUtils.createTestPage();
		wikiBase.savePage(page);
		
		List revisions = wikiBase.getRevisions(page.getTitle());
		Revision revision = (Revision) revisions.get(0);
		assertEquals(page.getDate().getTime(), revision.getTime());

		WikiPage historicalPage = wikiBase.loadPage(revision.getTitle(), revision.getId());
		assertNotNull(historicalPage);
		assertEquals(page.getText(), historicalPage.getText());
		assertEquals(page.getLastEditor(), historicalPage.getLastEditor());
		assertEquals(page.getTitle(), historicalPage.getTitle());
	}
	
	public void testLoadingFirstHistoricalPage() {
		WikiPage page = KwikWikiTestUtils.createTestPage();
		wikiBase.savePage(page);
		WikiPage historicalPage = wikiBase.loadPage(page.getTitle(), 1);
		
		assertNotNull(historicalPage);
	}

	public void testNonExistentHistory() {
		List revisions = wikiBase.getRevisions("TitleThatDefinitelyDoesNotExist");
		assertNotNull(revisions);
		assertTrue(revisions.size() == 0);
	}

	private Change getLastChange() {
		List logs = wikiBase.getChangeLogs(1);
		ChangeLog lastLog = (ChangeLog) logs.get(0);
		
		return (Change) lastLog.getChanges().get(0);
	}
}
