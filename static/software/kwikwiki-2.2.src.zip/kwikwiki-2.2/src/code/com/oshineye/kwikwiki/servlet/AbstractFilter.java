package com.oshineye.kwikwiki.servlet;

import javax.servlet.Filter;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;

import com.opensymphony.module.oscache.web.ServletCacheAdministrator;

/**
 * @author aoshineye
 */
public abstract class AbstractFilter implements Filter {
	protected static final String SEARCH_PATTERN = "__SEARCH__";
	protected static final String SHARED_PATTERN = "__SHARED__";
	protected static final String HISTORICAL_VIEW_PATTERN = "__HISTORICAL";
	private FilterConfig config;
	
	/* (non-Javadoc)
	 * @see javax.servlet.Filter#init(javax.servlet.FilterConfig)
	 */
	public void init(FilterConfig config) throws ServletException {
		this.config = config;
	}

	/* (non-Javadoc)
	 * @see javax.servlet.Filter#destroy()
	 */
	public void destroy() {
		this.config = null;
	}

	protected ServletCacheAdministrator getServletCacheAdministrator() {
		return ServletCacheAdministrator.getInstance(this.config.getServletContext());
	}
}
