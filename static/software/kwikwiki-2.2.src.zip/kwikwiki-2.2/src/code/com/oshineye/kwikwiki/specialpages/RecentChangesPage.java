package com.oshineye.kwikwiki.specialpages;

import java.util.Iterator;
import java.util.List;

import com.oshineye.kwikwiki.config.Config;
import com.oshineye.kwikwiki.markup.MarkUpEngine;
import com.oshineye.kwikwiki.wikibase.ChangeLog;
import com.oshineye.kwikwiki.wikibase.WikiBase;

public class RecentChangesPage implements SpecialPage {
    private static final int NUMBER_OF_CHANGES = 5;

    public RecentChangesPage() {
    }

	public String getText() {
		List logs = WikiBase.getInstance().getChangeLogs(NUMBER_OF_CHANGES);

		return convertToText(logs);
	}

	protected String convertToText(List logs) {
		StringBuffer sb = new StringBuffer();
		
		//go through logs - newest first
		for (Iterator it = logs.iterator(); it.hasNext();) {
			ChangeLog currentLog = (ChangeLog) it.next(); 
			List changes = currentLog.getFilteredChanges();
			sb.append(MarkUpEngine.convertToBold(currentLog.getDay()) + Config.LINE_ENDING);
			sb.append(MarkUpEngine.convertChanges(changes));
		}
		
		return sb.toString();
	}
}
