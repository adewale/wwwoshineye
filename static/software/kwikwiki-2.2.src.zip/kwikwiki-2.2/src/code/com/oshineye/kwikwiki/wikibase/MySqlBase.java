package com.oshineye.kwikwiki.wikibase;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.SortedSet;
import java.util.TreeSet;


/**
 * @author aoshineye
 * A WikiBase back-end implementation which stores WikiPages and Changes in a MySql Database.
 */
public class MySqlBase extends WikiBase {
    static {
        /*
        Load the database driver.
        Needed for Tomcat. WLS6.1 works fine without it.
        */
        try {
            Class.forName("org.gjt.mm.mysql.Driver");
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    private static final String DELETE_PAGE = "delete from pages where title=?";
    private static final String INSERT_CHANGE = "insert into changes(title, time, last_editor) values(?, ?, ?)";
    private static final String INSERT_PAGE = "insert into pages(title, last_edit, text) values(?, ?, ?)";
    private static final String INSERT_REVISION = "insert into revisions(title, id, time, editor, text) values(?, ?, ?, ?, ?)";
	private static final String SELECT_CHANGES = "select * from changes where TO_DAYS(FROM_UNIXTIME(time/1000)) >= TO_DAYS(?)";
	private static final String SELECT_CUTOFF_CHANGE_DAY = "select distinct FROM_UNIXTIME(time/1000, '%Y-%m-%d') as change_day from changes order by time desc limit ?,1";
    private static final String SELECT_PAGE = "select * from pages where title=?";
    private static final String SELECT_HISTORICAL_PAGE = "select title, id, time, editor, text from revisions where title=? and id=?";
    private static final String SELECT_REVISIONS = "select title, id, time, editor from revisions where title=? order by id desc";
    private static final String SELECT_TITLES = "select title from pages";
	private static final String SELECT_MAX_ID = "select MAX(id) from revisions where title=?";
    private static final String UPDATE_PAGE = "update pages set title=?, last_edit=?, text=? where title=?";

    protected MySqlBase() {
    }

    public WikiPage loadPage(final String title) {//final for inner class
        return (WikiPage) new JdbcProcess().executeQuery(SELECT_PAGE, new QueryBlock() {
			public void configure(PreparedStatement prep) throws SQLException {
				prep.setString(1, title);
			}
			
			public Object process(ResultSet rset) throws SQLException {
				WikiPage page = null;
				if (rset.next()) {
					page = new WikiPage(rset.getString("title"), rset.getString("text"), 
						rset.getLong("last_edit"));
				}
				return page;
			}
        });
    }

    protected void storePage(final WikiPage page) {
        new JdbcProcess().executeUpdate(UPDATE_PAGE, new JdbcBlock() {
        	public void configure(PreparedStatement prep) throws SQLException {
				prep.setString(1, page.getTitle());
				prep.setDate(2, new Date(page.getDate().getTime()));
				prep.setString(3, page.getText());
				prep.setString(4, page.getTitle());
			}
        });
    }

    protected void storeNewPage(final WikiPage page) {
		new JdbcProcess().executeUpdate(INSERT_PAGE, new JdbcBlock() {
			public void configure(PreparedStatement prep) throws SQLException {
				prep.setString(1, page.getTitle());
				prep.setLong(2, page.getDate().getTime());
				prep.setString(3, page.getText());
			}
		});
    }

    protected void storeChange(final Change change) {
		new JdbcProcess().executeUpdate(INSERT_CHANGE, new JdbcBlock() {
			public void configure(PreparedStatement prep) throws SQLException {
				prep.setString(1, change.getTitle());
				prep.setLong(2, change.getTime());
				prep.setString(3, change.getEditor());
			}
		});
    }

    protected SortedSet loadTitles() {
        SortedSet titles = new TreeSet();
        titles.addAll(loadAllTitles());

        return titles;
    }

    public List getChangeLogs(int numberOfDays) {
        Map logMap = new HashMap();
        List allChanges = getChanges(numberOfDays);

        //create a map with the days as keys and a list of changes as the values i.e. {day:[change]}
        for (Iterator it = allChanges.iterator(); it.hasNext();) {
            Change currentChange = (Change) it.next();
            String currentDay = currentChange.getDay();

            List changes = (List) logMap.get(currentDay);

            if (changes == null) {
                changes = new LinkedList();
                logMap.put(currentDay, changes);
            }

            changes.add(currentChange);
        }

        //convert the lists of changes to changelogs
        Collection changeLists = logMap.values();
        List changeLogs = new ArrayList();
        
        for (Iterator it = changeLists.iterator(); it.hasNext();) {
            List changes = (List) it.next();
            changeLogs.add(new ChangeLog(changes));
        }

		Collections.sort(changeLogs);
        return changeLogs;
    }

	public List getRevisions(final String title) {
		return (List) new JdbcProcess().executeQuery(SELECT_REVISIONS, new QueryBlock() {
			public void configure(PreparedStatement prep) throws SQLException {
				prep.setString(1, title);
			}
			
			public Object process(ResultSet rset) throws SQLException {
				List revisions = new LinkedList();
				while(rset.next()) {
					String title = rset.getString("title");
					long time = rset.getLong("time");
					String editor = rset.getString("editor");
					int id = rset.getInt("id");
					revisions.add(new Revision(title, time, editor, id));
				}
				return revisions;
			}
			});
	}
	
	protected void storeRevision(final WikiPage rawPage) {
		final String title = rawPage.getTitle();
		Integer result = (Integer) new JdbcProcess().executeQuery(SELECT_MAX_ID, new QueryBlock() {
			public void configure(PreparedStatement prep) throws SQLException {
				prep.setString(1, title);
			}
			
			public Object process(ResultSet rset) throws SQLException {
				rset.next();
				return new Integer(rset.getInt(1));//mysql converts nulls to 0 for ints
			}
		});

		final int revisionId = result.intValue() + 1;
		new JdbcProcess().executeUpdate(INSERT_REVISION, new JdbcBlock() {
			public void configure(PreparedStatement prep) throws SQLException {
				prep.setString(1, rawPage.getTitle());
				prep.setInt(2, revisionId);
				prep.setLong(3, rawPage.getDate().getTime());
				prep.setString(4, rawPage.getLastEditor());
				prep.setString(5, rawPage.getText());
			}
		});
	}

	public WikiPage loadPage(final String title, final int revisionId) {
		return (WikiPage) new JdbcProcess().executeQuery(SELECT_HISTORICAL_PAGE, new QueryBlock() {
			public void configure(PreparedStatement prep) throws SQLException {
				prep.setString(1, title);
				prep.setInt(2, revisionId);
			}
			
			public Object process(ResultSet rset) throws SQLException {
				WikiPage page = null;
				if (rset.next()) {
					page = new WikiPage(rset.getString("title"), rset.getString("text"), 
						new Date(rset.getLong("time")), rset.getString("editor"));
				}
				return page;
			}
		});
	}

	private List getChanges(final int numberOfDays) {
		final String cutoffChangeDay = (String) new JdbcProcess().executeQuery(SELECT_CUTOFF_CHANGE_DAY, new QueryBlock() {
			public void configure(PreparedStatement prep) throws SQLException {
				prep.setInt(1, numberOfDays-1);
			}
			public Object process (ResultSet rset) throws SQLException {
				String resultDay = null;
				if (rset.next()) {
					resultDay = rset.getString("change_day");
				}
				return resultDay;
			}
		});

		return (List) new JdbcProcess().executeQuery(SELECT_CHANGES, new QueryBlock() {
			public void configure(PreparedStatement prep) throws SQLException {
				prep.setString(1, cutoffChangeDay);
			}
			
			public Object process(ResultSet rset) throws SQLException {
				List allChanges = new LinkedList();
				while (rset.next()) {
					String title = rset.getString("title");
					java.util.Date date = new java.util.Date(rset.getLong("time"));
					String lastEditor = rset.getString("last_editor");
					Change change = new Change(title, date, lastEditor);
					allChanges.add(change);
				}
				return allChanges;
			}
		});
	}

    public void deletePage(String title) {
        getIndex().delete(title, this.loadPage(title).getText());

        deleteRow(title);
    }

    private void deleteRow(final String title) {
		new JdbcProcess().executeUpdate(DELETE_PAGE, new JdbcBlock() {
			public void configure(PreparedStatement prep) throws SQLException {
				prep.setString(1, title);
			}
		});
    }

    private List loadAllTitles() {
		return (List) new JdbcProcess().executeQuery(SELECT_TITLES, new QueryBlock() {
			public void configure(PreparedStatement prep) throws SQLException {
			}
			
			public Object process(ResultSet rset) throws SQLException {
				List titles = new LinkedList();
				while (rset.next()) {
					String title = rset.getString("title");
					titles.add(title);
				}
				return titles;
			}
		});
    }
}
