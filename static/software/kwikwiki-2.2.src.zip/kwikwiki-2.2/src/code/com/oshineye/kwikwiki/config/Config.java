package com.oshineye.kwikwiki.config;

import com.oshineye.kwikwiki.TunnellingException;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;

import java.util.Properties;

/**
 * @author aoshineye
 * A singleton that makes configuration information available to the rest of the system
 */
public class Config {
	private static Config instance;

	//We always use unix line-endings
	public static final String LINE_ENDING = "\n";
	private Properties properties;

	private Config() {
		//load the kwikwiki.properties in the war
		ClassLoader loader = this.getClass().getClassLoader();
		InputStream is = loader.getResourceAsStream("kwikwiki.properties");
		Properties defaultProperties = new Properties(System.getProperties());

		try {
			defaultProperties.load(is);
		} catch (IOException ioe) {
			throw new TunnellingException(ioe);
		}

		//if there's a kwikwiki.properties in user.home then load it on top
		String userHome = System.getProperty("user.home");
		File file = new File(userHome, "kwikwiki.properties");

		if (file.exists()) {
			Properties userProperties = new Properties(defaultProperties);

			try {
				userProperties.load(new FileInputStream(file));
			} catch (IOException ioe) {
				throw new TunnellingException(ioe);
			}

			this.properties = userProperties;
		} else {
			this.properties = defaultProperties;
		}
	}

	public static Config getInstance() {
		if (instance == null) {
			instance = new Config();
		}

		return instance;
	}

	public String getProperty(String name) {
		if (name == null) {
			return null;
		} else {
			return this.properties.getProperty(name);
		}
	}

	public String getProperty(String name, String defaultValue) {
		String result = this.getProperty(name);

		if (result == null) {
			return defaultValue;
		} else {
			return result;
		}
	}

	public boolean getValue(String name) {
		String value = this.getProperty(name);
		return "true".equalsIgnoreCase(value);
	}
}
