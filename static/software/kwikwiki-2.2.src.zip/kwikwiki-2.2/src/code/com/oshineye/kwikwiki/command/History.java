package com.oshineye.kwikwiki.command;

import com.oshineye.kwikwiki.markup.MarkUpEngine;
import com.oshineye.kwikwiki.markup.ViewBean;
import com.oshineye.kwikwiki.wikibase.WikiBase;

import java.util.List;
import java.util.logging.Logger;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


/**
 * @author aoshineye
 */
public class History extends Command {
    private static final Logger LOG = Logger.getLogger("com.oshineye.kwikwiki.command.History");

    public void execute(HttpServletRequest req, HttpServletResponse resp, ServletContext sc)
        throws Exception {
        LOG.info("==Executing history command==");

        String title = req.getParameter("title");

        WikiBase wikiBase = WikiBase.getInstance();

        if (wikiBase.pageExists(title)) {
            List revisions = wikiBase.getRevisions(title);
            String text = MarkUpEngine.convertRevisions(revisions);
            ViewBean page = new ViewBean(title, text);
            req.setAttribute("pageBean", page);

            Command.include("/historyTemplate.jsp", req, resp, sc);
        }
    }
}
