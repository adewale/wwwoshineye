package com.oshineye.kwikwiki.markup.rules;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * @author aoshineye
 * A class that encapsulates a pairing of a regular expression pattern and the
 *  text that should replace it. Taken together these form a markup rule that
 * defines the meaning of the language used on a wiki page.
 */
public class MarkUpRule {
    private Pattern pattern;
    private String replacementText;

    /**
 Construct a MarkUpRule which encapsulates a mapping from a regular expression pattern
 to the text that it will use to replace the input to the pattern's matcher.
 */
    protected MarkUpRule(String regularExpression, String replacementText) {
        this.pattern = Pattern.compile(regularExpression, Pattern.MULTILINE);
        this.replacementText = replacementText;
    }

    /**
 Construct a MarkUpRule which encapsulates a mapping from a regular expression pattern
 to the text that it will use to replace the input to the pattern's matcher.
 This constructor uses the empty string as it's replacement text to signify that it
 doesn't need that half of the mapping.
 */
    protected MarkUpRule(String regularExpression) {
        this(regularExpression, "");
    }

    protected MarkUpRule(Pattern pattern, String replacementText) {
        this.pattern = pattern;
        this.replacementText = replacementText;
    }

    protected MarkUpRule() {
        //default no-arguments constructor
    }

    protected Matcher getMatcher(CharSequence text) {
        //don't attempt to reuse matchers via reset() as it isn't thread-safe under high-load
        return this.pattern.matcher(text);
    }

    public CharSequence apply(CharSequence text) {
        Matcher matcher = this.getMatcher(text);

        if (matcher.find()) { //only process if there are matches
            return matcher.replaceAll(this.replacementText);
        }

        return text; //no matches so return original
    }
}
