package com.oshineye.kwikwiki.command;

import com.oshineye.kwikwiki.markup.MarkUpEngine;
import com.oshineye.kwikwiki.markup.ViewBean;
import com.oshineye.kwikwiki.wikibase.WikiBase;
import com.oshineye.kwikwiki.wikibase.WikiPage;

import java.util.Collection;
import java.util.logging.Logger;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class Search extends Command {
    private static final Logger LOG = Logger.getLogger("com.oshineye.kwikwiki.command.Search");

    public void execute(HttpServletRequest req, HttpServletResponse resp, ServletContext sc)
        throws Exception {
        LOG.info("==Executing search command==");

        String word = req.getParameter("word");

        if ((word == null) || (word.equals(""))) {
            Command.include("/searchTemplate.jsp", req, resp, sc);
        } else {
            WikiBase wikiBase = WikiBase.getInstance();
            Collection items = wikiBase.locateWord(word, req.getParameter("caseSensitive") != null);
            String text = MarkUpEngine.convertToWikiList(items);

            ViewBean page = new ViewBean(WikiPage.createSpecialPage(word, text));
            req.setAttribute("pageBean", page);

            Command.include("/searchResultsTemplate.jsp", req, resp, sc);
        }
    }
}
