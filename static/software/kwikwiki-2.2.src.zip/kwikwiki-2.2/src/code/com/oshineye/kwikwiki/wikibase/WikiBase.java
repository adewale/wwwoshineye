package com.oshineye.kwikwiki.wikibase;

import com.oshineye.kwikwiki.TunnellingException;
import com.oshineye.kwikwiki.config.Config;
import com.oshineye.kwikwiki.specialpages.PageFactory;

import java.util.Iterator;
import java.util.List;
import java.util.SortedSet;
import java.util.TreeSet;

/**
 * @author aoshineye
 * A Singleton class which represents the persistence store for this Wiki.
 * Because it's abstract the actual singleton is an instance of a concrete class.
 */
public abstract class WikiBase {
	private static WikiBase instance;
	private Index index;

	public static WikiBase getInstance() {
		if (instance == null) {
			instance = makeInstance();
		}

		return instance;
	}

	private static WikiBase makeInstance() {
		String impl = Config.getInstance().getProperty("kwikwiki.persistence");

		try {
			return (WikiBase) Class.forName(impl).newInstance();
		} catch (ClassNotFoundException cnfe) {
			throw new TunnellingException(cnfe);
		} catch (InstantiationException ie) {
			throw new TunnellingException(ie);
		} catch (IllegalAccessException iae) {
			throw new TunnellingException(iae);
		}
	}

	private void createIndex() {
		SortedSet titles = this.loadTitles();
		this.index = new Index(titles);
		for (Iterator it = titles.iterator(); it.hasNext();) {
			String title = (String) it.next();
			this.index.add(title, this.loadPage(title).getText());
		}
		this.index.registerSpecialPages(PageFactory.getAllSpecialPages());
	}

	public Index getIndex() {
		if (this.index == null) {
			this.createIndex();
		}

		return this.index;
	}

	public void savePage(WikiPage rawPage) {
		String title = rawPage.getTitle();
		String text = rawPage.getText();

		if (this.pageExists(title)) {
			String oldText = this.loadPage(title).getText();
			this.getIndex().update(title, oldText, text);

			this.storePage(rawPage);
		} else {
			this.storeNewPage(rawPage);
			this.getIndex().add(title, text);
		}

		this.storeChange(new Change(rawPage));
		this.storeRevision(rawPage);
	}

	/**
	Return a SortedSet of the titles of all the pages
	in this Wiki.
	*/
	public SortedSet getAllTitles() {
		return this.getIndex().getAllTitles();
	}

	public boolean pageExists(String title) {
		return this.getAllTitles().contains(title);
	}

	public SortedSet getTitlesStartingWith(String word) {
		//obtain set of titles that begin with the word
		SortedSet shareWord = new TreeSet();

		for (Iterator it = this.getAllTitles().iterator(); it.hasNext();) {
			String candidateTitle = (String) it.next();

			if (candidateTitle.startsWith(word)) {
				shareWord.add(candidateTitle);
			}
		}

		return shareWord;
	}

	public SortedSet getTitlesEndingWith(String word) {
		//obtain set of titles that end with the word
		SortedSet shareWord = new TreeSet();

		for (Iterator it = this.getAllTitles().iterator(); it.hasNext();) {
			String candidateTitle = (String) it.next();

			if (candidateTitle.endsWith(word)) {
				shareWord.add(candidateTitle);
			}
		}

		return shareWord;
	}

	/**
	* Return a SortedSet of Strings representing the titles of the pages that
	* contain the word.
	*/
	public SortedSet locateWord(String word, boolean isCaseSensitive) {
		if (isCaseSensitive) {
			return getIndex().getLocations(word);
		} else {
			return getIndex().getLocationsCaseInsensitive(word);
		}
	}

	/**
	* Return a SortedSet of Strings representing the titles of the pages that
	* contain the wikiname. WikiNames are case-sensitive so a search for
	* KwikWikiTest and KwikwikiTest give different results.
	*/
	public SortedSet locateWikiName(String wikiName) {
		return getIndex().getLocations(wikiName);
	}

	/**
	* Load a WikiPage with the appropriate title. If the page doesn't exist
	* then return null.
	*/
	public abstract WikiPage loadPage(String title);

	/**
	* Store an updated version of a pre-existing page.
	*/
	protected abstract void storePage(WikiPage rawPage);

	protected abstract void storeNewPage(WikiPage rawPage);

	protected abstract void storeChange(Change change);

	protected abstract SortedSet loadTitles();

	/**
	* Get an List of ChangeLogs for the last numberOfDays. The number of days
	* must be greater than 0.
	*/
	public abstract List getChangeLogs(int numberOfDays);

	public abstract void deletePage(String title);

	/**
	 * A list of revisions to the page with this title sorted in descending order.
	 */
	public abstract List getRevisions(String title);

	protected abstract void storeRevision(WikiPage rawPage);

	public abstract WikiPage loadPage(String page, int revisionId);
}
