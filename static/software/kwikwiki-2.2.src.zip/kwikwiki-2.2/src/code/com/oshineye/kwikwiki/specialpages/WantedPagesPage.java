package com.oshineye.kwikwiki.specialpages;

import com.oshineye.kwikwiki.markup.MarkUpEngine;
import com.oshineye.kwikwiki.wikibase.Index;
import com.oshineye.kwikwiki.wikibase.WikiBase;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;


public class WantedPagesPage implements SpecialPage {
    public String getText() {
        SortedSet wantedPages = this.getWantedPages();

        return MarkUpEngine.convertToWikiList(wantedPages);
    }

    SortedSet getWantedPages() {
        WikiBase wikiBase = WikiBase.getInstance();
        Set wikiNames = this.getWikiNames();

        //retrieve wanted wikinames
        SortedSet wantedPages = new TreeSet();
        for (Iterator it = wikiNames.iterator(); it.hasNext();) {
            String wikiName = (String) it.next();

            if (!wikiBase.pageExists(wikiName)) {
                wantedPages.add(wikiName);
            }
        }

        return wantedPages;
    }

    private Set getWikiNames() {
        Set wikiNames = new HashSet();
        Index index = WikiBase.getInstance().getIndex();

        for (Iterator it = index.getAllWordsInWiki().iterator(); it.hasNext();) {
            String word = (String) it.next();

            if (MarkUpEngine.isWikiName(word)) {
                wikiNames.add(word);
            }
        }

        return wikiNames;
    }
}
