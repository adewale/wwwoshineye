package com.oshineye.kwikwiki.wikibase;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

/**
 * @author aoshineye
 * A representation of all the changes that happened on a particular day.
 */
public class ChangeLog  implements Comparable {
	//format is Thursday 30 May 2002
	private static final SimpleDateFormat DAY_FORMATTER = new SimpleDateFormat("EEEE dd MMMM yyyy");
	private final String day;
	private final List changes;
	private Date date;

	/**
	* @param changes A list of Change objects for a particular day. This
	* list must have at least one element. Days without changes can't have ChangeLogs.
	*
	*/
	public ChangeLog(List changes) {
		//sort the changes in ascending order, earliest first
		Collections.sort(changes, Collections.reverseOrder());
		this.changes = changes;
		Change firstDay = (Change) this.changes.get(0);
		this.date = firstDay.getDate();
		this.day = DAY_FORMATTER.format(this.date);
	}

	public String getDay() {
		return this.day;
	}

	public List getChanges() {
		return this.changes;
	}

	public boolean isToday() {
		Calendar cal = Calendar.getInstance();
		Calendar logCal = Calendar.getInstance();
		logCal.setTime(this.date);
		
		return ((logCal.get(Calendar.DAY_OF_YEAR) == cal.get(Calendar.DAY_OF_YEAR))
			&& (logCal.get(Calendar.YEAR) == cal.get(Calendar.YEAR)));
	}

	public boolean isOlderThan(ChangeLog other) {
		return this.date.before(other.date);
	}

	public int compareTo(Object other) {
		ChangeLog otherLog = (ChangeLog) other;
		return (int)(otherLog.date.getTime() - this.date.getTime());
	}
	
	public List getFilteredChanges() {
		Map filteredChanges = new HashMap();
		for (Iterator it = this.changes.iterator(); it.hasNext();) {
			Change change = (Change) it.next();
			String title = change.getTitle();
			if (filteredChanges.containsKey(title)) {
				Change existingChange = (Change) filteredChanges.get(title);
				if (existingChange.getDate().before(change.getDate())) {
					filteredChanges.put(title, change);
				}
			} else {
				filteredChanges.put(title, change);
			}

		}
		return extractValues(filteredChanges);
	}

	private List extractValues(Map filteredChanges) {
		List resultingChanges = new ArrayList();
		
		for (Iterator it = filteredChanges.keySet().iterator(); it.hasNext();) {
			resultingChanges.add(filteredChanges.get(it.next()));
		}
		Collections.sort(resultingChanges, Collections.reverseOrder());
		return resultingChanges;
	}
}
