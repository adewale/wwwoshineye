package com.oshineye.archetype.locator;

import junit.framework.TestCase;
import junit.framework.TestSuite;
import junit.framework.Test;
import javax.sql.DataSource;

public class ServiceLocatorTest extends TestCase {
	public static void main(java.lang.String[] args) {
	    junit.textui.TestRunner.run(suite());
	}

	public static Test suite() {
	    TestSuite suite = new TestSuite(ServiceLocatorTest.class);

	    return suite;
	}

    public void testSingleton(){
	    assertTrue(ServiceLocator.getInstance() == ServiceLocator.getInstance());
	    assertTrue(ServiceLocator.getInstance().equals(ServiceLocator.getInstance()));
    }

	/*
	The following tests can only succeed if both the app server and the database
	are available.
	*/

	public void testInitialContext() {
		ServiceLocator sl = ServiceLocator.getInstance();
		assertNotNull(sl.getInitialContext());
		assertTrue(sl.getInitialContext().equals(sl.getInitialContext()));
		assertTrue(sl.getInitialContext() == sl.getInitialContext());
	}

	public void testDataSource() {
		String dsName = "jdbc/testDs";
		ServiceLocator sl = ServiceLocator.getInstance();
		assertNotNull(sl.getDataSource(dsName));
		assertTrue(sl.getDataSource(dsName) instanceof DataSource);
		assertTrue(sl.getDataSource(dsName).equals(sl.getDataSource(dsName)));
        assertTrue(sl.getDataSource(dsName) == sl.getDataSource(dsName));
	}
}
