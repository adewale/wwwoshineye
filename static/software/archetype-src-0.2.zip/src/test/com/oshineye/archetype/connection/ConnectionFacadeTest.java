package com.oshineye.archetype.connection;

import junit.framework.Test;
import junit.framework.TestSuite;
import junit.framework.TestCase;
import java.sql.Connection;
import java.sql.SQLException;

public class ConnectionFacadeTest extends TestCase {
    	public static void main(java.lang.String[] args) {
	    junit.textui.TestRunner.run(suite());
	}

	public static Test suite() {
	    TestSuite suite = new TestSuite(ConnectionFacadeTest.class);

	    return suite;
	}

    public void testGetConnection() {
        ConnectionFacade cf = new ConnectionFacade();
        assertNotNull(cf.getConnection());
    }

    public void testRelease() {
        ConnectionFacade cf = new ConnectionFacade();
        Connection conn = cf.getConnection();

        cf.release(conn, null, null);

        try {
            assertTrue(conn.isClosed());
        } catch (SQLException sqle) {
            sqle.printStackTrace();
            fail("SQLException whilst testing if a released connection was closed");
        }
    }

    public void testConnectionProcessing() {
        for (int i=0; i<10; i++) {
            ConnectionFacade cf = new ConnectionFacade();
            Connection conn = cf.getConnection();

            cf.release(conn, null, null);
        }
    }
}
