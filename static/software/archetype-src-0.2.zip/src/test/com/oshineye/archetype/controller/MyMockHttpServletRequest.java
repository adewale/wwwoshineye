package com.oshineye.archetype.controller;

import com.mockobjects.servlet.MockHttpServletRequest;

public class MyMockHttpServletRequest extends MockHttpServletRequest {
    private String servletPath;
    public void setupServletPath(String servletPath) {
        this.servletPath = servletPath;
    }

    public String getServletPath() {
        System.err.println("getting servlet path::" + this.servletPath);
        return this.servletPath;
    }
}
