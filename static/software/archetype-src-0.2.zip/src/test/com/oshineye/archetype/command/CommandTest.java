package com.oshineye.archetype.command;

import junit.framework.Test;
import junit.framework.TestSuite;
import junit.framework.TestCase;

public class CommandTest extends TestCase {

    public static void main(java.lang.String[] args) {
        junit.textui.TestRunner.run(suite());
    }

    public static Test suite() {
        TestSuite suite = new TestSuite(CommandTest.class);

        return suite;
    }

    public void testGetCommand() {
        String commandName = "/test";
        Command command = CommandFactory.getCommand(commandName);
        assertNotNull(command);

        //test caching
        assertEquals(command, CommandFactory.getCommand(commandName));
        assertTrue(command == CommandFactory.getCommand(commandName));
    }

}
