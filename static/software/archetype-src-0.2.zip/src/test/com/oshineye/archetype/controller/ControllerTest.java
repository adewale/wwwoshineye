package com.oshineye.archetype.controller;

import junit.framework.TestCase;
import junit.framework.Test;
import junit.framework.TestSuite;
import com.mockobjects.servlet.MockHttpServletResponse;
import com.mockobjects.servlet.MockServletConfig;

public class ControllerTest extends TestCase {
    public static void main(java.lang.String[] args) {
        junit.textui.TestRunner.run(suite());
    }

    public static Test suite() {
        TestSuite suite = new TestSuite(ControllerTest.class);

        return suite;
    }

    public void testService() {
        MyMockHttpServletRequest req = new MyMockHttpServletRequest();
        req.setupServletPath("/test");
        MockHttpServletResponse resp = new MockHttpServletResponse();

        Controller controller = new Controller();
        controller.init(new MockServletConfig());
        controller.service(req, resp);
    }
}
