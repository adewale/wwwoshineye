/*
 * Created on 07-Feb-2003
 *
 * To change this generated comment go to 
 * Window>Preferences>Java>Code Generation>Code Template
 */
package com.oshineye.archetype.command;

import java.io.IOException;
import java.io.InputStream;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

/**
 * @author aoshineye
 */
public class CommandFactory {
	private static final String FILE_NAME = "command.properties";
	private static Map commandCache;
	
	public static Command getCommand(String commandName) {
		if (commandCache==null) {
			populateCommandCache();
		}
		
	    return (Command) commandCache.get(commandName);
	}

	private static void populateCommandCache() {
		commandCache = new HashMap();
		Properties properties = null;
		try {
			//load command properties
			ClassLoader cl = CommandFactory.class.getClassLoader();
			InputStream is = cl.getResourceAsStream(FILE_NAME);
			properties = new Properties();

			properties.load( is );
		} catch (IOException e) {
			e.printStackTrace();
		}


		try {
			for (Enumeration keys=properties.propertyNames(); keys.hasMoreElements();) {
				String key = (String) keys.nextElement();
				String className = properties.getProperty(key);

				//putting instances here requires the commands to be multi-threaded
				//and deal with synchonisation issues for shared resources
				CommandFactory.commandCache.put(key, Class.forName(className).newInstance());
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
