package com.oshineye.archetype.command;


public class DummyCommand extends Command {
    public void execute(Argument arg) {
        //dummy command does nothing
        System.err.println("DummyCommand is executing");
    }
}
