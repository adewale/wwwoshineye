package com.oshineye.archetype.locator;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;
import java.io.InputStream;
import java.io.IOException;
import java.util.Properties;
import java.util.Map;
import java.util.HashMap;

public class ServiceLocator {
	private static ServiceLocator instance;
	private InitialContext ictx;
	private Map cache = new HashMap();

	private ServiceLocator() {
	}

	public static synchronized ServiceLocator getInstance() {
		if (instance == null) {
			instance = new ServiceLocator();
		}
		return instance;
	}

	public InitialContext getInitialContext() {
		if (ictx == null) {
			loadInitialContext();
		}
		return ictx;
	}

	public DataSource getDataSource(String jndiName) {
		DataSource ds = (DataSource) cache.get(jndiName);
		if (ds == null) {
			try {
				ds = (DataSource) getInitialContext().lookup(jndiName);
				cache.put(jndiName, ds);
			} catch(NamingException nme) {
				nme.printStackTrace();
			}
		}
		return ds;
	}

	private void loadInitialContext() {
        ClassLoader cl = ServiceLocator.class.getClassLoader();
        InputStream is = cl.getResourceAsStream("jndi.properties");

		if (is != null) {
			try {
				Properties prop = new Properties();
				prop.load(is);
				ictx = new InitialContext(prop);
			} catch (IOException ioe) {
				ioe.printStackTrace();
			} catch (NamingException nme) {
				nme.printStackTrace();
			}
		}
	}
}

