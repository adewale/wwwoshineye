/*
 * Created on 07-Feb-2003
 *
 * To change this generated comment go to 
 * Window>Preferences>Java>Code Generation>Code Template
 */
package com.oshineye.archetype.command;

import javax.servlet.ServletConfig;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


/**
 * @author aoshineye
 */
public class Argument {
	private final HttpServletRequest request;
	private final HttpServletResponse response;
	private final ServletConfig servletConfig;
	
	public Argument(HttpServletRequest req, HttpServletResponse resp, ServletConfig sc) {
		this.request = req;
		this.response = resp;
		this.servletConfig = sc;	
	}
	
	/**
	 * @return HttpServletRequest
	 */
	public HttpServletRequest getRequest() {
		return request;
	}

	/**
	 * @return HttpServletResponse
	 */
	public HttpServletResponse getResponse() {
		return response;
	}

	/**
	 * @return ServletConfig
	 */
	public ServletConfig getServletConfig() {
		return servletConfig;
	}
}
