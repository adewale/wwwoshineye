package com.oshineye.archetype.controller;

import com.oshineye.archetype.command.Argument;
import com.oshineye.archetype.command.Command;
import com.oshineye.archetype.command.CommandFactory;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.ServletConfig;

/**
 * A controller servlet for use in implementations of the ModelViewController
 *  model2 architecture where there is one controller for the entire web-application.
 */
public class Controller extends HttpServlet {
    public void service(HttpServletRequest req, HttpServletResponse resp) {
		String commandName = req.getServletPath();
		Command command = CommandFactory.getCommand(commandName);
		command.execute(new Argument(req, resp, this.getServletConfig()));
    }

    public void init(ServletConfig sc) {
    }
}
