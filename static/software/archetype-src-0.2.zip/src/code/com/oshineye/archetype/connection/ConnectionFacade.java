package com.oshineye.archetype.connection;

import com.oshineye.archetype.locator.ServiceLocator;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.ResultSet;

/**
 * A facade that hides the details behind getting and releasing JDBC connections
 */
public class ConnectionFacade {
    public Connection getConnection() {
        DataSource ds = ServiceLocator.getInstance().getDataSource("jdbc/testDs");

        Connection conn = null;
        try {
            conn = ds.getConnection();
        } catch (SQLException sqle) {
            sqle.printStackTrace();
        }
        return conn;
    }

    public void release(Connection conn, Statement stmt, ResultSet rset) {
        if (rset != null) {
            try {
                rset.close();
            } catch (SQLException sqle) {
                sqle.printStackTrace();
            }
        }

        if (stmt != null) {
            try {
                stmt.close();
            } catch (SQLException sqle) {
                sqle.printStackTrace();
            }
        }

        if (conn != null) {
            try {
                conn.close();
            } catch (SQLException sqle) {
                sqle.printStackTrace();
            }
        }
    }
}
