package com.oshineye.archetype.command;


public abstract class Command {
    public abstract void execute(Argument arg);
}
