/*
 * CommandTest.java
 * JUnit based test
 *
 * Created on 12 April 2002, 00:12
 */

package com.oshineye.kwikwiki.command;

import junit.framework.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author aoshineye
 */
public class CommandTest extends TestCase {
    
    public CommandTest(java.lang.String testName) {
        super(testName);
    }
    
    public static void main(java.lang.String[] args) {
        junit.textui.TestRunner.run(suite());
    }
    
    public static Test suite() {
        TestSuite suite = new TestSuite(CommandTest.class);
        
        return suite;
    }
    
    public void testGetCommand() throws Exception {
		System.out.println("testing Command.getCommand");
		
		assertTrue(Command.getCommand("View") instanceof View);
		
		assertTrue(Command.getCommand("Create") instanceof Create);
    }
}
