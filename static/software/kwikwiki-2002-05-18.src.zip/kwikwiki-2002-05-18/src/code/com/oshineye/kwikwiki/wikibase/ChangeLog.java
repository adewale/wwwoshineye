package com.oshineye.kwikwiki.wikibase;

import java.util.TreeMap;

/**
A sequence of Changes in order of date with older changes first and newer 
changes occurring later.
This implements the singleton pattern to ensure that there's only one
instance of the class available at all times.

<b>Warning</b>
There may be issues with synchronisation and multi-threading as well multiple
classloaders not honouring the singleton contract.
**/
public class ChangeLog {
	/*
	Wikibase should perform all changelogging. Clients should not be aware of Changelog.
	Wikibase would be the only client of ChangeLog.
	After all we're only keeping a log of the persitence related actions of wikibase.
	*/
	private TreeMap changeMap;//map day strings to lists of Changes
	private static ChangeLog instance;
		
	private ChangeLog() {
		
	}
	
	public ChangeLog getInstance() {
		if (instance == null) {
			instance = new ChangeLog();
		}
		
		return instance;
	}
	
	public void add(Change change) {
		
	}
}