package com.oshineye.kwikwiki;
/**
A runtime exception that enables exceptions to propagate from the lower tiers
up a tier where the exception can be dealt with. The idea is that actual 
exception that occurred is caught, wrapped in a tunnellingexception and then
the tunnellingexception is thrown up to user-oriented tier where sensible 
measures can be taken to deal with it based on information in the original 
exception.
*/
public class TunnellingException extends RuntimeException {
	
	public TunnellingException(Exception cause) {
		super(cause);
	}

}
