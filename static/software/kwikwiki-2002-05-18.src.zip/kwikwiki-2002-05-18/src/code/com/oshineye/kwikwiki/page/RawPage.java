package com.oshineye.kwikwiki.page;

import java.util.Date;


public class RawPage extends Page {
	private String title;
	private String text;
	private Date lastEdited;

	public RawPage() {
	}
	
	public RawPage(String title) {
		this.title = title;
	}
	
	public RawPage(String title, String text) {
		this(title);
		this.text = text;		
	}
	
	public RawPage(String title, String text, Date lastEdited) {
		this(title, text);
		this.lastEdited = lastEdited;
	}
	
	public String getTitle() {
		return this.title;
	}

	public void setTitle(String argTitle){
		this.title = argTitle;
	}

	public String getText() {
		return text.toString();
	}

	public void setText(String text){
		this.text = text;
	}

	public Date getLastEdited() {
		return this.lastEdited;
	}

	public void setLastEdited(Date argLastEdited){
		this.lastEdited = argLastEdited;
	}

}
