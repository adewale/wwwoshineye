package com.oshineye.kwikwiki.page;

//import java.util.Set;

public abstract class Page {
	public abstract String getText();
	public abstract String getTitle();
	//public abstract Set getWikiNames();
	
}
