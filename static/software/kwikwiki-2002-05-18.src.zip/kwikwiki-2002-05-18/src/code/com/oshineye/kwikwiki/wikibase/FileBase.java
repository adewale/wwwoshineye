package com.oshineye.kwikwiki.wikibase;

import com.oshineye.kwikwiki.TunnellingException;
import com.oshineye.kwikwiki.page.RawPage;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.FilenameFilter;
import java.io.IOException;
import java.util.Date;
import java.util.SortedSet;
import java.util.TreeSet;

public class FileBase extends WikiBase {
	private static final String WIKI_DIR_NAME= System.getProperty("user.home") 
		+ System.getProperty("file.separator") + "kwikwiki-data"
		+ System.getProperty("file.separator");
	private static final File WIKI_DIR = new File(WIKI_DIR_NAME);
	private static final TextFilter TEXT_FILTER = new TextFilter();
	private static final String TEXT_EXTENSION = ".txt";
	private static final int TEXT_EXTENSION_LENGTH = 4;//includes the dot
	//We always use unix line-endings
	private static final String LINE_ENDING = "\n";


	public RawPage getPage(String title) {
		//assume file always exists
		File file = new File(WIKI_DIR_NAME + title + TEXT_EXTENSION);
		
		StringBuffer rawText = null;
		try {
			rawText = this.readText(file);
		} catch (IOException ioe) {
			throw new TunnellingException(ioe);
		}
		
		Date lastEdited = new Date(file.lastModified());

		return new RawPage(title, rawText.toString(), lastEdited); 
	}
	
	private StringBuffer readText(File file) throws IOException {
		/*
		potential exists for performance optimisation by specifying buffer 
		sizes for the BufferedReader and StringBuffer based on the file's 
		length. Although that might lead to problems with very large files.
		*/
		BufferedReader br = new BufferedReader(new FileReader(file));
		StringBuffer sb = new StringBuffer();
		String line = null;
		
		while ((line = br.readLine()) != null) {
			sb.append(line);
			sb.append(LINE_ENDING);//avoid concatenation penalty
		}
		
		br.close();
		return sb;
	}

	public void savePage(RawPage rawPage) {
		String title = rawPage.getTitle();
		String text = rawPage.getText();
		File file = new File(WIKI_DIR_NAME + title + TEXT_EXTENSION);
		
		try {
			this.writeText(file, text);
		} catch (IOException ioe) {
			throw new TunnellingException(ioe);
		}
	}
	
	private void writeText(File file, String text) throws IOException {
		BufferedWriter bw = new BufferedWriter(new FileWriter(file));
		bw.write(text);
		bw.close();
	}
	
	public SortedSet loadTitles() {
		
		File[] files = WIKI_DIR.listFiles(TEXT_FILTER);
		
		SortedSet set = new TreeSet();
		int directoryNameLength = WIKI_DIR_NAME.length();
		for (int i=0; i<files.length; i++) {
			String temp = files[i].toString();
			int titleLength = temp.length() - TEXT_EXTENSION_LENGTH;
			
			//we only want the title not including the wiki directory or file extension
			String title = temp.substring(directoryNameLength, titleLength);
			set.add(title);
		}
		return set;
	}
	
	
	static class TextFilter implements FilenameFilter {
		public boolean accept(File file, String name) {
			return name.endsWith(".txt");
		}
	}
}
