package com.oshineye.kwikwiki.page;

import com.oshineye.kwikwiki.markup.MarkUpEngine;
import java.io.Serializable;

public class HtmlPage extends Page implements Serializable{
	private String title;
	private String text;
	private String lastEdited;

	public HtmlPage() {
	}
	
	public HtmlPage(RawPage rawPage) {
		this.title = rawPage.getTitle();
		this.text = MarkUpEngine.convertToHtml(rawPage.getText());
		
		Object obj = rawPage.getLastEdited();
		if (obj == null) {
			this.lastEdited = "Unknown time";
		} else {
			this.lastEdited = obj.toString();
		}
	}

	public String getTitle() {
		return title;
	}
	
	public void setTitle(String title) {
		this.title = title;
	}
	
	public String getText() {
		return text.toString();
	}
	
	public String getLastEdited() {
		return lastEdited;
	}
	
	public String toString() {
		return title + "\n" + text;
	}
}
