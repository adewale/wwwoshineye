package com.oshineye.kwikwiki.markup.rules;

import junit.framework.TestCase;

/**
 * @author aoshineye
 */
public class MailtoRuleTest extends TestCase {
	public void testMailtoRule() {
		String text = "mailto:example@example.com";
		String expectedText = "<a href=\"mailto:example@example.com\">mailto:example@example.com</a>";
		String resultText = new MailtoRule().apply(text).toString();
		assertEquals(expectedText, resultText);
	}

}
