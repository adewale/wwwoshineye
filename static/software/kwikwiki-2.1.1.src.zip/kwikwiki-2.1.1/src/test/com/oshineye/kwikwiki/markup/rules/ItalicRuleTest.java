package com.oshineye.kwikwiki.markup.rules;

import junit.framework.TestCase;

/**
 * @author aoshineye
 */
public class ItalicRuleTest extends TestCase {

	public void testWithEmptyString() {
		String text = "";
		assertEquals(text, new ItalicRule().apply(text));
	}
	
	public void testTextWithNoItalics(){
		String text = "test text with no italics";
		assertEquals(text, new ItalicRule().apply(text));
	}
	
	public void testItalicize() {
		String text = "test text ''with italics''";
		String expected = "test text <i>with italics</i>";
		assertEquals(expected, new ItalicRule().apply(text));
	}
}
