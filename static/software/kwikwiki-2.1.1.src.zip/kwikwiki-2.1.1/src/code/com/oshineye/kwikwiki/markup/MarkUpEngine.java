package com.oshineye.kwikwiki.markup;

import com.oshineye.kwikwiki.config.Config;
import com.oshineye.kwikwiki.markup.rules.BlankLineRule;
import com.oshineye.kwikwiki.markup.rules.BoldItalicRule;
import com.oshineye.kwikwiki.markup.rules.BoldRule;
import com.oshineye.kwikwiki.markup.rules.CodeRule;
import com.oshineye.kwikwiki.markup.rules.HorizontalLineRule;
import com.oshineye.kwikwiki.markup.rules.InlineLinkRule;
import com.oshineye.kwikwiki.markup.rules.ItalicRule;
import com.oshineye.kwikwiki.markup.rules.LinkRule;
import com.oshineye.kwikwiki.markup.rules.ListRule;
import com.oshineye.kwikwiki.markup.rules.MailtoRule;
import com.oshineye.kwikwiki.markup.rules.MarkUpRule;
import com.oshineye.kwikwiki.wikibase.Change;
import com.oshineye.kwikwiki.wikibase.Revision;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

public class MarkUpEngine {
	private static final LinkRule LINK_RULE = new LinkRule();
	/*
	The order of the mark-up rules is important : patterns that operate on
	whole lines have to come first.
	Also patterns that have side-effects on successive patterns are last.
	*/
	private static final MarkUpRule[] RULES = {
		LINK_RULE,
		new InlineLinkRule(),
		new ListRule(),
		new HorizontalLineRule(),
		new BlankLineRule(),
		new BoldItalicRule(),
		new BoldRule(),
		new ItalicRule(),
		new CodeRule(),
		new MailtoRule()
		};
	private static final String BOLD = "'''";
	private static final String ELLIPSIS = "&nbsp;.&nbsp;.&nbsp;.&nbsp;";
	private static final String LIST_START = " * ";
	private static final String LEFT_ANGLE_BRACKET = "<";
	private static final String LEFT_ANGLE_BRACKET_ENTITY = "&lt;";
	private static final String HTML_LIST_START = "<ul>";
	private static final String HTML_LIST_END = "</ul>";
	private static final String HTML_LIST_ITEM_START = "<li  class=\"listItem1\">";
	private static final String HTML_LIST_ITEM_END = "</li>";

	public static String convertToHtml(CharSequence text) {
		text = text.toString().replaceAll(LEFT_ANGLE_BRACKET, LEFT_ANGLE_BRACKET_ENTITY);
		for (int i = 0; i < RULES.length; i++) {
			text = RULES[i].apply(text);
		}

		return text.toString();
	}

	public static boolean isWikiName(String title) {
		if ((title == null) || title.equals("")) {
			return false;
		}

		return LINK_RULE.isWikiName(title);
	}

	public static String convertToBold(CharSequence sequence) {
		return BOLD + sequence + BOLD;
	}

	public static String convertToWikiList(Collection items) {
		StringBuffer wikiList = new StringBuffer();

		for (Iterator it = items.iterator(); it.hasNext();) {
			String line = (String) it.next();
			wikiList.append(LIST_START + line + Config.LINE_ENDING);
		}

		return wikiList.toString();
	}

	public static String convertChanges(List changes) {
		List lines = new ArrayList(changes.size());

		for (Iterator iter = changes.iterator(); iter.hasNext();) {
			Change currentChange = (Change) iter.next();
			String line = currentChange.getTitle() + ELLIPSIS + currentChange.getEditor() 
				+ "[" + currentChange.getDate() + "]";
			lines.add(line);
		}

		return MarkUpEngine.convertToWikiList(lines);
	}

	public static String convertRevisions(List revisions) {
		List lines = new ArrayList(revisions.size());

		for (Iterator iter = revisions.iterator(); iter.hasNext();) {
			Revision currentRevision = (Revision) iter.next();
			String line = "<a href=\"View?title=" + currentRevision.getTitle() + "&revision="
			+ currentRevision.getId() + "\"> Revision: " + currentRevision.getId() + "</a> by "
			+ currentRevision.getEditor() + " at " + currentRevision.getDate() ;
			lines.add(line);
		}

		return MarkUpEngine.convertToHtmlList(lines);
	}

	private static String convertToHtmlList(List lines) {
		StringBuffer sb = new StringBuffer();
		sb.append(HTML_LIST_START);
		for (Iterator it = lines.iterator(); it.hasNext();) {
			String line = (String) it.next();
			sb.append(HTML_LIST_ITEM_START);
			sb.append(line);
			sb.append(HTML_LIST_ITEM_END);
		}
		sb.append(HTML_LIST_END);
		return sb.toString();
	}
}
