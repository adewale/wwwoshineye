package com.oshineye.kwikwiki.markup;

import com.oshineye.kwikwiki.wikibase.WikiPage;

import java.util.Date;


public class ViewBean {
    private String lastEdited;
    private String title;
    private String text;
    private boolean special;

    private WikiPage rawPage;
	public ViewBean() {
    }

    /**
 * This constructor exists for situations where the calling method already
 *  has the text in html or does not wish the text to be further formatted.
 * @param title the title of the page
 * @param text the formatted text of the page
 */
    public ViewBean(String title, String text) {
        this.title = title;
        this.text = text;
    }

    /**
 * This constructor takes in a page in wiki format and converts it's
 * contents into html.
 * @param rawPage the WikiPage that have it's text converted to html
 */
    public ViewBean(WikiPage rawPage) {
        this.setTitle(rawPage.getTitle());

        String tempText = rawPage.getText();
        this.setText(MarkUpEngine.convertToHtml(tempText));

        Date date = rawPage.getDate();

        if (date == null) {
            this.lastEdited = "Unknown time";
        } else {
            this.lastEdited = date.toString();
        }

        this.setSpecial(rawPage.isSpecial());
        
        this.rawPage = rawPage;
    }

    public String getLastEdited() {
        return lastEdited;
    }

    public boolean isSpecial() {
        return this.special;
    }

    public void setSpecial(boolean special) {
        this.special = special;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getTitle() {
        return this.title;
    }

    public void setText(String text) {
        this.text = text;
    }

    public String getText() {
        return this.text;
    }

	/**
	 * 
	 */
	public WikiPage getRawPage() {
		return this.rawPage;
	}
}
