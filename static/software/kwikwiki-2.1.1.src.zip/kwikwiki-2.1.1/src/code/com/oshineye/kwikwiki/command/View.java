package com.oshineye.kwikwiki.command;

import com.oshineye.kwikwiki.markup.MarkUpEngine;
import com.oshineye.kwikwiki.markup.ViewBean;
import com.oshineye.kwikwiki.specialpages.PageFactory;
import com.oshineye.kwikwiki.wikibase.WikiBase;
import com.oshineye.kwikwiki.wikibase.WikiPage;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class View extends Command {
    public void execute(HttpServletRequest req, HttpServletResponse resp, ServletContext sc)
        throws Exception {
        System.err.println("==Executing view command==");

        String title = req.getParameter("title");
        String revision = req.getParameter("revision");
        
        
        if (MarkUpEngine.isWikiName(title)) {
			WikiBase wikiBase = WikiBase.getInstance();
            if (wikiBase.pageExists(title)) {
				WikiPage rawPage = null;
            	if (revision == null || revision.trim().equals("")) {
                	 rawPage = PageFactory.getPage(title);
            	} else {
            		int revisionId = Integer.parseInt(revision);
					rawPage = PageFactory.getPage(title, revisionId);
            	}
				ViewBean page = new ViewBean(rawPage);
            	
				req.setAttribute("pageBean", page);

                if (rawPage.isSpecial()) {
                    Command.include("/viewSpecialPageTemplate.jsp", req, resp, sc);
                } else {
                    Command.include("/viewTemplate.jsp", req, resp, sc);
                }
            } else {
                //title is valid wikiName but page doesn't exist
                Command action = CommandFactory.getCommand("Create");
                action.execute(req, resp, sc);
            }
        } else {
            //go to invalid page title error page
            Command.include(Command.INVALID_TITLE, req, resp, sc);
        }
    }
}
