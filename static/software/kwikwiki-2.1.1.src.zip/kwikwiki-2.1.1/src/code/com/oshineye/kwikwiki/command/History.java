package com.oshineye.kwikwiki.command;

import java.util.List;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.oshineye.kwikwiki.markup.MarkUpEngine;
import com.oshineye.kwikwiki.markup.ViewBean;
import com.oshineye.kwikwiki.wikibase.WikiBase;

/**
 * @author aoshineye
 */
public class History extends Command {
	public void execute(HttpServletRequest req, HttpServletResponse resp, ServletContext sc)
		throws Exception {
		System.err.println("==Executing history command==");

		String title = req.getParameter("title");
		if (MarkUpEngine.isWikiName(title)) {
			WikiBase wikiBase = WikiBase.getInstance();
			if (wikiBase.pageExists(title)) {
				List revisions = wikiBase.getRevisions(title);
				String text = MarkUpEngine.convertRevisions(revisions);
				ViewBean page = new ViewBean(title, text);
				req.setAttribute("pageBean", page);
				
				Command.include("/historyTemplate.jsp", req, resp, sc);
			}
			Command.include("/readOnlyFooter.jsp", req, resp, sc);
		} else {
			//go to invalid page title error page
			Command.include(Command.INVALID_TITLE, req, resp, sc);
		}
	}

}
