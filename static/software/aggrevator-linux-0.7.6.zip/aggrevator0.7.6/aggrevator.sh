#!/bin/sh
export LD_LIBRARY_PATH=/usr/lib/mozilla-1.7.3;
export MOZILLA_FIVE_HOME=/usr/lib/mozilla-1.7.3;
java -cp "commons-httpclient-3.0-rc1.jar:commons-codec-1.2.jar:commons-lang-2.0.jar:commons-logging.jar:concurrent.jar:informa.jar:jdom_1.0.jar:log4j-1.2.8.jar:mysql-connector-java-3.0.14-production-bin.jar:proxool-0.8.3.jar:xercesImpl.jar:xmlParserAPIs.jar:xom-1.0b1.jar:xpp3_min-1.1.3.4.M.jar:xstream-1.1.jar:core.jar:osgi.jar:runtime.jar:swt.jar:swt-pi.jar:swt-mozilla.jar:jface.jar:aggrevator.jar:c3p0-0.8.5.jar" -Djava.library.path=. com.oshineye.aggrevator.Main
