package same.filter;

/**
 * 
 * @author ade
 *
 * A Singleton factory class that provides different SourceFilters based on a
 * typecode
 */
public class SourceFilterFactory {
	private static final String NONE = "none";
	private static final SourceFilterFactory INSTANCE = new SourceFilterFactory();
	private SourceFilter filter = null;

	public static SourceFilterFactory instance() {
		return INSTANCE;
	}

	//package access so that tests can see it
	SourceFilterFactory() {
		//do nothing
	}

	public SourceFilter createFilter(String fileTypeCode) {
		if (filter == null) {
			if (fileTypeCode == null) {
				fileTypeCode = SourceFilterFactory.NONE;
			}
			filter = makeFilter(fileTypeCode);
		}
		return filter;
	}


	private SourceFilter makeFilter(String fileTypeCode) {
		if (fileTypeCode.equalsIgnoreCase("java")) {
			return new JavaFilter();
		} else if (fileTypeCode.equalsIgnoreCase("trim")) {
			return new TrimFilter();
		} else if (fileTypeCode.equalsIgnoreCase("baan")) {
			return new BaanFilter();
		} else if (fileTypeCode.equalsIgnoreCase("none")) {
			return new NullFilter();
		} else {
			return null;//invalid typecode
		}
	}
}
