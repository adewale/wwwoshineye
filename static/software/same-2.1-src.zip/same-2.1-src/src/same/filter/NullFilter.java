package same.filter;

/**
 * 
 * @author ade
 *
 * A filter which doesn't actually do any filtering.
 * It represents an implementation of the Null Object pattern.
 */
public class NullFilter extends SourceFilter {
	public String filter(String line) {
		return line;
	}
}
