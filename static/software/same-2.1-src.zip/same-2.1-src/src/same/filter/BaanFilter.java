package same.filter;

class BaanFilter extends SourceFilter {
	private boolean inDllUsage;

	public BaanFilter() {
		inDllUsage = false;
	}

	public String filter(String line) {
		if (line.startsWith("^")) {
			line = line.substring(1);
		}
		int commentStart = line.indexOf('|');
		if (commentStart >= 0) {
			line = line.substring(0, commentStart);
		}
		line = super.removeWhiteSpace(line).toLowerCase();
		if (inDllUsage) {
			if (line.equals("enddllusage")) {
				inDllUsage = false;
			}
			return "";
		}
		if (line.equals("dllusage")) {
			inDllUsage = true;
			return "";
		}
		return line;
	}
}
