/*
 * Created on 30-Jan-2003
 *
 * A reader that wraps around a list of lines and uses it for cacheing. The
 * reader guarantees not to mutate the list.
 */
package same.fs;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import same.filter.SourceFilter;

/**
 * @author aoshineye
 */
public class CachedReader implements Reader {

	private List lines;
	private int lineNumber;
	private int size;
	private SourceFilter filter;
	private String lastLine;

	public CachedReader(SourceFilter filter, List lines) {
		this.lines = lines;
		this.size = lines.size();
		this.filter = filter;
		this.lineNumber = 0;
	}

	public static Reader makeCachedReader(SourceFilter filter, List lines) {
		return new CachedReader(filter, lines);
	}

	/**
	 * @see same.fs.Reader#readLine()
	 */
	public String readLine() {
		lineNumber++;
		if (lineNumber <= size) {
			this.lastLine = (String)lines.get(lineNumber-1);
		} else {
			this.lastLine = null;
		}
		return this.lastLine;
	}

	/**
	 * @see same.fs.Reader#getLastLine()
	 */
	public String getLastLine() {
		return this.lastLine;
	}

	/**
	 * @see same.fs.Reader#getLastLineFiltered()
	 */
	public String getLastLineFiltered() {
		return this.filter.filter(validated(this.lastLine));
	}

	/**
	 * @see same.fs.Reader#readLineFiltered()
	 */
	public String readLineFiltered() {
		String line = this.readLine();
		
		if (line == null) {
			return null;
		} else {
			return this.filter.filter(line);
		}
	}

	private String validated(String temp) {
		return temp==null ? "" : temp;
	}

	/**
	 * @see same.fs.Reader#getLineNumber()
	 */
	public int getLineNumber() {
		return this.lineNumber;
	}

	/**
	 * @see same.fs.Reader#setLineNumber(int)
	 */
	public void setLineNumber(int lineNumber) {
		this.lineNumber = lineNumber;
	}

	public static List readLines(File file) throws IOException {
		List lines = new ArrayList();
		BufferedReader reader = null;
		
		try {
			reader = new BufferedReader(new FileReader(file));
			String line = null;
			while((line=reader.readLine()) != null) {
				lines.add(line);
			}
		}finally {
			CachedReader.closeSafely(reader);
		}
		return lines;
	}

	public static List readLines(String fileName) throws IOException {
		return CachedReader.readLines(new File(fileName));
	}

	private static void closeSafely(BufferedReader reader) {
		if (reader != null) {
			try {
				reader.close();
			} catch (IOException ioe) {
				System.err.println("Safe closing failed");
				ioe.printStackTrace(System.err);
			}
		}
	}
}
