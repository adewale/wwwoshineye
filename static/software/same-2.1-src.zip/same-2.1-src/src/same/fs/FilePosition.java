package same.fs;

/**
 * 
 * @author ade
 *
 * This represents a particular point within a particular file. This provides
 * access to the file's name and the line number.
 */
public class FilePosition {
	private final String fileName;
	private final int lineNumber;

	public FilePosition(String fileName, int lineNumber) {
		this.fileName = fileName;
		this.lineNumber = lineNumber;
	}

	public String getFileName() {
		return fileName;
	}

	public int getLineNumber() {
		return lineNumber;
	}

	public boolean equals(Object obj) {
		if (obj == null || !(obj instanceof FilePosition)) {
			return false;
		}
		FilePosition that = (FilePosition) obj;
		return this.lineNumber == that.lineNumber && this.fileName.equals(that.fileName);
	}

	public String toString() {
		return "FilePosition[" + fileName + "," + lineNumber + "]";
	}
}
