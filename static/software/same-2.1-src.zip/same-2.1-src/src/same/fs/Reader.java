package same.fs;
/**
 * @author aoshineye
 *
 * A reader
 */
public interface Reader {
	String readLine();
	String readLineFiltered();
	String getLastLine();
	String getLastLineFiltered();
	int getLineNumber();
	void setLineNumber(int lineNumber);
}