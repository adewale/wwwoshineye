package same.fs;

import java.io.File;
import java.io.IOException;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import same.filter.SourceFilter;
import same.filter.SourceFilterFactory;

public class SourceFileSystem {
	//strings were chosen to ensure widely distributed hashes
	public static final String ACROSS = "AAAAAAAAAAAAAA";
	public static final String DOWN = "ZZZZZZZZZZ";
	
	private final Map readerCache;/*String->SourceReader*/
	private SourceFilter filter;
	private int fragmentSize;

	public SourceFileSystem(int fragmentSize, String filterType) {
		this.filter = SourceFilterFactory.instance().createFilter(filterType);
		this.readerCache = new HashMap();
		this.fragmentSize = fragmentSize;
	}

	public Reader getNewReader(String fileName) throws IOException {
		return new CachedReader(filter, CachedReader.readLines(fileName));
	}

	/**
	 * Get a reader in this series pointing at filePosition
	 * @param filePosition
	 * @param series
	 * @return Reader
	 * @throws IOException
	 */
	public Reader getReader(FilePosition filePosition, String series) throws IOException {
		String fileName = filePosition.getFileName();
		int lineNumber = filePosition.getLineNumber();
		
		//get a reader for this file and series
		Reader result = this.getCachedReader(fileName, series);

		//make sure it's pointing to the correct position for subsequent reading
		result.setLineNumber(lineNumber-1);
		return result;
	}

	private Reader getCachedReader(String fileName, String series) throws IOException {
		String key = fileName + series;
		return (Reader) readerCache.get(key);
	}

	public void prepare(List files) throws IOException {
		//sort by file size descending
		Collections.sort(files, new Comparator() {
			public int compare(Object obj1, Object obj2) {
				File file1 = (File) obj1;
				File file2 = (File) obj2;
				
				long file1Length = file1.length();
				long file2Length = file2.length();
				if (file1Length > file2Length) {
					return 1;
				} else if (file1Length == file2Length) {
					return 0;
				} else {
					return -1;
				}
			}
		});
		
		cacheFiles(files);
	}
	
	private void cacheFiles(List files) throws IOException {		
		for (Iterator it = files.iterator(); it.hasNext();) {
			File file = (File) it.next();
			List lines = CachedReader.readLines(file);
			
			if (lines.size() < this.fragmentSize) {
				it.remove();
				continue;
			}
	
			String fileName = file.getAbsolutePath();
			String keyAcross = fileName + SourceFileSystem.ACROSS;
			String keyDown = fileName + SourceFileSystem.DOWN;
			
			readerCache.put(keyAcross, CachedReader.makeCachedReader(filter, lines));
			readerCache.put(keyDown, CachedReader.makeCachedReader(filter, lines));
		}
	}
}
