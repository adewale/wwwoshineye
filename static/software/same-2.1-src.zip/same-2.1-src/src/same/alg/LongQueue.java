package same.alg;

/**
 * @author ade
 *
 * A fixed size queue (FIFO) implemented as a circular array of longs. Note that
 * adding more elements after the queue is full will cause it to overwrite
 * existing entries.
 */
public class LongQueue {
	private final long[] array;
	private int index;
	private boolean full = false;

	public LongQueue(int size) {
		array = new long[size];
		index = 0;
	}

	public void append(long number) {
		array[index] = number;
		index = (index + 1) % array.length;//wrap
		full = full || (index == 0);
	}

	public long getFirst() {
		return array[index];
	}

	public boolean isFull() {
		return full;
	}
}
