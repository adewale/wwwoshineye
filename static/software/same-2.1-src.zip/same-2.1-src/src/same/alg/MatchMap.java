package same.alg;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * @author ade
 *
 * A Map of lines of text to the file positions where those lines of text are
 * duplicated.
 */
public class MatchMap {
	private Map map;
	
	public MatchMap() {
		this.map = new HashMap();
	}
	
	public int size() {
		return this.map.size();
	}
	
	/**
	 * Return an array of Map.Entry objects containing the text as a List and
	 * the FilePosition object represeting the points of duplication.
	 * @return Object[]
	 */
	public Object[] getEntries() {
		return this.map.entrySet().toArray();
	}

	public void update(Match match) {
		//update the match map with the data from this match
		List linesOfText = match.getLines();
		Set filePositions = (Set) this.map.get(linesOfText);
		
		if (filePositions == null) {
			filePositions = new HashSet();
			this.map.put(linesOfText, filePositions);
		}
		
		filePositions.add(match.getPosition1());
		filePositions.add(match.getPosition2());
	}
}
