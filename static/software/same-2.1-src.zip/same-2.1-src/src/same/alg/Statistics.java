package same.alg;

/**
 * @author aoshineye
 *
 * A class that represents all the statistics relating to the working of Same
 */
public class Statistics {
	private int numberOfFiles;
	private int totalLines;
	private int relevantLines;
	private int numberOfComparisons;
	private int numberOfPotentialMatches;

	private int numberOfActualMatches;
	public int getNumberOfFiles() {
		return numberOfFiles;
	}

	public int getTotalNumberOfLines() {
		return totalLines;
	}

	public int getRelevantNumberOfLines() {
		return relevantLines;
	}

	public int getNumberOfComparisons() {
		return numberOfComparisons;
	}

	public void incrementTotalLines() {
		totalLines++;
	}

	public void incrementRelevantLines() {
		relevantLines++;
	}

	/**
	 * Method incrementNumberOfFiles.
	 */
	public void incrementFiles() {
		numberOfFiles++;
	}

	/**
	 * Method incrementComparisons.
	 */
	public void incrementComparisons() {
		numberOfComparisons++;
	}

	public String getRelevantLinesAsPercentage() {
		if (this.relevantLines < 0.01) {
			return "<meaningless>%";
		}
		
		double percentage = Math.round(this.relevantLines * 1000 / this.totalLines) / (double) 10;
		return percentage + "%";
	}

	public void setNumberOfPotentialMatches(int numberOfPotentialMatches) {
		this.numberOfPotentialMatches = numberOfPotentialMatches;
	}

	public int getNumberOfPotentialMatches() {
		return this.numberOfPotentialMatches;
	}
	
	public void setNumberOfActualMatches(int numberOfActualMatches) {
		this.numberOfActualMatches = numberOfActualMatches;
	}
	
	public int getNumberOfActualMatches() {
		return this.numberOfActualMatches;
	}
}
