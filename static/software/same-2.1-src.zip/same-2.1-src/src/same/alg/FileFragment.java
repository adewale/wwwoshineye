package same.alg;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import same.fs.FilePosition;
import same.fs.Reader;

public class FileFragment {
	private final FilePosition startingPoint;
	private final List lines;/*<String>*/

	public FileFragment(FilePosition filePosition) {
		startingPoint = filePosition;
		lines = new ArrayList();
	}

	public FilePosition getStartingPoint() {
		return startingPoint;
	}

	public void removeLines(int number) {
		int end = this.lines.size();
		int start = end - number;
		this.lines.subList(start, end).clear();//remove everything from start to end of list
	}

	public int appendLines(Reader reader) throws IOException {
		int linesAdded = 0;
		String line = null;
		while ((line = reader.readLine()) !=null) {
			this.lines.add(line);
			linesAdded++;

			if (reader.getLastLineFiltered().length() != 0) {//line empty after filtering
				break;
			}
		}
		return linesAdded;
	}

	public List getLines() {
		return this.lines;
	}
}
