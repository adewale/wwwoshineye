package same.alg;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import same.fs.FilePosition;
import same.fs.Reader;
import same.fs.SourceFileSystem;

public class Same {
	private final Listener listener;
	private final List files; /*<File>*/
	private final int fragmentSize;
	private final SourceFileSystem readerPool;

	private Statistics stats;
	private MatchMap matchMap;//List->List<FilePosition>

	public Same(Listener listener, int fragmentSize, String filterType, List fileNames) {
		this.listener = listener;
		this.fragmentSize= fragmentSize;
		this.matchMap = new MatchMap();
		this.stats = new Statistics();
		this.readerPool = new SourceFileSystem(fragmentSize, filterType);
		this.files = this.getAllFiles(fileNames);
	}

	private List getAllFiles(List fileNames) {
		List files = new ArrayList();
		for (int i=0, size=fileNames.size(); i<size; i++) {
			File tempFile = new File((String) fileNames.get(i));
			if (tempFile.isDirectory()) {
				files.addAll(this.getDirectoryContents(tempFile));
			} else {
				files.add(tempFile);
			}
		}
		
		return files;
	}
	
	//return all the files in this directory and it's sub-directories
	private List getDirectoryContents(File dir) {
		File[] allFiles = dir.listFiles();
		List resultFiles = new ArrayList();
		for (int i = 0; i < allFiles.length; i++) {
			File temp = allFiles[i];
			if (temp.isDirectory()) {
				if (!temp.getName().endsWith(".svn") && !temp.getName().endsWith("CVS")) {
					//recurse
					resultFiles.addAll(this.getDirectoryContents(temp));
				}
			} else {
				resultFiles.add(temp);
			}
		}
		return resultFiles;
	}

	public void run() {
		listener.onStart();

		identifyRealMatches(processAllFiles());
		
		listener.onEnd();
	}

	public MatchMap getMatchMap() {
		return this.matchMap;
	}

	private List processAllFiles() {
		FragmentHashRegistry registry = new FragmentHashRegistry();
		HashFinder hashFinder = new HashFinder(fragmentSize, registry);
		
		prepareFiles();
		
		//process remaining files
		for(int i=0, size=files.size(); i<size; i++) {
			File file = (File) files.get(i);
			processFile(file, hashFinder);
		}
		
		List potentialMatches = registry.getPotentialMatches();
		stats.setNumberOfPotentialMatches(potentialMatches.size());
		return potentialMatches;
	}

	private void prepareFiles() {
		try {
			this.readerPool.prepare(files);
		} catch (IOException ioe) {
			ioe.printStackTrace(System.err);
		}
	}
	
	private void processFile(File file, HashFinder hashFinder) {
		Reader reader = null;
		try {
			reader = readerPool.getNewReader(file.getAbsolutePath());
			hashFinder.startFile(file.getAbsolutePath());
			
			String line = null;
			while ((line = reader.readLineFiltered()) != null) {
				hashFinder.addLine(line);
				stats.incrementTotalLines();
				if (line.length() != 0) {
					stats.incrementRelevantLines();
				}
			}
			stats.incrementFiles();
		} catch (IOException ex) {
			listener.onErrorPreprocessFile(file, ex);
			ex.printStackTrace(System.err);
		}
	}

	private void identifyRealMatches(List potentialMatches) {
		listener.onStartMatches();

		//for each potentialMatch
		Object[] matchMapEntries = this.matchMap.getEntries();
		for (int matchIndex=0, size=potentialMatches.size(); matchIndex<size; matchIndex++) {
			//compare all potentially matching positions against each other
			List positions = (List) potentialMatches.get(matchIndex);
			for (int outer = 1, spSize = positions.size(); outer < spSize ; outer++) {
				FilePosition filePosition2 = (FilePosition) positions.get(outer);
				
				for (int inner = 0; inner < outer; inner++) {
					FilePosition filePosition1 = (FilePosition) positions.get(inner);
					
					if (isPartOfExistingMatch(filePosition1, filePosition2, matchMapEntries)) {
						continue;
					}
					
					Match result = getMatch(filePosition1, filePosition2);			
					if (result != null) {
					    matchMap.update(result);
					    matchMapEntries =  this.matchMap.getEntries();
					}
					stats.incrementComparisons();
				}
			}
		}
		stats.setNumberOfActualMatches(matchMapEntries.length);
		listener.onEndMatches();
	}
	
	private Match getMatch(FilePosition filePosition1, FilePosition filePosition2)  {
		Match match = null;
		Reader reader1 = null;
		Reader reader2 = null;
		try {
			int duplicateCodeLength = 0;
			FileFragment fragment1 = new FileFragment(filePosition1);
			FileFragment fragment2 = new FileFragment(filePosition2);
			reader1 = readerPool.getReader(filePosition1, SourceFileSystem.ACROSS);
			reader2 = readerPool.getReader(filePosition2, SourceFileSystem.DOWN);
			
			while (true) {
				int linesAdded1 = fragment1.appendLines(reader1);
				int linesAdded2 = fragment2.appendLines(reader2);

				if (atEnd(reader1, reader2) || notMatched(reader1, reader2)) {
					fragment1.removeLines(linesAdded1);
					fragment2.removeLines(linesAdded2);
					break;
				}
				duplicateCodeLength++;
			}

			//only create a Match when necessary
			if (duplicateCodeLength >= fragmentSize) {
				match = new Match(fragment1, fragment2);
			}
		} catch (IOException ioe ) {
			ioe.printStackTrace(System.err);
		}
		return match;
	}

	private boolean notMatched(Reader reader1, Reader reader2) {
		return !reader1.getLastLineFiltered().equals(reader2.getLastLineFiltered());
	}

	private boolean atEnd(Reader reader1, Reader reader2) {
		return reader1.getLastLine() == null	|| reader2.getLastLine() == null;
	}

	private boolean isPartOfExistingMatch(FilePosition position1, FilePosition position2,
		Object[] matchMapEntries) {
		for (int i=0; i<matchMapEntries.length; i++) {
			Map.Entry entry = (Map.Entry) matchMapEntries[i];
			int numLines = ((List)entry.getKey()).size();
			Set positionsSet = (Set) entry.getValue();
			FilePosition[] positions = (FilePosition[])positionsSet.toArray(new FilePosition[0]);
			

			if (contains(positions, position1, numLines) 
				&& contains(positions, position2, numLines)) {
				return true;
			}
		}
		return false;
	}

	private boolean contains(FilePosition[] positions, FilePosition searchPosition, 
		int numLines) {
		String searchPositionFileName = searchPosition.getFileName();
		int searchLine = searchPosition.getLineNumber();
		for (int i = 0; i < positions.length; i++) {
			FilePosition currentPosition = (FilePosition) positions[i];
			int currentLine = currentPosition.getLineNumber();
			
			//same file and searchPosition is inside currentPosition's fragment
			if (searchPositionFileName.equals(currentPosition.getFileName())
				&& searchLine >= currentLine
				&& searchLine < (currentLine + numLines)
			) {
				return true;
			}
		}
		return false;
	}

	public Statistics getStatistics() {
		return this.stats;
	}
}
