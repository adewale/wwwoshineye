package same.alg;

import java.io.File;

/**
 * 
 * @author ade
 *
 * Implementations of this interface declare that they wish to be informed when
 * significant events happen within the Same class as it processes files.
 */
public interface Listener {
	void onStart();
	void onErrorPreprocessFile(File file, Exception exception);
	void onStartMatches();
	void onEndMatches();
	void onEnd();
}