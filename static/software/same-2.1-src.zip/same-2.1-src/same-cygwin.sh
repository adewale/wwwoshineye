#!/bin/sh

#ensure java is in the path
java -Xmx768M -cp "same-classes.zip;trove.jar" same.textui.SameCLI $*