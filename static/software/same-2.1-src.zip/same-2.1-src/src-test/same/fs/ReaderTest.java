package same.fs;

import java.io.IOException;
import java.util.List;

import junit.framework.TestCase;
import same.filter.NullFilter;
import same.filter.SourceFilter;
import same.filter.SourceFilterFactory;

/**
 * @author ade
 *
 * A testcase for readers
 */
public class ReaderTest extends TestCase {
	private static final String FILE_NAME = "TestData.txt";
	private static final SourceFilter FILTER = new NullFilter();

	public void testReadLine() throws Exception {
		Reader sr = getTestReader();
		String line = sr.readLine();
		
		assertEquals(line, "//duplicate friendly code for testing same");
	}

	public void testGetLastLine() throws Exception {
		Reader sr = getTestReader();
		assertEquals(sr.readLine(), sr.getLastLine());
	}

	public void testGetLineNumber() throws Exception {
		Reader sr = getTestReader();
		sr.readLine();
		sr.readLine();
		sr.readLine();
		sr.readLine();
		sr.readLine();
		
		assertTrue(sr.getLineNumber() == 5);
	}

	public void testFilteringAtEOF() throws Exception {
		SourceFilter workingFilter = SourceFilterFactory.instance().createFilter("java");
		List lines = CachedReader.readLines(FILE_NAME);
		Reader sr = CachedReader.makeCachedReader(workingFilter, lines);
		
		while (sr.readLine() != null) {
			//empty loop as we don't care about the file's contents
		}
		
		//at end
		assertNotNull(sr.getLastLineFiltered());
	}
	
	private Reader getTestReader() throws IOException {
		return CachedReader.makeCachedReader(FILTER, CachedReader.readLines(FILE_NAME));
	}
}
