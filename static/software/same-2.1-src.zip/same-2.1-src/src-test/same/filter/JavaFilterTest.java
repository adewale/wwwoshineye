package same.filter;

import junit.framework.TestCase;

public class JavaFilterTest extends TestCase {
	public void testFiltering() {
		JavaFilter jf = new JavaFilter();
		assertEquals("", jf.filter("   \t   \t"));
		assertEquals("", jf.filter("/*/"));
		assertEquals("test", jf.filter("test*/t es t"));
		assertEquals("test", jf.filter("test//*blabla"));
		assertEquals("test", jf.filter("t/*of List*/e/**/s/**//**/t//123"));
	}
}
