package same.filter;

import junit.framework.TestCase;

/**
 * @author ade
 *
 * Unit test confirming that the SourceFilterFactory works
 */
public class SourceFilterFactoryTest extends TestCase {

	public void testSingleton() {
		assertNotNull(SourceFilterFactory.instance());
		assertSame(SourceFilterFactory.instance(), SourceFilterFactory.instance());
		assertTrue(SourceFilterFactory.instance() == SourceFilterFactory.instance());
	}

	public void testCreateFilter() {
		assertTrue(new SourceFilterFactory().createFilter(null) instanceof NullFilter);
		assertTrue(new SourceFilterFactory().createFilter("none") instanceof NullFilter);
		assertTrue(new SourceFilterFactory().createFilter("None") instanceof NullFilter);
		
		assertTrue(new SourceFilterFactory().createFilter("baan") instanceof BaanFilter);
		assertTrue(new SourceFilterFactory().createFilter("Baan") instanceof BaanFilter);
		assertTrue(new SourceFilterFactory().createFilter("java") instanceof JavaFilter);
		assertTrue(new SourceFilterFactory().createFilter("Java") instanceof JavaFilter);
		assertTrue(new SourceFilterFactory().createFilter("trim") instanceof TrimFilter);
		assertTrue(new SourceFilterFactory().createFilter("Trim") instanceof TrimFilter);
		
		assertNull(new SourceFilterFactory().createFilter("nonsenical type code"));
	}

}
