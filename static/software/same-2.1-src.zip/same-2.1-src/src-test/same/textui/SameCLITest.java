package same.textui;

import junit.framework.TestCase;
import same.alg.Same;
import same.alg.Statistics;

/**
 * @author ade
 *
 * Test that uses SameCLI as an entry point for testing the behaviour of the
 * whole system. It's not really a unit-test but it's useful. 
 */
public class SameCLITest extends TestCase {
	public void testFunctionality() throws Exception {
		String[] args = {"-m", "1", "TestData.txt"};
		SameCLI cli = new SameCLI();
		cli.run(args);
		
		Same same = cli.getSame();
		Statistics stats = same.getStatistics();
		assertEquals(4, stats.getNumberOfActualMatches());
		assertEquals(1, stats.getNumberOfFiles());
		assertEquals(37, stats.getTotalNumberOfLines());
	}

}
