package same.alg;

import java.util.ArrayList;
import java.util.List;

import junit.framework.TestCase;
import same.fs.FilePosition;


public class FragmentHashRegistryTest extends TestCase {

	public void test() {
		FragmentHashRegistry registry = new FragmentHashRegistry();
		int firstHash = 627;
		int file1LineNumber1 = 33;
		int file1LineNumber2 = 45;
		int secondHash = 442;
		int file2LineNumber1 = 21;
		
		registry.registerFragment(firstHash, "file1", file1LineNumber1);
		registry.registerFragment(secondHash, "file1", file1LineNumber2);
		registry.registerFragment(firstHash, "file2", file2LineNumber1);

		List potentialMatches = new ArrayList();
		List potentialMatch = new ArrayList();
		
		potentialMatch.add(new FilePosition("file1", file1LineNumber1));
		potentialMatch.add(new FilePosition("file2", file2LineNumber1));
		
		potentialMatches.add(potentialMatch);

		assertEqual(potentialMatches, registry.getPotentialMatches());
	}

	private void assertEqual(List expectedMatches, List actualMatches) {
		assertEquals("expected equal List sizes", expectedMatches.size(), actualMatches.size());
		for (int i = 0; i < expectedMatches.size(); i++) {
			List expected = (List) expectedMatches.get(i);
			List actual = (List) actualMatches.get(i);

			assertEquals("expected equal nested List sizes at position " + i,
				expected.size(), actual.size());
				
			for (int j = 0; j < expected.size(); j++) {
				assertEquals("expected equal nested List element at position " + i + "->" + j,
					expected.get(j), actual.get(j));
			}
		}
	}
}
