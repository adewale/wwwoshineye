package same.alg;

import junit.framework.TestCase;

public class LongQueueTest extends TestCase {

	public void testShifting() {
		LongQueue sa = new LongQueue(2);
		sa.append(1L);
		assertEquals(0, sa.getFirst());
		sa.append(2L);
		assertTrue(1 == sa.getFirst());
		sa.append(3L);
		assertTrue(2 == sa.getFirst());
	}
}
