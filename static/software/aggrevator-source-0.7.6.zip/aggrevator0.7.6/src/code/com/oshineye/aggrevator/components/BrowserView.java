package com.oshineye.aggrevator.components;

import org.eclipse.swt.browser.LocationListener;
import org.eclipse.swt.browser.OpenWindowListener;

/**
 * @author aoshineye
 *
 */
public interface BrowserView extends BrowserObserver, View, LocationListener, OpenWindowListener {
	void focus();
}
