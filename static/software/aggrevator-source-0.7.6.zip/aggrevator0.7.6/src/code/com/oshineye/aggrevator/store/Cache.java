package com.oshineye.aggrevator.store;

import java.util.List;

/**
 * @author aoshineye
 *
 */
public interface Cache {
	public List getFeeds();
	
	public void shutDown();
}
