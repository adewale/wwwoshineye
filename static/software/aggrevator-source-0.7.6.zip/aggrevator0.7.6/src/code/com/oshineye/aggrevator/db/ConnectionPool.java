package com.oshineye.aggrevator.db;

import java.sql.Connection;

/**
 * @author aoshineye
 *
 */
public interface ConnectionPool {
	
	public Connection acquireConnection();
	
	public void shutDown();

}
