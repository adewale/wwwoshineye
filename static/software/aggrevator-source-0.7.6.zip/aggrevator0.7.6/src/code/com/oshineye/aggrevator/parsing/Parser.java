package com.oshineye.aggrevator.parsing;

import java.util.List;

import com.oshineye.aggrevator.InvalidFeedException;

/**
 * @author aoshineye
 *
 */
public interface Parser {
	public List fetchNewEntries(Location location, Long feedId) throws InvalidFeedException;

	public String getCurrentFeedTitle();
}