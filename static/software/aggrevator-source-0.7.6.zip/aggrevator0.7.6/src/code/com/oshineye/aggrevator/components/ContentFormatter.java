package com.oshineye.aggrevator.components;

import org.apache.commons.lang.StringEscapeUtils;
import org.apache.commons.lang.StringUtils;

import com.oshineye.aggrevator.Entry;

/**
 * @author aoshineye
 * Format content into html format for display
 */
public class ContentFormatter {
	private static final String HTML_START = "<html><head><title></title></head><body>" 
		+ "<div><span style=\"background-color: #cccccc; display:block; border-width: 1px;" 
		+ " border-style: solid; border-color: #000000; padding:5px;\">";
	private static final String TECHNORATI_START = "<span style=\"background-color: #cccccc; display:block; border-width: 1px; border-style: solid; border-color: #000000; padding:5px;\"><a href=\"http://www.technorati.com/cosmos/search.html?url="; 
	private static final String TECHNORATI_END = "\">Related entries</a></span>"; 
	private static final String HTML_END = "</div></div></body></html>";
	private Entry entry;

	public ContentFormatter(Entry entry) {
		this.entry = entry;
	}
	
	public String getFormattedContent() {
		boolean hasLink = hasLink(entry.getUrl());
		String link = "";
		if (hasLink) {
			link = createLink(entry.getTitle(), entry.getUrl());
		}

		StringBuffer buffer = new StringBuffer();
		buffer.append(HTML_START);
		buffer.append(entry.getFeedTitle());
		buffer.append(" :: ");
		buffer.append(link);
		buffer.append("</span>");
		
		if (hasLink) {
			buffer.append(createTechnoratiRelatedEntriesLink(entry.getUrl()));
		}
		
		buffer.append("<div style=\"padding:5px;\">");
		
		buffer.append(entry.getContent());
		buffer.append(HTML_END);
		
		String content = StringUtils.replace(buffer.toString(), "&quot;", "\"");
		return content;
	}
	
	private String createTechnoratiRelatedEntriesLink(String link) {
		return TECHNORATI_START + link + TECHNORATI_END;
	}
	
	private String createLink(String text, String url) {
		return "<a href=\"" + url + "\">" + StringEscapeUtils.escapeHtml(text) + "</a>";
	}

	private boolean hasLink(String url) {
		return Entry.NO_LINK != url;
	}
}
