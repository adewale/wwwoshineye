package com.oshineye.aggrevator.util;

import java.io.File;
import java.io.StringWriter;
import java.io.Writer;

/**
 * @author aoshineye
 *
 */
public class StringWriterFactory implements WriterFactory {
	private StringWriter writer;

	public StringWriterFactory(StringWriter writer) {
		this.writer = writer;
	}
	
	public Writer getWriter(File file) {
		return writer;
	}

}
