package com.oshineye.aggrevator.store.entry;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.oshineye.aggrevator.EntryContentService;
import com.oshineye.aggrevator.TunnellingException;
import com.oshineye.aggrevator.db.JdbcProcess;
import com.oshineye.aggrevator.db.JdbcProcessFactory;
import com.oshineye.aggrevator.db.QueryBlock;
import com.oshineye.aggrevator.util.QueryLoader;

/**
 * @author aoshineye
 *
 */
public class MySqlEntryContentService implements EntryContentService {

	private final JdbcProcessFactory processFactory;
	private final QueryLoader queryLoader;

	public MySqlEntryContentService(JdbcProcessFactory processFactory, QueryLoader queryLoader) {
		this.processFactory = processFactory;
		this.queryLoader = queryLoader;
	}

	public String getContent(final Long entryId) {
		JdbcProcess process = processFactory.createProcess();
		String query = queryLoader.getQuery("GET_ENTRY_CONTENT");
		String content = (String) process.executeQuery(query, new QueryBlock() {

			public Object process(ResultSet rset) throws SQLException {
				if (rset.next()) {
					return rset.getString(1);
				}
				throw new TunnellingException("No entry exists with id: " + entryId);
			}

			public void configure(PreparedStatement stmt) throws SQLException {
				stmt.setLong(1, entryId.longValue());
			}
			
		});
		return content;
	}

}
