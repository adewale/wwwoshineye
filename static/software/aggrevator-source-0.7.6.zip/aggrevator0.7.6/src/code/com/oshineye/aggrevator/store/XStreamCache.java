package com.oshineye.aggrevator.store;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;

import org.apache.log4j.Logger;

import com.oshineye.aggrevator.Feed;
import com.oshineye.aggrevator.FeedRecord;
import com.oshineye.aggrevator.TunnellingException;
import com.oshineye.aggrevator.util.IOUtils;
import com.oshineye.aggrevator.util.XStreamFactory;
import com.thoughtworks.xstream.XStream;
import com.thoughtworks.xstream.converters.ConversionException;

/**
 * @author aoshineye
 *
 */
public class XStreamCache implements Cache {
	private static final Logger LOG = Logger.getLogger(XStreamCache.class);
	private final File file;
	private final FeedFinder feedFinder;
	private List cachedFeeds;
	private final XStream xstream;

	public XStreamCache(File file, FeedFinder feedFinder) {
		this.file = file;
		this.feedFinder = feedFinder;
		this.xstream = XStreamFactory.createXStream();
		ensureFeedsLoaded();
	}

	public List getFeeds() {
		return cachedFeeds;
	}
	
	private void ensureFeedsLoaded() {
		loadFeeds();
		if (cachedFeeds == null || isInconsistent()) {
			LOG.warn("Unable to use cache. Loading feeds from store instead.");
			cachedFeeds = feedFinder.findAllFeeds();
		}
	}

	private void loadFeeds() {
		FileReader fileReader = null;
		try {
			//ensure file always exists
			file.createNewFile();
			
			if (file.length() == 0) {
				LOG.info("Cache file didn't exist.");
				return;
			}
			
			fileReader = new FileReader(file);
			cachedFeeds = extractFeeds(fileReader);
		} catch (ConversionException e) {
			//usually means we're trying to load a cache file that uses an old file format
			LOG.info("Cache file exists but contains content that can't be converted.");
		} catch (IOException e) {
			throw new TunnellingException(e);
		} finally {
			IOUtils.close(fileReader);
		}
	}

	protected List extractFeeds(FileReader fileReader) {
		return (List)xstream.fromXML(fileReader);
	}

	private boolean isInconsistent() {
		List feedRecords = feedFinder.findAllFeedRecords();
		if (cachedFeeds.size() != feedRecords.size()) {
			LOG.info("Cache is inconsistent because the number of cached feeds does not match the feed records");
			return true;
		}
		for (Iterator iter = cachedFeeds.iterator(); iter.hasNext();) {
			Feed feed = (Feed) iter.next();
			if (!contains(feedRecords, feed)) {
				LOG.warn("Cache is inconsistent because a cached feed (" + feed + ") has no equivalent in the feed records");
				return true;
			}
		}
		return false;
	}

	private boolean contains(List feedRecords, Feed feed) {
		for (Iterator iter = feedRecords.iterator(); iter.hasNext();) {
			FeedRecord record = (FeedRecord) iter.next();
			if (record.isEquivalent(feed)) {
				return true;
			}
		}
		
//		//FIXME debugging code used to verify cache consistency
//		for (Iterator iter = feedRecords.iterator(); iter.hasNext();) {
//			FeedRecord record = (FeedRecord) iter.next();
//			if (record.getUrl().equals(feed.getUrl())) {
//				LOG.warn("NonMatching Record->" + " id: " + record.getId() + " url: " + record.getUrl() 
//					+ " title: " + record.getTitle() + " etag: " + record.getEtag() + " lastModified: " + record.getLastModified());
//				LOG.warn("NonMatching Feed  ->" + " id: " + feed.getId() + " url: " + feed.getUrl() 
//						+ " title: " + feed.getTitle() + " etag: " + feed.getEtag() + " lastModified: " + feed.getLastModified());
//				Assert.assertEquals(record.getId(), feed.getId());
//				Assert.assertEquals(record.getUrl(), feed.getUrl());
//				Assert.assertEquals(record.getTitle().length(), feed.getTitle().length());
//				Assert.assertEquals(record.getTitle(), feed.getTitle());
//				Assert.assertEquals(record.getEtag(), feed.getEtag());
//				Assert.assertEquals(record.getLastModified(), feed.getLastModified());
//				System.exit(1);
//			}
//		}
		return false;
	}

	public void shutDown() {
		//triple file backup system
		//file -> bak -> old
		//so that if the user starts up the system and realises that they've corrupted the cache
		//they can still recover. It might also form the basis of a disaster recovery feature
		//(e.g people who lose their store for some reason and want to do a new 
		//installatation but carry across all their subscriptions with edited names and scores)
		if (file.exists()) {
			File backUpFile = new File(file.getName() + ".bak");
			File oldestBackUpFile = new File(backUpFile.getName() + ".old");
			
			oldestBackUpFile.delete();
			backUpFile.renameTo(oldestBackUpFile);
			file.renameTo(backUpFile);
		}
		
		FileWriter fileWriter = null;
		try {
			fileWriter = new FileWriter(file);
			xstream.toXML(cachedFeeds, fileWriter);
		} catch (IOException e) {
			LOG.warn("Something went wrong whilst persisting the cache", e);
		} finally {
			IOUtils.close(fileWriter);
		}
	}

}
