package com.oshineye.aggrevator;

import java.util.List;

import org.logicalcobwebs.proxool.ProxoolFacade;

import com.oshineye.aggrevator.components.FeedModel;
import com.oshineye.aggrevator.components.FeedModelImpl;
import com.oshineye.aggrevator.components.ThreadPool;
import com.oshineye.aggrevator.components.ThreadPoolImpl;
import com.oshineye.aggrevator.db.ConnectionPool;
import com.oshineye.aggrevator.db.ConnectionPoolFactory;
import com.oshineye.aggrevator.db.JdbcProcessFactory;
import com.oshineye.aggrevator.store.CachingFeedStore;
import com.oshineye.aggrevator.store.EntryStore;
import com.oshineye.aggrevator.store.FeedIdentityMap;
import com.oshineye.aggrevator.store.FeedStore;
import com.oshineye.aggrevator.store.MySqlEntryStore;
import com.oshineye.aggrevator.store.MySqlFeedStore;
import com.oshineye.aggrevator.util.QueryLoader;

/**
 * @author aoshineye
 */
public class RefreshAllMain {
	public static void main(String[] args) throws Exception {
		String startMessage = "Refreshing all feeds using: " + Constants.APPLICATION_NAME_AND_VERSION_NUMBER;
		System.out.println(startMessage);

		Configuration.load();
		FeedIdentityMap feedIdentityMap = new FeedIdentityMap();
		QueryLoader queryLoader = QueryLoaderFactory.createQueryLoader();
		String databaseName = Configuration.getDatabaseName();
		
		ConnectionPool connectionPool = ConnectionPoolFactory.getConnectionPool(databaseName);
		JdbcProcessFactory processFactory = new JdbcProcessFactory(connectionPool);
		
		FeedStore feedStore = new MySqlFeedStore(processFactory, feedIdentityMap, queryLoader);
		EntryStore entryStore = new MySqlEntryStore(processFactory, feedIdentityMap, queryLoader);
		CachingFeedStore cachingFeedStore = CachingFeedStore.createCachingFeedStore(feedStore, databaseName, feedIdentityMap);
		
		List allFeeds = cachingFeedStore.findAllFeeds();
		FeedModel feedModel = new FeedModelImpl(allFeeds);
		ThreadPool threadPool = new ThreadPoolImpl(cachingFeedStore, entryStore, feedModel);
		threadPool.enqueue(allFeeds);
		threadPool.shutDownAfterProcessingCurrentlyQueuedTasks();
		ProxoolFacade.shutdown(0);
		cachingFeedStore.shutDown();
		System.out.println("Finished refreshing " + allFeeds.size() + " feeds");
	}
}
