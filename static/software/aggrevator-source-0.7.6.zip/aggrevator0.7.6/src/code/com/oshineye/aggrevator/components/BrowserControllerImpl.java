package com.oshineye.aggrevator.components;

import java.util.List;

import com.oshineye.aggrevator.store.EntryStore;

/**
 * @author aoshineye
 */
public class BrowserControllerImpl implements BrowserController {

	private FeedModel feedModel;
	private EntryModel entryModel;
	private EntryStore entryStore;
	private BrowserModel browserModel;

	public BrowserControllerImpl(FeedModel feedModel, EntryModel entryModel, BrowserModel browserModel, EntryStore entryStore) {
		this.feedModel = feedModel;
		this.entryModel = entryModel;
		this.entryStore = entryStore;
		this.browserModel = browserModel;
	}

	public void handleLocationVisited(String locationVisited) {
		browserModel.setLocation(locationVisited);
		if (browserModel.alreadyAtThisLocation(locationVisited)) {
			return;
		}
		
		if (entryStore.markRead(locationVisited)) {
			List relatedFeeds = entryStore.getRelatedFeeds(locationVisited);
			feedModel.entryRead(relatedFeeds);
			entryModel.markRead(locationVisited);
		}
	}

}
