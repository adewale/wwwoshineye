package com.oshineye.aggrevator.util;

import org.eclipse.jface.dialogs.IInputValidator;


public class StringInputValidator implements IInputValidator {
	private String errorMessage;

	public StringInputValidator(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public String isValid(String newText) {
		if (newText.trim().length() == 0 ) {
			return errorMessage;
		}
		return null;
	}
}