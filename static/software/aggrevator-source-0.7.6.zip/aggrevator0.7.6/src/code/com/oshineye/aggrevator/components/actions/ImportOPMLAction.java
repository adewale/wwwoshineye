package com.oshineye.aggrevator.components.actions;

import org.apache.log4j.Logger;
import org.eclipse.jface.action.Action;
import org.eclipse.jface.window.ApplicationWindow;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.FileDialog;

import com.oshineye.aggrevator.components.FeedModel;
import com.oshineye.aggrevator.components.OPMLFileImporter;
import com.oshineye.aggrevator.components.OPMLImporter;
import com.oshineye.aggrevator.components.StatusRecorder;
import com.oshineye.aggrevator.store.FeedStore;
import com.oshineye.aggrevator.util.Summariser;
import com.oshineye.aggrevator.util.SummariserImpl;

/**
 * @author aoshineye
 */
public class ImportOPMLAction extends Action {
	private static final Logger LOG = Logger.getLogger(ImportOPMLAction.class);
	private ApplicationWindow window;
	private FeedStore feedStore;
	private FeedModel feedModel;
	private StatusRecorder recorder;

	public ImportOPMLAction(ApplicationWindow window, FeedStore feedStore, FeedModel feedModel, StatusRecorder recorder) {
		this.window = window;
		this.feedStore = feedStore;
		this.feedModel = feedModel;
		this.recorder = recorder;
		this.setText("&Import OPML File    @Ctrl+O");
	}

	public void run() {
		String fileToImport = getFileToImport();
		if (fileToImport == null) {
			return;
		}

		Summariser summariser = new SummariserImpl();
		OPMLImporter importer = getSubscriptionSet(fileToImport, summariser);
		importer.importFeeds();
		feedModel.appendFeeds(summariser.getNewlyAddedFeeds());
		
		String statusMessage = "Finished import of " + summariser.getStoredFeedsCount() + " out of " 
			+ summariser.getImportedFeedsCount() + " feeds in file: " + fileToImport;
		recorder.setStatus(statusMessage);
	}
	
	protected OPMLImporter getSubscriptionSet(String fileToImport, Summariser summariser) {
		LOG.debug("File to import is: " + fileToImport);
		return new OPMLFileImporter(fileToImport, feedStore, summariser);
	}

	protected String getFileToImport() {
		FileDialog dialog = new FileDialog(window.getShell(), SWT.OPEN);
		dialog.setFilterExtensions(new String[]{"*.opml", "*.*"});
		dialog.setFilterNames(new String[]{"OPML Files (*.opml)", "All Files (*.*)"});
		String fileToImport = dialog.open();
		return fileToImport;
	}
}
