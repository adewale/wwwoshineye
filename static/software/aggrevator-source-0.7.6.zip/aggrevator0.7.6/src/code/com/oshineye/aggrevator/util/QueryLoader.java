package com.oshineye.aggrevator.util;

import java.io.FileNotFoundException;

import org.apache.commons.lang.StringUtils;

import com.oshineye.aggrevator.Configuration;
import com.oshineye.aggrevator.ConfigurationProperties;
import com.oshineye.aggrevator.TunnellingException;

/**
 * @author aoshineye
 *
 */
public class QueryLoader {
	//FIXME this should have the names of all the queries in it as constants
	//this should then be renamed the MySqlQueryLoader and moved into the approperiate
	//package
	private ConfigurationProperties properties;

	public QueryLoader() {
		try {
			this.properties = new ConfigurationProperties("query.properties");
		} catch (FileNotFoundException e) {
			throw new TunnellingException(e);
		}
	}

	public String getQuery(String key) {
		if (queryRequiresAmendment(key) && isLazyLoading()) {
			return amend(properties.getProperty(key));
		}
		return properties.getProperty(key);
	}

	private String amend(String query) {
		return StringUtils.replace(query, "entry.content", "'' as content");
	}

	protected boolean isLazyLoading() {
		return Configuration.isLazyLoading();
	}

	private boolean queryRequiresAmendment(String key) {
		if (key.equals("GET_ENTRIES_IN_FEED") 
			|| key.equals("GET_MULTIPLE_ENTRIES") 
			|| key.equals("GET_MULTIPLE_ENTRIES_IN_FEED")) {
			return true;
		}
		return false;
	}
}
