package com.oshineye.aggrevator.components;

import org.apache.log4j.Logger;

import EDU.oswego.cs.dl.util.concurrent.ThreadedExecutor;

import com.oshineye.aggrevator.Feed;
import com.oshineye.aggrevator.components.commands.worker.background.DeleteFeedCommand;
import com.oshineye.aggrevator.components.commands.worker.background.LoadEntriesForFeedCommand;
import com.oshineye.aggrevator.components.executors.SlottedBackgroundExecutor;
import com.oshineye.aggrevator.components.executors.UserInterfaceExecutor;
import com.oshineye.aggrevator.store.EntryStore;
import com.oshineye.aggrevator.store.FeedStore;

public class FeedViewControllerImpl implements FeedViewController {
	private static final Logger LOG = Logger.getLogger(FeedViewControllerImpl.class);
	private EntryModel entryModel;
	private FeedModel feedModel;
	private FeedStore feedStore;
	private EntryStore entryStore;
	private UserInterfaceExecutor uiExecutor;
	private SlottedBackgroundExecutor slottedBackgroundExecutor;
	private ThreadedExecutor runOnNewThreadExecutor;
	private StatusRecorder recorder;

	public FeedViewControllerImpl(FeedModel feedModel, EntryModel entryModel) {
		this.feedModel = feedModel;
		this.entryModel = entryModel;
	}

	public FeedViewControllerImpl(FeedModel feedModel, EntryModel entryModel, 
			FeedStore feedStore, EntryStore entryStore, SlottedBackgroundExecutor slottedBackgroundExecutor,
			UserInterfaceExecutor uiExecutor, ThreadedExecutor runOnNewThreadExecutor, StatusRecorder recorder) {
		this(feedModel, entryModel);
		
		this.feedStore = feedStore;
		this.entryStore = entryStore;
		this.slottedBackgroundExecutor = slottedBackgroundExecutor;
		this.runOnNewThreadExecutor = runOnNewThreadExecutor;
		this.uiExecutor = uiExecutor;
		this.recorder = recorder;
	}

	public void handleFeedSelected(Feed feed) {
		selectFeed(feed);
		LoadEntriesForFeedCommand command = new LoadEntriesForFeedCommand(feed, entryModel, entryStore, uiExecutor, recorder);
		slottedBackgroundExecutor.executeInBackground(command);
	}

	private void selectFeed(Feed feed) {
		feedModel.select(feed);
		entryModel.clear(feed);
	}

	public void handleFeedDeleted(Feed feed) {
		feedModel.deleteFeed(feed);
		
		//since this is database only we don't care _when_ it happens as long as it happens
		deleteFromStoreOnNewThread(feed);

		entryModel.clear(feed);
		
		if (!feedModel.hasFeedSelected()) {
			return;
		}
		
		Feed selectedFeed = feedModel.getSelectedFeed();
		LoadEntriesForFeedCommand command = new LoadEntriesForFeedCommand(selectedFeed, entryModel, entryStore, uiExecutor, recorder);
		command.run();
	}

	private void deleteFromStoreOnNewThread(Feed feed) {
		DeleteFeedCommand deleteFeed = new DeleteFeedCommand(feed, feedStore, entryStore);
		try {
			runOnNewThreadExecutor.execute(deleteFeed);
		} catch (InterruptedException e) {
			LOG.warn(e.toString());
		}
	}

	public void handleFeedUpdated(Feed selectedFeed, String newFeedTitle, String newFeedUrl) {
		selectedFeed.setTitle(newFeedTitle);
		selectedFeed.setUrl(newFeedUrl);
		feedModel.refreshFeed(selectedFeed);
		feedStore.update(selectedFeed);
	}

}
