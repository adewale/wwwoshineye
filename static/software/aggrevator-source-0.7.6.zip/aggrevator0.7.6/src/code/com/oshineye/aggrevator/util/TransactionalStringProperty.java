package com.oshineye.aggrevator.util;

/**
 * @author aoshineye
 *
 */
public class TransactionalStringProperty {

	private String originalValue;
	private String value;

	public TransactionalStringProperty(String value) {
		this.value = value;
		this.originalValue = value;
	}

	public void setNewValue(String newValue) {
		this.originalValue = value;
		this.value = newValue;
	}

	public void rollBack() {
		value = originalValue;
	}

	public String getValue() {
		return value;
	}

	public String toString() {
		return value;
	}

	public void commit() {
		this.originalValue = value;
	}
}
