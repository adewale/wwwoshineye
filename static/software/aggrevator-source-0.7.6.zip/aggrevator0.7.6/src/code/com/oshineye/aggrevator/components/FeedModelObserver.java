package com.oshineye.aggrevator.components;

import java.util.List;

import com.oshineye.aggrevator.Feed;


public interface FeedModelObserver {

	void notifyFeedAdded(Feed feed);
	
	void notifyFeedsLoaded(List feeds);

	void notifyFeedRefreshed(Feed feed);

	void notifyFeedDeleted(Feed feed, int feedIndex);

}
