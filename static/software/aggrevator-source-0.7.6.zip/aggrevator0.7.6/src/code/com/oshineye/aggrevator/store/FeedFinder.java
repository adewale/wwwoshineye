package com.oshineye.aggrevator.store;

import java.util.List;

/**
 * @author aoshineye
 *
 */
public interface FeedFinder {
	public abstract List findAllFeeds();
	public abstract List findAllFeedRecords();
}
