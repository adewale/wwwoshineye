package com.oshineye.aggrevator.components.executors;

import org.apache.log4j.Logger;

import EDU.oswego.cs.dl.util.concurrent.LinkedQueue;
import EDU.oswego.cs.dl.util.concurrent.PooledExecutor;
import EDU.oswego.cs.dl.util.concurrent.ThreadFactory;

/**
 * @author aoshineye
 * A background executor that guarantees that all the runnables that are queued
 * up on it will be run before it shuts down
 */
public class ReliableBackgroundExecutor {
	private static final Logger LOG = Logger.getLogger(ReliableBackgroundExecutor.class);
	private PooledExecutor executor;
	private LinkedQueue linkedQueue;

	public ReliableBackgroundExecutor() {
		linkedQueue = new LinkedQueue();
		executor = new PooledExecutor(linkedQueue);
		executor.setThreadFactory(new ThreadFactory() {
			public Thread newThread(Runnable runnable) {
				//threads have been given names merely to help with debugging
				Thread thread = new Thread(runnable, "Reliable Background Executor Thread");
				thread.setDaemon(true);
				return thread;
			}
		});
		//threads in pool live forever
		executor.setKeepAliveTime(-1);
		executor.setMinimumPoolSize(1);
		executor.setMaximumPoolSize(1);
		executor.createThreads(1);
	}
	
	public void execute(Runnable runnable) {
		try {
			executor.execute(runnable);
		} catch (InterruptedException e) {
			LOG.warn(e.toString());
		}
	}
	
	public void shutDownAfterProcessingCurrentlyQueuedTasks() {
		executor.shutdownAfterProcessingCurrentlyQueuedTasks();
		try {
			if (linkedQueue.isEmpty()) {
				executor.shutdownNow();
				return;
			}
			executor.awaitTerminationAfterShutdown();
		} catch (InterruptedException e) {
			LOG.warn(e.toString());
		}
	}
}
