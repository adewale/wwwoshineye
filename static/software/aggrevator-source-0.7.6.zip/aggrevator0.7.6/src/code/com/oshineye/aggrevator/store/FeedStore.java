package com.oshineye.aggrevator.store;

import com.oshineye.aggrevator.Feed;

/**
 * @author aoshineye
 *
 */
public interface FeedStore extends FeedFinder {
	public static final String NO_TITLE = "No Title";
	/**
	 * Add the settings for a feed to the entryStore.
	 * Throws an unchecked DuplicateFeedException if this feed's url is already
	 * present in the entryStore.
	 */
	public abstract void add(Feed feed) throws DuplicateFeedException;
	public abstract Feed findFeed(Long id);
	public abstract void delete(Feed feed);
	public abstract void deleteAll();
	public abstract void reconcile(Feed feed);
	public abstract void markRead(Feed feed);
	public abstract boolean urlExists(Feed feed);
	public void update(Feed feed);
}