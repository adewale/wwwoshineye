package com.oshineye.aggrevator.components;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.oshineye.aggrevator.Entry;

/**
 * @author aoshineye
 *
 */
public class BrowserModelImpl implements BrowserModel {
	private List observers;
	private String location;
	private Entry currentEntry;

	public BrowserModelImpl() {
		this.observers = new ArrayList();
	}
	
	public void loadEntry(Entry entry) {
		for (Iterator iter = observers.iterator(); iter.hasNext();) {
			BrowserObserver observer = (BrowserObserver) iter.next();
			observer.notifyEntryLoaded(entry);
		}
		this.currentEntry = entry;
	}

	public void addObserver(BrowserObserver observer) {
		observers.add(observer);
	}

	public void setLocation(String location) {
		if (BrowserModel.ABOUT_BLANK.equals(location)) {
			this.location = currentEntry.getUrl();
			return;
		}
		this.location = location;
	}

	public String getLocation() {
		return location;
	}

	public boolean alreadyAtThisLocation(String locationBeingVisited) {
		if (isVisitingEntryThatHasJustBeenLoaded(locationBeingVisited)) {
			return true;
		}
		return isVisitingLocationOfCurrentEntry(locationBeingVisited);
	}

	private boolean isVisitingLocationOfCurrentEntry(String locationBeingVisited) {
		return currentEntry.getUrl().equals(locationBeingVisited);
	}

	private boolean isVisitingEntryThatHasJustBeenLoaded(String locationBeingVisited) {
		return BrowserModel.ABOUT_BLANK.equals(locationBeingVisited) && currentEntry.isRead();
	}

	public boolean locationCanBeOpened() {
		//there should never be a situation where the currentEntry is null
		//and we want to find out if the location can be opened. However
		//it's a state that this class can be in. It's just a state which the
		//rest of the application should never put this class into.
		if (currentEntry == null || BrowserModel.ABOUT_BLANK.equals(location) || Entry.NO_LINK.equals(location)) {
			return false;
		}
		return true;
	}
}
