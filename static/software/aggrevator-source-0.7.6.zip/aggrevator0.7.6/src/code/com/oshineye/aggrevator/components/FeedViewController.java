package com.oshineye.aggrevator.components;

import com.oshineye.aggrevator.Feed;

public interface FeedViewController {

	void handleFeedSelected(Feed feed);

	void handleFeedDeleted(Feed feed);

	void handleFeedUpdated(Feed selectedFeed, String newFeedTitle, String newFeedUrl);
}
