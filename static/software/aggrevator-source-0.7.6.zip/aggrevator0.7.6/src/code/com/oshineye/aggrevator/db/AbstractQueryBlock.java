package com.oshineye.aggrevator.db;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * @author aoshineye
 * A QueryBlock for use in queries with no parameters.
 */
public abstract class AbstractQueryBlock implements QueryBlock {
	/* (non-Javadoc)
	 * @see com.oshineye.aggrevator.db.JdbcBlock#configure(java.sql.PreparedStatement)
	 */
	public void configure(PreparedStatement stmt) throws SQLException {
		//default implementation that does nothing
	}

	/* (non-Javadoc)
	 * @see com.oshineye.aggrevator.db.QueryBlock#process(java.sql.ResultSet)
	 */
	public Object process(ResultSet rset) throws SQLException {
		return null;
	}
}
