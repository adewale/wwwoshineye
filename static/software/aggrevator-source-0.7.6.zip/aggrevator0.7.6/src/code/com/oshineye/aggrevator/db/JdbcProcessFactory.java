package com.oshineye.aggrevator.db;

import java.sql.Connection;


/**
 * @author aoshineye
 */
public class JdbcProcessFactory {
	private ConnectionPool connectionPool; 

	public JdbcProcessFactory(ConnectionPool connectionPool) {
		this.connectionPool = connectionPool;
	}

	public JdbcProcess createProcess() {
		return new JdbcProcess(getConnection());
	}
	
	public Connection getConnection() {
		return connectionPool.acquireConnection();
	}
}
