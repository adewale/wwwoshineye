package com.oshineye.aggrevator.store.entry;

import java.util.Date;

import com.oshineye.aggrevator.Configuration;
import com.oshineye.aggrevator.Entry;
import com.oshineye.aggrevator.LazyLoadedEntryProperty;

/**
 * @author aoshineye
 *
 */
public class EntryFactory {
	public static Entry createEntryFromStore(long entryId, String title, String content, Date date, String url, String feedTitle, long feedId, boolean read, int score) {
		Long entryIdAsLong = new Long(entryId);
		Long feedIdAsLong = new Long(feedId);
		if (Configuration.isLazyLoading()) {
			//make a lazy entry
			LazyLoadedEntryProperty property = new LazyLoadedEntryProperty(EntryContentServiceFactory.getEntryContentService(), entryIdAsLong);
			return new Entry(entryIdAsLong, title, property, date, url, feedTitle, feedIdAsLong, read, score);
		}
		//make an eager entry
		return new Entry(entryIdAsLong, title, content, date, url, feedTitle, feedIdAsLong, read, score);
	}
}
