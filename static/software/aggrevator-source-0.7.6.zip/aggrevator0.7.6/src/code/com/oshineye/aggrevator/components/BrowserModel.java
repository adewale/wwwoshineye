package com.oshineye.aggrevator.components;

import com.oshineye.aggrevator.Entry;

/**
 * @author aoshineye
 *
 */
public interface BrowserModel {
	public static final String ABOUT_BLANK = "about:blank";

	void loadEntry(Entry entry);

	void addObserver(BrowserObserver observer);

	void setLocation(String location);

	String getLocation();

	boolean alreadyAtThisLocation(String location);

	boolean locationCanBeOpened();
}
