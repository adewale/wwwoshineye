package com.oshineye.aggrevator.components;

import org.eclipse.swt.events.KeyListener;
import org.eclipse.swt.widgets.TableItem;

/**
 * @author aoshineye
 */
public interface FeedView extends FeedModelObserver, ListView, KeyListener {

	TableItem[] getItems();

}
