package com.oshineye.aggrevator;

import com.oshineye.aggrevator.parsing.ParserFactory;

/**
 * @author aoshineye
 * 
 * This class exists because creating a fully valid feed requires a primary key and all
 * FeedImpl constructors should take a primary key.
 * Since access to the primary key requires access to the FeedStore and I don't want
 * to couple the FeedImpl to the Feedstore. Nor do I want to couple clients of the FeedImpl
 * to the FeedStore's primary key generation strategy. Clients of the FeedImpl will use this class instead
 * and receive a Feed (so they need never know about FeedImpl) and this class will act as a facade
 * hiding the FeedStore's primary key generation strategy.
 */
public class FeedFactory {
	public static Feed createFeedFromUrl(String url) {
		return new FeedImpl(url, ParserFactory.createFeedParser(), createLocation(url, null, null));
	}

	public static Feed createFeedFromStore(long id, String url, String title, int unreadEntryCount, int score, String etag, String lastModified) {
		return new FeedImpl(new Long(id), url, title, unreadEntryCount, score, 
			ParserFactory.createFeedParser(), createLocation(url, etag, lastModified));
	}

	public static FeedRecord createFeedRecordFromStore(long id, String url, String title, String etag, String lastModified) {
		return new FeedRecord(new Long(id), url, title, etag, lastModified);
	}
	
	private static HttpLocation createLocation(String locationUrl, String locationEtag, String locationLastModified) {
		return new HttpLocation(locationUrl, locationEtag, locationLastModified);
	}
}
