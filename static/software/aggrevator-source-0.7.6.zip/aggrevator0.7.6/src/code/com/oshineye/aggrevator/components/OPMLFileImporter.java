package com.oshineye.aggrevator.components;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

import nu.xom.Attribute;
import nu.xom.Builder;
import nu.xom.Document;
import nu.xom.Element;
import nu.xom.Elements;
import nu.xom.ParsingException;
import nu.xom.ValidityException;

import org.apache.log4j.Logger;

import com.oshineye.aggrevator.Feed;
import com.oshineye.aggrevator.FeedFactory;
import com.oshineye.aggrevator.store.FeedStore;
import com.oshineye.aggrevator.util.IOUtils;
import com.oshineye.aggrevator.util.Summariser;

/**
 * @author aoshineye
 *
 */
public class OPMLFileImporter implements OPMLImporter {
	private static final Logger LOG = Logger.getLogger(OPMLFileImporter.class);
	/*
	 * Because opml files generated from Microsoft tools place a ByteOrderMark at the 1st character
	 * of the generated file the UTF-8 encoding support in the standard Reader classes can't handle it.
	 * However if we use an InputStream then the encoding support in our XML parser of choice (usually Xerces)
	 * gets to handle it and they can usually handle that kind of weirdness.
	 */
	private String fileName;
	private final FeedStore feedStore;
	private final Summariser summariser;

	public OPMLFileImporter(String fileName, FeedStore feedStore, Summariser summariser) {
		this.fileName = fileName;
		this.feedStore = feedStore;
		this.summariser = summariser;
	}

	public void importFeeds() {
		List urlsIncludingDuplicates = getUrlsIncludingDuplicates();
		String[] urls = getUrlsWithoutDuplicates(urlsIncludingDuplicates);
		
		for (int i = 0; i < urls.length; i++) {
			Feed feed = FeedFactory.createFeedFromUrl(urls[i]);
			summariser.feedImported(feed);
			LOG.debug("Importing " + feed);
			
			if (feedStore.urlExists(feed)) {
				LOG.info(feed + " is already in the entryStore");
				continue;
			}
			
			feedStore.add(feed);
			summariser.feedStored(feed);
		}
	}
	
	private String[] getUrlsWithoutDuplicates(List urlsIncludingDuplicates) {
		Set urlsWithoutDuplicates = new LinkedHashSet(urlsIncludingDuplicates);
		return (String[]) urlsWithoutDuplicates.toArray(new String[0]);
	}

	private List getUrlsIncludingDuplicates() {
		List urls = new ArrayList();
		Builder builder = new Builder(false);
		try {
			InputStream contentStream = getContentStream();
			Document doc = builder.build(contentStream, "");
			Element rootElement = doc.getRootElement();
			Element bodyElement = rootElement.getFirstChildElement("body");
			Elements elements = bodyElement.getChildElements("outline");
			extractUrls(urls, elements);
		} catch (ValidityException e) {
			LOG.warn(e.getMessage(), e);
		} catch (ParsingException e) {
			LOG.warn(e.getMessage(), e);
		} catch (IOException e) {
			LOG.warn(e.getMessage(), e);
		}
		return urls;
	}

	protected InputStream getContentStream() {
		String content = IOUtils.read(fileName);
		return new ByteArrayInputStream(content.getBytes());
	}

	private void extractUrls(List urls, Elements elements) {
		for (int i=0; i<elements.size(); i++) {
			Element outlineElement = elements.get(i);
			if (outlineElement.getChildCount() > 0) {
				extractUrls(urls, outlineElement.getChildElements("outline"));
			}
			Attribute xmlUrlAttribute = outlineElement.getAttribute("xmlUrl");
			if (xmlUrlAttribute == null) {
				continue;
			}
			urls.add(xmlUrlAttribute.getValue());
		}
	}
}
