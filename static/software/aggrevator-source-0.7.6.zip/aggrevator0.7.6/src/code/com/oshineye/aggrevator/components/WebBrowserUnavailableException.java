package com.oshineye.aggrevator.components;

import org.eclipse.swt.SWTError;

/**
 * @author aoshineye
 *
 */
public class WebBrowserUnavailableException extends RuntimeException {
	private SWTError error;
	public WebBrowserUnavailableException(SWTError error) {
		this.error = error;
	}

	public String getMessage() {
		return error.getMessage();
	}
}
