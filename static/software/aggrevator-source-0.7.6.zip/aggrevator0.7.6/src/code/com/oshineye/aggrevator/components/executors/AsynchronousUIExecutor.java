package com.oshineye.aggrevator.components.executors;

import org.apache.log4j.Logger;
import org.eclipse.swt.widgets.Display;

import com.oshineye.aggrevator.components.tasks.Task;

/**
 * @author aoshineye
 *
 * Execute Tasks asynchronously on the SWT UI thread
 */
public class AsynchronousUIExecutor implements UserInterfaceExecutor {
	private static Logger LOG = Logger.getLogger(AsynchronousUIExecutor.class);
	private final Display display;

	public AsynchronousUIExecutor(Display display) {
		this.display = display;
	}
	
	public void execute(Task task) {
		if (display.isDisposed()) {
			LOG.warn("Display is disposed");
			return;
		}
		display.asyncExec(task);
	}

}
