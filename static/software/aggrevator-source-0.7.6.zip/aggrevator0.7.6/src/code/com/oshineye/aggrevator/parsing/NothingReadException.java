package com.oshineye.aggrevator.parsing;

/**
 * @author aoshineye
 */
public class NothingReadException extends RuntimeException {
	//do nothing
}
