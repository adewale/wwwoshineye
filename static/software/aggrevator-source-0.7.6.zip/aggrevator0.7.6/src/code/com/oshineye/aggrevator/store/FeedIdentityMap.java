package com.oshineye.aggrevator.store;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.oshineye.aggrevator.Feed;

/**
 * @author aoshineye
 */
public class FeedIdentityMap {
	private Map urlIdentityMap;
	private Map idIdentityMap;
	private Set allFeeds;
	private boolean populated;
	
	public FeedIdentityMap() {
		this.urlIdentityMap = new LinkedHashMap();
		this.idIdentityMap = new LinkedHashMap();
		this.allFeeds = new LinkedHashSet();
	}

	public void remove(Feed feed) {
		urlIdentityMap.remove(feed.getUrl().toLowerCase());
		idIdentityMap.remove(feed.getId());
		allFeeds.remove(feed);
	}
	
	public List findByIds(List ids) {
		List relatedFeeds = new ArrayList();
		for (Iterator iter = ids.iterator(); iter.hasNext();) {
			Long id = (Long) iter.next();
			if (id != null && idIdentityMap.containsKey(id)) {
				relatedFeeds.add(idIdentityMap.get(id));
			}
		}
		return relatedFeeds;
	}
	
	public Feed findById(Long id) {
		return (Feed) idIdentityMap.get(id);
	}

	public void add(Feed feed) {
		urlIdentityMap.put(feed.getUrl().toLowerCase(), feed);
		idIdentityMap.put(feed.getId(), feed);
		allFeeds.add(feed);
	}

	public void removeAll() {
		urlIdentityMap.clear();
		idIdentityMap.clear();
		allFeeds.clear();
	}

	public boolean isPopulated() {
		return populated;
	}

	public List findAllFeeds() {
		return new ArrayList(allFeeds);
	}

	public void addAll(List feeds) {
		for (Iterator iter = feeds.iterator(); iter.hasNext();) {
			Feed feed = (Feed) iter.next();
			add(feed);
		}
		populated = true;
	}

	public boolean feedExists(String url) {
		return urlExists(url);
	}

	public boolean urlExists(String url) {
		return findFeedByUrl(url) != null;
	}
	
	private Feed findFeedByUrl(String url) {
		return (Feed)urlIdentityMap.get(url.toLowerCase());
	}
}
