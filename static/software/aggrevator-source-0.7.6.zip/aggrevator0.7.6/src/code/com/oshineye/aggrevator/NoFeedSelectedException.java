package com.oshineye.aggrevator;

/**
 * @author aoshineye
 *
 */
public class NoFeedSelectedException extends RuntimeException {
	//do nothing
}
