package com.oshineye.aggrevator.components.actions;

import com.oshineye.aggrevator.components.ComponentLocator;
import com.oshineye.aggrevator.components.ListView;

public class ShowSelectedItemAction extends AbstractWidgetSelectedAction {
		private ComponentLocator componentLocator;
		private Class key;

		public ShowSelectedItemAction(ComponentLocator componentLocator, Class key, String name) {
			this.componentLocator = componentLocator;
			this.key = key;
			this.setText("Show Selected " + name);
		}
		
		public void run() {
			ListView listView = componentLocator.getListView(key);
			listView.showSelectedItem();
		}
	}