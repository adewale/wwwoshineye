package com.oshineye.aggrevator.util;

import org.apache.commons.lang.StringEscapeUtils;

import com.thoughtworks.xstream.XStream;
import com.thoughtworks.xstream.converters.MarshallingContext;
import com.thoughtworks.xstream.converters.UnmarshallingContext;
import com.thoughtworks.xstream.converters.basic.StringConverter;
import com.thoughtworks.xstream.io.HierarchicalStreamReader;
import com.thoughtworks.xstream.io.HierarchicalStreamWriter;
import com.thoughtworks.xstream.io.xml.XppDriver;

/**
 * @author aoshineye
 *
 */
public class XStreamFactory {
	public static XStream createXStream() {
		XStream xstream = new XStream(new XppDriver());
		xstream.registerConverter(new StringConverter() {

			public void marshal(Object object, HierarchicalStreamWriter writer, MarshallingContext context) {
				writer.setValue(StringEscapeUtils.escapeXml(String.valueOf(object)));
			}

			public Object unmarshal(HierarchicalStreamReader reader, UnmarshallingContext context) {
				return StringEscapeUtils.unescapeXml(reader.getValue());
			}
			
		});
		return xstream;
	}
}
