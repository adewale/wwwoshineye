package com.oshineye.aggrevator.components;

import java.util.Comparator;

/**
 * @author aoshineye
 */
public interface SortableModel {
	public 	void sort(Comparator comparator);;
}
