package com.oshineye.aggrevator;

/**
 * @author aoshineye
 *
 */
public interface EntryContentService {
	public String getContent(Long entryId);
}
