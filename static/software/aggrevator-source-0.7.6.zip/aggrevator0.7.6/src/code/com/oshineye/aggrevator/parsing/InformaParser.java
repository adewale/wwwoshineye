package com.oshineye.aggrevator.parsing;

import java.io.IOException;
import java.io.Reader;
import java.net.MalformedURLException;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

import org.apache.log4j.Logger;

import com.oshineye.aggrevator.Entry;
import com.oshineye.aggrevator.InvalidFeedException;

import de.nava.informa.core.ChannelIF;
import de.nava.informa.core.ItemGuidIF;
import de.nava.informa.core.ItemIF;
import de.nava.informa.core.ParseException;
import de.nava.informa.impl.basic.ChannelBuilder;
import de.nava.informa.parsers.FeedParser;

/**
 * @author aoshineye
 *  
 */
public class InformaParser implements Parser {
	private static final Logger LOG = Logger.getLogger(InformaParser.class);

//	these fields should never be serialized or permanently stored
//	as they would duplicate information held elsewhere
	private transient String feedTitle;
	private transient String url;
	
	public InformaParser() {
		//do nothing
	}

	public List fetchNewEntries(Location location, Long feedId) throws InvalidFeedException {
		this.url = location.getUrl();
		ChannelIF fetchedChannel = null;
		try {
			fetchedChannel = fetchChannel(location);
		} catch (NothingReadException e) {
			LOG.warn("Nothing read for: " + url + " Etag: "
					+ location.getEtag() + " Last modified: "
					+ location.getLastModified());
			//for some reason (typically a 404 or socket timeout) nothing could be read
			return Collections.EMPTY_LIST;
		}
		List fetchedEntries = extractEntries(fetchedChannel, feedId);
		LOG.debug("Fetched " + fetchedEntries.size() + " entries from " + url);

		return fetchedEntries;
	}

	private ChannelIF fetchChannel(Location location) throws InvalidFeedException {
		ChannelIF fetchedChannel = null;
		try {
			Reader reader = location.createReader();
			fetchedChannel = FeedParser.parse(new ChannelBuilder(), reader);
			location.commit();
		} catch (SocketTimeoutException e) {
			LOG.warn(url + " : " + e.getMessage());
			//timing out is normal and expected
			throw new NothingReadException();
		} catch (SocketException e) {
			LOG.warn(url + " : " + e.getMessage());
			throw new NothingReadException();
		} catch (IOException e) {
			LOG.warn(url + " : " + e.getMessage(), e);
			throw new InvalidFeedException(e);
		} catch (ParseException e) {
			//Parsing exceptions happen so often that we can't really say
			//they're exceptional. They're not errors but a fact of life.
			throw new InvalidFeedException(url, e);
		} finally {
			if (!location.isCommitted()) {
				location.rollBack();
			}
		}

		setFeedTitle(fetchedChannel.getTitle());

		return fetchedChannel;
	}
	
	private void setFeedTitle(String feedTitle) {
		this.feedTitle = feedTitle;
	}

	public String getCurrentFeedTitle() {
		return feedTitle;
	}

	private List extractEntries(ChannelIF channel, Long feedId) {
		List entries = new ArrayList();
		for (Iterator iter = channel.getItems().iterator(); iter.hasNext();) {
			ItemIF item = (ItemIF) iter.next();

			URL link = createLink(item);

			String description = item.getElementValue("content:encoded");
			if (description == null) {
				description = item.getDescription();
			}

			Entry entry = new Entry(item.getTitle(), description, item.getDate(),
				link, feedTitle, feedId);
			entries.add(entry);
		}
		return entries;
	}

	private URL createLink(ItemIF item) {
		URL link = getLink(item);
		if (link != null) {
			return link;
		}

		ItemGuidIF guid = item.getGuid();
		if (guid == null) {
			//we only get here if the item has no link or GUID!!
			LOG.warn(url + " has an item with no permalink or guid");
			return createUrl(link, Entry.NO_LINK);
		}

		if (guid.isPermaLink()) {
			return createUrl(link, guid.getLocation());
		}

		//we only get here if there's no link and your guid (which exists)
		// isn't a permalink!!
		LOG.warn(url + " has an item with no permalink and the guid: " + guid.getLocation()
				+ " isn't a permalink");
		return link;
	}

	private URL getLink(ItemIF item) {
		String originalLocation = item.getElementValue("feedburner:origLink");
		if (originalLocation != null) {//it's a feedburner feed item
			return createUrl(null, originalLocation);
		}

		URL link = item.getLink();
		return link;
	}

	private URL createUrl(URL defaultLink, String location) {
		try {
			return new URL(location);
		} catch (MalformedURLException e) {
			LOG.warn(e.toString() + " " + "Location: " + location
					+ " was malformed with defaultLink: "
					+ defaultLink);
		}
		return defaultLink;
	}
}
