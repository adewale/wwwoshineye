package com.oshineye.aggrevator.components.actions;

import org.eclipse.jface.dialogs.IInputValidator;
import org.eclipse.jface.dialogs.InputDialog;
import org.eclipse.jface.window.ApplicationWindow;
import org.eclipse.swt.widgets.Shell;

import com.oshineye.aggrevator.components.FeedModel;
import com.oshineye.aggrevator.components.StatusRecorder;
import com.oshineye.aggrevator.store.FeedStore;
import com.oshineye.aggrevator.util.StringInputValidator;

/**
 * @author aoshineye
 *
 */
public abstract class AbstractNewSearchFeedAction extends NewFeedAction {

	public AbstractNewSearchFeedAction(ApplicationWindow window, FeedModel feedModel, FeedStore feedStore, StatusRecorder recorder) {
		super(window, feedModel, feedStore, recorder);
	}

	protected abstract String getSearchFeedType();
	
	protected void initialiseVisibleAttributes() {
		this.setText(getSearchFeedType() + " Feed");
		this.setToolTipText("Add a new " + getSearchFeedType() + " feed");
	}
	
	protected abstract String getUrl(InputDialog input);
	
	protected InputDialog createInputDialog(Shell shell) {
		String initialValue = getClipboardTextIfSuitable(shell);
		String errorMessage = "You need to enter a search term that isn't blank";
		String dialogTitle = "Add New " + getSearchFeedType() + " Feed";
		String message = "Please enter the search term";
		IInputValidator inputValidator = new StringInputValidator(errorMessage);
		InputDialog dialog = new InputDialog(shell, dialogTitle, message, initialValue, inputValidator);
		return dialog;
	}
}
