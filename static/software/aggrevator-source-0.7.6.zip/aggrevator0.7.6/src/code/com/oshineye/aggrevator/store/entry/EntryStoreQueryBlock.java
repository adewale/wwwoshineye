package com.oshineye.aggrevator.store.entry;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.oshineye.aggrevator.Entry;
import com.oshineye.aggrevator.db.AbstractQueryBlock;


public class EntryStoreQueryBlock extends AbstractQueryBlock {
	public Object process(ResultSet rset) throws SQLException {
		List entries = new ArrayList();
		while (rset.next()) {
			Entry entry = createEntry(rset);
			entries.add(entry);
		}
		return entries;
	}

	protected Entry createEntry(ResultSet rset) throws SQLException {
		long entryId = rset.getLong("entry_id");
		String title = rset.getString("title");
		String content = rset.getString("content");
		Date date = new Date(rset.getTimestamp("date_published").getTime());
		String url = rset.getString("perma_link");
		String feedTitle = rset.getString("feed.title");
		long feedId = rset.getLong("feed_id");
		boolean read = rset.getBoolean("is_read");
		int score = rset.getInt("score");

		return EntryFactory.createEntryFromStore(entryId, title, content, date, url, feedTitle, feedId, read, score);
	}
}