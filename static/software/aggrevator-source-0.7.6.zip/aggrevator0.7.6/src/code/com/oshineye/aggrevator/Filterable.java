package com.oshineye.aggrevator;


/**
 * @author aoshineye
 */
public interface Filterable {
	public String getTitle();
	public String getUrl();
}
