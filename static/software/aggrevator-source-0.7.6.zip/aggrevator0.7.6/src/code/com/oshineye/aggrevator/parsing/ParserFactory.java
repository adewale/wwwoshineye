package com.oshineye.aggrevator.parsing;

/**
 * @author aoshineye
 *
 */
public class ParserFactory {
	public static Parser createFeedParser() {
		return new InformaParser();
	}
}
