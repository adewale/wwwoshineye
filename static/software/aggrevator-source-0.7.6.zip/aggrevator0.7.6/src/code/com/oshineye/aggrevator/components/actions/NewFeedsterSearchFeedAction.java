package com.oshineye.aggrevator.components.actions;

import org.eclipse.jface.dialogs.InputDialog;
import org.eclipse.jface.window.ApplicationWindow;

import com.oshineye.aggrevator.components.FeedModel;
import com.oshineye.aggrevator.components.StatusRecorder;
import com.oshineye.aggrevator.store.FeedStore;
import com.oshineye.aggrevator.util.URLUtils;

/**
 * @author aoshineye
 *
 */
public class NewFeedsterSearchFeedAction extends AbstractNewSearchFeedAction {

	public NewFeedsterSearchFeedAction(ApplicationWindow window, FeedModel feedModel, FeedStore feedStore, StatusRecorder recorder) {
		super(window, feedModel, feedStore, recorder);
	}

	protected String getSearchFeedType() {
		return "Feedster";
	}
	
	protected String getUrl(InputDialog input) {
		return URLUtils.generateFeedsterSearchUrl(input.getValue());
	}

}
