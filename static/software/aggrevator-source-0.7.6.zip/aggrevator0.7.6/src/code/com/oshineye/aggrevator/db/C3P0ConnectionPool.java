package com.oshineye.aggrevator.db;

import java.beans.PropertyVetoException;
import java.sql.Connection;
import java.sql.SQLException;

import com.mchange.v2.c3p0.ComboPooledDataSource;
import com.oshineye.aggrevator.TunnellingException;

/**
 * @author aoshineye
 *  
 */
public class C3P0ConnectionPool implements ConnectionPool {
	private ComboPooledDataSource dataSource;

	public C3P0ConnectionPool(String driver, String url, String userName, String passWord, int connectionPoolSize) {
		dataSource = new ComboPooledDataSource();
		try {
			dataSource.setDriverClass(driver);
		} catch (PropertyVetoException e) {
			throw new TunnellingException(e);
		}
		dataSource.setJdbcUrl(url);
		dataSource.setUser(userName);
		dataSource.setPassword(passWord);
		dataSource.setMaxPoolSize(connectionPoolSize);
		dataSource.setMinPoolSize(1);
		dataSource.setInitialPoolSize(1);
		
		//commented out because it's very expensive (according to the c3po documentation)
//		dataSource.setTestConnectionOnCheckout(true);
		
		dataSource.setPreferredTestQuery("select CURRENT_DATE");
		
		//test the idle connections every 60 minutes
		dataSource.setIdleConnectionTestPeriod(3600);
	}

	public Connection acquireConnection() {
		try {
			return dataSource.getConnection();
		} catch (SQLException e) {
			throw new TunnellingException(e);
		}
	}

	public void shutDown() {
		try {
			dataSource.close();
		} catch (SQLException e) {
			throw new TunnellingException(e);
		}
	}

}
