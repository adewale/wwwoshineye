package com.oshineye.aggrevator.components.tasks;

import java.io.IOException;
import java.util.List;
import org.apache.log4j.Logger;

import com.oshineye.aggrevator.Feed;
import com.oshineye.aggrevator.InvalidFeedException;
import com.oshineye.aggrevator.RefreshInProgressException;
import com.oshineye.aggrevator.components.EntryModel;
import com.oshineye.aggrevator.components.FeedModel;
import com.oshineye.aggrevator.store.EntryStore;
import com.oshineye.aggrevator.store.FeedStore;

public class RefreshFeedTask extends Task {
	private static final Logger LOG = Logger.getLogger(RefreshFeedTask.class);
	private Feed feed;
	private FeedStore feedStore;
	private EntryStore entryStore;
	private FeedModel feedModel;
	private EntryModel entryModel;
	
	public RefreshFeedTask(Feed feed, FeedStore feedStore, EntryStore entryStore, FeedModel feedModel, EntryModel entryModel) {
		this.feed = feed;
		this.feedStore = feedStore;
		this.entryStore = entryStore;
		this.feedModel = feedModel;
		this.entryModel = entryModel;
	}

	public void doWork() {
		try {
			//try to acquire a write lock on the feed's refresh state
			startRefresh();
			LOG.debug("Started refreshing: " + feed + " with " + feed.getUnreadEntriesCount() + " unread");
		} catch (RefreshInProgressException e) {
			LOG.warn("Detected refresh already in progress. Aborting refresh.");
			return;
		}
		
		try {
			if (!feed.hasChanged()) {
				LOG.debug(feed + " has not changed");
				return;
			}
			
			List newEntries = feed.fetchNewEntries(entryStore);
			if (newEntries.isEmpty()) {
				LOG.debug("No new entries for: " + feed);
				
				//url, title, etag and lastModified may have changed
				feedStore.update(feed);
				return;
			}
			
			entryStore.addEntries(newEntries);
			feedStore.reconcile(feed);
		} catch (IOException e) {
			LOG.warn("Error whilst checking if: " + feed + " had changed.", e);
			return;
		} catch (InvalidFeedException e) {
			LOG.warn("Error whilst fetching new entries for: " + feed + ". Rolling back.", e);
			feed.rollBack();
			return;
		} finally {
			//release the lock one has on the feed's refresh state
			finishRefresh();
			LOG.debug("Finished refreshing: " + feed + " with " + feed.getUnreadEntriesCount() + " unread");
		}
		
		/*
		 * The possibility exists of a threading problem here
		 * if the user switches their selected feed in between the test and
		 * the action based on the test. That's because another thread can sneak in
		 * between the if and the body of code that's run inside it.
		 * If this becomes a problem we need to decide what we should synchronize on:
		 * the entire section of code or a particular object/class?
		 * 
		 * 
		 * feedA initiates a refresh
		 * feedA isSelected
		 * entryStore.findEntriesInFeed(feedA()) is called and takes a long time
			 * feedB is selected by the user
			 * entryStore.findEntriesInFeed(feedB()) is called and returns quickly
			 * the entryModel is loaded with feedB's entries
		 * entryStore.findEntriesInFeed(feedA()) finished
		 * the entryModel is loaded with feedA's entries
		 * we have an inconsistency/bug
		 * 
		*/
		//FIXME this has happened at least once when the machine is busy/slow
		if (feedModel.isSelected(feed)) {
			List entriesInFeed = entryStore.findEntriesInFeed(feed.getId());
			entryModel.loadEntries(entriesInFeed);
		}
	}

	private void startRefresh() throws RefreshInProgressException {
		feed.setRefreshStarted();
		feedModel.refreshFeed(feed);
	}

	private void finishRefresh() {
		feed.setRefreshFinished();
		feedModel.refreshFeed(feed);
	}

}