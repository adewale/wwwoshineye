package com.oshineye.aggrevator;

import com.oshineye.aggrevator.util.StringUtils;

/**
 * @author aoshineye
 *
 */
public class FeedRecord {
	private final Long id;
	private final String url;
	private final String title;
	private final String etag;
	private final String lastModified;

	public FeedRecord(Long id, String url, String title, String etag, String lastModified) {
		this.id = id;
		this.url = url;
		//assumes title can never be null because it comes from the database
		this.title = StringUtils.unescapeHtml(title);
		this.etag = etag;
		this.lastModified = lastModified;
	}
	
	public Long getId() {
		return id;
	}
	
	public String getTitle() {
		return title;
	}

	public String getUrl() {
		return url;
	}

	public String getEtag() {
		return etag;
	}

	public String getLastModified() {
		return lastModified;
	}

	public boolean isEquivalent(Feed feed) {
		return id.equals(feed.getId()) && url.equals(feed.getUrl())
//			&& title.equals(feed.getTitle())//encoding bug in informa-see commented out test for more data
			&& isEqualEvenWhenNull(etag, feed.getEtag())
			&& isEqualEvenWhenNull(lastModified, feed.getLastModified());
	}
	
	private boolean isEqualEvenWhenNull(String first, String second) {
		if (first == null) {
			return second == null;
		}
		return first.equals(second);
	}
}
