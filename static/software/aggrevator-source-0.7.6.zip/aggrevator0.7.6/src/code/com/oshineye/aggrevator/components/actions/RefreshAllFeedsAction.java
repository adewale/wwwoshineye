package com.oshineye.aggrevator.components.actions;

import org.eclipse.jface.action.Action;
import org.eclipse.jface.resource.ImageDescriptor;

import com.oshineye.aggrevator.components.FeedModel;
import com.oshineye.aggrevator.components.ThreadPool;
import com.oshineye.aggrevator.components.tasks.RefreshAllFeedsTask;
import com.oshineye.aggrevator.components.tasks.Task;


/**
 * @author aoshineye
 */
public class RefreshAllFeedsAction extends Action {
	private ThreadPool threadPool;
	private FeedModel feedModel;

	public RefreshAllFeedsAction(ThreadPool threadPool, FeedModel feedModel) {
		this.threadPool = threadPool;
		this.feedModel = feedModel;
		this.setText("Refresh &All Feeds@Shift+F5");
		this.setToolTipText("Refresh all feeds");
		this.setImageDescriptor(ImageDescriptor.createFromFile(NewFeedAction.class, "/refreshAllFeeds.png"));
	}

	public void run() {
		Task task = new RefreshAllFeedsTask(threadPool, feedModel);
		threadPool.execute(task);
	}

}
