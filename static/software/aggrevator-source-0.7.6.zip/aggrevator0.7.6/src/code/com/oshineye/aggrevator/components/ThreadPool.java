package com.oshineye.aggrevator.components;


/**
 * @author aoshineye
 *  
 */
public interface ThreadPool extends RefreshQueue {
	public abstract void shutDownNow();
	
	public abstract void execute(Runnable task);
	
	public abstract void shutDownAfterProcessingCurrentlyQueuedTasks();
}