package com.oshineye.aggrevator.components;

import org.apache.log4j.Logger;
import org.eclipse.swt.SWT;
import org.eclipse.swt.SWTError;
import org.eclipse.swt.browser.Browser;
import org.eclipse.swt.browser.LocationEvent;
import org.eclipse.swt.browser.WindowEvent;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.widgets.Composite;

import com.oshineye.aggrevator.Entry;

/**
 * @author aoshineye
 *
 */
public class BrowserViewImpl implements BrowserView {
	private static final Logger LOG = Logger.getLogger(BrowserViewImpl.class);
	private Browser browser;
	private BrowserController browserController;

	public BrowserViewImpl(BrowserModel browserModel, BrowserController browserController) {
		browserModel.addObserver(this);
		this.browserController = browserController;
	}

	public BrowserViewImpl(BrowserModel browserModel, Composite parent, BrowserStatusTextListener statusListener, BrowserController browserController) {
		this.browser = createBrowser(parent);
		this.browser.addStatusTextListener(statusListener);
		this.browser.addOpenWindowListener(this);
		this.browser.addLocationListener(this);
		this.browserController = browserController;
		
		browserModel.addObserver(this);
	}
	
	public void notifyEntryLoaded(Entry entry) {
		ContentFormatter cf = new ContentFormatter(entry);
		String content = cf.getFormattedContent();
		browser.setText(content);
	}
	
	private Browser createBrowser(Composite parent) {
		Composite padding = new Composite(parent, SWT.BORDER);
		FillLayout fl = new FillLayout();

		fl.marginWidth = 5;
		fl.marginHeight = 10;
		padding.setLayout(fl);

		try {
			return new Browser(padding, SWT.NONE);
		} catch (SWTError e) {
			LOG.warn("Browser unavailable\n" + e.toString());
			throw new WebBrowserUnavailableException(e);
		}
	}

	public void focus() {
		browser.setFocus();
	}

	public void changing(LocationEvent event) {
		//do nothing as we don't care what the browser is doing
		//but only about when it's finished doing it
	}

	public void changed(LocationEvent event) {
		browserController.handleLocationVisited(event.location);
	}

	public void open(WindowEvent event) {
		//FIXME This is bug: https://bugs.eclipse.org/bugs/show_bug.cgi?id=57068
		//which Eclipse 3.1 M5 is supposed to fix
		//we must implement this interface so that the SWT library will open external windows using the same
		//component that we browse pages with. It doesn't make a great deal of sense but it can be confirmed using
		//the entry at: http://jroller.com/page/aspinei/20041018#using_httpunit_out_of_the
		//the first link to httpunit opens a new window only when we implement the OpenWindowListener interface and
		//invoke the event's browser's getUrl() method. Nothing else works.
		//Furthermore any work we want to get done in this method must be called before getUrl() as this thread seems
		//to be killed after that line.
		String url = getEventUrl(event);
		
		//FIXME this never gets called in the real application
		//which means that urls visited through a new window don't get marked read
		//this is event.browser.getUrl() throws a NullPointerException before we get here
		browserController.handleLocationVisited(url);
	}
	
	protected String getEventUrl(WindowEvent event) {
		return event.browser.getUrl();
	}
}
