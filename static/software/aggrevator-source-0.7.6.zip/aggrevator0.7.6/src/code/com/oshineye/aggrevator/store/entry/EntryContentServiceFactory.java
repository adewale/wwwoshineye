package com.oshineye.aggrevator.store.entry;

import com.oshineye.aggrevator.Configuration;
import com.oshineye.aggrevator.EntryContentService;
import com.oshineye.aggrevator.QueryLoaderFactory;
import com.oshineye.aggrevator.db.ConnectionPool;
import com.oshineye.aggrevator.db.ConnectionPoolFactory;
import com.oshineye.aggrevator.db.JdbcProcessFactory;

/**
 * @author aoshineye
 *
 */
public class EntryContentServiceFactory {

	public static EntryContentService getEntryContentService() {
		ConnectionPool connectionPool = ConnectionPoolFactory.getConnectionPool(Configuration.getDatabaseName());
		JdbcProcessFactory processFactory = new JdbcProcessFactory(connectionPool);
		return new MySqlEntryContentService(processFactory, QueryLoaderFactory.createQueryLoader());
	}

}
