package com.oshineye.aggrevator;

/**
 * @author aoshineye
 *
 */
public class LazyLoadedEntryProperty {

	private final EntryContentService entryContentService;
	private final Long entryId;
	private String value;

	public LazyLoadedEntryProperty(EntryContentService entryContentService, Long entryId) {
		this.entryContentService = entryContentService;
		this.entryId = entryId;
	}

	public String getValue() {
		if (value == null) {
			value = entryContentService.getContent(entryId);
		}
		return value;
	}

}
