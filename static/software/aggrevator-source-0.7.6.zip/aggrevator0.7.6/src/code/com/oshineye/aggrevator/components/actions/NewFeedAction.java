package com.oshineye.aggrevator.components.actions;

import org.apache.log4j.Logger;
import org.eclipse.jface.action.Action;
import org.eclipse.jface.dialogs.IInputValidator;
import org.eclipse.jface.dialogs.InputDialog;
import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.jface.window.ApplicationWindow;
import org.eclipse.swt.dnd.Clipboard;
import org.eclipse.swt.dnd.TextTransfer;
import org.eclipse.swt.widgets.Shell;

import com.oshineye.aggrevator.Feed;
import com.oshineye.aggrevator.FeedFactory;
import com.oshineye.aggrevator.components.FeedModel;
import com.oshineye.aggrevator.components.StatusRecorder;
import com.oshineye.aggrevator.store.FeedStore;
import com.oshineye.aggrevator.util.StringInputValidator;

/**
 * @author aoshineye
 */
public class NewFeedAction extends Action {
	private static final Logger LOG = Logger.getLogger(NewFeedAction.class);
	private ApplicationWindow window;
	private FeedModel feedModel;
	private FeedStore feedStore;
	private StatusRecorder recorder;

	public NewFeedAction(ApplicationWindow window, FeedModel feedModel, FeedStore feedStore, StatusRecorder recorder) {
		this.window = window;
		this.feedModel = feedModel;
		this.feedStore = feedStore;
		this.recorder = recorder;
		
		initialiseVisibleAttributes();
	}
	
	protected void initialiseVisibleAttributes() {
		this.setText("&Feed@Ctrl+N");
		this.setToolTipText("Add a new feed");
		this.setImageDescriptor(ImageDescriptor.createFromFile(NewFeedAction.class, "/newFeed.png"));
	}

	public void run() {
		Shell shell = window.getShell();
		InputDialog input = createInputDialog(shell);
		int result = input.open();
		if (result == InputDialog.CANCEL) {
			return;
		}
		
		String feedUrl = getUrl(input);
		
		Feed feed = FeedFactory.createFeedFromUrl(feedUrl);
		if (feedModel.contains(feed)) {
			String message = feed + " is a duplicate feed";
			LOG.warn(message);
			recorder.setStatus(message);
			return;
		}
		
		feedStore.add(feed);
		feedModel.addFeed(feed);
		
		recorder.setStatus("Added " + feedUrl);
	}
	
	protected InputDialog createInputDialog(Shell shell) {
		String initialValue = getClipboardTextIfSuitable(shell);
		String errorMessage = "You need to enter a valid url for the feed";
		String dialogTitle = "Add New Feed";
		String message = "Please enter the url of the new feed";
		IInputValidator inputValidator = new StringInputValidator(errorMessage);
		InputDialog dialog = new InputDialog(shell, dialogTitle, message, initialValue, inputValidator);
		return dialog;
	}
	
	protected String getUrl(InputDialog input) {
		return input.getValue();
	}

	protected String getClipboardTextIfSuitable(Shell shell) {
		String text = "";
		Clipboard clipBoard  = new Clipboard(shell.getDisplay());
		TextTransfer textTransfer = TextTransfer.getInstance();
	    String textData = (String)clipBoard.getContents(textTransfer);
	    if (textData != null) {
	    	text = textData;
	    }
	    clipBoard.dispose();
	    return text;
	}
}
