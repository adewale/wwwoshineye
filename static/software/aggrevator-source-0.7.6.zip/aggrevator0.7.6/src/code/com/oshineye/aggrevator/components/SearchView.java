package com.oshineye.aggrevator.components;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.KeyEvent;
import org.eclipse.swt.events.KeyListener;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.TabFolder;
import org.eclipse.swt.widgets.TabItem;
import org.eclipse.swt.widgets.Text;

import com.oshineye.aggrevator.store.SearchSpecification;

/**
 * @author aoshineye
 *
 */
public class SearchView implements KeyListener, SelectionListener {
	private static final int ENTER_KEY = 13;
	private Text titleContainsInput;
	private Text contentContainsInput;
	private Text feedTitleContainsInput;
	private SearchController searchController;
	private SearchSpecification searchSpecification;


	public SearchView(TabFolder tabFolder, SearchSpecification searchSpecification, SearchController searchController) {
		this.searchSpecification = searchSpecification;
		
		Group searchTermsGroup = new Group(tabFolder, SWT.NONE);
		searchTermsGroup.setText("Describe what you are looking for");
		GridLayout layout = new GridLayout();
		layout.numColumns = 2;
		searchTermsGroup.setLayout(layout);
		
		createLabel(searchTermsGroup, "Title contains: ");
		this.titleContainsInput = createHorizontallyFilledText(searchTermsGroup);
		
		createLabel(searchTermsGroup, "Content contains: ");
		this.contentContainsInput = createHorizontallyFilledText(searchTermsGroup);
		
		createLabel(searchTermsGroup, "Feed title contains: ");
		this.feedTitleContainsInput = createHorizontallyFilledText(searchTermsGroup);
		
		createLabel(searchTermsGroup, "");
		Button searchButton = new Button(searchTermsGroup, SWT.PUSH|SWT.CENTER);
		searchButton.setText("     Search     ");
		searchButton.addSelectionListener(this);
		searchButton.setLayoutData(new GridData(GridData.HORIZONTAL_ALIGN_END));
		
		TabItem searchTab = new TabItem(tabFolder, SWT.NULL);
		searchTab.setControl(searchTermsGroup);
		searchTab.setText("Search");
		
		this.searchController = searchController;
	}

	public void keyReleased(KeyEvent e) {
		if (e.keyCode == ENTER_KEY) {
			search();
		}
	}

	private void search() {
		searchSpecification.clear();
		searchSpecification.setTitleField(titleContainsInput.getText());
		searchSpecification.setContentField(contentContainsInput.getText());
		searchSpecification.setFeedTitleField(feedTitleContainsInput.getText());
		searchController.handleSearch();
	}

	public void keyPressed(KeyEvent e) {
		//do nothing
	}
	
	public Label createLabel(Group group, String title) {
		Label label = new Label(group, SWT.NONE);
		label.setText(title);
		return label;
	}
	
	public Text createHorizontallyFilledText(Group group) {
		Text text = new Text(group, SWT.BORDER);
		text.setLayoutData(new GridData(GridData.GRAB_HORIZONTAL | GridData.HORIZONTAL_ALIGN_FILL));
		text.addKeyListener(this);
		return text;
	}

	public void widgetSelected(SelectionEvent e) {
		search();
	}

	public void widgetDefaultSelected(SelectionEvent e) {
		//do nothing
	}

}
