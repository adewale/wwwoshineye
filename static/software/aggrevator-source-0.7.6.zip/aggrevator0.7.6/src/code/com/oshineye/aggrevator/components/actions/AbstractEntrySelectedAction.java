package com.oshineye.aggrevator.components.actions;

import java.util.List;

import org.eclipse.swt.events.SelectionEvent;

import com.oshineye.aggrevator.components.EntryModel;
import com.oshineye.aggrevator.components.FeedModel;

/**
 * @author aoshineye
 * 
 * An Action that is only enabled when an entry is selected.
 */
public abstract class AbstractEntrySelectedAction extends AbstractWidgetSelectedAction {
	private FeedModel feedModel;
	private EntryModel entryModel;
	
	public AbstractEntrySelectedAction(FeedModel feedModel, EntryModel entryModel) {
		this.feedModel = feedModel;
		this.entryModel = entryModel;
	}

	public void widgetSelected(SelectionEvent e) {
		this.setEnabled(entryModel.entrySelected());
	}
	
	protected EntryModel getEntryModel() {
		return entryModel;
	}
	
	protected FeedModel getFeedModel() {
		return feedModel;
	}
	
	protected void refresh(List feeds) {
		feedModel.refreshFeeds(feeds);
	}
}
