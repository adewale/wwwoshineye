package com.oshineye.aggrevator.db;

import com.oshineye.aggrevator.Configuration;
import com.oshineye.aggrevator.TunnellingException;

/**
 * @author aoshineye
 *
 */
public class ConnectionPoolFactory {
	private static ConnectionPool SINGLETON_CONNECTION_POOL = null;
	private static String currentDatabaseName = null;
	public static synchronized ConnectionPool getConnectionPool(String databaseName) {
		if (SINGLETON_CONNECTION_POOL == null) {
			SINGLETON_CONNECTION_POOL = createConnectionPool(databaseName);
			currentDatabaseName = databaseName;
		} else {
			if (currentDatabaseName != null && !currentDatabaseName.equals(databaseName)) {
				String errorMessage = "Attempted to create a second connection pool. Current database name: " 
					+ currentDatabaseName + " New database name: " + databaseName;
				throw new TunnellingException(errorMessage);
			}
		}
		return SINGLETON_CONNECTION_POOL;
	}
	
	private static ConnectionPool createConnectionPool(String databaseName) {
		String driver = "org.gjt.mm.mysql.Driver";
		String url = Configuration.getDatabaseServer() + databaseName;
		String userName = Configuration.getUserName();
		String passWord = Configuration.getPassword();
		
		//there should be enough connections if the entire http pool is busy and
		//the user initiates other work on new threads so 20 extra 
		//connections can be created to provide breathing room
		int connectionPoolSize = Configuration.getNumberOfThreadsInPool() + 20;
		return new ProxoolConnectionPool(driver, url, userName, passWord, connectionPoolSize);
//		return new C3P0ConnectionPool(driver, url, userName, passWord, connectionPoolSize);
	}
}
