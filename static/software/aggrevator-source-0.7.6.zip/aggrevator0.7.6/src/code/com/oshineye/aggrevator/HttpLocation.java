package com.oshineye.aggrevator;

import java.io.IOException;
import java.io.Reader;
import java.io.StringReader;
import java.util.zip.GZIPInputStream;

import org.apache.commons.httpclient.Header;
import org.apache.commons.httpclient.HostConfiguration;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpMethod;
import org.apache.commons.httpclient.HttpStatus;
import org.apache.commons.httpclient.ProxyHost;
import org.apache.commons.httpclient.methods.GetMethod;
import org.apache.commons.httpclient.methods.HeadMethod;
import org.apache.commons.httpclient.params.HttpClientParams;
import org.apache.log4j.Logger;

import com.oshineye.aggrevator.parsing.Location;
import com.oshineye.aggrevator.parsing.NothingReadException;
import com.oshineye.aggrevator.util.IOUtils;
import com.oshineye.aggrevator.util.TransactionalStringProperty;


/**
 * @author aoshineye
 *
 */
public class HttpLocation implements Location {
	private static final Logger LOG = Logger.getLogger(HttpLocation.class);
	private TransactionalStringProperty urlProperty;
	private TransactionalStringProperty etagProperty;
	private TransactionalStringProperty lastModifiedProperty;
	private boolean committed;
	
	public HttpLocation(String url, String etag, String lastModified) {
		if ((null == url) || ((url = url.trim()).equals(""))) {
			throw new InvalidUrlException("Attempted to create location with an invalid url: " + url);
		}
		this.urlProperty = new TransactionalStringProperty(normalise(url));
		this.etagProperty = new TransactionalStringProperty(etag);
		this.lastModifiedProperty = new TransactionalStringProperty(lastModified);
	}
	
	private String normalise(String unNormalisedUrl) {
		if (unNormalisedUrl.startsWith("feed://")) {
			return "http://" + unNormalisedUrl.substring("feed://".length());
		}
		if (unNormalisedUrl.startsWith("feed:")) {
			return unNormalisedUrl.substring("feed:".length());
		}
		return unNormalisedUrl;
	}
	
	public Reader createReader() throws IOException {
		HttpClient client = createHttpClient();
		HttpMethod method = createGetMethod();
		try {
			method.setFollowRedirects(true);
			method.setRequestHeader("Accept-encoding", "gzip");
			
			int statusCode = client.executeMethod(method);
			if (statusCode == HttpStatus.SC_NOT_FOUND) {//handle 404
				LOG.warn("Requested urlProperty: " + urlProperty + " can not be found");
				throw new NothingReadException();
			}
			
			if (statusCode == HttpStatus.SC_MOVED_PERMANENTLY) {
				Header responseHeader = method.getResponseHeader("location");
				String newUrl = responseHeader.getValue();
				LOG.info("Changing urlProperty from: " + urlProperty + " to: " + newUrl);
				setUrl(newUrl);
				return getReaderWithoutFollowingRedirects();
			}
			
			LOG.debug("Requested urlProperty: " + urlProperty + " and status code was: " + statusCode);
			return getReader(method);
		} finally {
			LOG.debug("Retrieved content for: " + urlProperty);
			method.releaseConnection();
			LOG.debug("Released connection for: " + urlProperty);
		}
	}

	public boolean hasBeenModified() throws IOException {
	    //servers that don't support both of these standards should be treated as always having new content
	    if (etagProperty.getValue() == null && lastModifiedProperty.getValue() == null) {
	        return true;
	    }
		HttpClient client = createHttpClient();
		HttpMethod method = createHeadMethod();
		
		method.setRequestHeader("Accept-encoding", "gzip");
		method.setRequestHeader("If-None-Match", etagProperty.getValue());
		method.setRequestHeader("If-Modified-Since", lastModifiedProperty.getValue());
		int statusCode = client.executeMethod(method);
		return (statusCode != HttpStatus.SC_NOT_MODIFIED);
	}

	private String getGzippedContent(HttpMethod method) throws IOException {
		LOG.debug(this.toString() + " is being retrieved as gzipped content");
		GZIPInputStream stream = new GZIPInputStream(method.getResponseBodyAsStream());
		return IOUtils.read(stream);
	}
	
	private Reader getReader(HttpMethod method) throws IOException {
		updateStatus(method);
		
		Header responseHeader = method.getResponseHeader("content-encoding");
		
		if (responseHeader == null) {
			return getStringReader(method, method.getResponseBodyAsString());
		}
		return getStringReader(method, getGzippedContent(method));
	}
	
	private HttpClient createHttpClient() {
		HttpClientParams params = new HttpClientParams();
		params.setSoTimeout(Configuration.getHttpTimeoutInMilliseconds());
		HttpClient client = new HttpClient(params);

		ProxyHost proxyHost = Configuration.getProxyHost();
		if (proxyHost != null) {
			HostConfiguration configuration = new HostConfiguration();
			configuration.setProxyHost(proxyHost);
			client.setHostConfiguration(configuration);
		}
		return client;
	}
	
	private Reader getReaderWithoutFollowingRedirects() throws IOException {
		HttpClient client = createHttpClient();//time in milliseconds
		HttpMethod method = createGetMethod();
		try {
			setUserAgent(method);
			method.setRequestHeader("Accept-encoding", "gzip");
			
			int statusCode = client.executeMethod(method);
			
			LOG.debug("Requested urlProperty: " + urlProperty + " and status code was: " + statusCode);
			return getReader(method);
		} finally {
			LOG.debug("Retrieved content for: " + urlProperty);
			method.releaseConnection();
			LOG.debug("Released connection for: " + urlProperty);
		}
	}
	
	private void updateStatus(HttpMethod method) {
		//we assume that httpclient will do the right thing should there be more
		//than 1 etagProperty or last modified header returned by a client
		LOG.debug(this + " values were-> etagProperty: " + etagProperty + " lastModifiedProperty: " + lastModifiedProperty);
		
		Header etagHeader = method.getResponseHeader("ETag");
		if (etagHeader != null) {
			etagProperty.setNewValue(etagHeader.getValue());
		}
		Header lastModifiedHeader = method.getResponseHeader("Last-Modified");
		if (lastModifiedHeader != null) {
			lastModifiedProperty.setNewValue(lastModifiedHeader.getValue());
		}
		
		LOG.debug(this + " values are now-> etagProperty: " + etagProperty + " lastModifiedProperty: " + lastModifiedProperty);
	}
	
	private GetMethod createGetMethod() {
		GetMethod method = new GetMethod(urlProperty.getValue());
		setUserAgent(method);
		return method;
	}
	
	private void setUserAgent(HttpMethod method) {
		method.setRequestHeader("User-Agent", Constants.APPLICATION_NAME + "/" + Constants.VERSION_NUMBER);
	}
	
	private Reader getStringReader(HttpMethod method, String result) {
		if (result == null) {//when the connection times out then the result is null
			throw new NothingReadException();
		}
		return new StringReader(result);
	}

	private HeadMethod createHeadMethod() {
		HeadMethod method = new HeadMethod(urlProperty.getValue());
		setUserAgent(method);
		return method;
	}

	public String getLastModified() {
		return lastModifiedProperty.getValue();
	}

	public String getEtag() {
		return etagProperty.getValue();
	}

	public void setUrl(String url) {
		this.urlProperty.setNewValue(url);
	}

	public String getUrl() {
		return urlProperty.getValue();
	}

	public void commit() {
		this.committed = true;
		urlProperty.commit();
		etagProperty.commit();
		lastModifiedProperty.commit();
	}

	public boolean isCommitted() {
		return committed;
	}
	
	public void rollBack() {
		urlProperty.rollBack();
		etagProperty.rollBack();
		lastModifiedProperty.rollBack();
		committed = false;
	}
}
