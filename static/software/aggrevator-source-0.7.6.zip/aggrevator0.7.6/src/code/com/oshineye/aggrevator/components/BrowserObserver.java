package com.oshineye.aggrevator.components;

import com.oshineye.aggrevator.Entry;

/**
 * @author aoshineye
 *
 */
public interface BrowserObserver {

	void notifyEntryLoaded(Entry entry);
}
