package com.oshineye.aggrevator.components.tasks;

import org.apache.log4j.Logger;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Table;

import com.oshineye.aggrevator.util.ThreadingUtils;

/**
 * @author aoshineye
 * 
 * A task is a runnable that cleans up after itself. In other words it doesn't throw RuntimeExceptions.
 * This is needed because throwing RuntimeExceptions in Runnables that are being asynchronously executed 
 * causes the SWT event queue to hang. This prevents the application from shutting down.
 * Tasks also respect the current state of the application. So a task will not attempt to do any work
 * if the Display has been disposed because that means the application is shutting down.
 * 
 * It is one of our architectural principles that we never use Runnables that get passed to asyncExec or syncExec.
 * Admittedly this is only really needed for asyncExec but the consistency benefit of doing things one way make it
 * worthwhile.
 */
public abstract class Task implements Runnable {
	private static final Logger LOG = Logger.getLogger(Task.class);
	public final void run() {
		try {
			Display display = Display.getCurrent();
			if (ThreadingUtils.inUIThread() && display.isDisposed()) {
				return;
			}
			
			doWork();
		} catch (RuntimeException e) {
			if (LOG.isDebugEnabled()) {
				LOG.debug(e.getMessage(), e);
			} else {
				LOG.warn(e.getMessage(), e);
			}			
		}
	}

	public abstract void doWork();
	
	protected void selectTableItem(Table table, int index) {
	    table.select(index);
		table.setSelection(index);
		table.showSelection();
	}
}
