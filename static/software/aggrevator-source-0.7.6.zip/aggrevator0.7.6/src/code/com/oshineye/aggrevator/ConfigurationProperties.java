package com.oshineye.aggrevator;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import org.apache.log4j.Logger;

/**
 * @author aoshineye
 *
 */
public class ConfigurationProperties {
	private static final Logger LOG = Logger.getLogger(ConfigurationProperties.class);
	private Properties properties;

	public ConfigurationProperties(String fileName) throws FileNotFoundException {
		File propertyFile = new File(fileName);
		this.properties = new Properties();
		if (!propertyFile.exists()) {
			throw new FileNotFoundException("File: " + fileName + " was not found");
		}

		try {
			properties.load(new FileInputStream(propertyFile));
		} catch (FileNotFoundException e) {
			LOG.warn(e.getMessage(), e);
		} catch (IOException e) {
			LOG.warn(e.getMessage(), e);
		}
	}

	public String getProperty(String key) {
		return properties.getProperty(key);
	}

	public String getProperty(String key, String defaultValue) {
		return properties.getProperty(key, defaultValue);
	}

}
