package com.oshineye.aggrevator.components;

import java.util.List;

/**
 * @author aoshineye
 */
public interface FilterableModel {

	public List getItems();

	public void loadMatchingItems(String searchText);
}
