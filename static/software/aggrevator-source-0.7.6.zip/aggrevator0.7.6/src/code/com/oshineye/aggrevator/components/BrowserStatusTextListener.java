package com.oshineye.aggrevator.components;

import org.eclipse.jface.action.StatusLineManager;
import org.eclipse.swt.browser.StatusTextEvent;
import org.eclipse.swt.browser.StatusTextListener;

public class BrowserStatusTextListener implements StatusTextListener {
	private StatusLineManager statusLineManager;

	public BrowserStatusTextListener(StatusLineManager statusLineManager) {
		this.statusLineManager = statusLineManager;
	}

	public void changed(StatusTextEvent event) {
		setStatus(event.text);
	}

	private void setStatus(String text) {
		statusLineManager.setMessage(text);
	}

	public void changed(String text) {
		setStatus(text);
	}
}