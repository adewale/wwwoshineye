package com.oshineye.aggrevator.components;

import com.oshineye.aggrevator.Entry;
import com.oshineye.aggrevator.components.commands.worker.background.MarkEntryReadCommand;
import com.oshineye.aggrevator.components.executors.ReliableBackgroundExecutor;
import com.oshineye.aggrevator.components.executors.UserInterfaceExecutor;
import com.oshineye.aggrevator.store.EntryStore;

/**
 * @author aoshineye
 *
 */
public class EntryViewControllerImpl implements EntryViewController {
	private BrowserModel browserModel;
	private EntryStore entryStore;
	private FeedModel feedModel;
	private EntryModel entryModel;
	private final UserInterfaceExecutor uiExecutor;
	private final ReliableBackgroundExecutor reliableBackgroundExecutor;

	public EntryViewControllerImpl(FeedModel feedModel, EntryModel entryModel, BrowserModel browserModel, 
		EntryStore entryStore, ReliableBackgroundExecutor reliableBackgroundExecutor, UserInterfaceExecutor uiExecutor) {
		this.feedModel = feedModel;
		this.entryModel = entryModel;
		this.browserModel = browserModel;
		this.entryStore = entryStore;
		this.reliableBackgroundExecutor = reliableBackgroundExecutor;
		this.uiExecutor = uiExecutor;
	}

	public void handleEntrySelected(Entry entry) {
		entryModel.select(entry);
		browserModel.loadEntry(entry);

		if (entry.isRead()) {
			return;
		}
		
		MarkEntryReadCommand command = new MarkEntryReadCommand(entry, feedModel, entryStore, entryModel, uiExecutor);
		reliableBackgroundExecutor.execute(command);
	}
}
