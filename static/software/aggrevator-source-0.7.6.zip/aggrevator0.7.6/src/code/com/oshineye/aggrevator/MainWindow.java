package com.oshineye.aggrevator;

import org.apache.log4j.Logger;
import org.eclipse.jface.action.Action;
import org.eclipse.jface.action.MenuManager;
import org.eclipse.jface.action.Separator;
import org.eclipse.jface.action.StatusLineManager;
import org.eclipse.jface.action.ToolBarManager;
import org.eclipse.jface.window.ApplicationWindow;
import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.SashForm;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.layout.RowData;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.TabFolder;
import org.eclipse.swt.widgets.TabItem;
import org.eclipse.swt.widgets.Text;

import EDU.oswego.cs.dl.util.concurrent.ThreadedExecutor;

import com.oshineye.aggrevator.components.ApplicationWindowStatusRecorder;
import com.oshineye.aggrevator.components.BrowserController;
import com.oshineye.aggrevator.components.BrowserControllerImpl;
import com.oshineye.aggrevator.components.BrowserModel;
import com.oshineye.aggrevator.components.BrowserModelImpl;
import com.oshineye.aggrevator.components.BrowserStatusTextListener;
import com.oshineye.aggrevator.components.BrowserView;
import com.oshineye.aggrevator.components.BrowserViewImpl;
import com.oshineye.aggrevator.components.ComponentLocator;
import com.oshineye.aggrevator.components.EntryModel;
import com.oshineye.aggrevator.components.EntryModelImpl;
import com.oshineye.aggrevator.components.EntryView;
import com.oshineye.aggrevator.components.EntryViewController;
import com.oshineye.aggrevator.components.EntryViewControllerImpl;
import com.oshineye.aggrevator.components.EntryViewImpl;
import com.oshineye.aggrevator.components.FeedModel;
import com.oshineye.aggrevator.components.FeedModelImpl;
import com.oshineye.aggrevator.components.FeedView;
import com.oshineye.aggrevator.components.FeedViewController;
import com.oshineye.aggrevator.components.FeedViewControllerImpl;
import com.oshineye.aggrevator.components.FeedViewImpl;
import com.oshineye.aggrevator.components.Filter;
import com.oshineye.aggrevator.components.FilterableModel;
import com.oshineye.aggrevator.components.SearchController;
import com.oshineye.aggrevator.components.SearchView;
import com.oshineye.aggrevator.components.StatusRecorder;
import com.oshineye.aggrevator.components.ThreadPool;
import com.oshineye.aggrevator.components.ThreadPoolImpl;
import com.oshineye.aggrevator.components.WorkerThreadStatusRecorder;
import com.oshineye.aggrevator.components.actions.AbstractEntrySelectedAction;
import com.oshineye.aggrevator.components.actions.AbstractWidgetSelectedAction;
import com.oshineye.aggrevator.components.actions.BrowserViewFocusAction;
import com.oshineye.aggrevator.components.actions.EntryViewFocusAction;
import com.oshineye.aggrevator.components.actions.ExitAction;
import com.oshineye.aggrevator.components.actions.ExportOPMLAction;
import com.oshineye.aggrevator.components.actions.FeedViewFocusAction;
import com.oshineye.aggrevator.components.actions.ImportOPMLAction;
import com.oshineye.aggrevator.components.actions.LessLikeThisAction;
import com.oshineye.aggrevator.components.actions.MarkFeedReadAction;
import com.oshineye.aggrevator.components.actions.MoreLikeThisAction;
import com.oshineye.aggrevator.components.actions.NewBlogDiggerSearchFeedAction;
import com.oshineye.aggrevator.components.actions.NewFeedAction;
import com.oshineye.aggrevator.components.actions.NewFeedsterSearchFeedAction;
import com.oshineye.aggrevator.components.actions.OpenCurrentLocationAction;
import com.oshineye.aggrevator.components.actions.OpenSelectedEntryAction;
import com.oshineye.aggrevator.components.actions.RefreshAllFeedsAction;
import com.oshineye.aggrevator.components.actions.RefreshFeedAction;
import com.oshineye.aggrevator.components.actions.ShowSelectedEntryAction;
import com.oshineye.aggrevator.components.actions.ShowSelectedFeedAction;
import com.oshineye.aggrevator.components.executors.AsynchronousUIExecutor;
import com.oshineye.aggrevator.components.executors.ReliableBackgroundExecutor;
import com.oshineye.aggrevator.components.executors.SlottedBackgroundExecutor;
import com.oshineye.aggrevator.components.executors.UserInterfaceExecutor;
import com.oshineye.aggrevator.db.ConnectionPool;
import com.oshineye.aggrevator.store.EntryStore;
import com.oshineye.aggrevator.store.FeedStore;
import com.oshineye.aggrevator.store.SearchSpecification;

public class MainWindow extends ApplicationWindow {
	private static final Logger LOG = Logger.getLogger(MainWindow.class);
	private static final int[] RATIO_OF_FILTER_TO_PANEL = new int[]{1, 8};
	private static final int[] RATIO_OF_LEFT_TO_RIGHT_PANEL = new int[]{40,60};
	
	private ThreadPool threadPool;
	private ThreadedExecutor runOnNewThreadExecutor;

	private StatusLineManager statusLineManager;
	
	private ConnectionPool connectionPool;
	private FeedStore feedStore;
	private EntryStore entryStore;
	
	private BrowserModel browserModel;
	private EntryModel entryModel;
	private FeedModel feedModel;
	private FeedView feedView;
	private EntryView entryView;
	private BrowserView browserView;
	
	private Action exitAction;
	private Action importAction;
	private Action newFeedAction;
	private Action newFeedsterSearchFeedAction;
	private Action newBlogDiggerSearchFeedAction;
	private Action refreshAllFeedsAction;
	private RefreshFeedAction refreshFeedAction;
	private Action exportAction;
	private AbstractEntrySelectedAction moreLikeThisAction;
	private AbstractEntrySelectedAction lessLikeThisAction;
	private Action focusOnFeedViewAction;
	private Action focusOnEntryViewAction;
	private Action focusOnBrowserViewAction;
	private AbstractWidgetSelectedAction markFeedReadAction;
	private AbstractWidgetSelectedAction showSelectedFeedAction;
	private AbstractEntrySelectedAction showSelectedEntryAction;
	private AbstractEntrySelectedAction openSelectedEntryInExternalBrowserAction;
	private AbstractEntrySelectedAction openCurrentLocationInExternalBrowserAction;
	private ComponentLocator componentLocator;
	private StatusRecorder recorder;
	private SlottedBackgroundExecutor slottedBackgroundExecutor;
	private ReliableBackgroundExecutor reliableBackgroundExecutor;
	
	public MainWindow(ConnectionPool connectionPool, FeedStore feedStore, EntryStore entryStore) {
		super(null);
		this.connectionPool = connectionPool;

		this.feedStore = feedStore;
		this.entryStore = entryStore;

		this.browserModel = new BrowserModelImpl();
		this.entryModel = new EntryModelImpl();
		this.feedModel = new FeedModelImpl(feedStore.findAllFeeds());
		
		//this does not have to be shutdown as it doesn't maintain a pool
		this.runOnNewThreadExecutor = new ThreadedExecutor();
		
		//these have to be shutdown
		this.threadPool = new ThreadPoolImpl(feedStore, entryStore, feedModel, entryModel);
		slottedBackgroundExecutor = new SlottedBackgroundExecutor();
		
		recorder = new ApplicationWindowStatusRecorder(this);
		this.importAction = new ImportOPMLAction(this, feedStore, feedModel, recorder);
		this.exportAction = new ExportOPMLAction(this, feedModel, recorder);
		this.newFeedAction = new NewFeedAction(this, feedModel, feedStore, recorder);
		this.newFeedsterSearchFeedAction = new NewFeedsterSearchFeedAction(this, feedModel, feedStore, recorder);
		this.newBlogDiggerSearchFeedAction = new NewBlogDiggerSearchFeedAction(this, feedModel, feedStore, recorder);
		this.exitAction = new ExitAction(this);
		
		this.refreshAllFeedsAction = new RefreshAllFeedsAction(threadPool, feedModel);
		this.refreshFeedAction = new RefreshFeedAction(runOnNewThreadExecutor, feedStore, entryStore, feedModel, entryModel);
		this.markFeedReadAction = new MarkFeedReadAction(feedStore, entryStore, feedModel, entryModel);

		this.moreLikeThisAction = new MoreLikeThisAction(entryStore, feedModel, entryModel);
		this.lessLikeThisAction = new LessLikeThisAction(entryStore, feedModel, entryModel);
		
		this.componentLocator = new ComponentLocator();
		this.focusOnFeedViewAction = new FeedViewFocusAction(componentLocator);
		this.focusOnEntryViewAction = new EntryViewFocusAction(componentLocator);
		this.focusOnBrowserViewAction = new BrowserViewFocusAction(componentLocator);
		this.showSelectedFeedAction = new ShowSelectedFeedAction(componentLocator);
		this.showSelectedEntryAction = new ShowSelectedEntryAction(feedModel, entryModel, componentLocator);
		this.openSelectedEntryInExternalBrowserAction = new OpenSelectedEntryAction(feedModel, entryModel, this);
		this.openCurrentLocationInExternalBrowserAction = new OpenCurrentLocationAction(feedModel, entryModel, this, browserModel);
		
		this.addMenuBar();
		this.addStatusLine();
		this.addToolBar(SWT.SHADOW_OUT);
	}

	protected Control createContents(Composite root) {
		Shell shell = getShell();
		shell.setText(Constants.APPLICATION_NAME_AND_VERSION_NUMBER);
		shell.setMaximized(true);
		
		SashForm feedsPanelAndBrowserPanel = new SashForm(root, SWT.HORIZONTAL);
		Composite feedsAndEntriesPanel = new SashForm(feedsPanelAndBrowserPanel, SWT.VERTICAL);
		
		TabFolder tabFolder = new TabFolder(feedsAndEntriesPanel, SWT.TOP);
		
		SashForm filterAndFeedViewPanel = new SashForm(tabFolder, SWT.VERTICAL);
		createFilterBar(filterAndFeedViewPanel, feedModel, "Filter By Feed Url/Title: ");
		
		TabItem feedTab = new TabItem(tabFolder, SWT.NULL);
		feedTab.setControl(filterAndFeedViewPanel);
		feedTab.setText("Feeds");
		
		SearchSpecification searchSpecification = new SearchSpecification();
		WorkerThreadStatusRecorder multiThreadStatusRecorder = new WorkerThreadStatusRecorder(recorder, shell.getDisplay());
		SearchController searchController = new SearchController(entryModel, searchSpecification, entryStore, shell, multiThreadStatusRecorder);
		new SearchView(tabFolder, searchSpecification, searchController);
		
		//this doesn't have to be disposed
		UserInterfaceExecutor uiExecutor = new AsynchronousUIExecutor(shell.getDisplay());
		
		FeedViewController feedController = new FeedViewControllerImpl(feedModel, entryModel, feedStore, entryStore, slottedBackgroundExecutor, uiExecutor, runOnNewThreadExecutor, multiThreadStatusRecorder);
		this.feedView = new FeedViewImpl(feedModel, filterAndFeedViewPanel, feedController);
		componentLocator.registerListView(feedView, FeedView.class);
		SelectionListener[] feedViewSelectionListeners = new SelectionListener[]{refreshFeedAction, 
			markFeedReadAction, showSelectedFeedAction};
		addFeedViewSelectionListeners(feedViewSelectionListeners);
		filterAndFeedViewPanel.setWeights(RATIO_OF_FILTER_TO_PANEL);
		
		Composite browserPanel = new SashForm(feedsPanelAndBrowserPanel, SWT.VERTICAL);
		BrowserController browserController = new BrowserControllerImpl(feedModel, entryModel, browserModel, entryStore);
		BrowserStatusTextListener browserStatusTextListener = new BrowserStatusTextListener(statusLineManager);	

		SashForm filterAndEntryViewPanel = new SashForm(feedsAndEntriesPanel, SWT.VERTICAL);
		createFilterBar(filterAndEntryViewPanel, entryModel, "Filter By Entry Title: ");
		
		reliableBackgroundExecutor = new ReliableBackgroundExecutor();
		EntryViewController entryController = new EntryViewControllerImpl(feedModel, entryModel, browserModel, entryStore, reliableBackgroundExecutor, uiExecutor);
		this.entryView = new EntryViewImpl(entryModel, filterAndEntryViewPanel, entryController);
		componentLocator.registerListView(entryView, EntryView.class);
		SelectionListener[] entryViewSelectionListeners = new SelectionListener[]{moreLikeThisAction, lessLikeThisAction, 
			showSelectedEntryAction, openSelectedEntryInExternalBrowserAction};
		addEntryViewSelectionListeners(entryViewSelectionListeners);
		
		//the openCurrentLocationInExternalBrowserAction is special because it only cares about the entryview
		//selecting a different feed doesn't affect it
		entryView.addSelectionListener(openCurrentLocationInExternalBrowserAction);
		
		filterAndEntryViewPanel.setWeights(RATIO_OF_FILTER_TO_PANEL);
		
		this.browserView = new BrowserViewImpl(browserModel, browserPanel, browserStatusTextListener, browserController);
		componentLocator.registerBrowserView(browserView);

		feedModel.loadFeeds();
		feedsPanelAndBrowserPanel.setWeights(RATIO_OF_LEFT_TO_RIGHT_PANEL);
		
		String startMessage = "Started " + Constants.APPLICATION_NAME_AND_VERSION_NUMBER + " with " + feedStore.findAllFeeds().size() + " feeds";
		statusLineManager.setMessage(startMessage);
		LOG.info(startMessage);
		
		return null;
	}
	
	private void addEntryViewSelectionListeners(SelectionListener[] listeners) {
		//things that listen to the entryview must also listen to the feedview
		//so that they can detect when the feedview has been selected and 
		//consequently the entryview no longer has a valid selection
		for (int i = 0; i < listeners.length; i++) {
			feedView.addSelectionListener(listeners[i]);
			entryView.addSelectionListener(listeners[i]);
		}
	}

	private void addFeedViewSelectionListeners(SelectionListener[] listeners) {
		for (int i = 0; i < listeners.length; i++) {
			feedView.addSelectionListener(listeners[i]);
		}
	}

	private void createFilterBar(Composite panel, FilterableModel model, String description) {
		Composite toolBarGroup = new Composite(panel, SWT.NONE);
		toolBarGroup.setLayoutData(new RowData(SWT.MAX, SWT.DEFAULT));
		GridLayout toolBarLayout = new GridLayout();
		toolBarLayout.numColumns = 3;
		toolBarGroup.setLayout(toolBarLayout);
		Label filterLabel = new Label(toolBarGroup, SWT.NONE);
		filterLabel.setText(description);
		final Text filterInput = new Text(toolBarGroup, SWT.BORDER);
		filterInput.setLayoutData(new GridData(GridData.GRAB_HORIZONTAL | GridData.HORIZONTAL_ALIGN_FILL));
		filterInput.addModifyListener(new Filter(model, filterInput));
	}

	public void dispose() {
		reliableBackgroundExecutor.shutDownAfterProcessingCurrentlyQueuedTasks();
		slottedBackgroundExecutor.shutDown();
		threadPool.shutDownNow();
		connectionPool.shutDown();
	}

	protected MenuManager createMenuManager() {
		MenuManager menuBar = new MenuManager();
		
		MenuManager fileMenu = new MenuManager("&File");
		MenuManager newFileMenuSubMenu = new MenuManager("&New");
		fileMenu.add(newFileMenuSubMenu);
		newFileMenuSubMenu.add(newFeedAction);
		newFileMenuSubMenu.add(newFeedsterSearchFeedAction);
		newFileMenuSubMenu.add(newBlogDiggerSearchFeedAction);
		
		fileMenu.add(importAction);
		fileMenu.add(exportAction);
		fileMenu.add(new Separator());
		fileMenu.add(exitAction);
		
		MenuManager feedMenu = new MenuManager("Fee&d");
		feedMenu.add(refreshAllFeedsAction);
		feedMenu.add(refreshFeedAction);
		feedMenu.add(new Separator());
		feedMenu.add(markFeedReadAction);
		feedMenu.add(showSelectedFeedAction);
		
		MenuManager entryMenu = new MenuManager("&Entry");
		entryMenu.add(moreLikeThisAction);
		entryMenu.add(lessLikeThisAction);
		entryMenu.add(new Separator());
		entryMenu.add(showSelectedEntryAction);
		
		MenuManager browserMenu = new MenuManager("&Browser");
		browserMenu.add(openSelectedEntryInExternalBrowserAction);
		browserMenu.add(openCurrentLocationInExternalBrowserAction);
		
		MenuManager viewMenu = new MenuManager("&View");
		viewMenu.add(focusOnFeedViewAction);
		viewMenu.add(focusOnEntryViewAction);
		viewMenu.add(focusOnBrowserViewAction);
		
		menuBar.add(fileMenu);
		menuBar.add(feedMenu);
		menuBar.add(entryMenu);
		menuBar.add(browserMenu);
		menuBar.add(viewMenu);
		return menuBar;
	}

	protected StatusLineManager createStatusLineManager() {
		this.statusLineManager = new StatusLineManager();
		return statusLineManager;
	}
	
	protected ToolBarManager createToolBarManager(int style) {
		ToolBarManager toolBar = new ToolBarManager(style);
		
		toolBar.add(newFeedAction);
		toolBar.add(refreshFeedAction);
		toolBar.add(refreshAllFeedsAction);
		
		toolBar.add(moreLikeThisAction);
		toolBar.add(lessLikeThisAction);
		return toolBar;
	}
}