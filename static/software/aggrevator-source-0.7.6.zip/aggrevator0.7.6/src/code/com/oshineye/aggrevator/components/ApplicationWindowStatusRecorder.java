package com.oshineye.aggrevator.components;

import org.eclipse.jface.window.ApplicationWindow;

/**
 * @author aoshineye
 *
 */
public class ApplicationWindowStatusRecorder implements StatusRecorder {
	private ApplicationWindow window;

	public ApplicationWindowStatusRecorder(ApplicationWindow window) {
		this.window = window;
	}

	public void setStatus(String message) {
		window.setStatus(message);
	}

}
