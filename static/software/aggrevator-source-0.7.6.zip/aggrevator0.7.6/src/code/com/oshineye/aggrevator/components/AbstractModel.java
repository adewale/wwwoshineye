package com.oshineye.aggrevator.components;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;

import com.oshineye.aggrevator.ComparatorFactory;
import com.oshineye.aggrevator.Filterable;

/**
 * @author aoshineye
 */
public abstract class AbstractModel implements FilterableModel, SortableModel {
	private Comparator previousComparator;
	public void sort(Comparator comparator) {
		if (ComparatorFactory.isSameComparator(comparator, previousComparator)) {
			Comparator reverseComparator = ComparatorFactory.createReverseComparator(comparator);
			Collections.sort(getItems(), reverseComparator);
			this.previousComparator = reverseComparator;
		} else {
			Collections.sort(getItems(), comparator);
			this.previousComparator = comparator;
		}
	}
	
	public boolean isAlreadyShowing(List matchingItems) {
		return getItems().equals(matchingItems);
	}
	
	protected void sortWithPreviousComparator(List matchingItems) {
		if (previousComparator == null) {
			return;
		}
		Collections.sort(matchingItems, previousComparator);
	}
	
	
	protected List findMatchingItems(String searchText, List allItems) {
		searchText = searchText.toLowerCase();
		List matchingItems = new ArrayList();
		for (Iterator iter = allItems.iterator(); iter.hasNext();) {
			Filterable item = (Filterable) iter.next();
			if (contains(item.getTitle(), searchText) || contains(item.getUrl(), searchText)) {
				matchingItems.add(item);
			}
		}
		return matchingItems;
	}

	private boolean contains(String container, String searchTerm) {
		if (container == null) {
			return false;
		}
		return container.toLowerCase().indexOf(searchTerm) >= 0;
	}
}
