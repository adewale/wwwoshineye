package com.oshineye.aggrevator.components.actions;

import org.eclipse.jface.action.Action;
import org.eclipse.jface.window.ApplicationWindow;

/**
 * @author aoshineye
 *
 */
public class ExitAction extends Action {
	private ApplicationWindow window;

	public ExitAction(ApplicationWindow window) {
		this.window = window;
		this.setText("E&xit@Ctrl+Q");
	}
	
	public void run() {
		window.close();
	}
}
