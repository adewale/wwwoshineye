package com.oshineye.aggrevator.util;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;

import com.oshineye.aggrevator.TunnellingException;

/**
 * @author aoshineye
 *
 */
public class URLUtils {
	public static String generateFeedsterSearchUrl(String searchTerm) {
		return "http://feedster.com/search.php?q=" + encode(searchTerm) + "&sort=&ie=UTF-8&hl=&content=full&type=rss&limit=15";
	}
	
	public static String generateBlogDiggerSearchUrl(String searchTerm) {
		return "http://www.blogdigger.com/atom.jsp?q=" + encode(searchTerm) + "&sortby=date";
	}
	
	private static String encode(String searchTerm) {
		try {
			return URLEncoder.encode(searchTerm, "UTF-8");
		} catch (UnsupportedEncodingException e) {
			throw new TunnellingException(e);
		}
	}
}
