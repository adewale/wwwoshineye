package com.oshineye.aggrevator.util;

import java.util.List;

import com.oshineye.aggrevator.Feed;

/**
 * @author aoshineye
 */
public interface Summariser {

	void feedImported(Feed feed);

	void feedStored(Feed feed);

	int getStoredFeedsCount();

	int getImportedFeedsCount();

	List getNewlyAddedFeeds();

}
