package com.oshineye.aggrevator.components.actions;

import com.oshineye.aggrevator.Feed;
import com.oshineye.aggrevator.components.EntryModel;
import com.oshineye.aggrevator.components.FeedModel;
import com.oshineye.aggrevator.store.EntryStore;
import com.oshineye.aggrevator.store.FeedStore;

/**
 * @author aoshineye
 */
public class MarkFeedReadAction extends AbstractWidgetSelectedAction {
	private FeedStore feedStore;
	private EntryStore entryStore;
	private FeedModel feedModel;
	private EntryModel entryModel;
	public MarkFeedReadAction(FeedStore feedStore, EntryStore entryStore, FeedModel feedModel, EntryModel entryModel) {
		this.feedStore = feedStore;
		this.entryStore = entryStore;
		this.feedModel = feedModel;
		this.entryModel = entryModel;
		this.setText("&Mark Feed Read@Ctrl+R");
	}

	public void run() {
		Feed feed = feedModel.getSelectedFeed();
		feedStore.markRead(feed);
		feedModel.refreshFeed(feed);
		
		if (feedModel.isSelected(feed)) {
			//FIXME consider moving the query off the UI thread as it's potentially
			//long-running. Loading all the entries for a large feed will take a while
			//FIXME consider just altering the in-memory objects in the entrymodel
			//it would be quicker and would avoid going to the db
			entryModel.loadEntries(entryStore.findEntriesInFeed(feed.getId()));
		}
	}
}
