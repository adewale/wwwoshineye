package com.oshineye.aggrevator.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import org.apache.log4j.Logger;
import org.logicalcobwebs.proxool.ProxoolFacade;

import com.oshineye.aggrevator.TunnellingException;

/**
 * @author aoshineye
 *
 */
public class ProxoolConnectionPool implements ConnectionPool {
	private static final Logger LOG = Logger.getLogger(ProxoolConnectionPool.class);
	private static final String AGGREVATOR_ALIAS = "aggrevatorAlias";
	public ProxoolConnectionPool(String driver, String url, String userName, String passWord, int connectionPoolSize) {
		try {
			Class.forName("org.logicalcobwebs.proxool.ProxoolDriver");
			Properties info = new Properties();
			info.setProperty("proxool.maximum-connection-count", "" + connectionPoolSize);
			info.setProperty("proxool.test-before-use", "true");
			info.setProperty("proxool.house-keeping-test-sql", "select CURRENT_DATE");
			info.setProperty("proxool.maximum-connection-lifetime", "7200000");
			info.setProperty("proxool.maximum-active-time", "6000000");
			info.setProperty("user", userName);
			info.setProperty("password", passWord);
			String proxoolUrl = "proxool." + AGGREVATOR_ALIAS + ":" + driver + ":"
					+ url;
			ProxoolFacade.registerConnectionPool(proxoolUrl, info);
			
		} catch (Exception e) {
			LOG.warn(e.toString());
		}
	}

	public void shutDown() {
		ProxoolFacade.shutdown(0);
	}

	public Connection acquireConnection() {
		Connection conn;
		try {
			conn = DriverManager.getConnection("proxool." + AGGREVATOR_ALIAS);
		} catch (SQLException sqle) {
			throw new TunnellingException(sqle);
		}

		return conn;
	}
}
