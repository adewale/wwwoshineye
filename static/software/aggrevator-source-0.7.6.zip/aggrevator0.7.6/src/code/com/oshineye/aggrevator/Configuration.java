package com.oshineye.aggrevator;

import java.io.FileNotFoundException;

import org.apache.commons.httpclient.ProxyHost;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

/**
 * @author aoshineye
 */
public class Configuration {
	private static final Logger LOG = Logger.getLogger(Configuration.class);
	public static final String DATE_FORMAT = "EEEE yyyy-MM-dd";

	private static String databaseName = "aggrevator";
	private static String databaseServer = "jdbc:mysql://localhost/";
	
	private static String userName = "aggrevator_user";
	private static String password = "aggrevator_user_password";
	
	private static int numberOfThreadsInPool = 10;
	
	//http timeout in milliseconds
	private static int httpTimeOut = 1000 * 60;

	private static ProxyHost proxyHost;
	private static boolean isLazyLoading;

	public static String getDatabaseName() {
		return databaseName;
	}
	
	public static String getDatabaseServer() {
		return databaseServer;
	}

	public static String getUserName() {
		return userName;
	}
	
	public static String getPassword() {
		return password;
	}
	
	public static int getNumberOfThreadsInPool() {
		return numberOfThreadsInPool;
	}
	
	public static int getHttpTimeoutInMilliseconds() {
		return httpTimeOut;
	}

	public static void load() {
		startLog4J();
		
		ConfigurationProperties properties;
		try {
			properties = new ConfigurationProperties("configuration.properties");
		} catch (FileNotFoundException e) {
			throw new TunnellingException(e);
		}

		//get all the values defaulting to their original values if the user hasn't entered anything in the file for them
		databaseName = properties.getProperty("databaseName", databaseName);
		databaseServer = properties.getProperty("databaseServer", databaseServer);
		userName = properties.getProperty("userName", userName);
		password = properties.getProperty("password", password);
		numberOfThreadsInPool = Integer.parseInt(properties.getProperty("numberOfThreadsInPool", String.valueOf(numberOfThreadsInPool)));
		httpTimeOut = Integer.parseInt(properties.getProperty("httpTimeOut", String.valueOf(httpTimeOut)));
		
		
		String proxyHostUrl = properties.getProperty("proxyHost");
		String proxyHostPort = properties.getProperty("proxyPort");
		if (proxyHostUrl == null || proxyHostPort == null) {
			proxyHost = null;
			LOG.info("No proxy host set");
		} else {
			int proxyHostPortNumber = Integer.parseInt(proxyHostPort);
			proxyHost = new ProxyHost(proxyHostUrl, proxyHostPortNumber);
			LOG.info("Proxy host set to: " + proxyHost);
		}
		
		isLazyLoading = Boolean.valueOf(properties.getProperty("lazyLoading", "false")).booleanValue();
	}

	private static void startLog4J() {
		PropertyConfigurator.configureAndWatch("log4j.properties", 1000);
	}

	public static ProxyHost getProxyHost() {
		return proxyHost; 
	}

	public static boolean isLazyLoading() {
		return isLazyLoading;
	}
}
