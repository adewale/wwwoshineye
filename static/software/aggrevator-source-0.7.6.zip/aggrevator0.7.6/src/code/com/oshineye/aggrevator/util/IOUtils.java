package com.oshineye.aggrevator.util;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.Writer;

import org.apache.log4j.Logger;

/**
 * @author aoshineye
 *
 */
public class IOUtils {
	private static final Logger LOG = Logger.getLogger(IOUtils.class);
	public static void close(Reader reader) {
		try {
			if (reader == null) {
				LOG.debug("Attempted to close null reader");
				return;
			}
			reader.close();
		} catch (IOException e) {
			LOG.warn(e.getMessage(), e);
		}
	}

	public static void close(Writer writer) {
		try {
			if (writer == null) {
				LOG.warn("Attempted to close null writer");
				return;
			}
			writer.close();
		} catch (IOException e) {
			LOG.warn(e.getMessage(), e);
		}
	}
	
	public static String read(InputStream inputStream) throws IOException {
		BufferedReader reader = null;
		try {
			reader = new BufferedReader(new InputStreamReader(inputStream));
			return read(reader);
		} finally {
			IOUtils.close(reader);
		}
	}
	
	public static String read(String fileName) {
		BufferedReader reader = null;
		try {
			reader = new BufferedReader(new FileReader(fileName));
			return read(reader);
		} catch (IOException e) {
			LOG.warn(e.getMessage(), e);
		} finally {
			IOUtils.close(reader);
		}
		return "";
	}

	private static String read(BufferedReader reader) throws IOException {
		StringBuffer result = new StringBuffer();
		String line = null;
		while (null != (line = reader.readLine())) {
			result.append(line);
		}
		return result.toString();
	}

}
