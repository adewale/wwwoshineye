package com.oshineye.aggrevator.components.commands.worker.foreground;

import java.util.List;

import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.jface.operation.IRunnableWithProgress;

import com.oshineye.aggrevator.components.EntryModel;
import com.oshineye.aggrevator.components.StatusRecorder;
import com.oshineye.aggrevator.store.EntryStore;
import com.oshineye.aggrevator.store.SearchSpecification;


public class SearchCommand implements IRunnableWithProgress {
	private EntryModel entryModel;
	private EntryStore entryStore;
	private final SearchSpecification searchSpecification;
	private final StatusRecorder recorder;

	public SearchCommand(EntryModel entryModel, SearchSpecification searchSpecification, EntryStore entryStore, 
		StatusRecorder recorder) {
		super();
		this.entryModel = entryModel;
		this.searchSpecification = searchSpecification;
		this.entryStore = entryStore;
		this.recorder = recorder;
	}

	public void run(IProgressMonitor monitor) {
		monitor.beginTask("Searching for: " + searchSpecification, 2);
		List entriesMatching = entryStore.findEntriesMatching(searchSpecification);
		monitor.worked(1);

		if (monitor.isCanceled()) {
			recorder.setStatus("Search cancelled after query completed");
			return;
		}

		entryModel.loadEntries(entriesMatching);
		monitor.worked(2);
		recorder.setStatus("Search completed with " + entriesMatching.size() + " matching entries");
		monitor.done();
	}
}