package com.oshineye.aggrevator.components.commands.worker.background;

import java.util.List;

import com.oshineye.aggrevator.Entry;
import com.oshineye.aggrevator.components.EntryModel;
import com.oshineye.aggrevator.components.FeedModel;
import com.oshineye.aggrevator.components.executors.UserInterfaceExecutor;
import com.oshineye.aggrevator.components.tasks.Task;
import com.oshineye.aggrevator.store.EntryStore;

/**
 * @author aoshineye
 *
 */
public class MarkEntryReadCommand implements Runnable {
	private Entry selectedEntry;
	private FeedModel feedModel;
	private EntryModel entryModel;
	private UserInterfaceExecutor uiExecutor;
	private EntryStore entryStore;

	public MarkEntryReadCommand(Entry selectedEntry, FeedModel feedModel, EntryStore entryStore, EntryModel entryModel,
		UserInterfaceExecutor uiExecutor) {
		this.feedModel = feedModel;
		this.entryStore = entryStore;
		this.entryModel = entryModel;
		this.selectedEntry = selectedEntry;
		this.uiExecutor = uiExecutor;
	}

	public void run() {
		//the relatedFeeds and the selectedEntry are not shared mutable state
		//because the UI thread doesn't get hold of them till we've finished with them
		//and selecting the same entry multiple times isn't a problem because an entry
		//that's already been read can never get here
		final List relatedFeeds = entryStore.getRelatedFeeds(selectedEntry.getUrl());
		entryStore.markRead(selectedEntry);
		uiExecutor.execute(new Task() {
			public void doWork() {
				feedModel.entryRead(relatedFeeds);
				entryModel.markRead(selectedEntry.getUrl());
			}
		});
	}
}
