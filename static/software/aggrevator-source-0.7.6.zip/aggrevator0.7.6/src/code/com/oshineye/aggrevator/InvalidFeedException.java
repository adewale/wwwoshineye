package com.oshineye.aggrevator;



/**
 * @author aoshineye
 * An exception thrown to indicate that a feed has an invalid location (i.e
 * the server is down or the file isn't at the url and we're getting 404 
 * errors) or that the feed can't be correctly parsed for some reason.
 */
public class InvalidFeedException extends Exception {
	private String extraInfo;

	public InvalidFeedException(Exception cause) {
		super(cause);
	}

	public InvalidFeedException(String extraInfo, Exception cause) {
		this(cause);
		this.extraInfo = extraInfo;
	}
	
	public String getMessage() {
		String message = super.getMessage();
		if (extraInfo != null) {
			message = message + "\n" + "Extra info: " + extraInfo;
		}
		return message;
	}
}
