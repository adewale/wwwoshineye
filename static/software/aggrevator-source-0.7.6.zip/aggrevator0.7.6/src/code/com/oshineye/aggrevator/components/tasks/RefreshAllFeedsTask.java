package com.oshineye.aggrevator.components.tasks;

import org.apache.log4j.Logger;

import com.oshineye.aggrevator.components.FeedModel;
import com.oshineye.aggrevator.components.RefreshQueue;

public class RefreshAllFeedsTask extends Task {
	private static final Logger LOG = Logger.getLogger(RefreshAllFeedsTask.class);
	private RefreshQueue queue;
	private FeedModel feedModel;
	
	public RefreshAllFeedsTask(RefreshQueue queue, FeedModel feedModel) {
		super();
		this.queue = queue;
		this.feedModel = feedModel;
	}

	public void doWork() {
		LOG.debug("About to queue up all feeds for refresh");
		queue.enqueue(feedModel.getCurrentFeeds());
		LOG.debug("Finished queuing up all feeds for refresh");
	}
}