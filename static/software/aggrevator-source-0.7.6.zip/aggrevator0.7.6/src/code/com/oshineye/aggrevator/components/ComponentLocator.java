package com.oshineye.aggrevator.components;

import java.util.HashMap;
import java.util.Map;

/**
 * @author aoshineye
 *
 */
public class ComponentLocator {
	private BrowserView browserView;
	private Map map;
	
	public ComponentLocator() {
		this.map = new HashMap();
	}

	public View getBrowserView() {
		return browserView;
	}

	public void registerBrowserView(BrowserView browserView) {
		this.browserView = browserView;
	}

	public ListView getListView(Class key) {
		return (ListView) map.get(key);
	}

	public void registerListView(ListView view, Class key) {
		map.put(key, view);
	}
}
