package com.oshineye.aggrevator.components.commands.worker.foreground;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;

import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.jface.operation.IRunnableWithProgress;

import edu.stanford.ejalbert.BrowserLauncher;

/**
 * @author aoshineye
 *
 */
public class OpenInBrowserCommand implements IRunnableWithProgress {
	private final String url;

	public OpenInBrowserCommand(String url) {
		this.url = url;

	}
	
	public void run(IProgressMonitor monitor) throws InvocationTargetException {
		monitor.beginTask("Opening entry in external browser", IProgressMonitor.UNKNOWN);
		
		try {
			BrowserLauncher.openURL(url);
		} catch (IOException e) {
			throw new InvocationTargetException(e);
		}
		monitor.done();
	}
}
