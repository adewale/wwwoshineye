package com.oshineye.aggrevator.components;

/**
 * @author aoshineye
 */
public interface BrowserController {

	void handleLocationVisited(String location);

}
