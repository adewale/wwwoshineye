package com.oshineye.aggrevator;

import com.oshineye.aggrevator.util.QueryLoader;

/**
 * @author aoshineye
 *
 */
public class QueryLoaderFactory {
	private static final QueryLoader QUERY_LOADER = new QueryLoader();
	public static QueryLoader createQueryLoader() {
		return QUERY_LOADER;
	}
}
