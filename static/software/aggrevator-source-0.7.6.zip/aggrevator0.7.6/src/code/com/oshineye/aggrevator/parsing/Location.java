package com.oshineye.aggrevator.parsing;

import java.io.IOException;
import java.io.Reader;

/**
 * @author aoshineye
 *
 */
public interface Location {
	public boolean hasBeenModified() throws IOException;

	public String getLastModified();

	public String getEtag();

	public void setUrl(String url);

	public String getUrl();
	
	public Reader createReader() throws IOException ;

	public void commit();

	public boolean isCommitted();
	
	public void rollBack();
}