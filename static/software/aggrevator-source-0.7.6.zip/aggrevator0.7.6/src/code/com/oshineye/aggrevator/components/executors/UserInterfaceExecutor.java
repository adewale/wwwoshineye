package com.oshineye.aggrevator.components.executors;

import com.oshineye.aggrevator.components.tasks.Task;

/**
 * @author aoshineye
 *
 */
public interface UserInterfaceExecutor {
	public void execute(Task task);
}
