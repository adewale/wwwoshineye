package com.oshineye.aggrevator;

/**
 * @author aoshineye
 */
public class RefreshInProgressException extends Exception {
    //doesn't really do anything except specify the type of problem
}
