package com.oshineye.aggrevator.store;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import junit.framework.TestCase;

import com.oshineye.aggrevator.Entry;
import com.oshineye.aggrevator.Feed;
import com.oshineye.aggrevator.InvalidFeedException;

/**
 * @author aoshineye
 *
 */
public abstract class AbstractEntryStoreTest extends TestCase {
	protected Feed feed;
	protected Feed similarFeed;
	protected Feed secondFeed;
	protected EntryStore entryStore;
	protected FeedStore feedStore;
	
	protected abstract EntryStore createEntryStore();
	
	protected abstract FeedStore createFeedStore();
	
	public void setUp() throws Exception {
		feed = StubFixture.getStubFeed();
		similarFeed = StubFixture.getStubFeedWithUrl(StubFixture.TEST_URL_CLONE_WITH_ONE_LESS_ENTRY);
		secondFeed = StubFixture.getStubFeedWithUrl(StubFixture.TEST_URL2);


		//referential integrity requires us to create the feedstore first
		feedStore = createFeedStore();
		entryStore = createEntryStore();

		//referential integrity requires us to delete the entrystore first
		entryStore.deleteAll();
		feedStore.deleteAll();
		
		feedStore.add(feed);
		feedStore.add(similarFeed);
		feedStore.add(secondFeed);
	}
	
	public void tearDown() {
		entryStore.deleteAll();
		feedStore.deleteAll();
	}
	
	public void testAddingAndRetrievingEntries() throws InvalidFeedException {
		List fetchedEntries = feed.fetchNewEntries();
		entryStore.addEntries(fetchedEntries);
		
		List entries = entryStore.findEntriesInFeed(feed.getId());
		
		assertNotNull(entries);
		assertTrue("Didn't retrieve any entries", entries.size() > 0);
		assertEquals("Didn't retrieve the same number of entries back", fetchedEntries.size(), entries.size());
	}

	public void testAddedEntryCanBeRetrieved() throws InvalidFeedException {
		List fetchedEntries = feed.fetchNewEntries();
		entryStore.addEntries(fetchedEntries);
		List storedEntries = entryStore.findEntriesInFeed(feed.getId());
		Entry fetchedEntry = (Entry) fetchedEntries.get(0);
		Entry storedEntry = (Entry) storedEntries.get(0);

		assertEquals(fetchedEntries.size(), storedEntries.size());
		assertEquals(fetchedEntries, storedEntries);
		assertEquals(fetchedEntry.getUrl(), storedEntry.getUrl());
		assertEquals(fetchedEntry.getFeedTitle(), storedEntry.getFeedTitle());
		assertEquals(fetchedEntry.getContent(), storedEntry.getContent());
	}
	
	public void testAddingEmptyEntryListSucceeds() {
		assertNotNull(entryStore.findEntriesInFeed(feed.getId()));
		
		entryStore.addEntries(new ArrayList());
		
		assertNotNull(entryStore.findEntriesInFeed(feed.getId()));
	}

	public void testAddingAndRetrievingEntriesFromMultipleFeeds() throws InvalidFeedException {
		int expectedTotalNumberOfEntriesInTestFeeds = 16;
		entryStore.addEntries(feed.fetchNewEntries());
		entryStore.addEntries(secondFeed.fetchNewEntries());
		int feedCount = entryStore.findEntriesInFeed(feed.getId()).size() + entryStore.findEntriesInFeed(secondFeed.getId()).size();

		assertEquals(expectedTotalNumberOfEntriesInTestFeeds, feedCount);
	}

	public void testFindParticularEntriesForParticularFeed() throws InvalidFeedException {
	    List entries = feed.fetchNewEntries();
	    assertEquals(6, entries.size());
	    
	    entries.remove(0);
	    entryStore.addEntries(entries);//5 added to db
	    
	    List entries2 = feed.fetchNewEntries();
	    entries2.remove(5);
	    entries2.remove(4);
	    entries2.remove(3);
	    assertEquals(3, entries2.size());
	    List newEntries = entryStore.findMatchingEntriesInFeed(feed.getId(), entries2);
	    
	    //2 is planetnumber in db - number removed from entries2
	    assertEquals("Didn't get back the entries we already have.", 2, newEntries.size());
	}
	
	public void testMarkingEntryAsReadPersists() throws Exception {
		entryStore.addEntries(feed.fetchNewEntries());
		List entries = entryStore.findEntriesInFeed(feed.getId());
		Entry entry = (Entry) entries.get(0);
		
		entryStore.markRead(entry);
		List newEntries = entryStore.findEntriesInFeed(feed.getId());
		Entry newEntry = (Entry) newEntries.get(0);
		
		assertTrue(newEntry.isRead());
	}
	
	public void testMarkingEntryAsReadAltersScore() throws Exception {
		entryStore.addEntries(feed.fetchNewEntries());
		List entries = entryStore.findEntriesInFeed(feed.getId());
		Entry entry = (Entry) entries.get(0);
		
		entryStore.markRead(entry);
		List newEntries = entryStore.findEntriesInFeed(feed.getId());
		Entry newEntry = (Entry) newEntries.get(0);
		
		assertEquals(Feed.ENTRY_READ_SCORE, newEntry.getScore());
	}
	
	public void testRepeatedlyMarkingEntryAsReadAltersScoreOnlyOnce() throws Exception {
		entryStore.addEntries(feed.fetchNewEntries());
		List entries = entryStore.findEntriesInFeed(feed.getId());
		Entry entry = (Entry) entries.get(0);
		
		entryStore.markRead(entry);
		entryStore.markRead(entry);
		entryStore.markRead(entry);
		List newEntries = entryStore.findEntriesInFeed(feed.getId());
		Entry newEntry = (Entry) newEntries.get(0);
		
		assertEquals(Feed.ENTRY_READ_SCORE, newEntry.getScore());
	}
	
	public void testRepeatedlyMarkingLocationAsReadAltersScoreOnlyOnce() throws Exception {
		String permaLink = "some permalink";
		Entry entry = StubFixture.getStubEntryWithPermaLinkAndFeedId(permaLink, feed.getId());
		List entries = new ArrayList();
		entries.add(entry);
		
		entryStore.addEntries(entries);
		
		entryStore.markRead(permaLink);
		entryStore.markRead(permaLink);
		entryStore.markRead(permaLink);
		
		List newEntries = entryStore.findEntriesInFeed(feed.getId());
		Entry newEntry = (Entry) newEntries.get(0);
		
		assertEquals(Feed.ENTRY_READ_SCORE, newEntry.getScore());
	}
	
	public void testMarkingEntryWithUniquePermalinkAsReadInOneFeedMarksItAsReadEveryWhere() throws Exception {
		/*
		 * This is to deal with aggregated feeds like PlanetPython which may contain an entry that
		 * also turns up in the feed from the original site
		 */
		String permaLink = "somePermaLink";
		List feedList1 = new ArrayList();
		feedList1.add(StubFixture.getStubEntryWithPermaLinkAndFeedId(permaLink, feed.getId()));
		List feedList2 = new ArrayList();
		feedList2.add(StubFixture.getStubEntryWithPermaLinkAndFeedId(permaLink, secondFeed.getId()));
		entryStore.addEntries(feedList1);
		entryStore.addEntries(feedList2);
		
		Entry e1 = getFirstEntry(feed);
		assertFalse(e1.isRead());
		
		entryStore.markRead(e1);
		
		assertTrue(e1.isRead());
		assertTrue(getFirstEntry(secondFeed).isRead());
	}
	
	public void testMultipleEntriesWithSamePermaLinkFromDifferentFeedsShareMetaData() {
		String permaLink = "somePermaLink";
		List feedList1 = new ArrayList();
		feedList1.add(StubFixture.getStubEntryWithPermaLinkAndFeedId(permaLink, feed.getId()));
		entryStore.addEntries(feedList1);
		
		//change the metadata for the first feed
		Entry e1 = getFirstEntry(feed);
		entryStore.markRead(e1);
		assertEquals(Feed.ENTRY_READ_SCORE, e1.getScore());

		entryStore.incrementScore(e1);
		assertEquals(Feed.SCORE_UNITS + Feed.ENTRY_READ_SCORE, e1.getScore());
		
		//now add the second feed to the store
		List feedList2 = new ArrayList();
		feedList2.add(StubFixture.getStubEntryWithPermaLinkAndFeedId(permaLink, secondFeed.getId()));
		entryStore.addEntries(feedList2);
		Entry otherEntry = getFirstEntry(secondFeed);
		
		assertEquals(e1.isRead(), otherEntry.isRead());
		assertEquals(e1.getScore(), otherEntry.getScore());
	}
	
	public void testMultipleEntriesWithSamePermaLinkFromDifferentFeedsHaveSynchronizedScoresDespiteArrivingAtDifferentTimes() {
		int numberOfAlterations = 5;
		String permaLink = "somePermaLink";
		List feedList1 = new ArrayList();
		feedList1.add(StubFixture.getStubEntryWithPermaLinkAndFeedId(permaLink, feed.getId()));
		entryStore.addEntries(feedList1);
		
		//change the metadata for the first feed
		Entry e1 = getFirstEntry(feed);
		for (int i=0; i<numberOfAlterations; i++) {
			entryStore.incrementScore(e1);
		}
		
		//now add the second feed to the store
		List feedList2 = new ArrayList();
		feedList2.add(StubFixture.getStubEntryWithPermaLinkAndFeedId(permaLink, secondFeed.getId()));
		entryStore.addEntries(feedList2);
		Entry otherEntry = getFirstEntry(secondFeed);
		for (int i=0; i<numberOfAlterations; i++) {
			entryStore.decrementScore(otherEntry);
		}
		
		Entry newE1 = getFirstEntry(feed);
		assertEquals(newE1.getScore(), otherEntry.getScore());
		assertEquals(0, newE1.getScore());
	}

	public void testUpdatesExistingFeedWhenNewEntriesListHasContent() {
		String permaLink = "somePermaLink";
		List feed1 = new ArrayList();
		feed1.add(StubFixture.getStubEntryWithPermaLinkAndFeedId(permaLink, feed.getId()));
		entryStore.addEntries(feed1);
		Entry e1 = getFirstEntry(feed);
		entryStore.markRead(e1);

		List feed2 = new ArrayList();
		feed2.add(StubFixture.getStubEntryWithPermaLinkAndFeedId(permaLink, secondFeed.getId()));
		feed2.add(StubFixture.getStubEntryWithPermaLinkAndFeedId("some other permaLink", secondFeed.getId()));
		entryStore.addEntries(feed2);
		feedStore.reconcile(secondFeed);
		
		assertEquals(1, secondFeed.getUnreadEntriesCount());
		assertEquals(Feed.ENTRY_READ_SCORE, secondFeed.getScore());
	}
	
	public void testFeedReceivesPointsForReadingEntryAndChangingScore() {
		String permaLink = "somePermaLinkFor testReceivesPointsForReadingEntry";
		List feed1 = new ArrayList();
		feed1.add(StubFixture.getStubEntryWithPermaLinkAndFeedId(permaLink, feed.getId()));
		entryStore.addEntries(feed1);
		feedStore.reconcile(feed);
		assertEquals(0, feed.getScore());
		
		Entry e1 = getFirstEntry(feed);
		entryStore.markRead(e1);
		feedStore.reconcile(feed);
		assertEquals(Feed.ENTRY_READ_SCORE, feed.getScore());
		
		entryStore.incrementScore(e1);
		feedStore.reconcile(feed);
		assertEquals(Feed.ENTRY_READ_SCORE + Feed.SCORE_UNITS, feed.getScore());
	}
	
	public void testScoreChangeAffectsAllCopiesOfEntry() throws Exception {
		String permaLink = "somePermaLink";
		List feed1 = new ArrayList();
		feed1.add(StubFixture.getStubEntryWithPermaLinkAndFeedId(permaLink, feed.getId()));
		List feed2 = new ArrayList();
		feed2.add(StubFixture.getStubEntryWithPermaLinkAndFeedId(permaLink, secondFeed.getId()));
		entryStore.addEntries(feed1);
		entryStore.addEntries(feed2);
		
		Entry e1 = getFirstEntry(feed);
		entryStore.incrementScore(e1);
		
		assertEquals(e1.getScore(), getFirstEntry(secondFeed).getScore());
	}
	
	private Entry getFirstEntry(Feed targetFeed) {
		List entries = entryStore.findEntriesInFeed(targetFeed.getId());
		return (Entry) entries.get(0);
	}

	public void testEntriesCanBeRetrievedForParticularFeeds() throws InvalidFeedException {
		List entries = feed.fetchNewEntries();
		entryStore.addEntries(entries);
		entryStore.addEntries(secondFeed.fetchNewEntries());
		List retrievedEntries = entryStore.findEntriesInFeed(feed.getId());
		
		assertNotNull(retrievedEntries);
		assertEquals(entries.size(), retrievedEntries.size());
		assertTrue(entries.containsAll(retrievedEntries));
		assertTrue(retrievedEntries.containsAll(entries));
	}
	
	public void testDeletingEntriesForAFeedRemovesAllEntriesForThatFeed() throws InvalidFeedException {
		List entries = feed.fetchNewEntries();
		assertFalse(entries.isEmpty());
		
		entryStore.addEntries(entries);
		List storedEntries = entryStore.findEntriesInFeed(feed.getId());
		assertFalse(storedEntries.isEmpty());
		
		entryStore.delete(feed);

		assertTrue(entryStore.findEntriesInFeed(feed.getId()).isEmpty());
	}
	
	public void testFindsOnlyEntriesWithMatchingFeedTitle() throws InvalidFeedException {
		List entries = secondFeed.fetchNewEntries();
		entryStore.addEntries(entries);
		entryStore.addEntries(feed.fetchNewEntries());
		
		String feedTitle = "All Things Java";
		SearchSpecification searchSpecification = new SearchSpecification();
		searchSpecification.setFeedTitleField(feedTitle);
		List matchingEntries = entryStore.findEntriesMatching(searchSpecification);
		assertEquals(10, matchingEntries.size());
	}
	
	public void testFindsOnlyEntriesWithMatchingTitles() throws InvalidFeedException {
		List entries = secondFeed.fetchNewEntries();
		entryStore.addEntries(entries);
		
		String searchTitleTermThatExistsOnlyInEntryTitles = "FreeRoller.Net Issues";
		SearchSpecification searchSpecification = new SearchSpecification();
		searchSpecification.setTitleField(searchTitleTermThatExistsOnlyInEntryTitles);
		List matchingEntries = entryStore.findEntriesMatching(searchSpecification);
		assertEquals(1, matchingEntries.size());
	}
	
	public void testStoreRetrievesEmptyListIfTitleDoesNotMatchButContentDoes() throws InvalidFeedException {
		List entries = secondFeed.fetchNewEntries();
		entryStore.addEntries(entries);
		
		String searchTitleTermThatExistsOnlyInEntryContent = "just restarted Tomcat with some modifications";
		SearchSpecification searchSpecification = new SearchSpecification();
		searchSpecification.setTitleField(searchTitleTermThatExistsOnlyInEntryContent);
		List matchingEntries = entryStore.findEntriesMatching(searchSpecification);
		assertEquals(0, matchingEntries.size());
	}
	
	public void testFindsMatchingForAllPopulatedFields() throws InvalidFeedException {
		List entries = secondFeed.fetchNewEntries();
		entryStore.addEntries(entries);
		
		String searchTitleTermThatExistsInEntries = "FreeRoller.Net Issues";
		String searchContentTermThatExistsInEntries = "just restarted Tomcat with some modifications";
		String feedTitle = "All Things Java";
		SearchSpecification searchSpecification = new SearchSpecification();
		searchSpecification.setTitleField(searchTitleTermThatExistsInEntries);
		searchSpecification.setContentField(searchContentTermThatExistsInEntries);
		searchSpecification.setFeedTitleField(feedTitle);
		List matchingEntries = entryStore.findEntriesMatching(searchSpecification);
		assertEquals(1, matchingEntries.size());
	}
	
	public void testFindsAllEntriesWhenAllFieldsAreEmpty() throws InvalidFeedException {
		List entries = secondFeed.fetchNewEntries();
		entryStore.addEntries(entries);
		
		SearchSpecification searchSpecification = new SearchSpecification();
		List matchingEntries = entryStore.findEntriesMatching(searchSpecification);
		assertEquals(entries, matchingEntries);
		assertEquals(matchingEntries, entryStore.findEntriesInFeed(secondFeed.getId()));
	}
	
	public void testStoreRetrievesEmptyListIfContentDoesNotMatchAnything() throws InvalidFeedException {
		List entries = feed.fetchNewEntries();
		entryStore.addEntries(entries);
		
		String nonMatchingString = "aaaaaaaaaaaimprobablestringzzzzzzzzz";
		SearchSpecification searchSpecification = new SearchSpecification();
		searchSpecification.setContentField(nonMatchingString);
		List matchingEntries = entryStore.findEntriesMatching(searchSpecification);
		
		assertTrue(matchingEntries.isEmpty());
	}
	
	public void testStoreRetrievesEntriesIfContentMatches() throws InvalidFeedException {
		List entries = feed.fetchNewEntries();
		entryStore.addEntries(entries);
		String matchingString = "is";
		SearchSpecification searchSpecification = new SearchSpecification();
		searchSpecification.setContentField(matchingString);
		List matchingEntries = entryStore.findEntriesMatching(searchSpecification);
		
		assertEquals(6, matchingEntries.size());
		assertFalse(matchingEntries.isEmpty());
	}
	
	public void testTotalScoreIncreasesWhenStoreIncrementsEntrysScore() throws InvalidFeedException {
		entryStore.addEntries(feed.fetchNewEntries());
		List storedEntries = entryStore.findEntriesInFeed(feed.getId());
		assertEquals(0, sum(storedEntries));
		
		Entry entry = (Entry)storedEntries.get(0);
		entryStore.incrementScore(entry);
		assertEquals(Feed.SCORE_UNITS, sum(entryStore.findEntriesInFeed(feed.getId())));
	}

	public void testTotalScoreDecreasesWhenStoreDecrementsEntrysScore() throws InvalidFeedException {
		entryStore.addEntries(feed.fetchNewEntries());
		List storedEntries = entryStore.findEntriesInFeed(feed.getId());
		assertEquals(0, sum(storedEntries));
		
		Entry entry = (Entry)storedEntries.get(0);
		entryStore.decrementScore(entry);
		assertEquals(-Feed.SCORE_UNITS, sum(entryStore.findEntriesInFeed(feed.getId())));
	}
	
	public void testEntrysScoreIsAlteredByStore() throws InvalidFeedException {
		List newEntries = feed.fetchNewEntries();
		entryStore.addEntries(newEntries);
		List storedEntries = entryStore.findEntriesInFeed(feed.getId());
		Entry entry = (Entry)storedEntries.get(0);
		assertEquals(0, entry.getScore());
		
		entryStore.incrementScore(entry);
		assertEquals(Feed.SCORE_UNITS, entry.getScore());
		
		entryStore.decrementScore(entry);
		assertEquals(0, entry.getScore());
		
		entryStore.decrementScore(entry);
		assertEquals(-Feed.SCORE_UNITS, entry.getScore());
	}
	
	public void testRelatedFeedsAreChosenBecauseOfLink() {
		String permaLink = "somePermaLink";
		
		List aFeedsList = new ArrayList();
		Entry stubEntryWithPermaLinkAndFeedId = StubFixture.getStubEntryWithPermaLinkAndFeedId(permaLink, feed.getId());
		aFeedsList.add(stubEntryWithPermaLinkAndFeedId);
		
		List otherFeedsList = new ArrayList();
		otherFeedsList.add(StubFixture.getStubEntryWithPermaLinkAndFeedId(permaLink, similarFeed.getId()));
		entryStore.addEntries(aFeedsList);
		entryStore.addEntries(otherFeedsList);
		
		List relatedFeeds = entryStore.getRelatedFeeds(stubEntryWithPermaLinkAndFeedId);
		assertEquals(2, relatedFeeds.size());
		assertTrue(relatedFeeds.contains(feed));
		assertTrue(relatedFeeds.contains(similarFeed));
	}

	public void testRelatedFeedsForLocationAreChosenBecauseOfLink() {
		String permaLink = "somePermaLink";
		
		List aFeedsList = new ArrayList();
		Entry readEntryWithPermaLinkAndFeedId = StubFixture.getStubReadEntryWithPermaLinkAndFeedId(permaLink, feed.getId());
		aFeedsList.add(readEntryWithPermaLinkAndFeedId);
		
		List otherFeedsList = new ArrayList();
		otherFeedsList.add(StubFixture.getStubEntryWithPermaLinkAndFeedId(permaLink, similarFeed.getId()));
		
		List otherFeedsList2 = new ArrayList();
		otherFeedsList2.add(StubFixture.getStubEntryWithPermaLinkAndFeedId(permaLink, secondFeed.getId()));
		
		entryStore.addEntries(aFeedsList);
		entryStore.addEntries(otherFeedsList);
		entryStore.addEntries(otherFeedsList2);
		
		List relatedFeeds = entryStore.getRelatedFeeds(readEntryWithPermaLinkAndFeedId.getUrl());
		assertEquals(3, relatedFeeds.size());
		assertTrue(relatedFeeds.contains(feed));
		assertTrue(relatedFeeds.contains(similarFeed));
		assertTrue(relatedFeeds.contains(secondFeed));
	}
	
	public void testRelatedFeedsAreTheSameAsExistingFeeds() {
		String permaLink = "somePermaLink";
		List aFeedsList = new ArrayList();
		Entry stubEntryWithPermaLinkAndFeedId = StubFixture.getStubEntryWithPermaLinkAndFeedId(permaLink, feed.getId());
		aFeedsList.add(stubEntryWithPermaLinkAndFeedId);
		List otherFeedsList = new ArrayList();
		otherFeedsList.add(StubFixture.getStubEntryWithPermaLinkAndFeedId(permaLink, similarFeed.getId()));
		entryStore.addEntries(aFeedsList);
		entryStore.addEntries(otherFeedsList);
		
		List relatedFeeds = entryStore.getRelatedFeeds(stubEntryWithPermaLinkAndFeedId);
		assertNotNull(relatedFeeds.get(0));
		assertNotNull(relatedFeeds.get(1));
		assertSame(feed, relatedFeeds.get(relatedFeeds.indexOf(feed)));
		assertSame(similarFeed, relatedFeeds.get(relatedFeeds.indexOf(similarFeed)));
	}
	
	public void testRelatedFeedsIsEmptyListWhenNothingFound() {
		Entry stubEntryWithPermaLinkAndFeedId = StubFixture.getStubEntryWithPermaLinkAndFeedId("permaLink", feed.getId());
		
		List relatedFeeds = entryStore.getRelatedFeeds(stubEntryWithPermaLinkAndFeedId);
		
		assertNotNull(relatedFeeds);
		assertEquals(0, relatedFeeds.size());
	}
	
	public void testMarkingUrlReadAffectsAllEntriesWithThatPermaLink() {
		String permaLink = "somePermaLink";
		List aFeedsList = new ArrayList();
		Entry stubEntryWithPermaLinkAndFeedId = StubFixture.getStubEntryWithPermaLinkAndFeedId(permaLink, feed.getId());
		aFeedsList.add(stubEntryWithPermaLinkAndFeedId);
		List otherFeedsList = new ArrayList();
		otherFeedsList.add(StubFixture.getStubEntryWithPermaLinkAndFeedId(permaLink, similarFeed.getId()));
		entryStore.addEntries(aFeedsList);
		entryStore.addEntries(otherFeedsList);
		
		assertFalse(getFirstEntry(feed).isRead());
		assertFalse(getFirstEntry(similarFeed).isRead());
		entryStore.markRead(stubEntryWithPermaLinkAndFeedId.getUrl());
		assertTrue(getFirstEntry(feed).isRead());
		assertTrue(getFirstEntry(similarFeed).isRead());
	}
	
	private int sum(List entries) {
		int result = 0;
		for (Iterator iter = entries.iterator(); iter.hasNext();) {
			Entry entry = (Entry) iter.next();
			result += entry.getScore();
		}
		return result;
	}
}
