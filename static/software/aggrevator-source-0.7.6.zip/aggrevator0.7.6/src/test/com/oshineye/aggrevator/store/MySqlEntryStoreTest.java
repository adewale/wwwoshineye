package com.oshineye.aggrevator.store;

import com.oshineye.aggrevator.store.FeedStore;

/**
 * @author aoshineye
 */
public class MySqlEntryStoreTest extends AbstractEntryStoreTest {
	protected EntryStore createEntryStore() {
		return StubFixture.getEntryStore();
	}

	protected FeedStore createFeedStore() {
		return StubFixture.getFeedStore();
	}
	
	public void testToMakeSureEclipsePicksUpThisTestCase() {
		//eclipse 3.1 M1 needs this method if it's going to pick up this class when it's building the testsuite that
		//contains other testsuites that's used for running all the tests in one go
	}
}
