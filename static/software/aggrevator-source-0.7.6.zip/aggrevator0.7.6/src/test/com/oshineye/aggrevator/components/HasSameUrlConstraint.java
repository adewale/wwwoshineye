package com.oshineye.aggrevator.components;

import org.jmock.core.Constraint;

import com.oshineye.aggrevator.Feed;

final class HasSameUrlConstraint implements Constraint {
    private Feed feed;
    
    public HasSameUrlConstraint(Feed feed) {
        this.feed = feed;
    }
    
	public boolean eval(Object arg) {
        if (!(arg instanceof Feed)) {
            return false;
        }
        Feed otherFeed = (Feed) arg;
        return feed.hasSameUrl(otherFeed);
	}

	public StringBuffer describeTo(StringBuffer buffer) {
		return buffer.append("has same url <" + feed + ">");
	}
}