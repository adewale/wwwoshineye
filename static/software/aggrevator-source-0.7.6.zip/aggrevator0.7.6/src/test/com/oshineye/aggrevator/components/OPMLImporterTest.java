package com.oshineye.aggrevator.components;

import java.io.ByteArrayInputStream;
import java.io.InputStream;

import org.jmock.Mock;
import org.jmock.MockObjectTestCase;

import com.oshineye.aggrevator.Feed;
import com.oshineye.aggrevator.store.FeedStore;
import com.oshineye.aggrevator.store.StubFixture;
import com.oshineye.aggrevator.util.Summariser;

/**
 * @author aoshineye
 *
 */
public class OPMLImporterTest extends MockObjectTestCase {
	private Feed abcFeed;
	private Feed adamConnorFeed;
	private Feed chalstFeed;
	
	public void setUp() {
		abcFeed = StubFixture.getStubFeedWithKeyTitleAndUrl(new Long(1), "Agile Business Coach", "http://abc.truemesh.com/index.rdf");
		adamConnorFeed = StubFixture.getStubFeedWithKeyTitleAndUrl(new Long(2), "Adam Connor's Notebook", "http://adamconnor.org/index.rdf");
		chalstFeed = StubFixture.getStubFeedWithKeyTitleAndUrl(new Long(3), "Advogato diary for chalst", "http://advogato.org/person/chalst/rss.xml");
	}
	
	public void testImportsCorrectNumberOfFeedUrlsGivenNestedOutlineTags() {
		Mock mockSummariser = new Mock(Summariser.class);
		mockSummariser.expects(once()).method("feedImported").with(new HasSameUrlConstraint(abcFeed));
		mockSummariser.expects(once()).method("feedImported").with(new HasSameUrlConstraint(adamConnorFeed));
		mockSummariser.expects(once()).method("feedImported").with(new HasSameUrlConstraint(chalstFeed));
		mockSummariser.expects(exactly(3)).method("feedStored").withAnyArguments();
		
		Mock mockFeedStore = new Mock(FeedStore.class);
		mockFeedStore.stubs().method("urlExists").withAnyArguments().will(returnValue(false));
		mockFeedStore.expects(exactly(3)).method("add").withAnyArguments();

		String content = "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n" +
		"<opml version=\"1.0\">\n" +
		"<head><title>Harvester export</title></head>\n" +
		"  <body>\n" +
	    "	<outline title=\"Some  folder name\">" +
		"    	<outline title=\"Agile Business Coach\" description=\"\" xmlUrl=\"http://abc.truemesh.com/index.rdf\" htmlUrl=\"\" />\n" +
		"    	<outline title=\"http://adamconnor.org/index.rdf\" description=\"Adam Connor's Notebook\" xmlUrl=\"http://adamconnor.org/index.rdf\" htmlUrl=\"\" />\n" +
		"    	<outline title=\"http://advogato.org/person/chalst/rss.xml\" description=\"Advogato diary for chalst\" xmlUrl=\"http://advogato.org/person/chalst/rss.xml\" htmlUrl=\"\" />\n" +
		"	</outline>" +
		"  </body>\n" +
		"</opml>";
		final ByteArrayInputStream stream = new ByteArrayInputStream(content.getBytes());
		String fileName = "someFileName";
		
		OPMLImporter importer = new OPMLFileImporter(fileName, 
				(FeedStore) mockFeedStore.proxy(), (Summariser)mockSummariser.proxy()) {
			protected InputStream getContentStream() {
				return stream;
			}
		};
		importer.importFeeds();
		
		mockSummariser.verify();
		mockFeedStore.verify();
	}

	public void testExtractsCorrectNumberOfFeedUrlsIgnoringDuplicates() {
		Mock mockSummariser = new Mock(Summariser.class);
		mockSummariser.expects(once()).method("feedImported").with(new HasSameUrlConstraint(abcFeed));
		mockSummariser.expects(once()).method("feedImported").with(new HasSameUrlConstraint(adamConnorFeed));
		mockSummariser.expects(once()).method("feedImported").with(new HasSameUrlConstraint(chalstFeed));
		mockSummariser.expects(exactly(3)).method("feedStored").withAnyArguments();
		
		Mock mockFeedStore = new Mock(FeedStore.class);
		mockFeedStore.stubs().method("urlExists").withAnyArguments().will(returnValue(false));
		mockFeedStore.expects(exactly(3)).method("add").withAnyArguments();
		String content = "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n" +
		"<opml version=\"1.0\">\n" +
		"<head><title>Harvester export</title></head>\n" +
		"  <body>\n" +
		"    <outline title=\"Agile Business Coach\" description=\"\" xmlUrl=\"http://abc.truemesh.com/index.rdf\" htmlUrl=\"\" />\n" +
		"    <outline title=\"http://adamconnor.org/index.rdf\" description=\"Adam Connor's Notebook\" xmlUrl=\"http://adamconnor.org/index.rdf\" htmlUrl=\"\" />\n" +
		"    <outline title=\"http://adamconnor.org/index.rdf\" description=\"Adam Connor's Notebook\" xmlUrl=\"http://adamconnor.org/index.rdf\" htmlUrl=\"\" />\n" +
		"    <outline title=\"http://advogato.org/person/chalst/rss.xml\" description=\"Advogato diary for chalst\" xmlUrl=\"http://advogato.org/person/chalst/rss.xml\" htmlUrl=\"\" />\n" +
		"  </body>\n" +
		"</opml>";
		final ByteArrayInputStream stream = new ByteArrayInputStream(content.getBytes());
		String fileName = "someFileName";
		
		OPMLImporter importer = new OPMLFileImporter(fileName, 
				(FeedStore) mockFeedStore.proxy(), (Summariser)mockSummariser.proxy()) {
			protected InputStream getContentStream() {
				return stream;
			}
		};
		importer.importFeeds();
		
		mockSummariser.verify();
		mockFeedStore.verify();
	}

	public void testExtractsCorrectNumberOfFeedUrlsTreatingUrlsCaseSensitively() {
		Mock mockSummariser = new Mock(Summariser.class);
		mockSummariser.expects(once()).method("feedImported").with(new HasSameUrlConstraint(abcFeed));
		mockSummariser.expects(atLeastOnce()).method("feedImported").with(new HasSameUrlConstraint(adamConnorFeed));
		mockSummariser.expects(once()).method("feedImported").with(new HasSameUrlConstraint(chalstFeed));
		mockSummariser.expects(exactly(4)).method("feedStored").withAnyArguments();
		
		Mock mockFeedStore = new Mock(FeedStore.class);
		mockFeedStore.stubs().method("urlExists").withAnyArguments().will(returnValue(false));
		mockFeedStore.expects(exactly(4)).method("add").withAnyArguments();
		String content = "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n" +
		"<opml version=\"1.0\">\n" +
		"<head><title>Harvester export</title></head>\n" +
		"  <body>\n" +
		"    <outline title=\"Agile Business Coach\" description=\"\" xmlUrl=\"http://abc.truemesh.com/index.rdf\" htmlUrl=\"\" />\n" +
		"    <outline title=\"http://adamconnor.org/index.rdf\" description=\"Adam Connor's Notebook\" xmlUrl=\"http://adamconnor.org/index.rdf\" htmlUrl=\"\" />\n" +
		"    <outline title=\"http://adamconnor.org/index.rdf\" description=\"Adam Connor's Notebook\" xmlUrl=\"HTTP://adamconnor.org/index.rdf\" htmlUrl=\"\" />\n" +
		"    <outline title=\"http://advogato.org/person/chalst/rss.xml\" description=\"Advogato diary for chalst\" xmlUrl=\"http://advogato.org/person/chalst/rss.xml\" htmlUrl=\"\" />\n" +
		"  </body>\n" +
		"</opml>";
		final ByteArrayInputStream stream = new ByteArrayInputStream(content.getBytes());
		String fileName = "someFileName";
		
		OPMLImporter importer = new OPMLFileImporter(fileName, 
				(FeedStore) mockFeedStore.proxy(), (Summariser)mockSummariser.proxy()) {
			protected InputStream getContentStream() {
				return stream;
			}
		};
		importer.importFeeds();
		
		mockSummariser.verify();
		mockFeedStore.verify();
	}

	public void testExtractsCorrectNumberOfFeedUrls() {
		Mock mockSummariser = new Mock(Summariser.class);
		mockSummariser.expects(once()).method("feedImported").with(new HasSameUrlConstraint(abcFeed));
		mockSummariser.expects(once()).method("feedImported").with(new HasSameUrlConstraint(adamConnorFeed));
		mockSummariser.expects(once()).method("feedImported").with(new HasSameUrlConstraint(chalstFeed));
		mockSummariser.expects(exactly(3)).method("feedStored").withAnyArguments();
		
		Mock mockFeedStore = new Mock(FeedStore.class);
		mockFeedStore.stubs().method("urlExists").withAnyArguments().will(returnValue(false));
		mockFeedStore.expects(exactly(3)).method("add").withAnyArguments();
		String content = "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n" +
		"<opml version=\"1.0\">\n" +
		"<head><title>Harvester export</title></head>\n" +
		"  <body>\n" +
		"    <outline title=\"Agile Business Coach\" description=\"\" xmlUrl=\"http://abc.truemesh.com/index.rdf\" htmlUrl=\"\" />\n" +
		"    <outline title=\"http://adamconnor.org/index.rdf\" description=\"Adam Connor's Notebook\" xmlUrl=\"http://adamconnor.org/index.rdf\" htmlUrl=\"\" />\n" +
		"    <outline title=\"http://advogato.org/person/chalst/rss.xml\" description=\"Advogato diary for chalst\" xmlUrl=\"http://advogato.org/person/chalst/rss.xml\" htmlUrl=\"\" />\n" +
		"  </body>\n" +
		"</opml>";
		final ByteArrayInputStream stream = new ByteArrayInputStream(content.getBytes());
		String fileName = "someFileName";
		
		OPMLImporter importer = new OPMLFileImporter(fileName, 
				(FeedStore) mockFeedStore.proxy(), (Summariser)mockSummariser.proxy()) {
			protected InputStream getContentStream() {
				return stream;
			}
		};
		importer.importFeeds();
		
		mockSummariser.verify();
		mockFeedStore.verify();
	}

	public void testImportsOnlyFeedsThatAreNotAlreadyInStore() {
		Mock mockSummariser = new Mock(Summariser.class);
		mockSummariser.expects(once()).method("feedImported").with(new HasSameUrlConstraint(abcFeed));
		mockSummariser.expects(once()).method("feedImported").with(new HasSameUrlConstraint(adamConnorFeed));
		mockSummariser.expects(once()).method("feedImported").with(new HasSameUrlConstraint(chalstFeed));
		mockSummariser.expects(once()).method("feedStored").withAnyArguments();
		mockSummariser.expects(once()).method("feedStored").withAnyArguments();
		
		Mock mockFeedStore = new Mock(FeedStore.class);
		mockFeedStore.expects(once()).method("urlExists").with(new HasSameUrlConstraint(abcFeed))
			.will(returnValue(false));
		mockFeedStore.expects(once()).method("urlExists").with(new HasSameUrlConstraint(adamConnorFeed))
			.will(returnValue(true));
		mockFeedStore.expects(once()).method("urlExists").with(new HasSameUrlConstraint(chalstFeed))
			.will(returnValue(false));
		
		mockFeedStore.expects(once()).method("add").with(new HasSameUrlConstraint(abcFeed));
		mockFeedStore.expects(once()).method("add").with(new HasSameUrlConstraint(chalstFeed));
		
		String content = "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n" +
		"<opml version=\"1.0\">\n" +
		"<head><title>Harvester export</title></head>\n" +
		"  <body>\n" +
		"    <outline title=\"Agile Business Coach\" description=\"\" xmlUrl=\"http://abc.truemesh.com/index.rdf\" htmlUrl=\"\" />\n" +
		"    <outline title=\"http://adamconnor.org/index.rdf\" description=\"Adam Connor's Notebook\" xmlUrl=\"http://adamconnor.org/index.rdf\" htmlUrl=\"\" />\n" +
		"    <outline title=\"http://advogato.org/person/chalst/rss.xml\" description=\"Advogato diary for chalst\" xmlUrl=\"http://advogato.org/person/chalst/rss.xml\" htmlUrl=\"\" />\n" +
		"  </body>\n" +
		"</opml>";
		final ByteArrayInputStream stream = new ByteArrayInputStream(content.getBytes());
		String fileName = "someFileName";
		
		OPMLImporter importer = new OPMLFileImporter(fileName, 
				(FeedStore) mockFeedStore.proxy(), (Summariser)mockSummariser.proxy()) {
			protected InputStream getContentStream() {
				return stream;
			}
		};
		importer.importFeeds();

		mockSummariser.verify();
		mockFeedStore.verify();
	}
	
	public void testImportsFeedsFromFilesContainingByteOrderMarker() throws Exception {
		Mock mockSummariser = new Mock(Summariser.class);
		mockSummariser.expects(exactly(29)).method("feedImported");
		mockSummariser.expects(exactly(29)).method("feedStored").withAnyArguments();
		Mock mockFeedStore = new Mock(FeedStore.class);
		mockFeedStore.stubs().method("urlExists").withAnyArguments().will(returnValue(false));
		mockFeedStore.expects(exactly(29)).method("add").withAnyArguments();
		
		OPMLImporter importer = new OPMLFileImporter("testData/exportedFeedsWithByteOrderMarker.opml", (FeedStore)mockFeedStore.proxy(), (Summariser)mockSummariser.proxy());
		importer.importFeeds();
		
		mockFeedStore.verify();
		mockSummariser.verify();
	}
	
	//FIXME find out how to make Xerces handle UTF-16
//	public void testImportsJonasGalvezOPMLFileFromBlogLines() throws Exception {
//		Mock mockSummariser = new Mock(Summariser.class);
//		mockSummariser.expects(exactly(298)).method("feedImported");
//		mockSummariser.expects(exactly(298)).method("feedStored").withAnyArguments();
//		Mock mockFeedStore = new Mock(FeedStore.class);
//		mockFeedStore.stubs().method("urlExists").withAnyArguments().will(returnValue(false));
//		mockFeedStore.expects(exactly(298)).method("add").withAnyArguments();
//		
//		OPMLImporter importer = new OPMLFileImporter("testData/jonasGalvez.opml", (FeedStore)mockFeedStore.proxy(), (Summariser)mockSummariser.proxy());
//		importer.importFeeds();
//		
//		mockFeedStore.verify();
//		mockSummariser.verify();
//	}
}
