package com.oshineye.aggrevator;

import java.io.IOException;

import com.oshineye.aggrevator.parsing.Location;

import junit.framework.TestCase;

/**
 * @author aoshineye
 *
 */
public class HttpLocationTest extends TestCase {
	public void testNullIsNotAValidUrl() {
		try {
			new HttpLocation(null, null, null);
			fail("Created location with a null url");
		} catch (InvalidUrlException e) {
			//ignore
		}
	}
	
	public void testEmptyStringIsNotAValidUrl() {
		try {
			new HttpLocation("", null, null);
			fail("Created location with an empty string as the url");
		} catch (InvalidUrlException e) {
			//ignore
		}
	}
	
	public void testEffectivelyEmptyStringIsNotAValidUrl() {
		try {
			new HttpLocation("      ", null, null);
			fail("Created location with an empty string as the url");
		} catch (InvalidUrlException e) {
			//ignore
		}
	}
	
	public void testUrlsAreTrimmedOfExcessWhiteSpace() {
		String url = "http://example.com/rss.xml";
		assertEquals(url, new HttpLocation("\t" +url + " ", null, null).getUrl());
	}
	
	public void testFeedURISyntaxGetsNormalisedAccordingToSpec() {
		//first 3 examples are taken from the specification at: http://www.25hoursaday.com/draft-obasanjo-feed-URI-scheme-02.html#rfc.section.3
		assertEquals("http://example.com/rss.xml", new HttpLocation("feed:http://example.com/rss.xml", null, null).getUrl());
		assertEquals("https://example.com/rss.xml", new HttpLocation("feed:https://example.com/rss.xml", null, null).getUrl());
		assertEquals("http://example.com/rss.xml", new HttpLocation("feed://example.com/rss.xml", null, null).getUrl());
		assertEquals("http://support.journurl.com/users/admin/index.cfm?template=rss&rssuser=5D53F295-3048-424F-429C567A44CA987D", new HttpLocation("feed:http://support.journurl.com/users/admin/index.cfm?template=rss&rssuser=5D53F295-3048-424F-429C567A44CA987D", null, null).getUrl());
	}
	
	public void testNormalisationHasNoEffectWhenFeedURISyntaxIsNotUsed() {
		String url = "http://example.com/rss.xml";
		assertEquals(url, new HttpLocation(url, null, null).getUrl());
	}
	
	public void testCanRollBackUrlEtagAndLastModifiedToOriginalValues() {
		String originalUrl = "originalUrl";
		String originalEtag = "originalEtag";
		String originalLastModified = "originalLastModified";
		Location location = new HttpLocation(originalUrl, originalEtag, originalLastModified);
		location.setUrl("newUrl");
		
		location.rollBack();
		
		assertEquals(originalUrl, location.getUrl());
		assertEquals(originalEtag, location.getEtag());
		assertEquals(originalLastModified , location.getLastModified ());
	}
	
	public void testServersThatDoNotSupportBothEtagAndLastModifiedAlwaysSeemToHaveNewContent() throws IOException {
		String url = "url";
		Location location = new HttpLocation(url, null, null);
		assertTrue(location.hasBeenModified());
	}
	
	public void testCommitingChangesToLocationMeansRollBackHasNoEffect() {
		String newUrl = "newUrl";
		String originalUrl = "originalUrl";
		String originalEtag = "originalEtag";
		String originalLastModified = "originalLastModified";
		Location location = new HttpLocation(originalUrl, originalEtag, originalLastModified);
		location.setUrl(newUrl);
		location.commit();
		
		assertTrue(location.isCommitted());
		assertEquals(newUrl, location.getUrl());
		
		location.rollBack();
		assertEquals(newUrl, location.getUrl());
		assertFalse(location.isCommitted());
		
		location.rollBack();
		assertEquals(newUrl, location.getUrl());
		assertFalse(location.isCommitted());
	}
	
	public void testChangesAreCommittedToLocationPropertiesImmediately() {
		String originalUrl = "originalUrl";
		Location location = new HttpLocation(originalUrl, null, null);
		String validUrl = "validUrl";
		location.setUrl(validUrl);
		location.commit();
		assertTrue(location.isCommitted());

		String invalidUrl = "url that is not valid";
		location.setUrl(invalidUrl);
		location.rollBack();
		assertFalse(location.isCommitted());
		assertEquals(validUrl, location.getUrl());
	}
}
