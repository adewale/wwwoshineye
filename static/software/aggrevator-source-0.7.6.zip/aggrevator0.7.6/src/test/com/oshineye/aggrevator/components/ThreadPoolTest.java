package com.oshineye.aggrevator.components;

import java.util.ArrayList;
import java.util.List;

import junit.framework.TestCase;

import com.mockobjects.dynamic.Mock;
import com.oshineye.aggrevator.Feed;
import com.oshineye.aggrevator.components.FeedModel;
import com.oshineye.aggrevator.components.ThreadPoolImpl;
import com.oshineye.aggrevator.components.tasks.Task;
import com.oshineye.aggrevator.store.EntryStore;
import com.oshineye.aggrevator.store.FeedStore;
import com.oshineye.aggrevator.store.StubFixture;
import com.oshineye.aggrevator.util.ThreadingUtils;

/**
 * @author aoshineye
 *
 */
public class ThreadPoolTest extends TestCase {
	
	public void testExecutingTaskTakesNoTime() {
		Mock mockFeedStore = new Mock(FeedStore.class);
		Mock mockEntryStore = new Mock(EntryStore.class);
		Mock mockFeedModel = new Mock(FeedModel.class);
		
		ThreadPoolImpl threadPool = new ThreadPoolImpl((FeedStore)mockFeedStore.proxy(), 
			(EntryStore)mockEntryStore.proxy(), (FeedModel)mockFeedModel.proxy());
		long startTime = System.currentTimeMillis();
		long duration = 1000 * 10;//wait 10 seconds
		
		threadPool.execute(new TimedTask(duration));
		
		assertTrue((System.currentTimeMillis() - startTime) < duration);
		mockFeedStore.verify();
		mockEntryStore.verify();
		mockFeedModel.verify();
	}

	public void testRefreshAllFeedsTakesNoTime() {
		final long duration = 1000 * 10;//wait 10 seconds
		List fakeFeeds = new ArrayList();
		fakeFeeds.add(StubFixture.getStubFeed());
		fakeFeeds.add(StubFixture.getStubFeed());
		fakeFeeds.add(StubFixture.getStubFeed());
		Mock mockFeedStore = new Mock(FeedStore.class);
		Mock mockEntryStore = new Mock(EntryStore.class);
		Mock mockFeedModel = new Mock(FeedModel.class);
		
		ThreadPoolImpl threadPool = new ThreadPoolImpl((FeedStore)mockFeedStore.proxy(), 
			(EntryStore)mockEntryStore.proxy(), (FeedModel)mockFeedModel.proxy()) {
			protected Runnable getFeedRefreshTask(Feed feed) {
				return new TimedTask(duration);
			}
		};
		
		long startTime = System.currentTimeMillis();
		threadPool.enqueue(fakeFeeds);
		
		assertTrue((System.currentTimeMillis() - startTime) < duration);
		mockFeedStore.verify();
		mockEntryStore.verify();
		mockFeedModel.verify();
	}

	public void testRefreshAllFeedsCreatesAndExecutesTaskPerFeed() throws Exception {
		final List fakeFeeds = new ArrayList();
		fakeFeeds.add(StubFixture.getStubFeedWithKeyAndUrl(new Long(1), StubFixture.TEST_URL));
		fakeFeeds.add(StubFixture.getStubFeedWithKeyAndUrl(new Long(2), StubFixture.TEST_URL2));
		fakeFeeds.add(StubFixture.getStubFeedWithKeyAndUrl(new Long(3), StubFixture.TEST_URL_CLONE_WITH_ONE_LESS_ENTRY));
		Mock mockFeedStore = new Mock(FeedStore.class);
		Mock mockEntryStore = new Mock(EntryStore.class);
		Mock mockFeedModel = new Mock(FeedModel.class);
		final int[] counter = new int[1];
		
		ThreadPoolImpl threadPool = new ThreadPoolImpl((FeedStore)mockFeedStore.proxy(), 
			(EntryStore)mockEntryStore.proxy(), (FeedModel)mockFeedModel.proxy()) {
			protected Runnable getFeedRefreshTask(Feed feed) {
				assertEquals(fakeFeeds.indexOf(feed), counter[0]);
				return null;
			}
			
			public void execute(Runnable task) {
				counter[0]++;
			}
		};
		threadPool.enqueue(fakeFeeds);
		
		assertEquals(fakeFeeds.size(), counter[0]);
		mockFeedStore.verify();
		mockEntryStore.verify();
		mockFeedModel.verify();
	}
	
	private static class TimedTask extends Task {
		private long timeToTake;

		public TimedTask(long timeToTake) {
			this.timeToTake = timeToTake;
		}

		public void doWork() {
			ThreadingUtils.sleep(timeToTake);
		}
	}
}
