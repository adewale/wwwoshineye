package com.oshineye.aggrevator.components.commands.worker.background;

import java.util.ArrayList;
import java.util.List;

import org.jmock.Mock;
import org.jmock.MockObjectTestCase;

import com.oshineye.aggrevator.Feed;
import com.oshineye.aggrevator.components.EntryModel;
import com.oshineye.aggrevator.components.StatusRecorder;
import com.oshineye.aggrevator.components.executors.DirectUIExecutor;
import com.oshineye.aggrevator.store.EntryStore;
import com.oshineye.aggrevator.store.StubFixture;

/**
 * @author aoshineye
 *
 */
public class LoadEntriesForFeedCommandTest extends MockObjectTestCase {
	public void testUpdatesEntryModelWithEntriesInSelectedFeed() {
		Feed feed = StubFixture.getStubFeed();
		
		List entriesInFeed = new ArrayList();
		Mock mockEntryStore = new Mock(EntryStore.class);
		mockEntryStore.expects(once()).method("findEntriesInFeed").
			with(eq(feed.getId())).will(returnValue(entriesInFeed));
		
		Mock mockEntryModel = new Mock(EntryModel.class);
		mockEntryModel.expects(once()).method("loadEntries").with(same(entriesInFeed));
		
		DirectUIExecutor directUIExecutor = new DirectUIExecutor();
		Mock mockStatusRecorder  = new Mock(StatusRecorder.class);
		mockStatusRecorder.expects(exactly(2)).method("setStatus").withAnyArguments();
		
		LoadEntriesForFeedCommand cmd = new LoadEntriesForFeedCommand(feed, 
			(EntryModel)mockEntryModel.proxy(), (EntryStore)mockEntryStore.proxy(),
			directUIExecutor, (StatusRecorder)mockStatusRecorder.proxy());
		cmd.run();
		
		mockEntryModel.verify();
		mockEntryStore.verify();
		mockStatusRecorder.verify();
	}
}
