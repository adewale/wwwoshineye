package com.oshineye.aggrevator.components;

import org.jmock.Mock;
import org.jmock.MockObjectTestCase;

import com.oshineye.aggrevator.Entry;
import com.oshineye.aggrevator.components.BrowserModel;
import com.oshineye.aggrevator.components.BrowserModelImpl;
import com.oshineye.aggrevator.components.BrowserObserver;
import com.oshineye.aggrevator.store.StubFixture;

/**
 * @author aoshineye
 *
 */
public class BrowserModelTest extends MockObjectTestCase {
	public void testModelNotifiesObserversOfLoadedEntry() {
		Entry entry = StubFixture.getStubEntry();
		Mock mockObserver = new Mock(BrowserObserver.class);
		mockObserver.expects(once()).method("notifyEntryLoaded").with(same(entry));
		Mock mockObserver2 = new Mock(BrowserObserver.class);
		mockObserver2.expects(once()).method("notifyEntryLoaded").with(same(entry));
		BrowserModel model = new BrowserModelImpl();
		model.addObserver((BrowserObserver) mockObserver.proxy());
		model.addObserver((BrowserObserver) mockObserver2.proxy());
		
		model.loadEntry(entry);
		
		mockObserver.verify();
		mockObserver2.verify();
	}
	
	public void testModelReturnsEntryLocationWhenGivenLocationIsAboutBlank() {
		Entry entry = StubFixture.getStubEntry();
		BrowserModel model = new BrowserModelImpl();
		model.loadEntry(entry);
		model.setLocation("about:blank");
		
		assertEquals(entry.getUrl(), model.getLocation());
	}
	
	public void testModelReturnsGivenLocationWhenGivenLocationIsNotAboutBlank() {
		Entry entry = StubFixture.getStubEntry();
		BrowserModel model = new BrowserModelImpl();
		model.loadEntry(entry);
		String expectedLocation = "not " + "about:blank";
		model.setLocation(expectedLocation);
		
		assertEquals(expectedLocation, model.getLocation());
	}
	
	public void testModelCanDetectWhenItIsAlreadyAtALocation() {
		Entry entry = StubFixture.getStubEntry();
		BrowserModel model = new BrowserModelImpl();
		model.loadEntry(entry);
		assertTrue(model.alreadyAtThisLocation(entry.getUrl()));
	}
	
	public void testModelCanDetectWhenItIsBeingNotifiedOfAVisitToALocationBecauseAnEntryWasJustLoaded() {
		Entry entry = StubFixture.getStubReadEntryWithPermaLinkAndFeedId("some permalink", new Long(-1));
		BrowserModel model = new BrowserModelImpl();
		model.loadEntry(entry);
		assertTrue(model.alreadyAtThisLocation(BrowserModelImpl.ABOUT_BLANK));
	}
	
	public void testCanDetectLocationsThatCanBeOpened() {
		//on start up
		BrowserModel model = new BrowserModelImpl();
		assertFalse("Location can be opened even if there's no entry or location yet", model.locationCanBeOpened());
		
		//select entry with blank url
		Entry blankEntry = StubFixture.getStubReadEntryWithPermaLinkAndFeedId(BrowserModel.ABOUT_BLANK, new Long(-1));
		model.loadEntry(blankEntry);
		model.setLocation(BrowserModel.ABOUT_BLANK);
		assertEquals(BrowserModel.ABOUT_BLANK, model.getLocation());
		assertFalse(model.locationCanBeOpened());
		
		//click on link
		model.setLocation("some valid url on the web");
		assertTrue(model.locationCanBeOpened());
		
		//select entry with no link
		Entry noLinkEntry = StubFixture.getStubReadEntryWithPermaLinkAndFeedId(Entry.NO_LINK, new Long(-1));
		model.loadEntry(noLinkEntry);
		model.setLocation(Entry.NO_LINK);
		assertEquals(Entry.NO_LINK, model.getLocation());
		assertFalse(model.locationCanBeOpened());
	}
}
