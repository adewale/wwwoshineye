package com.oshineye.aggrevator.store;

import com.oshineye.aggrevator.QueryLoaderFactory;
import com.oshineye.aggrevator.db.ConnectionPool;
import com.oshineye.aggrevator.db.ConnectionPoolFactory;
import com.oshineye.aggrevator.db.JdbcProcessFactory;
import com.oshineye.aggrevator.util.QueryLoader;


/**
 * @author aoshineye
 */
public class MySqlFeedStoreTest extends AbstractFeedStoreTest {
	protected EntryStore createEntryStore() {
		return StubFixture.getEntryStore();
	}

	protected FeedStore createFeedStore() {
		return StubFixture.getFeedStore();
	}

	public void testFeedIdentityMapIsPopulatedByFirstCallToFindAllFeeds() {
		FeedIdentityMap map = new FeedIdentityMap();
		
		ConnectionPool connectionPool = ConnectionPoolFactory.getConnectionPool(StubFixture.TEST_DATABASE_NAME);
		JdbcProcessFactory processFactory = new JdbcProcessFactory(connectionPool);
		
		QueryLoader queryLoader = QueryLoaderFactory.createQueryLoader();
		FeedStore mySqlFeedStore = new MySqlFeedStore(processFactory, map, queryLoader);
		assertFalse(map.isPopulated());
		
		mySqlFeedStore.findAllFeeds();
		assertTrue(map.isPopulated());
	}
	
}
