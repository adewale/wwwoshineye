package com.oshineye.aggrevator.store.entry;

import java.util.ArrayList;
import java.util.List;

import junit.framework.TestCase;

import com.oshineye.aggrevator.Entry;
import com.oshineye.aggrevator.EntryContentService;
import com.oshineye.aggrevator.Feed;
import com.oshineye.aggrevator.QueryLoaderFactory;
import com.oshineye.aggrevator.TunnellingException;
import com.oshineye.aggrevator.store.EntryStore;
import com.oshineye.aggrevator.store.FeedStore;
import com.oshineye.aggrevator.store.StubFixture;

/**
 * @author aoshineye
 *
 */
public class MySqlEntryContentServiceTest extends TestCase {
	public void testFetchesContentForSpecifiedEntryId() {
		Feed feed = StubFixture.getStubFeed();
		FeedStore feedStore = StubFixture.getFeedStore();
		feedStore.add(feed);
		
		String content = "some content";
		Entry entry = StubFixture.getStubEntryWithIdFeedIdAndContent(-1, feed.getId(), content);
		List entries = new ArrayList();
		entries.add(entry);
		EntryStore entryStore = StubFixture.getEntryStore();
		entryStore.addEntries(entries);
		List retrievedEntries = entryStore.findEntriesInFeed(entry.getFeedId());
		Entry fetchedEntry = (Entry) retrievedEntries.get(0);
		
		EntryContentService service = new MySqlEntryContentService(StubFixture.PROCESS_FACTORY, QueryLoaderFactory.createQueryLoader());
		assertEquals(content, service.getContent(fetchedEntry.getId()));
	}
	
	public void testThrowsExceptionWhenGivenNonExistentEntryId() {
		EntryContentService service = new MySqlEntryContentService(StubFixture.PROCESS_FACTORY, QueryLoaderFactory.createQueryLoader());
		try {
			service.getContent(new Long(Long.MIN_VALUE));
			fail("Did not throw an exception when asked to get content of a non-existent entry");
		} catch (TunnellingException e) {
			//expected
		}
	}

}
