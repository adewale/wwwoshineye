package com.oshineye.aggrevator.util;

import org.apache.commons.lang.StringUtils;

import junit.framework.TestCase;

/**
 * @author aoshineye
 *
 */
public class QueryLoaderTest extends TestCase {
	public void testRemovesEntryContentFromEntryRetrievalQueries() {
		QueryLoader queryLoader = new QueryLoader() {
			protected boolean isLazyLoading() {
				return false;
			}
		};
		String entryContentClause = "entry.content";
		assertTrue(StringUtils.contains(queryLoader.getQuery("GET_ENTRIES_IN_FEED"), entryContentClause));
		assertTrue(StringUtils.contains(queryLoader.getQuery("GET_MULTIPLE_ENTRIES"), entryContentClause));
		assertTrue(StringUtils.contains(queryLoader.getQuery("GET_MULTIPLE_ENTRIES_IN_FEED"), entryContentClause));
		
		queryLoader = new QueryLoader() {
			protected boolean isLazyLoading() {
				return true;
			}
		};
		
		String lazyEntryContentClause = "'' as content";
		assertTrue(StringUtils.contains(queryLoader.getQuery("GET_ENTRIES_IN_FEED"), lazyEntryContentClause));
		assertTrue(StringUtils.contains(queryLoader.getQuery("GET_MULTIPLE_ENTRIES"), lazyEntryContentClause));
		assertTrue(StringUtils.contains(queryLoader.getQuery("GET_MULTIPLE_ENTRIES_IN_FEED"), lazyEntryContentClause));
	}
}
