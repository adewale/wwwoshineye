package com.oshineye.aggrevator;

import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;

import com.oshineye.aggrevator.parsing.ParserFactory;

public class StubFeed extends FeedImpl {
	private static final class StubLocation extends HttpLocation {
		private final String fileName;

		private StubLocation(String url, String etag, String lastModified, String fileName) {
			super(url, etag, lastModified);
			this.fileName = fileName;
		}

		public Reader createReader() throws IOException {
			return new FileReader(TEST_DATA_FOLDER + fileName);
		}
	}

	private static final String TEST_DATA_FOLDER = "testData";

    public StubFeed(Long id, String title, String url, int score) {
    	super(id, url, title, 0, score, ParserFactory.createFeedParser(), createLocation(url, "etag", "lastModified"));
	}
	
	public StubFeed(String url) {
		super(Feed.PLACE_HOLDER_ID, url, Feed.NO_TITLE, 0, 0, ParserFactory.createFeedParser(), createLocation(url, "etag", "lastModified"));
	}
	
	public StubFeed(Long id, String url) {
	    super(id, url, Feed.NO_TITLE, 0, 0, ParserFactory.createFeedParser(), createLocation(url, "etag", "lastModified"));
    }
	
    public StubFeed(Long id, String title, String url) {
        super(id, url, title, 0, 0, ParserFactory.createFeedParser(), createLocation(url, "etag", "lastModified"));
    }
	
	public StubFeed(String url, int unreadEntriesCount, int score) {
		super(Feed.PLACE_HOLDER_ID, url, "title", unreadEntriesCount, score, ParserFactory.createFeedParser(), createLocation(url, null, null));
	}

	public StubFeed(String url, String title, int unreadEntriesCount, int score) {
		super(Feed.PLACE_HOLDER_ID, url, title, unreadEntriesCount, score, ParserFactory.createFeedParser(), createLocation(url, null, null));
	}

	public StubFeed(Feed feed) {
		super(Feed.PLACE_HOLDER_ID, feed.getUrl(), feed.getTitle(), feed.getUnreadEntriesCount(),
			feed.getScore(), ParserFactory.createFeedParser(), createLocation(feed.getUrl(), feed.getEtag(), feed.getLastModified()));
	}

	public StubFeed(Long id, String title, String url, String etag, String lastModified) {
		super(id, url, title, 0, 0, ParserFactory.createFeedParser(), createLocation(url, etag, lastModified));
	}

	protected static HttpLocation createLocation(String locationUrl, String locationEtag, String locationLastModified) {
		final String fileName = convertToLocalFileName(locationUrl);
		return new StubLocation(locationUrl, locationEtag, locationLastModified, fileName);
	}

	private static String convertToLocalFileName(String locationUrl) {
		int lastSlashPosition = locationUrl.lastIndexOf("/");
		if (lastSlashPosition < 0) {
			//dummy file name that isn't meant to be used
			//returning null means that attempts to use this filename will fail-fast
			return null;
		}
		String fileName = locationUrl.substring(lastSlashPosition);
		return fileName;
	}
	
	public boolean hasChanged() {
		return true;
	}
}