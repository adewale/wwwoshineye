package com.oshineye.aggrevator.components.tasks;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.jmock.Mock;
import org.jmock.MockObjectTestCase;

import com.oshineye.aggrevator.Feed;
import com.oshineye.aggrevator.InvalidFeedException;
import com.oshineye.aggrevator.RefreshInProgressException;
import com.oshineye.aggrevator.components.EntryModel;
import com.oshineye.aggrevator.components.FeedModel;
import com.oshineye.aggrevator.store.EntryStore;
import com.oshineye.aggrevator.store.FeedStore;
import com.oshineye.aggrevator.store.StubFixture;

/**
 * @author aoshineye
 *
 */
public class RefreshFeedTaskTest extends MockObjectTestCase {
	public RefreshFeedTaskTest() {
		//turn off logging for this testcase so that we don't clutter the test output
		Logger.getLogger(RefreshFeedTask.class).setLevel(Level.OFF);
	}

	public void testUpdatesOnlyTheFeedStoreWhenNewEntriesListIsEmpty() {
		Mock mockFeed = new Mock(Feed.class);
		mockFeed.expects(once()).method("setRefreshStarted");
		mockFeed.expects(once()).method("toString").will(returnValue("MockFeed"));
		mockFeed.expects(exactly(2)).method("getUnreadEntriesCount").will(returnValue(0));
		mockFeed.expects(once()).method("hasChanged").will(returnValue(true));
		mockFeed.expects(once()).method("fetchNewEntries").with(NOT_NULL).will(returnValue(Collections.EMPTY_LIST));
		mockFeed.expects(once()).method("setRefreshFinished");
		
		Mock mockFeedStore = new Mock(FeedStore.class);
		mockFeedStore.expects(once()).method("update");

		Mock mockEntryStore = new Mock(EntryStore.class);

		Mock mockFeedModel = new Mock(FeedModel.class);
		mockFeedModel.expects(exactly(2)).method("refreshFeed");

		Mock mockEntryModel = new Mock(EntryModel.class);
		
		RefreshFeedTask task = new RefreshFeedTask((Feed)mockFeed.proxy(), (FeedStore) mockFeedStore.proxy(), 
			(EntryStore)mockEntryStore.proxy(), (FeedModel)mockFeedModel.proxy(), (EntryModel)mockEntryModel.proxy());

		task.run();
		
		mockFeedStore.verify();
		mockFeedModel.verify();
		mockFeed.verify();
	}
	
	public void testDoesNothingToStoresWhenFeedHasNotChanged() {		
		Mock mockFeed = new Mock(Feed.class);
		mockFeed.expects(once()).method("setRefreshStarted");
		mockFeed.expects(once()).method("toString").will(returnValue("MockFeed"));
		mockFeed.expects(exactly(2)).method("getUnreadEntriesCount").will(returnValue(0));
		mockFeed.expects(once()).method("hasChanged").will(returnValue(false));
		mockFeed.expects(once()).method("setRefreshFinished");
		
		Mock mockFeedStore = new Mock(FeedStore.class);
		Mock mockEntryStore = new Mock(EntryStore.class);

		Mock mockFeedModel = new Mock(FeedModel.class);
		mockFeedModel.expects(exactly(2)).method("refreshFeed");
		
		Mock mockEntryModel = new Mock(EntryModel.class);
		
		RefreshFeedTask task = new RefreshFeedTask((Feed)mockFeed.proxy(), (FeedStore) mockFeedStore.proxy(), 
			(EntryStore)mockEntryStore.proxy(), (FeedModel)mockFeedModel.proxy(), (EntryModel)mockEntryModel.proxy());

		task.run();
		
		mockFeedModel.verify();
		mockFeed.verify();
	}
	
	public void testDoesNothingToStoresWhenFeedHasNotChangedBecauseExceptionThrown() {		
		Mock mockFeed = new Mock(Feed.class);
		mockFeed.expects(once()).method("setRefreshStarted");
		mockFeed.expects(exactly(3)).method("toString").will(returnValue("MockFeed"));
		mockFeed.expects(exactly(2)).method("getUnreadEntriesCount").will(returnValue(0));
		mockFeed.expects(once()).method("hasChanged").will(throwException(new IOException()));
		mockFeed.expects(once()).method("setRefreshFinished");
		
		Mock mockFeedStore = new Mock(FeedStore.class);
		Mock mockEntryStore = new Mock(EntryStore.class);

		Mock mockFeedModel = new Mock(FeedModel.class);
		mockFeedModel.expects(exactly(2)).method("refreshFeed");
		
		Mock mockEntryModel = new Mock(EntryModel.class);

		RefreshFeedTask task = new RefreshFeedTask((Feed)mockFeed.proxy(), (FeedStore) mockFeedStore.proxy(), 
			(EntryStore)mockEntryStore.proxy(), (FeedModel)mockFeedModel.proxy(), (EntryModel)mockEntryModel.proxy());
		
		task.run();
		
		mockFeedModel.verify();
		mockFeed.verify();
	}
	
	public void testDoesNothingToStoresOrModelsIfRefreshInProgress() throws RefreshInProgressException {		
		Feed feed = StubFixture.getStubFeed();
		feed.setRefreshStarted();
		
		Mock mockFeedStore = new Mock(FeedStore.class);
		Mock mockEntryStore = new Mock(EntryStore.class);
		Mock mockFeedModel = new Mock(FeedModel.class);
		Mock mockEntryModel = new Mock(EntryModel.class);
		
		RefreshFeedTask task = new RefreshFeedTask(feed, (FeedStore) mockFeedStore.proxy(), 
			(EntryStore)mockEntryStore.proxy(), (FeedModel)mockFeedModel.proxy(), (EntryModel)mockEntryModel.proxy());

		task.run();
		
		mockFeedStore.verify();
		mockEntryStore.verify();
		mockFeedModel.verify();
		mockEntryModel.verify();
	}
	
	public void testAddsEntriesToEntryStoreWhenNewEntriesListHasContent() {
		List newEntries = new ArrayList();
		newEntries.add(StubFixture.getStubEntry());
		
		Mock mockFeed = new Mock(Feed.class);
		mockFeed.expects(once()).method("setRefreshStarted");
		mockFeed.expects(exactly(2)).method("toString").will(returnValue("MockFeed"));
		mockFeed.expects(exactly(2)).method("getUnreadEntriesCount").will(returnValue(0));
		mockFeed.expects(once()).method("hasChanged").will(returnValue(true));
		mockFeed.expects(once()).method("fetchNewEntries").with(NOT_NULL).will(returnValue(newEntries));
		mockFeed.expects(once()).method("setRefreshFinished");
		
		Mock mockFeedStore = new Mock(FeedStore.class);
		mockFeedStore.expects(once()).method("reconcile");
		Mock mockEntryStore = new Mock(EntryStore.class);
		mockEntryStore.expects(once()).method("addEntries").with(same(newEntries));
		
		Mock mockFeedModel = new Mock(FeedModel.class);
		mockFeedModel.expects(exactly(2)).method("refreshFeed").with(NOT_NULL);
		mockFeedModel.expects(once()).method("isSelected").with(NOT_NULL).will(returnValue(false));

		Mock mockEntryModel = new Mock(EntryModel.class);
		
		RefreshFeedTask task = new RefreshFeedTask((Feed)mockFeed.proxy(), (FeedStore) mockFeedStore.proxy(), 
			(EntryStore)mockEntryStore.proxy(), (FeedModel)mockFeedModel.proxy(), (EntryModel)mockEntryModel.proxy());

		task.run();
		
		mockFeedStore.verify();
		mockEntryStore.verify();
		mockFeedModel.verify();
		mockFeed.verify();
	}
	
	public void testLoadsNewEntriesIntoEntryModelWhenNewEntriesListHasContentFromSelectedFeed() {		
		List entriesInStore = new ArrayList();
		List newEntries = new ArrayList();
		newEntries.add(StubFixture.getStubEntry());
		List finalEntries = new ArrayList();
		finalEntries.addAll(entriesInStore);
		finalEntries.addAll(newEntries);
		
		Mock mockFeed = new Mock(Feed.class);
		mockFeed.expects(once()).method("setRefreshStarted");
		mockFeed.expects(exactly(2)).method("toString").will(returnValue("MockFeed"));
		mockFeed.expects(exactly(2)).method("getUnreadEntriesCount").will(returnValue(0));
		mockFeed.expects(once()).method("hasChanged").will(returnValue(true));
		mockFeed.expects(once()).method("fetchNewEntries").with(NOT_NULL).will(returnValue(newEntries));
		mockFeed.expects(once()).method("getId").will(returnValue(new Long(1)));
		mockFeed.expects(once()).method("setRefreshFinished");
		
		Mock mockFeedStore = new Mock(FeedStore.class);
		mockFeedStore.expects(once()).method("reconcile");
		Mock mockEntryStore = new Mock(EntryStore.class);
		mockEntryStore.expects(once()).method("findEntriesInFeed").with(NOT_NULL).will(returnValue(finalEntries));
		mockEntryStore.expects(once()).method("addEntries").with(same(newEntries));
		
		Mock mockFeedModel = new Mock(FeedModel.class);
		mockFeedModel.expects(exactly(2)).method("refreshFeed").with(NOT_NULL);
		mockFeedModel.expects(once()).method("isSelected").with(eq(mockFeed.proxy())).will(returnValue(true));

		Mock mockEntryModel = new Mock(EntryModel.class);
		mockEntryModel.expects(once()).method("loadEntries").with(eq(finalEntries));
		
		RefreshFeedTask task = new RefreshFeedTask((Feed)mockFeed.proxy(), (FeedStore) mockFeedStore.proxy(), 
			(EntryStore)mockEntryStore.proxy(), (FeedModel)mockFeedModel.proxy(), (EntryModel)mockEntryModel.proxy());

		task.run();
		
		mockFeedStore.verify();
		mockEntryStore.verify();
		mockFeedModel.verify();
		mockEntryModel.verify();
		mockFeed.verify();
	}
	
	public void testReconcilesFeedStoreWhenNewEntriesListHasContent() {
		List newEntries = new ArrayList();
		newEntries.add(StubFixture.getStubEntry());
		
		Mock mockFeed = new Mock(Feed.class);
		mockFeed.expects(once()).method("setRefreshStarted");
		mockFeed.expects(exactly(2)).method("toString").will(returnValue("MockFeed"));
		mockFeed.expects(exactly(2)).method("getUnreadEntriesCount").will(returnValue(0));
		mockFeed.expects(once()).method("hasChanged").will(returnValue(true));
		mockFeed.expects(once()).method("fetchNewEntries").with(NOT_NULL).will(returnValue(newEntries));
		mockFeed.expects(once()).method("setRefreshFinished");
		
		Mock mockFeedStore = new Mock(FeedStore.class);
		mockFeedStore.expects(once()).method("reconcile");
		Mock mockEntryStore = new Mock(EntryStore.class);
		mockEntryStore.expects(once()).method("addEntries").with(same(newEntries));
		
		Mock mockFeedModel = new Mock(FeedModel.class);
		mockFeedModel.expects(exactly(2)).method("refreshFeed").with(NOT_NULL);
		mockFeedModel.expects(once()).method("isSelected").with(NOT_NULL).will(returnValue(false));

		Mock mockEntryModel = new Mock(EntryModel.class);
		
		RefreshFeedTask task = new RefreshFeedTask((Feed)mockFeed.proxy(), (FeedStore) mockFeedStore.proxy(), 
			(EntryStore)mockEntryStore.proxy(), (FeedModel)mockFeedModel.proxy(), (EntryModel)mockEntryModel.proxy());

		task.run();
		
		mockFeedStore.verify();
		mockEntryStore.verify();
		mockFeedModel.verify();
		mockFeed.verify();
	}
	
	public void testDoesNotReconcileFeedStoreOrAddEntriesIfFeedIsInvalid() {
		Mock mockFeed = new Mock(Feed.class);
		mockFeed.expects(once()).method("setRefreshStarted");
		mockFeed.expects(exactly(2)).method("toString").will(returnValue("MockFeed"));
		mockFeed.expects(exactly(2)).method("getUnreadEntriesCount").will(returnValue(0));
		mockFeed.expects(once()).method("hasChanged").will(returnValue(true));
		mockFeed.expects(once()).method("fetchNewEntries").with(ANYTHING).will(throwException(new InvalidFeedException(new Exception())));
		mockFeed.expects(once()).method("rollBack");
		mockFeed.expects(once()).method("setRefreshFinished");
		
		Mock mockFeedStore = new Mock(FeedStore.class);
		Mock mockEntryStore = new Mock(EntryStore.class);
		Mock mockFeedModel = new Mock(FeedModel.class);
		mockFeedModel.expects(exactly(2)).method("refreshFeed").with(NOT_NULL);
		Mock mockEntryModel = new Mock(EntryModel.class);
		
		RefreshFeedTask task = new RefreshFeedTask((Feed)mockFeed.proxy(), (FeedStore) mockFeedStore.proxy(), 
			(EntryStore)mockEntryStore.proxy(), (FeedModel)mockFeedModel.proxy(), (EntryModel)mockEntryModel.proxy());

		task.run();
		
		mockFeedStore.verify();
		mockEntryStore.verify();
		mockFeedModel.verify();
		mockEntryModel.verify();
		mockFeed.verify();
	}
}
