package com.oshineye.aggrevator;

import junit.framework.TestCase;

/**
 * @author aoshineye
 *
 */
public class FeedRecordTest extends TestCase {
	public void testCanDetectEquivalenceWhenEtagIsNull() {
		FeedRecord record = FeedFactory.createFeedRecordFromStore(99, "some url", "some title", null, "some last modified");
		Feed feed = FeedFactory.createFeedFromStore(99, "some url", "some title", 0, 0, null, "some last modified");
		assertTrue(record.isEquivalent(feed));
	}
	
	public void testCanDetectEquivalenceWhenLastModifiedIsNull() {
		FeedRecord record = FeedFactory.createFeedRecordFromStore(99, "some url", "some title", "some etag", null);
		Feed feed = FeedFactory.createFeedFromStore(99, "some url", "some title", 0, 0, "some etag", null);
		assertTrue(record.isEquivalent(feed));
	}
	
	public void testCanDetectEquivalenceWhenFeedHasEscapedTitle() {
		String escapedTitle = "title &amp; title";
		FeedRecord record = FeedFactory.createFeedRecordFromStore(99, "some url", escapedTitle, "some etag", null);
		Feed feed = FeedFactory.createFeedFromStore(99, "some url", escapedTitle, 0, 0, "some etag", null);
		assertTrue(record.isEquivalent(feed));
	}
	
	public void testCanDetectEquivalenceWhenFeedHasUnescapedTitleFromNullToBlank() {
		FeedRecord record = FeedFactory.createFeedRecordFromStore(99, "some url", "", "some etag", null);
		Feed feed = FeedFactory.createFeedFromStore(99, "some url", null, 0, 0, "some etag", null);
		assertEquals(feed.getTitle(), record.getTitle());
		assertTrue(record.isEquivalent(feed));
	}
	
	public void testCanDetectEquivalenceWhenFeedHasTitleThatContainsIllegalHtmlEntities() {
		String titleWithIllegalHtmlEntities = "title &amp; title&#x92;";
		FeedRecord record = FeedFactory.createFeedRecordFromStore(99, "some url", titleWithIllegalHtmlEntities, "some etag", null);
		Feed feed = FeedFactory.createFeedFromStore(99, "some url", titleWithIllegalHtmlEntities, 0, 0, "some etag", null);
		assertTrue(record.isEquivalent(feed));
	}
	
	public void testCanDetectEquivalenceWhenFeedHasNoTitleBecauseItHasNeverBeenRefreshed() {
		String title = Feed.NO_TITLE;
		FeedRecord record = FeedFactory.createFeedRecordFromStore(Feed.PLACE_HOLDER_ID.longValue(), "some url", title, null, null);
		Feed feed = FeedFactory.createFeedFromUrl("some url");
		assertEquals(Feed.NO_TITLE, feed.getTitle());
		assertEquals(feed.getTitle(), record.getTitle());
		assertTrue(record.isEquivalent(feed));
	}
	
	public void testDetectsEquivalenceDespiteTitles() {
		String title = "title";
		String differentTitle = "different title";
		FeedRecord record = FeedFactory.createFeedRecordFromStore(99, "some url", title, "some etag", null);
		Feed feed = FeedFactory.createFeedFromStore(99, "some url", differentTitle, 0, 0, "some etag", null);
		
		//this is only done because some feeds have
		assertTrue(record.isEquivalent(feed));
	}
}
