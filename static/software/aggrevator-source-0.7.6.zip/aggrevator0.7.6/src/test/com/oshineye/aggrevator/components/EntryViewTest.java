package com.oshineye.aggrevator.components;

import java.util.ArrayList;
import java.util.List;

import junit.framework.TestCase;

import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;

import com.mockobjects.dynamic.C;
import com.mockobjects.dynamic.Mock;
import com.oshineye.aggrevator.components.Block;
import com.oshineye.aggrevator.components.EntryModel;
import com.oshineye.aggrevator.components.EntryView;
import com.oshineye.aggrevator.components.EntryViewImpl;
import com.oshineye.aggrevator.store.StubFixture;


public class EntryViewTest extends TestCase {
	public void testViewRegistersAsObserverOnModel() {
		Mock mockModel = new Mock(EntryModel.class);
		mockModel.expect("addObserver", C.IS_NOT_NULL);
		new EntryViewImpl((EntryModel) mockModel.proxy());
		
		mockModel.verify();
	}
	
	public void testEntriesLoadedEventPopulatesViewsTable() {
		final List entries = new ArrayList();
		entries.add(StubFixture.getStubEntry());
		Mock mockModel = new Mock(EntryModel.class);
		mockModel.expect("addObserver", C.IS_NOT_NULL);
		mockModel.expectAndReturn("getSelectedEntryIndex", -1);
		
		final MyApplicationWindow window = new MyApplicationWindow((EntryModel) mockModel.proxy());
		window.execute(new Block() {
			public void execute() {
				EntryView view = window.getView();
				view.notifyEntriesLoaded(entries);
			}
		});
		
		mockModel.verify();
	}

	public void testEntriesLoadedEventPopulatesViewsTableByReplacingAllExistingItems() {
		final List firstEntries = new ArrayList();
		firstEntries.add(StubFixture.getStubEntry());
		
		final String otherEntryTitle = "Another entry title";
		final List secondEntries = new ArrayList();
		secondEntries.add(StubFixture.getStubEntry(2, otherEntryTitle));
		
		Mock mockModel = new Mock(EntryModel.class);
		mockModel.expect("addObserver", C.IS_NOT_NULL);
		mockModel.expectAndReturn("getSelectedEntryIndex", -1);
		mockModel.expectAndReturn("getSelectedEntryIndex", -1);
		
		final MyApplicationWindow window = new MyApplicationWindow((EntryModel) mockModel.proxy());
		
		window.execute(new Block() {
			public void execute() {
				EntryView view = window.getView();
				view.notifyEntriesLoaded(firstEntries);
				view.notifyEntriesLoaded(secondEntries);

				assertEquals(1, view.getItemCount());
			}
		});
		
		mockModel.verify();
	}
	
	private static class MyApplicationWindow extends StubApplicationWindow {
		private EntryView view;
		private EntryModel model;
		
		protected Control createContents(Composite parent) {
			view = new EntryViewImpl(model, parent);
			return null;										
		}

		public EntryView getView() {
			return view;
		}

		public MyApplicationWindow(EntryModel model) {
			this.model = model;
		}
	}
}
