package com.oshineye.aggrevator.store;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.jmock.Mock;
import org.jmock.MockObjectTestCase;

import com.oshineye.aggrevator.Feed;
import com.oshineye.aggrevator.FeedFactory;
import com.oshineye.aggrevator.FeedImpl;
import com.oshineye.aggrevator.FeedRecord;
import com.oshineye.aggrevator.HttpLocation;
import com.oshineye.aggrevator.parsing.Location;
import com.oshineye.aggrevator.parsing.ParserFactory;
import com.oshineye.aggrevator.util.XStreamFactory;
import com.thoughtworks.xstream.XStream;
import com.thoughtworks.xstream.converters.ConversionException;

/**
 * @author aoshineye
 *
 */
public class XStreamCacheTest extends MockObjectTestCase{
	
	private File emptyFile;
	private File populatedFile;
	private File tempFile;
	
	public void testCacheIsInconstentIfCachedListSmallerThanStoredRecordList() throws Exception {
		populatedFile = File.createTempFile("tempFile", "tmp");
		List cachedFeeds = StubFixture.createFeedList();
		populateFile(cachedFeeds, populatedFile);
		
		List records = new ArrayList();
		records.add(FeedFactory.createFeedRecordFromStore(999, "some url", "some title", "some etag", "some last modified"));
		records.add(FeedFactory.createFeedRecordFromStore(9999, "some url", "some title", "some etag", "some last modified"));
		Mock mockFeedFinder = new Mock(FeedFinder.class);
		mockFeedFinder.expects(once()).method("findAllFeedRecords").will(returnValue(records));
		
		//because cache is inconsistent
		mockFeedFinder.expects(once()).method("findAllFeeds").will(returnValue(Collections.EMPTY_LIST));
		
		XStreamCache cache = new XStreamCache(populatedFile, (FeedFinder)mockFeedFinder.proxy());
		mockFeedFinder.verify();
		assertSame(Collections.EMPTY_LIST, cache.getFeeds());
	}
	
	public void testCacheIsInconstentIfCachedListBiggerThanStoredRecordList() throws Exception {
		populatedFile = File.createTempFile("tempFile", "tmp");
		List cachedFeeds = StubFixture.createFeedList();
		populateFile(cachedFeeds, populatedFile);
		
		Mock mockFeedFinder = new Mock(FeedFinder.class);
		mockFeedFinder.expects(once()).method("findAllFeedRecords").will(returnValue(Collections.EMPTY_LIST));
		
		//because cache is inconsistent
		mockFeedFinder.expects(once()).method("findAllFeeds").will(returnValue(Collections.EMPTY_LIST));
		
		XStreamCache cache = new XStreamCache(populatedFile, (FeedFinder)mockFeedFinder.proxy());
		mockFeedFinder.verify();
		assertSame(Collections.EMPTY_LIST, cache.getFeeds());
	}
	
	public void testCacheIsConsistentIfFeedaHaveEquivalentRecordsAndSizesAreEqual() throws Exception {
		populatedFile = File.createTempFile("tempFile", "tmp");
		List cachedFeeds = new ArrayList();
		cachedFeeds.add(FeedFactory.createFeedFromStore(999, "some url", "some title",0, 0, "some etag", "some last modified"));
		populateFile(cachedFeeds, populatedFile);
		
		List records = new ArrayList();
		records.add(FeedFactory.createFeedRecordFromStore(999, "some url", "some title", "some etag", "some last modified"));
		Mock mockFeedFinder = new Mock(FeedFinder.class);
		mockFeedFinder.expects(once()).method("findAllFeedRecords").will(returnValue(records));
		
		XStreamCache cache = new XStreamCache(populatedFile, (FeedFinder)mockFeedFinder.proxy());
		mockFeedFinder.verify();
		assertEquals(cachedFeeds, cache.getFeeds());
	}
	
	public void testCacheIsInconsistentIfFeedHasNoEquivalentRecordButSizesAreEqual() throws Exception {
		populatedFile = File.createTempFile("tempFile", "tmp");
		List cachedFeeds = StubFixture.createFeedList();
		cachedFeeds.add(StubFixture.getStubFeedWithKeyAndUrl(new Long(1111), "some unique url"));
		populateFile(cachedFeeds, populatedFile);
		
		List records = new ArrayList();
		FeedRecord record = FeedFactory.createFeedRecordFromStore(999, "some url", "some title", "some etag", "some last modified");
		records.add(record);
		records.add(record);
		Mock mockFeedFinder = new Mock(FeedFinder.class);
		mockFeedFinder.expects(once()).method("findAllFeedRecords").will(returnValue(records));
		
		//because cache is inconsistent
		mockFeedFinder.expects(once()).method("findAllFeeds").will(returnValue(Collections.EMPTY_LIST));
		
		XStreamCache cache = new XStreamCache(populatedFile, (FeedFinder)mockFeedFinder.proxy());
		mockFeedFinder.verify();
		assertSame(Collections.EMPTY_LIST, cache.getFeeds());
	}
	
	public void testCacheIsInconsistentIfRecordHasNoEquivalentFeedButSizesAreEqual() throws Exception {
		populatedFile = File.createTempFile("tempFile", "tmp");
		List cachedFeeds = StubFixture.createFeedList();
		cachedFeeds.add(cachedFeeds.get(0));
		populateFile(cachedFeeds, populatedFile);
		
		List records = new ArrayList();
		records.add(FeedFactory.createFeedRecordFromStore(999, "some url", "some title", "some etag", "some last modified"));
		records.add(FeedFactory.createFeedRecordFromStore(999, "some other url", "some other title", "some other etag", "some other last modified"));
		Mock mockFeedFinder = new Mock(FeedFinder.class);
		mockFeedFinder.expects(once()).method("findAllFeedRecords").will(returnValue(records));
		
		//because cache is inconsistent
		mockFeedFinder.expects(once()).method("findAllFeeds").will(returnValue(Collections.EMPTY_LIST));
		
		XStreamCache cache = new XStreamCache(populatedFile, (FeedFinder)mockFeedFinder.proxy());
		mockFeedFinder.verify();
		assertSame(Collections.EMPTY_LIST, cache.getFeeds());
	}

	public void testCacheQueriesFeedFinderIfFileCausesConversionException() throws Exception {
		List list = Arrays.asList(new String[]{"bad", "data", "that isn't a valid list of feeds"});
		Mock mockFeedFinder = new Mock(FeedFinder.class);

		//because cache is inconsistent
		mockFeedFinder.expects(once()).method("findAllFeeds").will(returnValue(Collections.EMPTY_LIST));
		File invalidFile = File.createTempFile("tempFile", "tmp");
		populateFile(list, invalidFile);
		
		XStreamCache cache = new XStreamCache(invalidFile, (FeedFinder)mockFeedFinder.proxy()) {
			protected List extractFeeds(FileReader fileReader) {
				throw new ConversionException("File format can't be converted into objects");
			}
		};
		List cachedFeeds = cache.getFeeds();
		
		assertSame(Collections.EMPTY_LIST, cachedFeeds);
		mockFeedFinder.verify();
	}
	
	public void testCacheQueriesFeedFinderIfFileEmpty() throws Exception {
		List feeds = Collections.EMPTY_LIST;
		Mock mockFeedFinder = new Mock(FeedFinder.class);
		mockFeedFinder.expects(once()).method("findAllFeeds").will(returnValue(feeds));
		emptyFile = new File("aggrevator.testTmpFile");
		
		XStreamCache cache = new XStreamCache(emptyFile, (FeedFinder)mockFeedFinder.proxy());
		List cachedFeeds = cache.getFeeds();
		
		assertSame(feeds, cachedFeeds);
		mockFeedFinder.verify();
	}
	
	public void testCacheReturnsCachedFeedsIfFileNotEmpty() throws Exception {
		populatedFile = File.createTempFile("tempFile", "tmp");
		List feeds = StubFixture.createFeedList();
		populateFile(feeds, populatedFile);
		
		Mock mockFeedFinder = new Mock(FeedFinder.class);
		mockFeedFinder.expects(once()).method("findAllFeedRecords").will(returnValue(StubFixture.createFeedRecords(feeds)));
		
		XStreamCache cache = new XStreamCache(populatedFile, (FeedFinder)mockFeedFinder.proxy());
		List cachedFeeds = cache.getFeeds();
		
		assertEquals(1, cachedFeeds.size());
		mockFeedFinder.verify();
	}
	
	public void testCacheOnlyQueriesFeedFinderOnceNoMatterHowOftenItIsInvoked() throws Exception {
		List feeds = Collections.EMPTY_LIST;
		Mock mockFeedFinder = new Mock(FeedFinder.class);
		mockFeedFinder.expects(once()).method("findAllFeeds").will(returnValue(feeds));
		emptyFile = new File("aggrevator.testTmpFile");
		
		XStreamCache cache = new XStreamCache(emptyFile, (FeedFinder)mockFeedFinder.proxy());
		cache.getFeeds();
		cache.getFeeds();
		cache.getFeeds();
		
		mockFeedFinder.verify();
	}
	
	public void testShuttingDownSavesFeeds() throws Exception {
		tempFile = File.createTempFile("tempFile", "tmp");
		List feeds = StubFixture.createFeedList();
		
		Mock mockFeedFinder = new Mock(FeedFinder.class);
		mockFeedFinder.expects(once()).method("findAllFeeds").will(returnValue(feeds));
		mockFeedFinder.expects(once()).method("findAllFeedRecords").will(returnValue(StubFixture.createFeedRecords(feeds)));
		
		XStreamCache cache = new XStreamCache(tempFile, (FeedFinder)mockFeedFinder.proxy());
		cache.shutDown();

		
		XStreamCache newCache = new XStreamCache(tempFile, (FeedFinder)mockFeedFinder.proxy());
		List cachedFeeds = newCache.getFeeds();
		
		assertEquals(feeds, cachedFeeds);
		assertEquals(feeds.get(0), cachedFeeds.get(0));
		mockFeedFinder.verify();
	}

	public void testPersistedFeedsHaveRefreshStateSetToFalse() throws Exception {
		tempFile = File.createTempFile("tempFile", "tmp");
		List feeds = StubFixture.createFeedList();
		Feed feed = (Feed) feeds.get(0);
		feed.setRefreshStarted();
		
		Mock mockFeedFinder = new Mock(FeedFinder.class);
		mockFeedFinder.expects(once()).method("findAllFeeds").will(returnValue(feeds));
		mockFeedFinder.expects(once()).method("findAllFeedRecords").will(returnValue(StubFixture.createFeedRecords(feeds)));
		
		XStreamCache cache = new XStreamCache(tempFile, (FeedFinder)mockFeedFinder.proxy());
		cache.shutDown();
		
		XStreamCache newCache = new XStreamCache(tempFile, (FeedFinder)mockFeedFinder.proxy());
		List cachedFeeds = newCache.getFeeds();
		
		Feed retrievedFeed = (Feed) cachedFeeds.get(0);
		
		assertNotSame(feed, retrievedFeed);
		assertTrue(feed.isRefreshing());
		assertFalse(retrievedFeed.isRefreshing());
		mockFeedFinder.verify();
	}
	
	public void testPersistedFeedsAreRecreatedCorrectly() throws Exception {
		tempFile = File.createTempFile("tempFile", "tmp");
		Feed feed = StubFixture.getStubFeedWithKeyTitleUrlEtagAndLastModified(new Long(99), "some title", StubFixture.TEST_URL, "some etag", "some lastModified");
		List feeds = new ArrayList();
		feeds.add(feed);
		
		Mock mockFeedFinder = new Mock(FeedFinder.class);
		mockFeedFinder.expects(once()).method("findAllFeeds").will(returnValue(feeds));
		mockFeedFinder.expects(once()).method("findAllFeedRecords").will(returnValue(StubFixture.createFeedRecords(feeds)));
		
		XStreamCache cache = new XStreamCache(tempFile, (FeedFinder)mockFeedFinder.proxy());
		cache.shutDown();
		
		XStreamCache newCache = new XStreamCache(tempFile, (FeedFinder)mockFeedFinder.proxy());
		List cachedFeeds = newCache.getFeeds();
		
		Feed retrievedFeed = (Feed) cachedFeeds.get(0);

		assertEquals(feed, retrievedFeed);
		assertEquals(feed.getEtag(), retrievedFeed.getEtag());
		assertNotNull(retrievedFeed.getEtag());
		assertEquals(feed.getLastModified(), retrievedFeed.getLastModified());
		assertNotNull(retrievedFeed.getLastModified());
		
		//confirm the parser is valid
		assertNotNull(retrievedFeed.fetchNewEntries());

		mockFeedFinder.verify();
	}
	
	public void testPersistedFeedsAreRecreatedCorrectlyUsingOriginalValues() throws Exception {
		tempFile = File.createTempFile("tempFile", "tmp");
		String url = "originalUrl";
		Location location = new HttpLocation(url, "some etag", "some lastModified");
		Feed feed =  new FeedImpl(new Long(99), url, "some title", 0, 0, ParserFactory.createFeedParser(), location);
		feed.setTitle("newTitle");
		feed.setUrl("newUrl");
		
		List feeds = new ArrayList();
		feeds.add(feed);
		
		Mock mockFeedFinder = new Mock(FeedFinder.class);
		mockFeedFinder.expects(once()).method("findAllFeeds").will(returnValue(feeds));
		mockFeedFinder.expects(once()).method("findAllFeedRecords").will(returnValue(StubFixture.createFeedRecords(feeds)));
		
		XStreamCache cache = new XStreamCache(tempFile, (FeedFinder)mockFeedFinder.proxy());
		cache.shutDown();
		
		XStreamCache newCache = new XStreamCache(tempFile, (FeedFinder)mockFeedFinder.proxy());
		List cachedFeeds = newCache.getFeeds();
		
		Feed retrievedFeed = (Feed) cachedFeeds.get(0);

		assertEquals(feed, retrievedFeed);
		assertEquals(feed.getTitle(), retrievedFeed.getTitle());
		assertEquals(feed.getUrl(), retrievedFeed.getUrl());
		assertEquals(feed.getEtag(), retrievedFeed.getEtag());
		assertEquals(feed.getLastModified(), retrievedFeed.getLastModified());
		
		feed.rollBack();
		retrievedFeed.rollBack();
		
		assertEquals(feed, retrievedFeed);
		assertEquals(feed.getTitle(), retrievedFeed.getTitle());
		assertEquals(feed.getUrl(), retrievedFeed.getUrl());
		assertEquals(feed.getEtag(), retrievedFeed.getEtag());
		assertEquals(feed.getLastModified(), retrievedFeed.getLastModified());

		mockFeedFinder.verify();
	}
	
	public void testPersistedFeedsAreRecreatedCorrectlyEvenWhenTheyContainEscapedEntities() throws Exception {
		tempFile = File.createTempFile("tempFile", "tmp");
		Feed feed = StubFixture.getStubFeedWithTitle("AKMA&#146;s Random Thoughts");
		List feeds = new ArrayList();
		feeds.add(feed);
		
		Mock mockFeedFinder = new Mock(FeedFinder.class);
		mockFeedFinder.expects(once()).method("findAllFeeds").will(returnValue(feeds));
		mockFeedFinder.expects(once()).method("findAllFeedRecords").will(returnValue(StubFixture.createFeedRecords(feeds)));
		
		XStreamCache cache = new XStreamCache(tempFile, (FeedFinder)mockFeedFinder.proxy());
		cache.shutDown();
		
		XStreamCache newCache = new XStreamCache(tempFile, (FeedFinder)mockFeedFinder.proxy());
		List cachedFeeds = newCache.getFeeds();
		
		Feed retrievedFeed = (Feed) cachedFeeds.get(0);
		
		assertNotSame(feed, retrievedFeed);
		assertEquals(feed.getTitle(), retrievedFeed.getTitle());
		
		//confirm the parser is valid
		assertNotNull(retrievedFeed.fetchNewEntries());
		mockFeedFinder.verify();
	}
	
	public void testCreatesFileIfItDoesNotExist() {
		tempFile = new File("tmpTEST.tmp");
		List feeds = StubFixture.createFeedList();
		Mock mockFeedFinder = new Mock(FeedFinder.class);
		mockFeedFinder.expects(once()).method("findAllFeeds").will(returnValue(feeds));
		
		XStreamCache cache = new XStreamCache(tempFile, (FeedFinder)mockFeedFinder.proxy());
		cache.shutDown();
		
		mockFeedFinder.verify();
		assertTrue(tempFile.exists());
	}
	
	private void populateFile(List feeds, File file) throws Exception {
		XStream xstream = XStreamFactory.createXStream();
		FileWriter fileWriter = new FileWriter(file);
		xstream.toXML(feeds, fileWriter);
		fileWriter.close();
	}
	
	protected void tearDown() throws Exception {
		delete(emptyFile);
		delete(populatedFile);
		delete(tempFile);
	}
	
	private void delete(File file) {
		if (file != null) {
			File newFile = new File(file.getName() + ".bak");
			file.delete();
			newFile.delete();
		}
	}
}
