package com.oshineye.aggrevator.components.tasks;

import java.util.ArrayList;
import java.util.List;

import org.jmock.Mock;
import org.jmock.MockObjectTestCase;

import com.oshineye.aggrevator.components.FeedModel;
import com.oshineye.aggrevator.components.RefreshQueue;

/**
 * @author aoshineye
 *
 */
public class RefreshAllFeedsTaskTest extends MockObjectTestCase {
	public void testEnqueuesCurrentFeeds() {
		List feeds = new ArrayList();
		
		Mock mockQueue = new Mock(RefreshQueue.class);
		mockQueue.expects(once()).method("enqueue").with(same(feeds));
		
		Mock mockFeedModel = new Mock(FeedModel.class);
		mockFeedModel.expects(once()).method("getCurrentFeeds").withNoArguments()
			.will(returnValue(feeds));
		
		Task task = new RefreshAllFeedsTask((RefreshQueue)mockQueue.proxy(), (FeedModel)mockFeedModel.proxy());
		task.run();
	}
}
