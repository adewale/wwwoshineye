package com.oshineye.aggrevator.components.commands.worker.background;

import java.util.Collections;

import org.jmock.Mock;
import org.jmock.MockObjectTestCase;

import com.oshineye.aggrevator.Entry;
import com.oshineye.aggrevator.components.EntryModel;
import com.oshineye.aggrevator.components.FeedModel;
import com.oshineye.aggrevator.components.executors.DirectUIExecutor;
import com.oshineye.aggrevator.store.EntryStore;
import com.oshineye.aggrevator.store.StubFixture;

/**
 * @author aoshineye
 *
 */
public class MarkEntryReadCommandTest extends MockObjectTestCase {
	public void testMarksEntryReadAndUpdatesUserInterface() {
		Entry entry = StubFixture.getStubEntry();
		Mock mockFeedModel = new Mock(FeedModel.class);
		mockFeedModel.expects(once()).method("entryRead").with(same(Collections.EMPTY_LIST));
		Mock mockEntryStore = new Mock(EntryStore.class);
		mockEntryStore.expects(once()).method("getRelatedFeeds").will(returnValue(Collections.EMPTY_LIST));
		mockEntryStore.expects(once()).method("markRead").with(eq(entry));
		Mock mockEntryModel = new Mock(EntryModel.class);
		mockEntryModel.expects(once()).method("markRead").with(eq(entry.getUrl()));
		DirectUIExecutor directUIExecutor = new DirectUIExecutor();
		
		
		MarkEntryReadCommand cmd = new MarkEntryReadCommand(entry, 
			(FeedModel)mockFeedModel.proxy(), (EntryStore)mockEntryStore.proxy(),
			(EntryModel)mockEntryModel.proxy(), directUIExecutor);
		cmd.run();
		
		mockFeedModel.verify();
		mockEntryStore.verify();
		mockEntryModel.verify();
	}
}
