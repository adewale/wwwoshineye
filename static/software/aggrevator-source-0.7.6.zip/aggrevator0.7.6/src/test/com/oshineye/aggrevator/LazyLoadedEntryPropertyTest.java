package com.oshineye.aggrevator;

import org.jmock.Mock;
import org.jmock.MockObjectTestCase;

import com.oshineye.aggrevator.EntryContentService;
import com.oshineye.aggrevator.LazyLoadedEntryProperty;

/**
 * @author aoshineye
 *
 */
public class LazyLoadedEntryPropertyTest extends MockObjectTestCase {
	public void testLoadsContentFromServiceWhenAskedForValue() {
		String expectedValue = "Some content";
		Long entryId = new Long(0);
		Mock mockContentService = new Mock(EntryContentService.class);
		mockContentService.expects(once()).
			method("getContent").
			with(eq(entryId)).
			will(returnValue(expectedValue));
		LazyLoadedEntryProperty property = new LazyLoadedEntryProperty((EntryContentService) mockContentService.proxy(), entryId);
		
		assertSame(expectedValue, property.getValue());
		mockContentService.verify();
	}
	
	public void testDoesNothingIfNotAskedForValue() {
		Long entryId = new Long(0);
		Mock mockContentService = new Mock(EntryContentService.class);
		new LazyLoadedEntryProperty((EntryContentService) mockContentService.proxy(), entryId);
		mockContentService.verify();
	}
	
	public void testOnlyLoadsContentFromServiceTheFirstTimeItIsAskedForValue() {
		String expectedValue = "Some content";
		Long entryId = new Long(0);
		Mock mockContentService = new Mock(EntryContentService.class);
		mockContentService.expects(once()).
			method("getContent").
			with(eq(entryId)).
			will(returnValue(expectedValue));
		LazyLoadedEntryProperty property = new LazyLoadedEntryProperty((EntryContentService) mockContentService.proxy(), entryId);
		
		assertSame(expectedValue, property.getValue());
		assertSame(expectedValue, property.getValue());
		mockContentService.verify();
	}
}
