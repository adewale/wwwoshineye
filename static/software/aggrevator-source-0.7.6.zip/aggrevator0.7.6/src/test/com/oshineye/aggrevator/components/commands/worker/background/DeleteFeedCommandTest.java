package com.oshineye.aggrevator.components.commands.worker.background;

import org.jmock.Mock;
import org.jmock.MockObjectTestCase;

import com.oshineye.aggrevator.Feed;
import com.oshineye.aggrevator.store.EntryStore;
import com.oshineye.aggrevator.store.FeedStore;
import com.oshineye.aggrevator.store.StubFixture;

/**
 * @author aoshineye
 *
 */
public class DeleteFeedCommandTest extends MockObjectTestCase {
	private Feed feed;
	private DeleteFeedCommand command;
	private Mock mockFeedStore;
	private Mock mockEntryStore;

	public void setUp() {
		setupExpectations();
	}
	
	private void setupExpectations() {
		feed = StubFixture.getStubFeed();

		mockFeedStore = new Mock(FeedStore.class);
		mockFeedStore.expects(once()).with(same(feed));
		mockEntryStore = new Mock(EntryStore.class);
		mockEntryStore.expects(once()).method("delete").with(same(feed));
		
		command = new DeleteFeedCommand(feed, (FeedStore)mockFeedStore.proxy(),
			(EntryStore)mockEntryStore.proxy());

		command.run();
	}
	
	public void testDeletingFeedFromViewDeletesItFromFeedStore() {
		mockFeedStore.verify();
	}

	public void testDeletingFeedFromViewDeletesAllItsEntriesFromEntryStore() {
		mockEntryStore.verify();
	}
}
