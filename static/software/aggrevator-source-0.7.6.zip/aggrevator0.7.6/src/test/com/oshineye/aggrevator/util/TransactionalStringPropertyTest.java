package com.oshineye.aggrevator.util;

import junit.framework.TestCase;

/**
 * @author aoshineye
 *
 */
public class TransactionalStringPropertyTest extends TestCase {
	public void testSetStringCanBeRolledBackToOriginalValue() {
		String originalValue = "originalValue";
		TransactionalStringProperty property = new TransactionalStringProperty(originalValue);
		String newValue = "newValue";
		property.setNewValue(newValue);
		property.rollBack();
		
		assertEquals(originalValue, property.getValue());
	}
	
	public void testSetStringCanBeObtained() {
		String originalValue = "originalValue";
		TransactionalStringProperty property = new TransactionalStringProperty(originalValue);
		assertEquals(originalValue, property.getValue());
		
		String newValue = "newValue";
		property.setNewValue(newValue);
		
		assertEquals(newValue, property.getValue());
	}
	
	public void testRollBackWhenThereIsNoValueToRollBackToHasNoEffect() {
		String originalValue = "originalValue";
		TransactionalStringProperty property = new TransactionalStringProperty(originalValue);
		property.rollBack();
		
		assertEquals(originalValue, property.getValue());
	}
	
	public void testStringRepresentationIsTheValue() {
		String value = "value";
		TransactionalStringProperty property = new TransactionalStringProperty(value);
		
		assertEquals(value, property.toString());
	}
	
	public void testSetStringCanBeRolledBackToNewValueAfterCommit() {
		String originalValue = "originalValue";
		TransactionalStringProperty property = new TransactionalStringProperty(originalValue);
		String newValue = "newValue";
		property.setNewValue(newValue);
		property.commit();
		property.rollBack();
		
		assertEquals(newValue, property.getValue());
	}
}
