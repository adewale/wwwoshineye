package com.oshineye.aggrevator;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang.time.DateFormatUtils;
import org.jmock.Mock;
import org.jmock.MockObjectTestCase;

import com.oshineye.aggrevator.store.StubFixture;
import com.oshineye.aggrevator.store.entry.EntryFactory;

/**
 * @author aoshineye
 *
 */
public class EntryTest extends MockObjectTestCase {
	private String title;
	private String content;
	private Date date;
	private boolean read;
	private String feedTitle = "";
	private String url = "";
	private Entry entry;
	private long entryId = -1;

	public void setUp() {
		long feedId = -1;
		this.title = "title";
		this.content = "content";
		this.date = new Date();
		this.read = false;
		this.entry = EntryFactory.createEntryFromStore(entryId, title, content, date, url, feedTitle, feedId, read, 0);
	}
	
	public void testCreatingEntryWithNullDateResultsInCurrentDateBeingUsed() throws Exception {
		date = new Date();
		entry = EntryFactory.createEntryFromStore(entryId, title, content, null, url, feedTitle, -1, read, 0);
		
		Date storedDate = entry.getDate();
		
		assertNotNull(storedDate);
		assertTrue((date.getTime()/1000) <= (storedDate.getTime()/1000));
	}
	
	public void testEntriesHaveEntitiesInTitlesCleanedUp() {
		entry = EntryFactory.createEntryFromStore(entryId, "&gt;&gt;&quot;&amp;&quot;&lt;&lt;", content, null, url, feedTitle, -1, read, 0);
		assertEquals(">>\"&\"<<", entry.getTitle());
	}
	
	public void testEntriesHaveEntitiesInFeedTitlesCleanedUp() {
		entry = EntryFactory.createEntryFromStore(entryId, title, content, null, url, "&gt;&gt;&quot;&amp;&quot;&lt;&lt;", -1, read, 0);
		assertEquals(">>\"&\"<<", entry.getFeedTitle());
	}
	
	public void testEntriesDoNotHaveTitlesCleanedUpIfTheyContainIllegalHtmlEntities() {
		String originalTitle = "&gt;&gt;&quot;&amp;&quot;&lt;&lt;&#x92;";
		entry = EntryFactory.createEntryFromStore(entryId, originalTitle, content, null, url, feedTitle, -1, read, 0);
		assertEquals(originalTitle, entry.getTitle());
	}
	
	public void testEntriesDoNotHaveFeedTitlesCleanedUpIfTheyContainIllegalHtmlEntities() {
		String originalFeedTitle = "&gt;&gt;&quot;&amp;&quot;&lt;&lt;&#x92;";
		entry = EntryFactory.createEntryFromStore(entryId, title, content, null, url, originalFeedTitle, -1, read, 0);
		assertEquals(originalFeedTitle, entry.getFeedTitle());
	}

	public void testEntryFormatsDateToShortForm() {
		String dateText = entry.getFormattedDate();
		assertEquals(DateFormatUtils.format(date, Configuration.DATE_FORMAT), dateText);
	}

	public void testMarkingEntryAsReadChangesIt() {
		entry.markRead();
		assertTrue(entry.isRead());
		assertEquals(Feed.ENTRY_READ_SCORE, entry.getScore());
	}
	
	public void testMarkingEntryAsReadMultipleTimesOnlyChangesTheScoreOnce() {
		entry.markRead();
		entry.markRead();
		entry.markRead();
		entry.markRead();
		assertTrue(entry.isRead());
		assertEquals(Feed.ENTRY_READ_SCORE, entry.getScore());
	}
	
	public void testEntryThatAlreadyHasAScorePreservesThatScoreIfItIsMarkedReadAgain() {
		entry.markRead();
		assertEquals(Feed.ENTRY_READ_SCORE, entry.getScore());
		
		entry.incrementScore();
		entry.markRead();
		
		assertEquals(Feed.SCORE_UNITS + Feed.ENTRY_READ_SCORE, entry.getScore());
	}
	
	public void testScoreCanBeIncreasedAndDecreased() {
		int score = entry.getScore();
		
		entry.incrementScore();
		assertEquals(score + Feed.SCORE_UNITS, entry.getScore());
		
		entry.decrementScore();
		assertEquals(score, entry.getScore());
		
		entry.decrementScore();
		assertEquals(score - Feed.SCORE_UNITS, entry.getScore());
	}
	
	public void testEntriesCanBeMeaningfullyComparedForEquality() throws InvalidFeedException {
		Feed feed = StubFixture.getStubFeed();
		List entries = feed.fetchNewEntries();
		Entry zero = (Entry) entries.get(0);
		Entry one = (Entry) entries.get(1);
		Entry otherZero = (Entry) feed.fetchNewEntries().get(0);
		
		assertFalse(zero.equals(one));
		assertNotSame(zero, otherZero);
		assertEquals(zero, otherZero);
	}
	
	public void testEntriesWithSamePermaLinkButDifferentContentConsideredEqual() {
		String content2 = "Dummy entry's content 2";
		String permaLink = "some permaLink";
		Entry e1 = EntryFactory.createEntryFromStore(entryId, title, content, date, permaLink, feedTitle, -1, read, 0);
		Entry e2 = EntryFactory.createEntryFromStore(entryId, title, content2, date, permaLink, feedTitle, -1, read, 0);
		assertEquals(e1, e2);
	}
	
	public void testEntriesWithNullPermaLinkButSameContentConsideredEqual() {
		String content2 = "Dummy entry's content 2";
		String permaLink = null;
		Entry e1 = EntryFactory.createEntryFromStore(entryId, title, content, date, permaLink, feedTitle, -1, read, 0);
		Entry e2 = EntryFactory.createEntryFromStore(entryId, title, content2, date, permaLink, feedTitle, -1, read, 0);
		assertEquals(e1, e2);
	}
	
	public void testEntriesWithDifferentPermaLinksButSameContentNotConsideredEqual() {
		Entry e1 = EntryFactory.createEntryFromStore(entryId, title, content, date, "permaLink1", feedTitle, -1, read, 0);
		Entry e2 = EntryFactory.createEntryFromStore(entryId, title, content, date, "permaLink2", feedTitle, -1, read, 0);
		assertFalse(e1.equals(e2));
		assertFalse(e2.equals(e1));
		
		assertEquals(e1.getContent(), e2.getContent());
		assertFalse(e1.getUrl().equals(e2.getUrl()));
		assertFalse(e2.getUrl().equals(e1.getUrl()));
	}
	
	public void testEntriesWithSameIdsAreNotConsideredEqualIfPermaLinksDiffer() {
		Entry e1 = EntryFactory.createEntryFromStore(entryId, title, content, date, "permaLink1", feedTitle, -1, read, 0);
		Entry e2 = EntryFactory.createEntryFromStore(entryId, title, content, date, "permaLink2", feedTitle, -1, read, 0);
		assertFalse(e1.equals(e2));
		assertFalse(e2.equals(e1));
		
		assertEquals(e1.getId(), e2.getId());
		assertFalse(e1.getUrl().equals(e2.getUrl()));
		assertFalse(e2.getUrl().equals(e1.getUrl()));
	}
	
	public void testEntryObjectsConvertToStringContainingTitleAndPermaLink() {
		String permaLink = "some permaLink";
		Entry e1 = EntryFactory.createEntryFromStore(entryId, title, content, date, permaLink, feedTitle, -1, read, 0);
		
		assertEquals("Entry::" + title + "::" + permaLink, e1.toString());
	}
	
	public void testIdCanBeRetrievedFromEntry() {
		Entry e1 = EntryFactory.createEntryFromStore(entryId, title, content, date, "permaLink", feedTitle, entryId, read, 0);
		assertEquals(new Long(entryId), e1.getId());
	}
	
	public void testContentForEntryCanAlwaysBeRetrieved() throws MalformedURLException {
		Long feedId = new Long(-1);
		Entry entryCreatedFromTheWeb = new Entry(title, content, date, new URL("http://www.example.com"), feedTitle, feedId);
		assertEquals(content, entryCreatedFromTheWeb.getContent());
		
		Long entryIdAsLong = new Long(entryId);
		Entry entryCreatedFromStoreWithoutProperty = new Entry(entryIdAsLong, title, content, date, "permaLink", feedTitle, feedId, true, 0);
		assertEquals(content, entryCreatedFromStoreWithoutProperty.getContent());
		
		
		Mock mockEntryContentService = new Mock(EntryContentService.class);
		mockEntryContentService.expects(once()).method("getContent").with(eq(entryIdAsLong)).will(returnValue(content));
		LazyLoadedEntryProperty property = new LazyLoadedEntryProperty((EntryContentService)mockEntryContentService.proxy(), entryIdAsLong);
		Entry entryCreatedFromStoreWithProperty = new Entry(entryIdAsLong, title, property, date, "permaLink", feedTitle, feedId, true, 0);
		assertEquals(content, entryCreatedFromStoreWithProperty.getContent());
		
		mockEntryContentService.verify();
	}
}
