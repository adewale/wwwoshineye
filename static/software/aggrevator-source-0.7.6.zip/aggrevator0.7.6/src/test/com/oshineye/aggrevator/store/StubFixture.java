package com.oshineye.aggrevator.store;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.Reader;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import com.oshineye.aggrevator.Entry;
import com.oshineye.aggrevator.Feed;
import com.oshineye.aggrevator.FeedRecord;
import com.oshineye.aggrevator.QueryLoaderFactory;
import com.oshineye.aggrevator.StubFeed;
import com.oshineye.aggrevator.db.ConnectionPoolFactory;
import com.oshineye.aggrevator.db.JdbcProcessFactory;
import com.oshineye.aggrevator.store.entry.EntryFactory;

/**
 * @author aoshineye
 * Provide stubs used by test cases
 */
public class StubFixture {
	private static final String TEST_DATA_FOLDER = "testData";
	public static final String TEST_DATABASE_NAME = "aggrevator_test";
	public static final String TEST_URL = "http://localhost/sampleRss091.xml";
	public static final String TEST_URL2 = "http://localhost/aeden.rss";
	public static final String FEED_TITLE = "stubFeedTitle";
	public static final String TEST_URL_CLONE_WITH_ONE_LESS_ENTRY = "http://localhost/sampleRss091_clone.xml";
	
	private static final FeedIdentityMap MAP = new FeedIdentityMap();
	public static final JdbcProcessFactory PROCESS_FACTORY = new JdbcProcessFactory(ConnectionPoolFactory.getConnectionPool(TEST_DATABASE_NAME));
	
	
	private static final EntryStore ENTRY_STORE = new MySqlEntryStore(PROCESS_FACTORY, MAP, QueryLoaderFactory.createQueryLoader());
	private static final FeedStore FEED_STORE = new MySqlFeedStore(PROCESS_FACTORY, MAP, QueryLoaderFactory.createQueryLoader());
	
	public static FeedStore getFeedStore() {
		return FEED_STORE;
	}

	public static EntryStore getEntryStore() {
		return ENTRY_STORE;
	}
	
	public static FeedIdentityMap getFeedIdentityMap() {
		return MAP;
	}
	
	public static StubFeed getStubFeed(){
		return new StubFeed(TEST_URL);
	}

    public static StubFeed getStubFeedWithKeyAndUrl(Long id, String url) {
        return new StubFeed(id, url);
    }
    
	public static StubFeed getStubFeedWithUrl(String url) {
		return new StubFeed(url);
	}
	
	public static StubFeed getStubFeedWithTitle(String title) {
		return getStubFeedWithTitleAndUrl(title, TEST_URL);
	}
	
	public static StubFeed getStubFeedWithUnreadEntriesCount(int unreadEntriesCount) {
		return new StubFeed(TEST_URL, FEED_TITLE, unreadEntriesCount, 0);
	}
    
	public static Feed getStubFeedWithKeyTitleAndUrl(Long id, String title, String url) {
        return new StubFeed(id, title, url);
    }
    
	public static StubFeed getStubFeedWithTitleAndUrl(String title, String url) {
		return new StubFeed(url, title, 0, 0);
	}
	
	public static Feed getStubFeedWithKeyTitleUrlEtagAndLastModified(Long id, String title, String url, String etag, String lastModified) {
		return new StubFeed(id, title, url, etag, lastModified);
	}
	
	public static Feed getStubFeedWithKeyTitleUrlAndScore(Long id, String title, String url, int score) {
		return new StubFeed(id, title, url, score);
	}
	
	public static StubFeed getStubFeedWithTitleUrlAndScore(String title, String url, int score) {
		return new StubFeed(title, url, 0, score);
	}
	
	public static StubFeed getStubFeedWithTitleAndScore(String title, int score) {
		return getStubFeedWithTitleUrlAndScore(title, TEST_URL, score);
	}
	
	public static Entry getStubEntry() {
		int id = 0;
		String title = "Dummy entry title";
		return getStubEntry(id, title);
	}

	public static Entry getStubEntry(Feed feed) {
		String title = "Dummy entry title";
		String content = "Dummy entry's content";
		Date date = new Date();
		boolean read = false;
		String feedTitle = feed.getTitle();
		String entryLink = "http://localhost/blog/dummy.html";
		return EntryFactory.createEntryFromStore(-1, title, content, date, entryLink, feedTitle, 0, read, 0);
	}
	
	public static Entry getStubEntry(int id, String title) {
		String content = "Dummy entry's content";
		return getStubEntry(id, title, content);
	}

	public static Entry getStubEntry(int id, String title, String content) {
		Date date = new Date();
		boolean read = false;
		String feedTitle = "Dummy feed title";
		String entryLink = "http://localhost/blog/dummy2.html";
		return EntryFactory.createEntryFromStore(id, title, content, date, entryLink, feedTitle, 0, read, 0);
	}
	
	public static Entry getStubEntryWithIdFeedIdAndContent(int id, Long feedId, String content) {
		String title = "Dummy entry title";
		Date date = new Date();
		boolean read = false;
		String feedTitle = "Dummy feed title";
		String entryLink = "http://localhost/blog/dummy2.html";
		return EntryFactory.createEntryFromStore(id, title, content, date, entryLink, feedTitle, feedId.longValue(), read, 0);
	}
	
	public static Entry getStubEntryWithTitle(String title) {
		return getStubEntry(0, title);
	}

	public static Entry getStubEntryWithTime(Feed feed, long time) {
		String title = "Dummy entry title";
		String content = "Dummy entry's content";
		boolean read = false;
		String feedTitle = "Dummy feed title";
		String entryLink = "http://localhost/blog/dummy2.html";
		return EntryFactory.createEntryFromStore(-1, title, content, new Date(time), entryLink, feedTitle, -1, read, 0);
	}

	public static Entry getStubEntryWithDate(Feed feed, Date date) {
		String title = "Dummy entry title";
		String content = "Dummy entry's content";
		boolean read = false;
		String feedTitle = "Dummy feed title";
		String entryLink = "http://localhost/blog/dummy2.html";
		Long feedId = feed.getId();
		return EntryFactory.createEntryFromStore(-1, title, content, date, entryLink, feedTitle, feedId.longValue(), read, 0);
	}
	
	public static Entry getStubEntryWithPermaLinkAndFeedId(String permaLink, Long feedId) {
		return getStubEntryWithPermaLinkFeedIdAndReadStatus(permaLink, feedId, false);
	}

	public static Entry getStubReadEntryWithPermaLinkAndFeedId(String permaLink, Long feedId) {
		return getStubEntryWithPermaLinkFeedIdAndReadStatus(permaLink, feedId, true);
	}
	
	private static Entry getStubEntryWithPermaLinkFeedIdAndReadStatus(String permaLink, Long feedId, boolean read) {
		String title = "Dummy entry title";
		String content = "Dummy entry's content";
		Date date = new Date();
		String feedTitle = "Dummy feed title";
		return EntryFactory.createEntryFromStore(-1, title, content, date, permaLink, feedTitle, feedId.longValue(), read, 0);
	}
	
	public static Entry getStubEntryWithPermaLinklTitleAndContent(String url, String title, String content) {
		Date date = new Date();
		boolean read = false;
		String feedTitle = "Dummy feed title";
		return EntryFactory.createEntryFromStore(-1, title, content, date, url, feedTitle, 0, read, 0);
	}

	public static Reader getTestDataReader(String fileName) throws FileNotFoundException {
		return new FileReader(new File(TEST_DATA_FOLDER, fileName));
	}

	public static Entry getStubEntryWithTitleAndScore(String title, int score) {
		Date date = new Date();
		boolean read = false;
		String feedTitle = "Dummy feed title";
		return EntryFactory.createEntryFromStore(-1, title, "content", date, "url", feedTitle, 0, read, score);
	}

	public static List createFeedList() {
		List feeds = new ArrayList();
		feeds.add(StubFixture.getStubFeed());
		return feeds;
	}
	
	public static List createFeedRecords(List feeds) {
		List records = new ArrayList();
		for (Iterator iter = feeds.iterator(); iter.hasNext();) {
			Feed feed = (Feed) iter.next();
			FeedRecord record = new FeedRecord(feed.getId(), feed.getUrl(), feed.getTitle(), feed.getEtag(), feed.getLastModified());
			records.add(record);
		}
		return records;
	}
}
