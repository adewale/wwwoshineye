package com.oshineye.kwikwiki.command;

import com.oshineye.kwikwiki.markup.MarkUpEngine;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.oshineye.kwikwiki.wikibase.WikiBase;
import com.oshineye.kwikwiki.page.HtmlPage;


public class View extends Command {
	public void execute(HttpServletRequest req, HttpServletResponse resp, 
						ServletContext sc) throws Exception {
		System.err.println("==Executing view command==");
		
        String title = req.getParameter("title");
		WikiBase wikiBase = WikiBase.getInstance();
		
		if (MarkUpEngine.isWikiName(title)) {
			if (wikiBase.pageExists(title)) {
				HtmlPage page = new HtmlPage(wikiBase.getPage(title));
				req.setAttribute("pageBean", page);
				this.include("/viewTemplate.jsp", req, resp, sc);
				
				if (page.isSpecial()) {
					this.include("/readOnlyFooter.jsp", req, resp, sc);
				} else {
					this.include("/readWriteFooter.jsp", req, resp, sc);
				}
			} else {
				//title is valid wikiName but page doesn't exist
				Command action = Command.getCommand("Create");
				action.execute(req, resp, sc);
			}
			
		} else {
			//go to invalid page title error page
			this.include(Command.INVALID_TITLE, req, resp, sc);
		}
	}
}
