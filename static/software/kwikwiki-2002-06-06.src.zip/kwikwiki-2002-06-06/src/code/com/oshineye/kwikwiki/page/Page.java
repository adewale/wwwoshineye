package com.oshineye.kwikwiki.page;

import java.io.Serializable;

/**
An abstraction representing a page of data. 
This class fulfills all the criteria to be a JavaBean.*/
public abstract class Page implements Serializable {
	//Use of self-encapsulation enables subclasses to override the behvaiour
	//of the constructors
	private String title;
	private String text;
	private boolean special;

	public Page() {
	}

	public Page(String title, String text) {
		this.setTitle(title);
		this.setText(text);
	}
	
	public String getTitle() {
		return title;
	}
	
	protected void setTitle(String title) {
		this.title = title;
	}
	
	public String getText() {
		return text;
	}
	
	protected void setText(String text){
		this.text = text;
	}

	public boolean isSpecial() {
		return this.special;
	}

	protected void setSpecial(boolean special) {
		this.special = special;
	}
}
