package com.oshineye.kwikwiki.page;

import java.util.Date;

/**
A class that represent a page's raw unformatted data.
It also keeps track of when it was created and who last edited it.
This class fulfills all the criteria to be a JavaBean.
*/
public class RawPage extends Page {
	private Date date;
	private String lastEditor;

	public RawPage() {
	}

	public RawPage(String title, String text, Date date) {
		super(title, text);
		this.date = date;
	}

	public RawPage(String title, String text, Date date, String lastEditor) {
		this(title, text, date);
		this.lastEditor = lastEditor;
	}

	public RawPage(String title, String text, boolean special) {
		this(title, text, null);
		this.setSpecial(special);
	}
	
	public Date getDate() {
		return this.date;
	}

	public String getLastEditor() {
		return this.lastEditor;
	}
}
