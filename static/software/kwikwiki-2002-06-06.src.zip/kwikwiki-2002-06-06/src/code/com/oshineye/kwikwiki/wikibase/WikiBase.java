package com.oshineye.kwikwiki.wikibase;

import com.oshineye.kwikwiki.page.RawPage;
import com.oshineye.kwikwiki.markup.MarkUpEngine;
import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;
import java.util.SortedSet;

/**
A Singleton class which represents the persistence store for this Wiki.
Because it's abstract the actual singleton is an instance of a conrete class.
*/
public abstract class WikiBase {
	private static WikiBase instance;
	private SortedSet allTitles;
	private static final String LIST_START = " * ";
	private static final String LINE_ENDING = "\n";
	private static final String ELLIPSIS = "&nbsp;.&nbsp;.&nbsp;.&nbsp;";
	private static final int DEFAULT_AMOUNT_OF_CHANGES = 5;

    //the special pages array must be in sorted order
	private static final String[] SPECIAL_PAGES = {"RecentChanges", "TitleIndex", "TodaysChanges"};

	protected WikiBase() {
		allTitles = loadTitles();
		
		//add special pages to the set of titles
		for (int i=0; i<SPECIAL_PAGES.length; i++) {
			allTitles.add(SPECIAL_PAGES[i]);
		}
		
	}

	protected abstract SortedSet loadTitles();
		
	public static WikiBase getInstance() {
		if (instance == null) {
			instance = new FileBase();
		}
		return instance;
	}
	
	public RawPage getPage(String title) {
		RawPage rawPage;
		if (this.isSpecialPage(title)) {
			rawPage = this.getSpecialPage(title);
		} else {
			rawPage = this.loadPage(title);
		}
		return rawPage;
	}
	
	protected abstract RawPage loadPage(String title);
	
	public void savePage(RawPage rawPage) {
		//if we're storing a new page add it to the set of titles
		String title = rawPage.getTitle();
		if (!this.pageExists(title)) {
			allTitles.add(title);
		}
		
		storePage(rawPage);
		storeChange(new Change(rawPage));
	}
	
	protected abstract void storePage(RawPage rawPage);
	
	protected abstract void storeChange(Change change);
	
	/**
	Return an <b>unmodifiable</b> SortedSet of the titles of all the pages
	in this Wiki.
	*/
	public SortedSet getAllTitles() {
		return Collections.unmodifiableSortedSet(allTitles);
	}
	
	public boolean pageExists(String title) {
		return allTitles.contains(title);
	}
	
	protected boolean isSpecialPage(String title) {
		//binarySearch returns positive ints if it finds the title and a
		//negative int if it doesn't
		return (Arrays.binarySearch(SPECIAL_PAGES, title) >= 0);
	}
	
	public RawPage getSpecialPage(String title) {
		if (title.equals("TitleIndex")) {
			return getTitleIndexPage();
		} else if (title.equals("TodaysChanges")) {
			return getTodaysChangesPage();
		} else { //(title.equals("RecentChanges")) {
			return getRecentChangesPage();
		}
	}
	
	private RawPage getTitleIndexPage() {
		StringBuffer sb = new StringBuffer();
		for (Iterator it = allTitles.iterator(); it.hasNext();) {
			String item = (String)it.next();
			sb.append(LIST_START + item + LINE_ENDING);
		}
		return new RawPage("TitleIndex", sb.toString(), true);
	}

	private RawPage getTodaysChangesPage() {
		ChangeLog[] log = this.getRecentChanges(1);
		ChangeLog todaysLog = log[0];
		Change[] changes = todaysLog.getChanges();

		StringBuffer sb = convertChanges(changes);
		String header = MarkUpEngine.embolden(todaysLog.getDay()) + LINE_ENDING;
		return new RawPage("TodaysChanges", header + sb.toString(), true);
	}

	private StringBuffer convertChanges(Change[] changes) {
		StringBuffer sb = new StringBuffer();
		for (int i=0; i<changes.length; i++) {
			Change item = changes[i];
			sb.append(LIST_START + item.getTitle() + ELLIPSIS + item.getEditor() + LINE_ENDING);
		}
		return sb;
	}

	private RawPage getRecentChangesPage() {
		ChangeLog[] log = this.getRecentChanges(DEFAULT_AMOUNT_OF_CHANGES);

		StringBuffer sb = new StringBuffer();

		//go through logs in reverse chronological order
		for (int i=log.length-1; i>=0; i--) {
			ChangeLog currentLog = log[i];
			Change[] changes = currentLog.getChanges();
			String header = MarkUpEngine.embolden(currentLog.getDay()) + LINE_ENDING;
			sb.append(header);
			sb.append(convertChanges(changes));
		}

		return new RawPage("RecentChanges", sb.toString(), true);
	}

	/**
	 * Get an array of ChangeLogs for the last numberOfDays. The number of days
	 * must be greater than 0.
	 */
	protected abstract ChangeLog[] getRecentChanges(int numberOfDays);
}
