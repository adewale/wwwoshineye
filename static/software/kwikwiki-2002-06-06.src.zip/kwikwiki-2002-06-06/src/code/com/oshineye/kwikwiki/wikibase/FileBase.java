package com.oshineye.kwikwiki.wikibase;

import com.oshineye.kwikwiki.TunnellingException;
import com.oshineye.kwikwiki.page.RawPage;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.FilenameFilter;
import java.io.IOException;
import java.util.regex.Pattern;
import java.util.regex.Matcher;
import java.util.Date;
import java.util.Arrays;
import java.util.ArrayList;
import java.util.List;
import java.util.SortedSet;
import java.util.TreeSet;
import java.text.ParseException;

public class FileBase extends WikiBase {
	private static final String FILE_SEPARATOR = System.getProperty("file.separator");

	private static final String WIKI_DIR_NAME= System.getProperty("user.home")
		+ FILE_SEPARATOR + "kwikwiki-data" + FILE_SEPARATOR;
	private static final File WIKI_DIR = new File(WIKI_DIR_NAME);

	private static final String METADATA_DIR_NAME = WIKI_DIR_NAME
		+ FILE_SEPARATOR + "metadata" + FILE_SEPARATOR;

	private static final String CHANGES_DIR_NAME = METADATA_DIR_NAME
		+ FILE_SEPARATOR + "changelogs" + FILE_SEPARATOR;
    private static final File CHANGES_DIR = new File(CHANGES_DIR_NAME);

	private static final TextFilter TEXT_FILTER = new TextFilter();
	private static final String TEXT_EXTENSION = ".txt";
	private static final int TEXT_EXTENSION_LENGTH = 4;//includes the dot
	//We always use unix line-endings
	private static final String LINE_ENDING = "\n";


	public RawPage loadPage(String title) {
		//assume file always exists
		File file = new File(WIKI_DIR_NAME + title + TEXT_EXTENSION);
		
		CharSequence rawText;
		try {
			rawText = this.readText(file);
		} catch (IOException ioe) {
			throw new TunnellingException(ioe);
		}
		
		Date lastEdited = new Date(file.lastModified());

		return new RawPage(title, rawText.toString(), lastEdited); 
	}
	
	private CharSequence readText(File file) throws IOException {
		/*
		potential exists for performance optimisation by specifying buffer 
		sizes for the BufferedReader and StringBuffer based on the file's 
		length. Although that might lead to problems with very large files.
		*/
		BufferedReader br = new BufferedReader(new FileReader(file));
		StringBuffer sb = new StringBuffer();

		String line;
		while ((line = br.readLine()) != null) {
			sb.append(line);
			sb.append(LINE_ENDING);//avoid concatenation penalty
		}
		
		br.close();
		return sb;
	}

	public void storePage(RawPage rawPage) {
		String title = rawPage.getTitle();
		String text = rawPage.getText();
		
		//1 argument constructor chosen for performance
		File file = new File(WIKI_DIR_NAME + title + TEXT_EXTENSION);
		
		try {
			this.writeText(file, text, false);
		} catch (IOException ioe) {
			throw new TunnellingException(ioe);
		}
	}
	
	private void writeText(File file, CharSequence text, boolean shouldAppend) throws IOException {
		BufferedWriter bw = new BufferedWriter(new FileWriter(file, shouldAppend));
		bw.write(text.toString());
		bw.close();
	}

	protected void storeChange(Change change) {
		String day = change.getDay();

		//1 argument constructor chosen for performance
		File file = new File(CHANGES_DIR_NAME + day + TEXT_EXTENSION);
		
		try {
			String newChangeLine = LINE_ENDING + "title:" + change.getTitle()
			+ ",date:" 	+ change.getDate().getTime() + ",editor:" + change.getEditor() + ",";

			writeText(file, newChangeLine, true);
		} catch (IOException ioe) {
			throw new TunnellingException(ioe);
		}
	}

	protected ChangeLog[] getRecentChanges(int numberOfDays) {
		//load all the changelog file names
		String[] fileNames = CHANGES_DIR.list();
        int numberOfLogs = fileNames.length;

		Date[] times = convertToDates(fileNames);

		//sort the names by time
		Arrays.sort(times);

		//create an array of logs
		ChangeLog[] logs;
        if (numberOfLogs < numberOfDays) {
			logs = new ChangeLog[numberOfLogs];
		} else {
			logs = new ChangeLog[numberOfDays];
		}

		//populate the array with ChangeLog objects representing the files
		try {
			for (int i=numberOfLogs-logs.length, j=0; i<numberOfLogs; i++,j++) {
				String day = Change.formatChangeDate(times[i]);
				File currentChangeFile = new File(CHANGES_DIR_NAME + day + TEXT_EXTENSION);
				CharSequence changeText = readText(currentChangeFile);
				Change[] temp = parseChanges(changeText);
				logs[j] = new ChangeLog(temp);
			}
		} catch (IOException ioe) {
			throw new TunnellingException(ioe);
		}

		//return the array of ChangeLogs
        return logs;
	}

	private Date[] convertToDates(String[] fileNames) {
		int numberOfLogs = fileNames.length;
		//convert the names to dates
		Date[] times = new Date[numberOfLogs];
		try {
			for(int i=0; i<numberOfLogs; i++) {
				String currentName = fileNames[i];
				String temp = currentName.substring(0, currentName.length() - TEXT_EXTENSION_LENGTH);
				times[i] = Change.parseChangeDay(temp);
			}
		} catch (ParseException pe) {
			throw new TunnellingException(pe);
		}
		return times;
	}

	private Change[] parseChanges(CharSequence changeLines) {
		Pattern pattern = Pattern.compile("(title:(.*),date:(.*),editor:(.*),)", Pattern.MULTILINE);
		Matcher matcher = pattern.matcher(changeLines);
		List changeList = new ArrayList();

		while(matcher.find()) {
			String tempTitle = matcher.group(2);
			String tempDate = matcher.group(3);
			String tempEditor = matcher.group(4);
			long tempTime = Long.parseLong(tempDate);
			Change temp = new Change(tempTitle, new Date(tempTime), tempEditor);
			changeList.add(temp);
		}

		//convert to an array of Changes
		Change[] changes = new Change[changeList.size()];
		for (int i=0; i<changes.length;i++) {
			changes[i] = (Change) changeList.get(i);
		}

		return changes;
	}

	public SortedSet loadTitles() {
		File[] files = WIKI_DIR.listFiles(TEXT_FILTER);
		
		SortedSet set = new TreeSet();
		int directoryNameLength = WIKI_DIR_NAME.length();
		for (int i=0; i<files.length; i++) {
			String temp = files[i].toString();
			int titleLength = temp.length() - TEXT_EXTENSION_LENGTH;
			
			//we only want the title not including the wiki directory or file extension
			String title = temp.substring(directoryNameLength, titleLength);
			set.add(title);
		}
		return set;
	}
	
	static class TextFilter implements FilenameFilter {
		public boolean accept(File file, String name) {
			return name.endsWith(".txt");
		}
	}
}
