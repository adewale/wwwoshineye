package com.oshineye.kwikwiki.command;

import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.HashMap;

public abstract class Command {
	
	private static final String PACKAGE_NAME = "com.oshineye.kwikwiki.command.";
	protected static final String INVALID_TITLE = "/invalidTitle.jsp";
	protected static final String ERROR = "/error.jsp";
	protected static final String EDIT = "/editTemplate.jsp";
	//~ private static HashMap classes = new HashMap();
	private static HashMap preloadedClasses = new HashMap();
		
	static {
		try {
			preloadedClasses.put("View", Class.forName("com.oshineye.kwikwiki.command.View"));
			preloadedClasses.put("Edit", Class.forName("com.oshineye.kwikwiki.command.Edit"));
			preloadedClasses.put("Save", Class.forName("com.oshineye.kwikwiki.command.Save"));
			preloadedClasses.put("Create", Class.forName("com.oshineye.kwikwiki.command.Create"));
		} catch (Exception e) {
			e.printStackTrace(System.err);
		}
		
	}
	
	public static Command getCommand(String typeName) throws 
		ClassNotFoundException, InstantiationException, IllegalAccessException {
		Class classType = (Class)preloadedClasses.get(typeName);
		return (Command) classType.newInstance();
	}
	
	//~ public static Command getCommand(String typeName) throws 
		//~ ClassNotFoundException, InstantiationException, IllegalAccessException {
		//~ String fullTypeName = PACKAGE_NAME + typeName;
		//~ Class classType = Class.forName(fullTypeName);
		//~ return (Command) classType.newInstance();
	//~ }

	//~ public static Command getCachedCommandOriginal(String typeName) throws 
		//~ ClassNotFoundException, InstantiationException, IllegalAccessException {
		//~ if (!classes.containsKey(typeName)) {
			//~ String fullTypeName = PACKAGE_NAME + typeName;
			//~ Class classType = Class.forName(fullTypeName);
			//~ classes.put(typeName, classType);
		//~ }
		
		//~ Class classType = (Class)classes.get(typeName);
		//~ return (Command) classType.newInstance();
	//~ }
	
	protected void include(String resource, HttpServletRequest req,
						   HttpServletResponse resp, ServletContext sc) 
		throws IOException, ServletException {
		RequestDispatcher rd = sc.getRequestDispatcher(resource);
		rd.include(req, resp);
	}
	
	public abstract void execute(HttpServletRequest req, HttpServletResponse resp,
								 ServletContext sc) throws Exception;
}
