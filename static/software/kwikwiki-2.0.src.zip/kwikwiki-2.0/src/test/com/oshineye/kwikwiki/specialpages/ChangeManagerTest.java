package com.oshineye.kwikwiki.specialpages;

import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import junit.framework.TestCase;

import com.oshineye.kwikwiki.KwikWikiTestUtils;
import com.oshineye.kwikwiki.wikibase.Change;
import com.oshineye.kwikwiki.wikibase.ChangeLog;
import com.oshineye.kwikwiki.wikibase.WikiBase;

/**
 * @author aoshineye
 */
public class ChangeManagerTest extends TestCase {
	public void testChangeFiltering() {
		WikiBase wikiBase = WikiBase.getInstance();
		
		//first change
		wikiBase.savePage(KwikWikiTestUtils.createTestPage());
		
		//second change
		wikiBase.savePage(KwikWikiTestUtils.createTestPage());
		
		List logs = wikiBase.getChangeLogs(1);
		ChangeLog currentLog = (ChangeLog) logs.get(0);
		Collection changes = currentLog.getFilteredChanges();
		
		assertTrue(sameChangeDoesNotOccurTwice(changes));
	}

	/**
	 * @param changes
	 * @return boolean
	 */
	private boolean sameChangeDoesNotOccurTwice(Collection changes) {
		Set changeTitles = new HashSet();
		for (Iterator it = changes.iterator(); it.hasNext();) {
			Change change = (Change) it.next();
			if (changeTitles.contains(change.getTitle())) {
				return false;
			}
			changeTitles.add(change.getTitle());
		}
		
		return true;
	}
}
