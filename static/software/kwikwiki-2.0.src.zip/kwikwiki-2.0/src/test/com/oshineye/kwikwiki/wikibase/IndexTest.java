package com.oshineye.kwikwiki.wikibase;

import com.oshineye.kwikwiki.KwikWikiTestUtils;

import junit.framework.TestCase;

import java.util.Set;


public class IndexTest extends TestCase {
    public void testAdd() {
    }

    public void testGetLocations() {
    }

    public void testCaseInsensitiveSearching() {
        Index index = getIndexWithNewPage();

        //do a search for various mixed-case spellings
        Set locations1 = index.getLocationsCaseInsensitive("kwikwiki");
        Set locations2 = index.getLocationsCaseInsensitive("KwIkwIki");

        //assert that we find at least one mention of "kwikwiki"
        assertTrue(locations1.size() > 0);

        //assert that they all give the same results
        assertEquals("Case-insensitive search results differed", locations1, locations2);

        //assert that when we search for something case-insensitively we get at least as many
        //results back as if we search case-sensitively
        assertTrue(index.getLocations("KwikWiki").size() <= locations1.size());
    }

    private Index getIndexWithNewPage() {
        //create an index
        Index index = WikiBase.getInstance().getIndex();

        //add kwikwiki and KwikWiki to it
        WikiPage page = KwikWikiTestUtils.createTestPage();
        index.add(page.getTitle(), "kwikwiki");

        return index;
    }

    public void testUpdate() {
    }

    public void testGetAllWordsInWiki() {
    }

    public void testDelete() {
        Index index = getIndexWithNewPage();

        Set locationsAtBeginning = index.getLocations("kwikwiki");
        int numberOfLocationsAtStart = locationsAtBeginning.size();

        index.delete(KwikWikiTestUtils.createTestPage().getTitle(), "kwikwiki");

        Set locationsAtEnd = index.getLocations("kwikwiki");

        assertTrue(numberOfLocationsAtStart > 0);

        String msg = "The number of occurrences did not shrink after deletion";
        assertTrue(msg, numberOfLocationsAtStart > locationsAtEnd.size());
    }
}
