package com.oshineye.kwikwiki.specialpages;

import com.oshineye.kwikwiki.KwikWikiTestUtils;
import com.oshineye.kwikwiki.wikibase.WikiBase;

import junit.framework.TestCase;

import java.util.Iterator;
import java.util.SortedSet;


public class OrphanedPagesTest extends TestCase {
    public void testGetOrphanedPages() {
        WikiBase wikiBase = WikiBase.getInstance();
        wikiBase.savePage(KwikWikiTestUtils.createTestOrphanedPage());

        OrphanedPagesPage op = new OrphanedPagesPage();
        SortedSet pages = op.getOrphanedPages();
        assertNotNull(pages);
        assertTrue(pages.size() > 0);

        for (Iterator it = pages.iterator(); it.hasNext();) {
            String wikiName = (String) it.next();
            SortedSet wordLocations = wikiBase.locateWikiName(wikiName);

            assertTrue(wordLocations.size() == 0);
            assertTrue(wikiBase.pageExists(wikiName));

            String msg = "Found in the set of orphaned pages a SpecialPage::" + wikiName;
            assertFalse(msg, PageFactory.isSpecialPage(wikiName));
        }

        assertNotNull(op.getText());
    }
}
