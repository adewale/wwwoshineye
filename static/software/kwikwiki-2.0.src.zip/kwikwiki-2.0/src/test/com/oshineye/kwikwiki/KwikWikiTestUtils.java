package com.oshineye.kwikwiki;

import com.oshineye.kwikwiki.wikibase.WikiPage;

import java.util.Date;


public class KwikWikiTestUtils {
    public static WikiPage createTestPage() {
        //the newline is essential when creating pages by hand in this way.
        WikiPage page = new WikiPage("KwikWikiTestingTestPage",
                "This page exists for testing purposes only at:: " + new Date() + "\n" +
                ". It contains a deliberately missing page. Known as " +
                "PleaseDoNotCreateThisPageAsItIsUsedForTesting.\n", new Date(), "testUser");

        return page;
    }

    public static WikiPage createTestOrphanedPage() {
        WikiPage page = new WikiPage("KwikWikiTestingTestPageThatIsNotMeantToBeLinkedTo", "",
                new Date(), "testUser");

        return page;
    }

	public static WikiPage createStartingPoints() {
		WikiPage page = new WikiPage("StartingPoints", "Default StartingPoints page\n",
			new Date(), "testUser");
		return page;
	}
}
