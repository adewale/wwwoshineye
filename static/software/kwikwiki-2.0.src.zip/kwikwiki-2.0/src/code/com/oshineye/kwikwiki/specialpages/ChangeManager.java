/*
 * An abstract super class for pages which manipulate changes.
 */
package com.oshineye.kwikwiki.specialpages;

import java.util.List;
import java.util.ListIterator;

import com.oshineye.kwikwiki.config.Config;
import com.oshineye.kwikwiki.markup.MarkUpEngine;
import com.oshineye.kwikwiki.wikibase.ChangeLog;
import com.oshineye.kwikwiki.wikibase.WikiBase;

/**
 * @author aoshineye
 */
public abstract class ChangeManager {
	protected abstract int getNumberOfChanges();
	
	public String getText() {
		List logs = WikiBase.getInstance().getChangeLogs(this.getNumberOfChanges());

		StringBuffer sb = new StringBuffer();

		//go through logs in reverse chronological order
		for (ListIterator it = logs.listIterator(logs.size()); it.hasPrevious();) {
			ChangeLog currentLog = (ChangeLog) it.previous(); 
			List changes = currentLog.getFilteredChanges();
			sb.append(MarkUpEngine.convertToBold(currentLog.getDay()) + Config.LINE_ENDING);
			sb.append(MarkUpEngine.convertChanges(changes));
		}

		return sb.toString();
	}
}
