package com.oshineye.kwikwiki.wikibase;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileFilter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.FilenameFilter;
import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.SortedSet;
import java.util.TreeSet;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.oshineye.kwikwiki.TunnellingException;
import com.oshineye.kwikwiki.config.Config;

/**
 * A WikiBase back-end implementation which stores WikiPages and Changes in a file system.
 */
public class FileBase extends WikiBase {
	private static final String FILE_SEPARATOR = System.getProperty("file.separator");
	private static final String WIKI_DIR_NAME =
		System.getProperty("user.home") + FILE_SEPARATOR + "kwikwiki-data" + FILE_SEPARATOR;
	private static final File WIKI_DIR = new File(WIKI_DIR_NAME);
	private static final String METADATA_DIR_NAME =	WIKI_DIR_NAME + FILE_SEPARATOR + "metadata" 
		+ FILE_SEPARATOR;
	private static final String CHANGES_DIR_NAME =
		METADATA_DIR_NAME + FILE_SEPARATOR + "changelogs" + FILE_SEPARATOR;
	private static final File CHANGES_DIR = new File(CHANGES_DIR_NAME);
	private static final String HISTORY_DIR_NAME =
		METADATA_DIR_NAME + FILE_SEPARATOR + "history" + FILE_SEPARATOR;
	private static final File HISTORY_DIR = new File(HISTORY_DIR_NAME);
	private static final String REVISION_HISTORY_FILE_NAME = "revisions.txt";
	private static final TextFilter TEXT_FILTER = new TextFilter();
	private static final String TEXT_EXTENSION = ".txt";
	private static final int TEXT_EXTENSION_LENGTH = 4; //includes the dot
	
	private final IdGenerator idGenerator;

	public FileBase() {
		this.idGenerator = new IdGenerator(getCurrentRevisions());
	}

	private Map getCurrentRevisions() {
		File[] revisionDirs = HISTORY_DIR.listFiles(new FileFilter() {
			public boolean accept(File file) {
				return file.isDirectory();
			}
		});
		
		Map revisions = new HashMap();
		for (int i = 0; i < revisionDirs.length; i++) {
			File revisionsFile = new File(revisionDirs[i], REVISION_HISTORY_FILE_NAME);
			if (!revisionsFile.exists()) {
				continue;
			}
			
			String line = getLastLine(revisionsFile);
			
			Pattern pattern = Pattern.compile("(.*,id:(.*),)");
			Matcher matcher = pattern.matcher(line);
			if (matcher.find()) {
				int id = Integer.parseInt(matcher.group(2));
				revisions.put(revisionDirs[i].getName(), new Integer(id));
			}
		}
		return revisions;
	}

	private String getLastLine(File file) {
			String line = null;
			List lines = this.readLines(file);
			int linesSize = lines.size(); 
			if (linesSize > 0) {
				line = (String) lines.get(linesSize-1);
			}
			return line + "";//always return a valid string
	}

	protected SortedSet loadTitles() {
		File[] files = WIKI_DIR.listFiles(TEXT_FILTER);

		SortedSet set = new TreeSet();
		int directoryNameLength = WIKI_DIR_NAME.length();

		for (int i = 0; i < files.length; i++) {
			String temp = files[i].toString();
			int titleLength = temp.length() - TEXT_EXTENSION_LENGTH;

			//we only want the title not including the wiki directory or file extension
			String title = temp.substring(directoryNameLength, titleLength);
			set.add(title);
		}

		return set;
	}

	/**
	* TextFilter only accepts files with names that end in ".txt".
	* A FilenameFilter was used rather than a FileFilter to avoid the ovehead
	* of creating a File object for each file in the directory that will be
	* filtered. This has the side-effect that the <code>file</code> argument is
	* completely redundant.
	*/
	static class TextFilter implements FilenameFilter {
		public boolean accept(File file, String name) {
			return name.endsWith(".txt");
		}
	}

	public void deletePage(String title) {
		File file = new File(WIKI_DIR_NAME + title + TEXT_EXTENSION);

		if (file.exists()) {
			getIndex().delete(title, this.readText(file).toString());

			//delete the file
			file.delete();
		}
	}

	public WikiPage loadPage(String title) {
		File file = new File(WIKI_DIR_NAME + title + TEXT_EXTENSION);

		return convertFileToWikiPage(title, file);
	}

	private WikiPage convertFileToWikiPage(String title, File file) {
		if (!file.exists()) {
			return null;
		}
		CharSequence rawText = this.readText(file);
		return new WikiPage(title, rawText.toString(), file.lastModified());
	}

	protected void storePage(WikiPage rawPage) {
		String title = rawPage.getTitle();
		String newText = rawPage.getText();

		//1 argument constructor chosen for performance
		File file = new File(WIKI_DIR_NAME + title + TEXT_EXTENSION);

		this.writeText(file, newText, false);
	}

	protected void storeNewPage(WikiPage rawPage) {
		this.storePage(rawPage);
	}

	protected void storeChange(Change change) {
		//1 argument constructor chosen for performance
		File file = new File(CHANGES_DIR_NAME + change.getDay() + TEXT_EXTENSION);

		String newChangeLine = Config.LINE_ENDING + change.convertToString();

		writeText(file, newChangeLine, true);
	}

	public List getChangeLogs(int numberOfDays) {
		//load all the names of all the changelog files
		String[] changeLogFiles = CHANGES_DIR.list();
		int numberOfLogs = changeLogFiles.length;

		Date[] times = convertToDates(changeLogFiles);

		//sort the names by time
		Arrays.sort(times);

		List logs = new ArrayList();
		int startingIndex = numberOfLogs - numberOfDays;
		if (startingIndex < 0) {//numberOfDays > numberOfLogs
			startingIndex = 0;
		}
		
		//create ChangeLog objects representing the last numberOfDays days
		for (int i = startingIndex; i < numberOfLogs; i++) {
			String currentDay = Change.formatChangeDate(times[i]);
			File currentChangeFile = new File(CHANGES_DIR_NAME + currentDay + TEXT_EXTENSION);
			logs.add(new ChangeLog(parseChanges(readLines(currentChangeFile))));
		}

		return logs;
	}

	public List getRevisions(String title) {
		File parentDir = new File(HISTORY_DIR, title);
		if (!parentDir.exists()) {
			return Collections.EMPTY_LIST;
		}

		File revisionsFile = new File(parentDir, REVISION_HISTORY_FILE_NAME);
		List revisions = this.parseRevisions(this.readLines(revisionsFile));
		
		Collections.sort(revisions, new Comparator() {
			//sort revisions in descending order of id
			public int compare(Object o1, Object o2) {
				Revision r1 = (Revision) o1;
				Revision r2 = (Revision) o2;
						
				if (r1.getId() < r2.getId()) {
					return 1;
				} else  if (r1.getId() > r2.getId()) {
					return -1;
				} else {
					return 0;
				}
			}
		});
		return revisions;
	}

	protected void storeRevision(WikiPage rawPage) {
		String title = rawPage.getTitle();
		File parentDir = new File(HISTORY_DIR, title);
		int revisionId = this.idGenerator.next(title);
		File historicalFile = new File(parentDir, revisionId + TEXT_EXTENSION);

		//ensure directory structure exists
		parentDir.mkdirs();

		this.writeText(historicalFile, rawPage.getText(), false);
		
		//1 argument constructor chosen for performance
		File revisionFile = new File(parentDir, REVISION_HISTORY_FILE_NAME);

		String newRevisionLine = Config.LINE_ENDING 
			+ new Revision(rawPage, revisionId).convertToString();

		writeText(revisionFile, newRevisionLine, true);
	}

	public WikiPage loadPage(String title, int revisionId) {
		File parentDir = new File(HISTORY_DIR, title);
		File file = new File(parentDir, revisionId + TEXT_EXTENSION);
		CharSequence text = this.readText(file);
		List lines = this.readLines(new File(parentDir, REVISION_HISTORY_FILE_NAME));
		
		String revisionLine = (String) lines.get(revisionId-1);//revisions start from 1
		Revision revision = Revision.createRevisionFromString(revisionLine);
		return new WikiPage(title, text.toString(), revision.getDate(), revision.getEditor());
	}

	private void writeText(File file, CharSequence text, boolean shouldAppend) {
		BufferedWriter bw;

		try {
			bw = new BufferedWriter(new FileWriter(file, shouldAppend));
			bw.write(text.toString());
			bw.close();
		} catch (IOException ioe) {
			throw new TunnellingException(ioe);
		}
	}

	private CharSequence readText(File file) {
		/*
		potential exists for performance optimisation by specifying buffer
		sizes for the BufferedReader and StringBuffer based on the file's
		length. Although that might lead to problems with very large files.
		*/
		try {
			BufferedReader br = new BufferedReader(new FileReader(file));
			StringBuffer sb = new StringBuffer();

			String line;
			while ((line = br.readLine()) != null) {
				sb.append(line);
				sb.append(Config.LINE_ENDING); //avoid concatenation penalty
			}

			br.close();

			return sb;
		} catch (IOException ioe) {
			throw new TunnellingException(ioe);
		}
	}

	private List readLines(File file) {
		try {
			List lines = new ArrayList();
			BufferedReader br = new BufferedReader(new FileReader(file));
	
			String line;
			while ((line = br.readLine()) != null) {
				lines.add(line);
			}
	
			br.close();
	
			return lines;
		} catch (IOException ioe) {
			throw new TunnellingException(ioe);
		}
	}
	
	private Date[] convertToDates(String[] fileNames) {
		int numberOfLogs = fileNames.length;

		//convert the names to dates
		Date[] times = new Date[numberOfLogs];

		try {
			for (int i = 0; i < numberOfLogs; i++) {
				String currentName = fileNames[i];
				int nameLength = currentName.length() - TEXT_EXTENSION_LENGTH;
				String temp = currentName.substring(0, nameLength);
				times[i] = Change.parseChangeDay(temp);
			}
		} catch (ParseException pe) {
			throw new TunnellingException(pe);
		}

		return times;
	}

	private List parseChanges(List changeLines) {
		List changes = new ArrayList();
		for (Iterator it = changeLines.iterator(); it.hasNext();) {
			String line = (String) it.next();
			if (!line.trim().equals("")) {
				changes.add(Change.createChangeFromString(line));
			}
		}
		return changes;
	}

	private List parseRevisions(List revisionLines) {
		List revisions = new ArrayList();
		for (Iterator it = revisionLines.iterator(); it.hasNext();) {
			String line = (String) it.next();
			if (!line.trim().equals("")) {
				revisions.add(Revision.createRevisionFromString(line));
			}
		}
		return revisions;
	}
	
	/**
	 * @author aoshineye
	 *
	 * A thread-safe id generator based on the StaticCounter example from Doug Lea's
	 * Concurrent programming in Java 2nd edition, page 86
	 */
	private class IdGenerator {
		private Map idMap;
		
		public IdGenerator(Map currentRevisionIds) {
			this.idMap = new HashMap(currentRevisionIds);
		}
		
		public synchronized int next(String title) {
			int idNumber;
			Integer idObject = (Integer) idMap.get(title);
			if (idObject == null) {
				idNumber = 0;
			} else {
				idNumber = idObject.intValue();
			}
			idNumber++;
			idMap.put(title, new Integer(idNumber));
			return idNumber;
		}
	}
}
