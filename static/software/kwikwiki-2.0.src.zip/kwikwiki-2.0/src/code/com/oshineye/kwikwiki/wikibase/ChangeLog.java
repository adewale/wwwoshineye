package com.oshineye.kwikwiki.wikibase;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

/**
 * A representation of all the changes that happened on a particular day.
 */
public class ChangeLog {
	//format is Thursday 30 May 2002
	private static final SimpleDateFormat DAY_FORMATTER = new SimpleDateFormat("EEEE dd MMMM yyyy");
	private static final ChangeComparator CHANGE_COMPARATOR = new ChangeComparator();
	private final String day;
	private final List changes;

	/**
	* @param changes A list of Change objects for a particular day. This
	* list must have at least one element. Days without changes can't have ChangeLogs.
	*
	*/
	public ChangeLog(List changes) {
		//sort the changes in ascending order, earliest first
		Collections.sort(changes, CHANGE_COMPARATOR);
		this.changes = changes;
		Change firstDay = (Change) this.changes.get(0);
		this.day = DAY_FORMATTER.format(firstDay.getDate());
	}

	public String getDay() {
		return this.day;
	}

	public List getChanges() {
		return this.changes;
	}

	public List getFilteredChanges() {
		Map filteredChanges = new HashMap();
		for (Iterator it = this.changes.iterator(); it.hasNext();) {
			Change change = (Change) it.next();
			String title = change.getTitle();
			if (filteredChanges.containsKey(title)) {
				Change existingChange = (Change) filteredChanges.get(title);
				if (existingChange.getDate().before(change.getDate())) {
					filteredChanges.put(title, change);
				}
			} else {
				filteredChanges.put(title, change);
			}

		}
		return extractValues(filteredChanges);
	}

	private List extractValues(Map filteredChanges) {
		List resultingChanges = new ArrayList();
		
		for (Iterator it = filteredChanges.keySet().iterator(); it.hasNext();) {
			resultingChanges.add(filteredChanges.get(it.next()));
		}
		Collections.sort(resultingChanges, CHANGE_COMPARATOR);
		return resultingChanges;
	}

	static class ChangeComparator implements Comparator {
		public int compare(Object obj1, Object obj2) {
			Change c1 = (Change) obj1;
			Change c2 = (Change) obj2;

			int result = c1.compareTo(c2);

			//flip the results
			if (result < 0) {
				return 1;
			} else if (result == 0) {
				return 0;
			} else {
				return -1;
			}
		}
	}
}
