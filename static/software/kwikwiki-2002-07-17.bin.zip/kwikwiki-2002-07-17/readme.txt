KwikWiki
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
KwikWiki is an implementation of Ward Cunningham's WikiWiki idea. In other
words it is a web-based collaborative hypertext environment. 
It's written in Java and makes us of features from Java 1.4 such as regular
expressions. The author is Adewale Oshineye.

I can be reached via my website at www.oshineye.com.

The website for KwikWiki itself is at:
http://www.oshineye.com/software/kwikwiki.html

New builds tend to go up when there's been some change worth sharing.

KwikWiki is deliberately designed to use new technologies, such as Java 
1.4, Servlets 2.3 and lots of CSS2. Good free implementations are available
if you need them. Sun's JDK1.4, Jakarta Tomcat and Mozilla are all you need.

If that's unacceptable then I suggest taking a look at either MoinMoin or
Gareth Cronin's VeryQuickWiki.


Installation instructions
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Before installing make sure you have installed and properly
configured: 
An app server/servlet engine such as Tomcat or BEA
Weblogic. I've tested KwikWiki on Tomcat 4.0.2 (under Windows and
Linux), Weblogic 6.1 (SP1 and SP2 under Windows 2000) and Weblogic 7.0
(under Windows 2000).  Java 1.4


Unzip the file you downloaded. If you downloaded the binary version
then you will have a war file. Deploy that to your app-server using
whatever technique you feel is appropriate. That may involve copying
the war across to a deployment directory or using some kind of GUI
tool.

After deploying the war file, copy across the docs/kwikwiki-data
folder to your home directory. This is the same as the standard java
property user.home.  Unix users can just copy it to ~/yourUserName.
Windows users will have more problems. 
On Windows 2000 your home directory is C:\Documents and Settings\yourUserName\.
On Windows NT your home directory is C:\WINNT\profiles\yourUserName\


Start a web browser and visit:
http://yourServerName:yourPort/kwikwiki/View?title=StartingPoints

Enjoy


Design and implementation questions
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Q:	What packages were used to produce the UML diagrams?
A:	Dia (http://www.lysator.liu.se/~alla/dia) was used to create the .dia file 
and the png version. ArgoUML 0.10.0 (http://www.ArgoUML.org) was used to auto-
generate the .zargo file from the source code. They're both free, open source, 
cross-platform tools.
