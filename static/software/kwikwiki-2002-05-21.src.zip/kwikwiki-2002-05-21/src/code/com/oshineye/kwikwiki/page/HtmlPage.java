package com.oshineye.kwikwiki.page;

import com.oshineye.kwikwiki.markup.MarkUpEngine;
import java.util.Date;

public class HtmlPage extends Page {
	private String lastEdited;

	public HtmlPage() {
	}
	
	public HtmlPage(RawPage rawPage) {
		this.setTitle(rawPage.getTitle());
		
		String tempText = rawPage.getText();
		this.setText(MarkUpEngine.convertToHtml(tempText));
		
		Date date = rawPage.getDate();
		if (date == null) {
			this.lastEdited = "Unknown time";
		} else {
			this.lastEdited = date.toString();
		}
	}
	
	public String getLastEdited() {
		return lastEdited;
	}

}
