package com.oshineye.kwikwiki.markup;

import java.util.regex.Pattern;

/**
A class that encapsulates a pairing of a regular expression pattern and the text that 
should replace it. Taken together these form a markup rule that defines the 
meaning of the language used on a wiki page.
*/
public class MarkUpRule {
	private Pattern pattern;
	private String replacementText;
	
	public MarkUpRule(String regularExpression, String replacementText) {
		this.pattern = Pattern.compile(regularExpression);
		this.replacementText = replacementText;
	}

	/**
	Construct a MarkUpRule and specify which of the modes defined in the 
	Pattern class as a constant should be used.
	*/
	public MarkUpRule(String regularExpression, String replacementText, int mode) {
		this.pattern = Pattern.compile(regularExpression, mode);
		this.replacementText = replacementText;
	}

	public Pattern getPattern() {
		return this.pattern;
	}
	
	public String getReplacementText() {
		return this.replacementText;
	}
}