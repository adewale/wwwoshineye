package com.oshineye.kwikwiki.page;

import java.util.Date;

/**
A class that represent a page's raw unformatted data.
It also keeps track of when it was created.
This class fulfills all the criteria to be a JavaBean.
*/
public class RawPage extends Page {
	private Date date;

	public RawPage() {
	}
	
	public RawPage(String title, String text) {
		this(title, text, new Date());
	}
	
	public RawPage(String title, String text, Date date) {
		super(title, text);
		this.date = date;
	}

	public Date getDate() {
		return this.date;
	}

}
