package com.oshineye.kwikwiki.wikibase;

import com.oshineye.kwikwiki.page.RawPage;
import java.util.Date;
import java.text.SimpleDateFormat;

public class Change {
	private static final SimpleDateFormat FORMATTER = new SimpleDateFormat("yyyy_MM_dd");
	private String title;
	private Date date;
	private String day;
	
	public Change(RawPage rawPage) {
		this.title = rawPage.getTitle();
		this.date = rawPage.getDate();
		
		if (date == null) {
			this.day = "";
		} else {
			this.day = FORMATTER.format(this.date);
		}
	}

	public Date getDate() {
		return this.date;
	}
	
	public String getDay() {
		return this.day;
	}
	
	public void setDate(Date date) {
		this.date = date;
	}
	
	public String getTitle() {
		return this.title;
	}
	
	public void setTitle(String title) {
		this.title = title;
	}

}